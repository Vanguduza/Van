"""Static signed-APK inspection, not installation, device performance or rig acceptance."""
from pathlib import Path
import hashlib,json,subprocess,zipfile,re,struct,time
root=Path.cwd();project=root/'source-checkout';work=root/'software-apk-inspection-final';work.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
build=json.loads((root/'software-apk-committed/RECEIPT.json').read_text())
assert build['status']=='DEBUG_APK_ASSEMBLED' and build['inputs_unchanged'] and build['head']=='d78368f2df1426a124072e7e04d703327f229ccd'
apk=project/'android/app/build/outputs/apk/debug/app-debug.apk';assert sha(apk)==build['apk_sha256']
checks=[]
def verified(name,value):
 assert value,name
 checks.append({'check':name,'passed':True})
log=work/'signature-verification.log'
with log.open('w') as out:r=subprocess.run([str(root/'android-sdk/build-tools/35.0.0/apksigner'),'verify','--verbose','--print-certs',str(apk)],stdout=out,stderr=subprocess.STDOUT,timeout=120)
verified('Original SDK apksigner verifies the generated debug signature',r.returncode==0)
signature=log.read_text();cert=re.search(r'certificate SHA-256 digest: ([0-9a-f]+)',signature);verified('Signing certificate digest recorded without sharing a private key',cert is not None)
with zipfile.ZipFile(apk) as z:
 names=z.namelist();verified('APK ZIP members are unique',len(names)==len(set(names)))
 verified('APK ZIP CRC validation passes',z.testzip() is None)
 provenance=json.loads(z.read('assets/van-build-provenance.json'))
 verified('Packaged source identity is the exact normal-hook source commit',provenance['source_sha']==build['head'])
 original=(project/'android/voice/voice_asset_manifest.json').read_bytes();actual=z.read('assets/voice/voice_asset_manifest.json')
 verified('Actual APK voice manifest is byte-identical to the unchanged source lock',actual==original)
 voice=json.loads(actual);verified('No owner voice profile is included',voice['owner_profile_included'] is False)
 hashed=[]
 for f in voice['files']:
  target='assets/voice/bundle/'+f['path'];digest=hashlib.sha256();count=0
  with z.open(target) as stream:
   while block:=stream.read(1024*1024):digest.update(block);count+=len(block)
  verified('Voice model exact bytes '+f['path'],count==f['size'] and digest.hexdigest()==f['sha256'])
  hashed.append({'path':target,'bytes':count,'sha256':digest.hexdigest()})
 libraries=sorted(n for n in names if n.startswith('lib/') and n.endswith('.so'))
 for name in ['librive-android.so','libsherpa-onnx-jni.so','libonnxruntime.so','libjingle_peerconnection_so.so']:
  verified('Native arm64 runtime present '+name,'lib/arm64-v8a/'+name in libraries)
 verified('Unadmitted prototype not silently promoted to main APK', 'assets/van.riv' not in names and 'assets/van_candidate.riv' not in names)
 verified('Unadmitted contextual metadata not silently activated', 'assets/van.context.json' not in names and 'assets/van_candidate.context.json' not in names)
 classes=set();dex_files=[]
 for name in names:
  if not re.fullmatch(r'classes\d*\.dex',name):continue
  raw=z.read(name);verified('Genuine DEX magic '+name,raw.startswith(b'dex\n'))
  string_count,string_offset=struct.unpack_from('<II',raw,56);type_count,type_offset=struct.unpack_from('<II',raw,64);class_count,class_offset=struct.unpack_from('<II',raw,96)
  def text(index):
   assert index<string_count
   position=struct.unpack_from('<I',raw,string_offset+index*4)[0]
   for _ in range(5):
    byte=raw[position];position+=1
    if byte<128:break
   return raw[position:raw.index(0,position)].decode('utf-8',errors='strict')
  for i in range(class_count):
   index=struct.unpack_from('<I',raw,class_offset+i*32)[0];assert index<type_count
   descriptor=struct.unpack_from('<I',raw,type_offset+index*4)[0];classes.add(text(descriptor))
  dex_files.append({'path':name,'classes':class_count,'sha256':hashlib.sha256(raw).hexdigest()})
 expected=['overlay/OverlaySessionRuntime','overlay/OverlaySnapshotOwnership','overlay/OverlayPersonalControlsKt','overlay/OverlayPrivacyVisibility','visual/VanBoundedRiveView','visual/VanRiveContextCapabilities','visual/VanRiveUpdateGate','visual/RiveCandidateHostActivity','visual/CharacterRigLabKt','visual/ForgePreviewView','voice/PcmPlaybackVisualClock','visual/VanNativeScreenContext']
 for suffix in expected:verified('Compiled current hardening class '+suffix,'Lcom/dial/van/'+suffix+';' in classes)
receipt={'status':'SIGNED_DEBUG_APK_STATIC_INSPECTION_PASSED','source_commit':build['head'],'apk_path':str(apk),'apk_sha256':sha(apk),'apk_bytes':apk.stat().st_size,'certificate_sha256':cert.group(1),'signature_verification_exit':r.returncode,'signature_log_sha256':sha(log),'checks':checks,'check_count':len(checks),'native_libraries':libraries,'voice_files':hashed,'voice_total_bytes':sum(f['bytes'] for f in hashed),'dex_files':dex_files,'compiled_class_count':len(classes),'build_provenance':provenance,'native_prototype_qualified':False,'renderer_in_apk':'existing admitted fallback; refined Rive kept as separate unadmitted source candidate','installed':False,'physical_tests':'DEFERRED_FINAL_STAGE','signing_type':'debug candidate, not release acceptance'}
(work/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['checks','native_libraries','voice_files','dex_files','build_provenance']},indent=2),flush=True)
