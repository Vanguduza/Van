from pathlib import Path
import os,json,hashlib,subprocess,time
root=Path.cwd();project=root/'source-checkout';work=root/'software-instrumentation-package';work.mkdir(exist_ok=False)
prep=json.loads((root/'PREPARED_BUILD_RECEIPT.json').read_text());assert prep['source_overlay_verified']
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
inputs={str(p.relative_to(project)):sha(p) for p in sorted((project/'android').rglob('*')) if p.is_file() and '/build/' not in str(p) and '/.gradle/' not in str(p) and '/.kotlin/' not in str(p) and p.suffix in ['.kt','.kts','.java','.xml','.json','.properties']}
env=os.environ.copy();env['GRADLE_USER_HOME']=str(root/'gradle-home');env['ANDROID_HOME']=str(root/'android-sdk');env['ANDROID_SDK_ROOT']=str(root/'android-sdk')
cmd=['./gradlew',':app:assembleDebugAndroidTest','--no-daemon','--max-workers=1','-Pkotlin.compiler.execution.strategy=in-process','-Pandroid.aapt2FromMavenOverride='+str(root/'compatibility/bin/aapt2'),'-Dorg.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=384m -XX:ActiveProcessorCount=1 -Dfile.encoding=UTF-8']
log=work/'gradle.log';started=time.monotonic()
try:
 with log.open('w') as out:r=subprocess.run(cmd,cwd=project/'android',env=env,stdout=out,stderr=subprocess.STDOUT,timeout=1200)
 code=r.returncode
except subprocess.TimeoutExpired:code=124
apk=project/'android/app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'
receipt={'scope':'Original Gradle instrumentation APK assembly ONLY; no test execution or device connection with unchanged declared dependency versions and original configured repositories; cache miss lifecycle-common-java8:2.8.7 acquired by Gradle. Original aapt2 via user-mode ARM/x86 transport. No task exclusion, production asset promotion, installation or physical test.','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip(),'input_sha256':inputs,'inputs_unchanged':all(sha(project/p)==h for p,h in inputs.items()),'exit_code':code,'seconds':round(time.monotonic()-started,2),'log_sha256':sha(log),'apk_present':apk.is_file(),'apk_sha256':sha(apk) if apk.is_file() else None,'apk_bytes':apk.stat().st_size if apk.is_file() else 0,'physical_test':False}
receipt['status']='INSTRUMENTATION_APK_ASSEMBLED_NOT_EXECUTED' if code==0 and apk.is_file() and receipt['inputs_unchanged'] else 'NOT_PASSED'
(work/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print('OFFLINE_APK',receipt['status'],'exit',code,'seconds',receipt['seconds'],'bytes',receipt['apk_bytes'],flush=True);print(log.read_text()[-20000:],flush=True)
raise SystemExit(code)
