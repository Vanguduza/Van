from pathlib import Path
import hashlib,json,subprocess,zipfile,re,struct
root=Path.cwd();work=root/'software-instrumentation-inspection';work.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
main=json.loads((root/'software-apk-inspection-final/RECEIPT.json').read_text());assert main['status']=='SIGNED_DEBUG_APK_STATIC_INSPECTION_PASSED'
build=json.loads((root/'software-instrumentation-package/RECEIPT.json').read_text());assert build['status']=='INSTRUMENTATION_APK_ASSEMBLED_NOT_EXECUTED' and build['inputs_unchanged']
main_file=Path(main['apk_path']);assert sha(main_file)==main['apk_sha256']
apk=root/'source-checkout/android/app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk';assert sha(apk)==build['apk_sha256']
log=work/'signature.log'
with log.open('w') as out:r=subprocess.run([str(root/'android-sdk/build-tools/35.0.0/apksigner'),'verify','--verbose','--print-certs',str(apk)],stdout=out,stderr=subprocess.STDOUT,timeout=60)
assert r.returncode==0
match=re.search(r'certificate SHA-256 digest: ([0-9a-f]+)',log.read_text());assert match and match.group(1)==main['certificate_sha256']
classes=set()
with zipfile.ZipFile(apk) as z:
 assert z.testzip() is None
 names=z.namelist();assert len(names)==len(set(names))
 for name in names:
  if not re.fullmatch(r'classes\d*\.dex',name):continue
  raw=z.read(name);assert raw.startswith(b'dex\n')
  sc,so=struct.unpack_from('<II',raw,56);tc,to=struct.unpack_from('<II',raw,64);cc,co=struct.unpack_from('<II',raw,96)
  def text(index):
   assert index<sc;pos=struct.unpack_from('<I',raw,so+index*4)[0]
   for _ in range(5):
    b=raw[pos];pos+=1
    if b<128:break
   return raw[pos:raw.index(0,pos)].decode('utf-8')
  for i in range(cc):
   ti=struct.unpack_from('<I',raw,co+i*32)[0];assert ti<tc
   classes.add(text(struct.unpack_from('<I',raw,to+ti*4)[0]))
 required=['PhysicalS24MotionPerformanceTest','RiveContractTest']
 for c in required:assert 'Lcom/dial/van/instrumentation/'+c+';' in classes,c
manifest=work/'manifest-badging.log'
with manifest.open('w') as out:r2=subprocess.run([str(root/'compatibility/bin/aapt2'),'dump','badging',str(apk)],stdout=out,stderr=subprocess.STDOUT,timeout=40)
assert r2.returncode==0
badging=manifest.read_text();assert "package: name='com.dial.van.test'" in badging
record={'status':'SIGNED_INSTRUMENTATION_APK_STATIC_CHECKED_NOT_EXECUTED','source_commit':build['head'],'apk_path':str(apk),'apk_sha256':sha(apk),'apk_bytes':apk.stat().st_size,'signature_verified':True,'same_debug_certificate_as_main':True,'certificate_sha256':match.group(1),'required_test_classes_present':required,'compiled_class_count':len(classes),'main_apk_unchanged_sha256':sha(main_file),'signature_log_sha256':sha(log),'manifest_log_sha256':sha(manifest),'test_execution':False,'device_connected_by_this_step':False,'installed':False,'physical_stage':'DEFERRED_FINAL_STAGE'}
(work/'RECEIPT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
