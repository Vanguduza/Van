package com.dial.van.preview

import com.dial.van.visual.*
import java.awt.Color
import java.awt.Font
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

/** Shared production planner and original Java2D executor; NOT a handset screenshot. */
fun main(args: Array<String>) {
    val out=File(args[0]).apply { mkdirs() }
    val frame = VanSceneFrame(presentation=VanPresentation.COMMAND_CENTRE)
    val silhouette=AwtVanRenderer.interimSilhouette(VanPresentation.COMMAND_CENTRE)
    val stateList=listOf(VanDurableState.IDLE,VanDurableState.WORKING,VanDurableState.ERROR)
    for(state in stateList) {
        val dir=File(out,state.name).apply {mkdirs()}
        val spec=VanAuraSpecs.forState(state)
        for(i in 0 until 48) {
            val elapsed=i*1_000_000_000L/12
            val phase=VanAuraMotionPhase.at(elapsed)
            val slow=(elapsed%23_700_000_000L).toFloat()/23_700_000_000f
            val image=BufferedImage(420,420,BufferedImage.TYPE_INT_RGB)
            val g=image.createGraphics();AwtVanRenderer.prepare(g)
            g.color=Color(0x07111B);g.fillRect(0,0,420,420)
            val ops=VanAuraPlanner.plan(spec,spec,210f,210f,128f,VanEffectBudget.FULL,
                phase,silhouette=silhouette,slowPhase=slow)
            check(ops.none { it is VanAuraOp.Rim || it is VanAuraOp.Polyline || it is VanAuraOp.Quad })
            GlassPainter.drawAuraOps(g,ops,VanAuraDepth.BACK)
            AwtVanRenderer.paintVan(g,VanVisualState(durableState=state),frame,82f,82f,256f,256f)
            GlassPainter.drawAuraOps(g,ops,VanAuraDepth.FRONT)
            g.color=Color(0xD2DFE8);g.font=Font(Font.SANS_SERIF,Font.PLAIN,12)
            g.drawString("${state.name} · shared native aura geometry",14,390)
            g.drawString("Source-render preview · not S24 capture",14,409)
            g.dispose();ImageIO.write(image,"png",File(dir,"%03d.png".format(i)))
        }
    }
    println("ACTUAL_SHARED_PLANNER_FRAMES 144")
}
