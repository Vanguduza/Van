from pathlib import Path
import hashlib,json,subprocess,time,os
root=Path.cwd();work=root/'.git/aura-workboard-20261105';out=work/'preview-classes';out.mkdir(exist_ok=True)
libs=json.loads((root/'.git/floating-r1/compiler-dependencies.json').read_text())
cp=os.pathsep.join([str(work/'pure/integration-classes')]+[x['path'] for x in libs])
sources=[root/'android/visual-preview/src/main/kotlin/com/dial/van/preview/GlassPainter.kt',root/'android/visual-preview/src/main/kotlin/com/dial/van/preview/AwtVanRenderer.kt',work/'AuraSourcePreview.kt']
frozen={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
base=['java','-Xmx256m','-XX:MaxMetaspaceSize=160m','-XX:ActiveProcessorCount=1','-Djava.awt.headless=true']
commands=[('compile',base+['-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-jvm-target','17','-d',str(out)]+[str(p) for p in sources]),('render',base+['-cp',str(out)+os.pathsep+cp,'com.dial.van.preview.AuraSourcePreviewKt',str(work/'source-motion')])]
rows=[]
for name,cmd in commands:
 log=work/(name+'-preview.log');start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append({'step':name,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,2),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 print(name,r.returncode,log.read_text()[-4500:],flush=True)
 if r.returncode:break
result={'scope':'Actual shipping pure Kotlin aura planner and original shared Java2D executor over original Candidate B fallback PNG. Not Compose/Android/S24 capture.','source_sha256':frozen,'steps':rows,'input_unchanged':all(hashlib.sha256((root/f).read_bytes()).hexdigest()==h for f,h in frozen.items()),'frame_count':len(list((work/'source-motion').rglob('*.png')))}
(work/'source-motion.receipt.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(0 if len(rows)==2 and all(r['exit_code']==0 for r in rows) else 1)
