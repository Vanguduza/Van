"""Long-running session service (Rev 5 Part F): `python -m vati serve --account <alias>`.

One process per account alias. It resolves the venue adapter and market feed
from the account registry, builds the same DecisionCycle the backtest uses,
runs startup reconciliation, then steps once per closed bar. Every bar also
writes an ACCOUNT_SNAPSHOT and MARKET_DATA_HEALTH event so the owner surface
reads portfolio truth from the ledger, never from memory. A heartbeat file is
refreshed each loop for the commander's status command. Stopping is graceful
on SIGTERM: open positions keep their venue stops; no new orders are placed."""

from __future__ import annotations

import json
import os
import signal
import time
import uuid
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Callable, Optional

from vati.accounts import Account, AccountRegistry, BrokerKind
from vati.app.cycle import DecisionCycle, SessionConfig
from vati.app.runner import SessionRunner
from vati.arbiter import OpportunityEngine
from vati.core.events import EventKind, make_event
from vati.core.ledger_pg import open_ledger
from vati.execution.base import VenueAdapter
from vati.execution.paper import PaperAdapter
from vati.intelligence.calendar_feed import build_matrix
from vati.market_data.bars import Bar
from vati.market_data.calendars import FX_CALENDAR
from vati.market_data.feeds.lake import TIMEFRAMES_MS, BarLake
from vati.learning.episodes import Environment
from vati.learning.hooks import LearningHooks
from vati.learning.replay import restore_learning_runtime
from vati.learning.runtime_cohort import execution_cohort_for
from vati.risk import AuthorizationMode, TradingMandate
from vati.risk.serde import contract_from_dict
from vati.strategies import STRATEGY_IMPLEMENTATIONS, CapsuleRegistry

ROOT = Path(__file__).resolve().parents[2]


@dataclass
class ServiceConfig:
    account_alias: str
    symbol: str
    base: str
    quote: str
    timeframe: str
    contract: dict
    mandate: dict
    capsules: list[str]
    #: Additional instruments activate the account-level coordinator runtime.
    #: Each mapping may override symbol/base/quote/timeframe/contract/capsules/cost.
    instruments: list[dict] = field(default_factory=list)
    round_trip_cost_pct: str = "0.0003"
    registry_path: str = "accounts.json"
    ledger: str = "vati.sqlite"
    lake_root: str = "lake"
    calendar_path: Optional[str] = None
    heartbeat_path: str = "heartbeat.json"
    capsule_dir: Optional[str] = None
    warmup_bars: int = 60
    max_quote_age_ms: int = 5000
    poll_seconds: float = 5.0
    activation_id: str = "vtil-act-unresolved"
    #: GAP-F-004. Shadow cognition's provider invoker, which had no injection
    #: point anywhere in production. Shape:
    #:
    #:   {"invoker": "none" | "http_json" | "hermes_run",
    #:    "endpoint": "...", "credential_ref": "secretref://cognition/primary#TOKEN",
    #:    "model_id": "...", "timeout_s": 20,
    #:    "research_budget_micros": 0}
    #:
    #: The default is `none`, so an existing deployment behaves exactly as it
    #: did: an explicit MODEL_UNAVAILABLE abstention and an untouched
    #: deterministic decision.
    cognition: dict = field(default_factory=dict)
    # Operator-admitted provider/model qualifications; packets cannot set these.
    cognitive_fabric: dict = field(default_factory=dict)
    #: Where `secretref://` credential handles resolve. Mirrors the gateway's
    #: `vati_secrets_dir`; the credential value itself is never configuration.
    secrets_dir: str = ""
    #: GAP-F-003. Headline ingress for active-trade intelligence. Shape:
    #:
    #:   {"path": "news.jsonl", "sources": [{"source_id": "...", "trust": "T1_PRIMARY"}],
    #:    "relevance_window_ms": 21600000}
    #:
    #: Empty means no news path, which is the behaviour before this existed.
    #: News is reduce-only wherever it lands; the economic calendar remains the
    #: blackout authority.
    news: dict = field(default_factory=dict)
    #: Native public owner keys, shared with Commander; no private signing key.
    owner_authority_keys: str = ""
    #: Internal lifecycle governance selection; no default admission or activation.
    lifecycle_policy_grant_id: str = ""
    lifecycle_policy_qualification_keys: str = ""
    #: Explicit simulator close capability; empty preserves continuous legacy closes.
    #: Entry constraints never supply a close grid.
    paper_close_contracts: dict = field(default_factory=dict)

    @classmethod
    def load(cls, path: str | Path) -> "ServiceConfig":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(**d)


#: P1-TRADE-008 — which learning environment a session's experience belongs to. Taken from
#: the mandate's authorization mode rather than assumed, so a demo session's episodes are
#: never pooled with a live one's; the two are not comparable evidence.
from vati.learning.scope import ENVIRONMENT_FOR_MODE


def paper_close_contracts_from_config(config):
    """The simulator enforces these explicit close contracts itself."""
    from vati.execution.paper import PaperCloseContract
    if not isinstance(config,dict):raise ValueError("paper close contracts must be a symbol mapping")
    result={}
    allowed={'quantity_quantum','partial_min','partial_max','minimum_remaining','revision'}
    for symbol,body in config.items():
        if (not isinstance(symbol,str) or not symbol or symbol!=symbol.upper() or not isinstance(body,dict)
                or set(body)-allowed or not {'quantity_quantum','revision'}<=set(body)):
            raise ValueError("explicit paper close capability schema/revision is invalid")
        values={key:(Decimal(str(value)) if key!='revision' and value is not None else value)
            for key,value in body.items()}
        result[symbol]=PaperCloseContract(**values)
    return result


def build_adapter(account: Account, registry: AccountRegistry, *, equity_hint: Decimal = Decimal("10000"), deriv_connector=None, symbol_contracts=None, paper_close_contracts=None) -> VenueAdapter:
    """Adapter from the account record. Credentials are resolved inside the transport and never returned."""
    from vati.accounts.access import bind_entry_authority
    def bound(adapter):
        return bind_entry_authority(adapter, registry, account)
    if account.broker == BrokerKind.PAPER:
        return bound(PaperAdapter(venue=account.router_venue, account_alias=account.alias, currency=account.currency,
            equity=equity_hint, symbol_contracts=symbol_contracts,
            close_contracts=paper_close_contracts_from_config(paper_close_contracts or {})))
    if paper_close_contracts:
        raise ValueError("paper close capability configuration cannot qualify a native adapter")
    if account.broker == BrokerKind.MT5:
        from vati.execution.mt5_identity import Mt5Identity
        identity = Mt5Identity.from_account(account)
        from vati.execution.mt5_bridge import Mt5BridgeAdapter, Mt5BridgeClient
        from vati.execution.transports.mt5_http import Mt5HttpTransport
        secrets = registry.credentials(account.alias)
        key = secrets.get("BRIDGE_SIGNING_KEY", "")
        if not key:
            raise RuntimeError(f"{account.alias}: BRIDGE_SIGNING_KEY missing from secrets")
        transport = Mt5HttpTransport(account.bridge_url, ca_file=secrets["BRIDGE_CA_FILE"], client_cert=secrets.get("BRIDGE_CLIENT_CERT"), client_key=secrets.get("BRIDGE_CLIENT_KEY"))
        return bound(Mt5BridgeAdapter(Mt5BridgeClient(signing_key=key.encode(), transport=transport), account_alias=account.alias, venue=account.router_venue,
            identity=identity))
    if account.broker == BrokerKind.DERIV:
        from vati.execution.deriv_identity import validate_deriv_endpoint
        validate_deriv_endpoint(account.bridge_url)
        from vati.execution.deriv import DerivAdapter
        from vati.execution.deriv_identity import DerivIdentity
        from vati.accounts.access import SENDING_MODES, entry_fence
        from vati.execution.transports.deriv_ws import DerivWebSocketTransport
        identity = DerivIdentity(account.login, account.currency, account.demo, account.mode in SENDING_MODES)
        transport = DerivWebSocketTransport(app_id=account.server or "1089", token_provider=lambda: registry.credentials(account.alias).get("DERIV_API_TOKEN") or registry.credentials(account.alias).get("TOKEN", ""),
                                            endpoint=account.bridge_url or "wss://ws.derivws.com/websockets/v3",
                                            identity=identity, entry_scope=lambda: entry_fence(registry, account),
                                            **({"connector": deriv_connector} if deriv_connector is not None else {}))
        return DerivAdapter(venue=account.router_venue, account_alias=account.alias, transport=transport,
                            identity=identity, entry_enabled=account.enabled and account.mode in SENDING_MODES)
    if account.broker == BrokerKind.CTRADER:
        from vati.execution.ctrader import CtraderAdapter, CtraderTransport
        secrets = registry.credentials(account.alias)
        for k in ("CTRADER_CLIENT_ID", "CTRADER_CLIENT_SECRET", "CTRADER_ACCESS_TOKEN"):
            if not secrets.get(k):
                raise RuntimeError(f"{account.alias}: {k} missing from secrets")
        from vati.accounts.physical_scope import ctrader_host
        host = ctrader_host(account)
        return bound(CtraderAdapter(CtraderTransport(host=host), client_id=secrets["CTRADER_CLIENT_ID"], client_secret_provider=lambda: registry.credentials(account.alias)["CTRADER_CLIENT_SECRET"],
                              access_token_provider=lambda: registry.credentials(account.alias)["CTRADER_ACCESS_TOKEN"], ctid_trader_account_id=int(account.login), account_alias=account.alias, venue=account.router_venue))
    if account.broker == BrokerKind.MT5_EA:
        from vati.execution.mt5_identity import Mt5Identity
        identity = Mt5Identity.from_account(account)
        from vati.execution.mt5_pull import Mt5PullAdapter, open_bridge_queue
        secrets = registry.credentials(account.alias)
        if not secrets.get("BRIDGE_SIGNING_KEY"):
            raise RuntimeError(f"{account.alias}: BRIDGE_SIGNING_KEY missing from secrets")
        return bound(Mt5PullAdapter(open_bridge_queue(secrets.get("BRIDGE_QUEUE", "")), account_alias=account.alias, venue=account.router_venue,
            identity=identity))
    if account.broker == BrokerKind.ZSE_OWNER_TICKET:
        from vati.execution.zse_ticket import OwnerTicketAdapter
        return bound(OwnerTicketAdapter(venue=account.router_venue, account_alias=account.alias,
            currency=account.currency, equity=equity_hint, csd_verified=False))
    raise RuntimeError(f"no adapter for broker {account.broker}")


@dataclass
class SessionService:
    cfg: ServiceConfig
    bar_source: Callable[[int], list[Bar]]          # now_ms → closed bars history (lake / feed)
    clock: Callable[[], int] = lambda: int(time.time() * 1000)
    adapter: Optional[VenueAdapter] = None
    stop_requested: bool = False
    cycles: int = 0
    last_bar_end_ms: int = 0
    runner: Optional[SessionRunner] = None
    #: GAP-F-003 headline ingress, built from `cfg.news`; None when unconfigured.
    news: object = None
    _ledger: object = None
    _started_ms: int = 0
    lease: object = None
    _lease_store: object = None
    _lease_allows_entry: bool = False
    _lease_outcome: str = "NOT_ACQUIRED"
    _entry_registry: object = None
    _entry_account: object = None

    def build(self) -> "SessionService":
        c = self.cfg
        registry = AccountRegistry(c.registry_path)
        account = registry.get(c.account_alias)
        self._entry_registry,self._entry_account=registry,account
        if not account.enabled:
            raise RuntimeError(f"account {account.alias} is disabled")
        mandate = TradingMandate.from_mapping(c.mandate)
        if mandate.temperament_enabled:
            raise RuntimeError("trading temperaments require AccountCoordinatorService; "
                               "single-symbol session refuses unsupported signed posture")
        from vati.accounts.access import validate_mode
        validate_mode(account, mandate.mode.value)
        if mandate.account_alias != account.alias:
            raise RuntimeError(f"mandate is signed for account {mandate.account_alias!r} but the session is for {account.alias!r}: refuse to start (every intent would be ACCOUNT_MISMATCH)")
        from vati.accounts.access import SENDING_MODES
        shared = str(c.ledger).startswith(("postgres://", "postgresql://"))
        if not shared and account.broker != BrokerKind.PAPER and mandate.mode.value in SENDING_MODES:
            raise RuntimeError("native venue entry requires the shared PostgreSQL VATI authority store; a local lease is not a cross-host fence")
        contract = contract_from_dict({**c.contract, "venue": account.router_venue})
        self.adapter = self.adapter or build_adapter(account, registry, symbol_contracts={c.symbol: contract}, paper_close_contracts=c.paper_close_contracts)
        if isinstance(self.adapter, PaperAdapter):
            self.adapter.bind_contracts({c.symbol: contract})
            if c.paper_close_contracts:
                self.adapter.bind_close_contracts(paper_close_contracts_from_config(c.paper_close_contracts))
        self._ledger = open_ledger(c.ledger)
        from vati.app.account_lease import PostgresLeaseStore
        from vati.app.physical_account_lease import build_runtime_lease
        from vati.app.sqlite_lease import SQLiteLeaseStore
        self._lease_store = PostgresLeaseStore(c.ledger) if shared else SQLiteLeaseStore(c.ledger)
        self.lease = build_runtime_lease(self._lease_store, account=account, mode=mandate.mode.value,
            instance_id=f"{os.uname().nodename}:{os.getpid()}:{uuid.uuid4().hex}",
            software_version="vati-single-session/1", git_sha=os.environ.get("VAN_GIT_SHA", ""))
        scfg = SessionConfig(symbol=c.symbol, base=c.base, quote=c.quote, venue=account.router_venue, account_alias=account.alias, contract=contract, mandate_dict=c.mandate, timeframe=c.timeframe,
                             warmup_bars=c.warmup_bars, max_quote_age_ms=c.max_quote_age_ms, session_id=f"{account.alias}:{c.symbol}:{int(self.clock())}", activation_id=c.activation_id,
                             software_stops=account.broker == BrokerKind.ZSE_OWNER_TICKET)
        reg = CapsuleRegistry.load_dir(c.capsule_dir or ROOT / "strategies" / "registry")
        impl = {sid: STRATEGY_IMPLEMENTATIONS[sid.rsplit("-", 1)[0]](strategy_id=sid) for sid in c.capsules}
        engine = OpportunityEngine(reg, impl, mandate)
        cost = Decimal(c.round_trip_cost_pct)
        # P1-TRADE-008 — `learning` was never passed here, so capsule-health demotion,
        # broker-liquidity learning and experience artefacts existed only in backtests.
        # Bind actual adapter provenance as well as the policy ceiling: a Paper
        # account configured with a live policy still supplies simulated facts.
        #
        # This is safe to wire because the effects it can have are already bounded: the
        # LearningBoundary permits reduce-only adjustments, and a demotion moves a capsule
        # towards SHADOW or DEGRADED, never towards more authority. That boundary is what
        # made this a wiring job rather than a design one.
        learning = LearningHooks(
            environment=execution_cohort_for(self.adapter, mandate.mode).environment,
            account_alias=account.alias,
            broker=str(getattr(account.broker, "value", account.broker)).lower(),
        )
        self.learning_replay = restore_learning_runtime(
            self._ledger, learning, {c.symbol.upper(): engine})
        cycle = DecisionCycle(cfg=scfg, adapter=self.adapter, ledger=self._ledger, engine=engine, cost_fn=lambda st: cost, calendar=FX_CALENDAR, events=build_matrix(c.calendar_path), learning=learning,
            runtime_lease=self.lease, lease_clock=self.clock, lease_permission=self._entry_permitted)
        # GAP-F-003. The single-symbol runtime gets the same headline ingress the
        # account runtime has, so backtest-to-live parity covers the thesis and
        # event path rather than only the order path. No `news` block in the
        # config means no news path at all — the behaviour before this existed.
        cycle.news = self._build_news()
        self.news = cycle.news
        self.learning = learning
        self.runner = SessionRunner(cycle)
        return self

    def _build_news(self):
        """Headline ingress from `cfg.news`, or None. Reduce-only everywhere."""
        from vati.events.news_runtime import build_news_file
        return build_news_file(getattr(self.cfg,'news',None) or {},ledger=self._ledger,
            scope=f'account:{self.cfg.account_alias}:symbol:{self.cfg.symbol.upper()}',now_ms=self.clock())

    def refresh_news(self, now_ms: int) -> dict:
        """Re-read the headline file and push candidate event risk into sizing.

        Runs before the bar is handed to the cycle, so an adverse headline is
        present in the pass that assesses the theses it bears on and in the
        meta-labeller that judges the next candidate, rather than one pass late.
        """
        news = getattr(self, "news", None)
        if news is None:
            return {}
        from vati.events.news_runtime import refresh_news_file
        counts=refresh_news_file(news,getattr(self.cfg,'news',None) or {},ledger=self._ledger,
            scope=f'account:{self.cfg.account_alias}:symbol:{self.cfg.symbol.upper()}',now_ms=now_ms)
        try:
            multiplier, _materiality, _refs = news.candidate_risk(
                self.cfg.symbol, now_ms=now_ms)
            self.runner.cycle.engine.m.news_event_risk[
                self.cfg.symbol.upper()] = multiplier
            counts = dict(counts) | {"event_risk_multiplier": str(multiplier)}
        except Exception as exc:  # noqa: BLE001 — optional news cannot stop protective work
            counts=dict(counts)|{'risk_state':'UNAVAILABLE','risk_error_code':type(exc).__name__}
        return counts

    # ------------------------------------------------------------------ loop
    def _heartbeat(self, status: str, extra: Optional[dict] = None) -> None:
        from vati.events.news_runtime import news_heartbeat
        if getattr(self, "learning", None) is not None and getattr(self, "_ledger", None) is not None:
            self.learning.update_projection(self._ledger)
        hb = {"account_alias": self.cfg.account_alias, "symbol": self.cfg.symbol, "session_id": self.runner.cycle.cfg.session_id if self.runner else None, "status": status, "cycles": self.cycles, "last_bar_end_ms": self.last_bar_end_ms,
              "owner_policy_current": bool(self.runner and self.runner.cycle.mandate.owner_keys_current()),
              "permit_new_orders": bool(self._entry_permitted()
                  and self.lease and self.lease.fence(self.lease.epoch, now_ms=self.clock())), "kill_switch": sorted(t.value for t in self.runner.cycle.kill.active) if self.runner else [],
              "lease_outcome": self._lease_outcome, "lease_epoch": self.lease.epoch if self.lease else None,
              "risk_history_issue": self.runner.cycle.streaks.recovery_issue if self.runner else "",
              "unresolved_entry_count": len(self.runner.cycle.unresolved_entry_attempts) if self.runner else 0,
              "unresolved_entry_ids": sorted(self.runner.cycle.unresolved_entry_attempts) if self.runner else [],
              "learning_history_issue": self.learning.recovery_issue if getattr(self, "learning", None) else "",
              "restated_learning": self.learning.projection_summary if getattr(self, "learning", None) else {"status":"NOT_CONSTRUCTED"},
              "news":news_heartbeat(self.news),
              "updated_ms": self.clock(), "pid": os.getpid(), **(extra or {})}
        if self.runner and self.lease:
            from vati.app.runtime_control_actor import recovery_review
            hb['runtime_recovery'] = recovery_review(self)
        Path(self.cfg.heartbeat_path).write_text(json.dumps(hb))

    def _account_snapshot(self, now_ms: int) -> None:
        if getattr(self, "learning", None) is not None and getattr(self, "_ledger", None) is not None:
            self.learning.update_projection(self._ledger)
        r = self.runner
        assert r is not None
        acct = r.cycle.adapter.sync_account()
        observed_clock=self.clock()
        account_observed_ms=observed_clock if type(observed_clock) is int and observed_clock>=now_ms else None
        from vati.execution.native_margin import account_margin_body
        margin=account_margin_body(r.cycle.adapter,acct,observed_at_ms=account_observed_ms)
        hb = r.cycle.adapter.heartbeat(now_ms=now_ms)
        positions = r.cycle.adapter.positions()
        from vati.funding.worker import snapshot_funding
        funding = snapshot_funding(self,r.cycle.ledger,r.cycle.adapter,acct,now_ms=now_ms)
        from vati.funding.native import account_mark_body
        mark=account_mark_body(acct)
        from vati.execution.mt5_observation import account_observation_body
        received_ms=max(now_ms,acct.server_time_unix_ms,self.clock())
        r.cycle.ledger.append(make_event(EventKind.ACCOUNT_SNAPSHOT, "vati-service", {
            "account_alias": acct.account_alias, "equity": str(acct.equity), "balance": str(acct.balance), "currency": acct.currency, "verified": acct.verified,
            "funding_observation": funding,
            "margin": margin,
            "native_account_mark": mark,
            "native_account_observation": account_observation_body(acct),
            "connected": hb.connected, "server_offset_ms": hb.server_offset_ms, "open_positions": len(positions), "peak_equity": str(r.cycle.peak_equity), "day_start_equity": str(r.cycle.day_start_equity),
            "week_start_equity": str(r.cycle.week_start_equity), "kill_switch": sorted(t.value for t in r.cycle.kill.active), "mode": r.cycle.mandate.mode.value,
            "risk_history_issue": r.cycle.streaks.recovery_issue,
            "learning_history_issue": self.learning.recovery_issue if getattr(self, "learning", None) else "",
            "restated_learning": self.learning.projection_summary if getattr(self, "learning", None) else {"status":"NOT_CONSTRUCTED"},
        }, event_time_ms=now_ms, received_time_ms=received_ms, correlation_id=r.cycle.cfg.session_id))

    def start(self) -> None:
        assert self.runner is not None, "build() first"
        if self.runner.started:
            raise RuntimeError("single-symbol runtime is already started")
        result = self.lease.acquire(now_ms=self.clock())
        self._lease_outcome = result.outcome.value
        self._lease_allows_entry = result.permits_orders
        if not result.permits_orders:
            raise RuntimeError(f"account runtime lease refused: {result.outcome.value}")
        try:
            self._start_reconciled()
        except BaseException:
            self.close()
            raise

    def _start_reconciled(self) -> None:
        now = self.clock()
        self._started_ms = now
        rep = self.runner.startup(now_ms=now)
        # P0-TRADE-003 — an owner halt written before this process started used to be
        # discarded, so a restart undid it. Checked here, before the first bar, so the
        # session never runs a cycle believing it is permitted when it is not.
        self._observe_owner_halt(now)
        self._account_snapshot(now)
        self._heartbeat("STARTED", {"reconciliation": rep.counts()})

    def close(self) -> None:
        from vati.funding.worker import stop_funding
        stop_funding(self)
        self._lease_allows_entry = False
        try:
            if self.lease is not None:
                self.lease.release(now_ms=self.clock())
        finally:
            if self._lease_store is not None:
                self._lease_store.close()

    def _observe_owner_halt(self, now_ms: int) -> None:
        """An OWNER_HALT written by the gateway or the commander (A4) stops new orders.

        P0-TRADE-003 — this filtered events at or after `self._started_ms`, so restarting
        the session discarded an active owner halt. `restart_service` is an exposed
        commander command, which made "halt trading" undoable by the same interface that
        was meant to enforce it.

        The filter is now the *latest* OWNER_HALT and whether anything cleared it since,
        which is a property of the ledger rather than of this process. A halt therefore
        survives a restart, and a clear is what ends it — as it always was for a session
        that happened to stay up.
        """
        assert self.runner is not None
        from vati.risk.contracts import KillSwitchTrigger
        if KillSwitchTrigger.OWNER_HALT in self.runner.cycle.kill.active:
            return
        from vati.app.runtime_control_actor import outstanding_owner_halts
        halts = outstanding_owner_halts(self.runner.cycle.ledger, self.cfg.account_alias)
        if not halts:
            return
        latest_halt = halts[-1]
        self.runner.cycle.kill.trip(KillSwitchTrigger.OWNER_HALT, now_ms)
        self.runner.permit_new_orders = False
        self.runner.cycle.ledger.append(make_event(
            EventKind.SESSION, "vati-service",
            {"event": "OWNER_HALT_OBSERVED", "source_event": latest_halt.hash,
             "halt_event_time_ms": latest_halt.event_time_ms,
             "observed_after_restart": latest_halt.event_time_ms < self._started_ms},
            event_time_ms=now_ms, received_time_ms=now_ms,
            correlation_id=self.runner.cycle.cfg.session_id,
        ))

    def _entry_permitted(self) -> bool:
        if self.stop_requested or self.runner is None:
            return False
        self._observe_owner_halt(self.clock())
        from vati.accounts.access import entry_fence,AccountModeAuthorityError
        from vati.core.file_lock import StateFileLockError
        try:
            # The adapter remains the final submission fence. This fresh check
            # keeps the session gate and owner readback consistent with it.
            with entry_fence(self._entry_registry,self._entry_account):
                profile_permitted=True
        except (ValueError,AccountModeAuthorityError,OSError,StateFileLockError):
            profile_permitted=False
        return bool(profile_permitted and self._lease_allows_entry and self.runner.permit_new_orders
            and not self.runner.cycle.unresolved_entry_attempts
            and self.runner.cycle.mandate.sends_orders() and self.runner.cycle.mandate.owner_keys_current()
            and not self.runner.cycle.kill.halted)

    def step_once(self) -> Optional[str]:
        """One loop iteration; returns the cycle decision when a new bar closed, else None."""
        assert self.runner is not None
        if not self.runner.started:
            raise RuntimeError("start() first")
        now = self.clock()
        result = self.lease.renew(now_ms=now)
        self._lease_outcome = result.outcome.value
        self._lease_allows_entry = result.permits_orders
        self._observe_owner_halt(now)
        from vati.app.entry_recovery import reconcile_inflight_entries
        reconcile_inflight_entries(self.runner.cycle,now_ms=now)
        from vati.app.runtime_control_actor import process_recovery_requests
        process_recovery_requests(self)
        bars = self.bar_source(now)
        if not bars:
            self.runner.cycle.ledger.append(make_event(EventKind.MARKET_DATA_HEALTH, "vati-service", {"symbol": self.cfg.symbol, "state": "NO_DATA"}, event_time_ms=now, received_time_ms=now, correlation_id=self.cfg.symbol))
            self._heartbeat("NO_DATA")
            return None
        last = bars[-1]
        if last.end_ms <= self.last_bar_end_ms:
            self._heartbeat("WAITING_FOR_BAR")
            return None
        age = now - last.end_ms
        state = "LIVE" if age <= 2 * TIMEFRAMES_MS[self.cfg.timeframe] else ("DELAYED" if age <= 6 * TIMEFRAMES_MS[self.cfg.timeframe] else "STALE")
        self.runner.cycle.ledger.append(make_event(EventKind.MARKET_DATA_HEALTH, "vati-service", {"symbol": self.cfg.symbol, "state": state, "bar_age_ms": age, "bars": len(bars)}, event_time_ms=now, received_time_ms=now, correlation_id=self.cfg.symbol))
        self.refresh_news(now)
        res = self.runner.on_bar(bars, now_ms=now, last_quote_ms=last.end_ms if state == "LIVE" else last.end_ms - age)
        self.last_bar_end_ms = last.end_ms
        self.cycles += 1
        self._account_snapshot(now)
        self._heartbeat("RUNNING", {"last_decision": res.decision, "data_state": state})
        return res.decision

    def run_forever(self) -> int:
        def _stop(*_):
            self.stop_requested = True
        signal.signal(signal.SIGTERM, _stop)
        signal.signal(signal.SIGINT, _stop)
        try:
            return self._run_started_loop()
        finally:
            self.close()

    def _run_started_loop(self) -> int:
        self.start()
        while not self.stop_requested:
            try:
                self.step_once()
            except Exception as exc:  # noqa: BLE001 — a loop fault must not drop protection; it is logged and the loop continues fail-closed
                now = self.clock()
                self.runner.cycle.ledger.append(make_event(EventKind.SESSION, "vati-service", {"event": "LOOP_FAULT", "error": str(exc)[:300]}, event_time_ms=now, received_time_ms=now, correlation_id=self.runner.cycle.cfg.session_id))
                self._heartbeat("FAULT", {"error": str(exc)[:200]})
            time.sleep(self.cfg.poll_seconds)
        now = self.clock()
        self._lease_allows_entry = False
        self.runner.cycle.ledger.append(make_event(EventKind.SESSION, "vati-service", {"event": "STOPPED", "open_positions": len(self.runner.cycle.adapter.positions())}, event_time_ms=now, received_time_ms=now, correlation_id=self.runner.cycle.cfg.session_id))
        self._heartbeat("STOPPED")
        return 0


def lake_bar_source(lake: BarLake, symbol: str, timeframe: str, *, lookback_bars: int = 400) -> Callable[[int], list[Bar]]:
    def src(now_ms: int) -> list[Bar]:
        bars, _ = lake.read(symbol, timeframe, end_ms=now_ms + 1)
        return [b for b in bars if b.end_ms <= now_ms][-lookback_bars:]
    return src
