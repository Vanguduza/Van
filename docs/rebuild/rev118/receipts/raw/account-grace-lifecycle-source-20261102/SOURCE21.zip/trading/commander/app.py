from __future__ import annotations

import fnmatch
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
import threading
import weakref
import json
import hashlib
import secrets
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import time
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.request import Request, urlopen

from fastapi import FastAPI, HTTPException, Request as FastRequest
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from commander.accounts import ACCOUNT_COMMANDS, ACCOUNT_TOOL_SCHEMAS, AccountControlSettings, build_account_handlers, redact_args, require_resource_version
from commander.strategies import (
    PROMOTION_COMMANDS,
    PROMOTION_TOOL_SCHEMAS,
    StrategyPromotionSettings,
    build_strategy_handlers,
)
from commander.auth import DEFAULT_PRINCIPAL, NonceCache, verify_request_principal
from commander.runtime_controls import RUNTIME_COMMANDS, RUNTIME_TOOL_SCHEMAS, build_runtime_control_handlers

REDACT = re.compile(r"(?i)(password|passwd|token|api[_-]?key|secret|bearer|signing[_-]?key)(\s*[:=]\s*)\S+")
UNIT_RE = re.compile(r"^[A-Za-z0-9@._-]+$")
DEFAULT_UNITS = ("vati-session@*.service", "vati-commander.service", "vati-vekl.service", "vati-supabase.service", "vati-mt5-pull.service", "caddy.service")
COMMANDS = ("status", "ledger_status", "services", "restart_service", "tail_log", "run_backtest", "vekl_resolve", "halt", "doctor", "accounts",
            # GAP-F-003. Read-only trading observation, so the Hermes MCP shim
            # for the commander can ground a question about the book instead of
            # answering it from host uptime and event counts. Both are
            # projections of the VATI ledger; neither can create, size, modify
            # or cancel anything, and neither is in GATEWAY_ONLY_COMMANDS
            # because observation is not a mutation.
            "positions", "assessment") + ACCOUNT_COMMANDS + PROMOTION_COMMANDS + RUNTIME_COMMANDS
# Credential-bearing and strategy-promotion commands are gateway-only. This is a
# positive allow-list: the authenticated principal must be exactly van-gateway.
# A legacy/shared credential or a future/renamed agent cannot acquire mutation
# authority merely by avoiding a deny-list.
GATEWAY_PRINCIPAL = "van-gateway"
GATEWAY_ONLY_COMMANDS = frozenset(ACCOUNT_COMMANDS + PROMOTION_COMMANDS + RUNTIME_COMMANDS)
# Compatibility name used by the MCP/tool-list contract.
AGENT_HIDDEN_COMMANDS = GATEWAY_ONLY_COMMANDS
# Reads do not wait behind native writes or a long backtest. Halt remains an
# independently authorized, atomic reduce-only path. Unknown/new commands use
# the serialized executor by default.
PARALLEL_COMMANDS = frozenset({"status", "ledger_status", "services", "tail_log",
    "doctor", "accounts", "positions", "assessment", "account_revision", "account_review",
    "account_verify", "account_operation", "ctrader_discover", "halt", "runtime_recovery_review", "runtime_recovery_operation"})
MAX_NATIVE_PENDING_COMMANDS = 16
Runner = Callable[[list[str], int], tuple[int, str, str]]


def default_runner(argv: list[str], timeout_s: int) -> tuple[int, str, str]:
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout_s, check=False)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout after {timeout_s}s"
    except FileNotFoundError as exc:
        return 127, "", str(exc)


@dataclass
class CommanderSettings:
    token_file: str = os.environ.get("VAN_COMMANDER_TOKEN_FILE", "/opt/van-trading/secrets/commander.token")
    ledger: str = os.environ.get("VAN_COMMANDER_LEDGER", "/var/lib/van-trading/ledger/vati.sqlite")
    heartbeat_dir: str = os.environ.get("VAN_COMMANDER_HEARTBEAT_DIR", "/var/lib/van-trading/heartbeats")
    log_dir: str = os.environ.get("VAN_COMMANDER_LOG_DIR", "/var/log/van-trading")
    data_dir: str = os.environ.get("VAN_COMMANDER_DATA_DIR", "/var/lib/van-trading")
    repo_root: str = os.environ.get("VAN_COMMANDER_REPO", str(Path(__file__).resolve().parents[2]))
    vekl_url: str = os.environ.get("VAN_VEKL_URL", "http://127.0.0.1:9134")
    vekl_token: str = os.environ.get("VAN_VEKL_TOKEN", "")
    accounts_registry: str = os.environ.get("VAN_ACCOUNTS_REGISTRY", "/opt/van-trading/config/accounts.json")
    secrets_dir: str = os.environ.get("VAN_SECRETS", "/opt/van-trading/secrets")
    capsule_dir: str = os.environ.get("VAN_CAPSULE_DIR", "")
    owner_authority_keys: str = os.environ.get(
        "VAN_OWNER_AUTHORITY_KEYS",
        "/var/lib/van-trading/owner_authority_keys.json",
    )
    lifecycle_policy_qualification_keys: str = os.environ.get("VATI_LIFECYCLE_QUALIFICATION_KEYS", "")
    lifecycle_session_sources: tuple | None = None
    account_control: Optional[AccountControlSettings] = None   # injected for tests; else derived
    units: tuple[str, ...] = tuple(filter(None, os.environ.get("VAN_COMMANDER_UNITS", ",".join(DEFAULT_UNITS)).split(",")))
    backtest_timeout_s: int = int(os.environ.get("VAN_COMMANDER_BACKTEST_TIMEOUT", "600"))
    max_log_lines: int = 400
    python: str = sys.executable
    runner: Runner = field(default=default_runner)
    token: Optional[str] = None      # injected for tests; otherwise read from token_file
    #: Per-principal tokens, injected for tests; otherwise read from <token_file>.<principal>.
    tokens: Optional[dict[str, str]] = None
    _owner_authority: Any = None     # lazily built OwnerAuthorityVerifier (P0-TRADE-001)

    def load_tokens(self) -> dict[str, str]:
        """Load authenticated principals and fail closed on ambiguous credentials.

        The base token remains the legacy commander principal for non-sensitive
        compatibility. Privileged mutations require the dedicated van-gateway
        principal at the route boundary.

        Per-principal files are named <token_file>.<principal>. Weak, loosely
        permissioned, or duplicate values are configuration errors rather than entries
        silently ignored, because partial deployment must never fall back to shared
        authority.
        """
        if self.tokens is not None:
            tokens = dict(self.tokens)
        else:
            tokens = {DEFAULT_PRINCIPAL: self.load_token()}
            if not self.token:
                base = Path(self.token_file)
                for extra in sorted(base.parent.glob(f"{base.name}.*")):
                    principal = extra.name[len(base.name) + 1:]
                    if not principal:
                        raise RuntimeError(f"invalid commander principal token path: {extra}")
                    if stat.S_IMODE(extra.stat().st_mode) & 0o077:
                        raise RuntimeError(f"commander principal token must be mode 0600: {extra}")
                    value = extra.read_text().strip()
                    if len(value) < 32:
                        raise RuntimeError(
                            f"commander principal token too short for {principal} (need ≥ 32 chars)"
                        )
                    tokens[principal] = value

        if not tokens:
            raise RuntimeError("no commander principal tokens configured")
        values: dict[str, str] = {}
        for principal, value in sorted(tokens.items()):
            if not principal or len(value) < 32:
                raise RuntimeError(f"invalid commander token for principal {principal!r}")
            if value in values:
                raise RuntimeError(
                    f"commander principals {values[value]!r} and {principal!r} share a token"
                )
            values[value] = principal
        return tokens
    def owner_authority(self):
        """The verifier for owner-signed acts on this host (P0-TRADE-001)."""
        from vati.authority import OwnerAuthorityVerifier, load_owner_keys

        if self._owner_authority is None:
            self._owner_authority = OwnerAuthorityVerifier(
                load_owner_keys(self.owner_authority_keys), registry_path=self.owner_authority_keys
            )
        return self._owner_authority

    def load_token(self) -> str:
        if self.token:
            return self.token
        p = Path(self.token_file)
        if not p.is_file():
            raise RuntimeError(f"commander token file missing: {self.token_file}")
        if stat.S_IMODE(p.stat().st_mode) & 0o077:
            raise RuntimeError("commander token file must be mode 0600")
        tok = p.read_text().strip()
        if len(tok) < 32:
            raise RuntimeError("commander token too short (need ≥ 32 chars)")
        return tok

    def unit_allowed(self, unit: str) -> bool:
        return bool(UNIT_RE.match(unit)) and any(fnmatch.fnmatch(unit, pat) for pat in self.units)


def redact(text: str) -> str:
    return REDACT.sub(lambda m: f"{m.group(1)}{m.group(2)}[REDACTED]", text)


class CmdBody(BaseModel):
    """P1-HER-005 — `requested_by` used to live here and be trusted.

    It is still accepted so an existing client is not broken, but it is now only ever
    compared with the principal the signature authenticated. A body that disagrees is
    refused rather than believed.
    """

    args: dict[str, Any] = Field(default_factory=dict)
    requested_by: str = ""


TOOL_SCHEMAS = {
    "status": {"description": "Session heartbeats, ledger head, VEKL health and unit states on van-trading-core.", "properties": {}},
    "ledger_status": {"description": "Event counts by kind and full chain verification of the VATI ledger.", "properties": {}},
    "services": {"description": "Active/enabled state of the allowlisted vati-* systemd units.", "properties": {}},
    "restart_service": {"description": "Restart one allowlisted vati-* unit (audited). Open positions keep venue stops; no orders are placed by a restart.", "properties": {"unit": {"type": "string"}}, "required": ["unit"]},
    "tail_log": {"description": "Last N journal lines of an allowlisted unit, secrets redacted.", "properties": {"unit": {"type": "string"}, "lines": {"type": "integer", "default": 100}}, "required": ["unit"]},
    "run_backtest": {"description": "Run `python -m vati backtest` on files under the data directory; bounded by timeout; result is a candidate, never a promotion.", "properties": {"config": {"type": "string"}, "bars": {"type": "string"}}, "required": ["config", "bars"]},
    "vekl_resolve": {"description": "Resolve trading engineering knowledge through the dedicated trading VEKL; returns an activation id.", "properties": {"instruction": {"type": "string"}, "affected_paths": {"type": "array", "items": {"type": "string"}}}, "required": ["instruction"]},
    "halt": {"description": "Owner-signed halt (A4): appends KILL_SWITCH OWNER_HALT to the ledger; sessions stop new orders. Requires owner_signature_ref.", "properties": {"owner_signature_ref": {"type": "string"}, "reason": {"type": "string"}}, "required": ["owner_signature_ref"]},
    "doctor": {"description": "Host diagnostics: runtimes, disk, ledger reachability, VEKL, heartbeat ages, secret file modes.", "properties": {}},
    "accounts": {"description": "Public view of the account registry (aliases, broker kind, safety identity). Never credentials.", "properties": {}},
    "positions": {"description": "Open positions read from the VATI ledger: thesis and its current state, health, exposure, protection, unrealised R, linked events and the latest adjustment proposal. Read-only; no order path.", "properties": {"limit": {"type": "integer", "default": 20}}},
    "assessment": {"description": "VAN's reading of the book: urgent risks, portfolio heat, available risk headroom, active theses by state, kill-switch state and the cognition invoker actually configured. Read-only; a reading, never a permission.", "properties": {}},
    **ACCOUNT_TOOL_SCHEMAS,
    **PROMOTION_TOOL_SCHEMAS,
    **RUNTIME_TOOL_SCHEMAS,
}


def create_app(settings: Optional[CommanderSettings] = None) -> FastAPI:
    st = settings or CommanderSettings()
    native_writes = ThreadPoolExecutor(max_workers=1, thread_name_prefix="van-native-command")
    native_slots = threading.BoundedSemaphore(MAX_NATIVE_PENDING_COMMANDS)

    @asynccontextmanager
    async def native_lifespan(_app):
        try:
            yield
        finally:
            # Stop work that has not started and let actual native work finish.
            # Lifecycle teardown must not create a second executor over it.
            await asyncio.to_thread(native_writes.shutdown, wait=True, cancel_futures=True)

    app = FastAPI(title="Van Trading Commander", version="1.0.0", lifespan=native_lifespan)
    weakref.finalize(app, native_writes.shutdown, wait=False, cancel_futures=True)
    # Exposed so a deployment or a test can install the owner authority verifier
    # this host should trust, the same way the gateway exposes its services.
    app.state.commander_settings = st
    nonces = NonceCache()
    audit_path = Path(st.log_dir) / "commander-audit.jsonl"
    started = time.time()

    def audit(cmd: str, requested_by: str, args: dict, result: str) -> None:
        try:
            audit_path.parent.mkdir(parents=True, exist_ok=True)
            with audit_path.open("a") as f:
                f.write(json.dumps({"ts": int(time.time()), "cmd": cmd, "by": requested_by, "args": redact_args({k: v for k, v in args.items() if k != "owner_signature_ref"}), "result": result[:200]}) + "\n")
        except OSError:
            pass

    def ledger():
        from vati.core.ledger_pg import open_ledger
        return open_ledger(st.ledger)

    def heartbeats() -> list[dict]:
        out = []
        d = Path(st.heartbeat_dir)
        if d.is_dir():
            for p in sorted(d.glob("*.json")):
                try:
                    hb = json.loads(p.read_text()); hb["age_s"] = int(time.time() - hb.get("updated_ms", 0) / 1000); hb["file"] = p.name; out.append(hb)
                except (OSError, ValueError):
                    out.append({"file": p.name, "error": "unreadable"})
        return out

    def vekl_get(path: str) -> dict:
        try:
            req = Request(st.vekl_url + path, headers={"Authorization": f"Bearer {st.vekl_token}"} if st.vekl_token else {})
            with urlopen(req, timeout=5) as r:  # noqa: S310 — loopback service
                return json.loads(r.read())
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)[:200]}

    def units_state() -> list[dict]:
        out = []
        for pat in st.units:
            if "*" in pat:
                code, o, _ = st.runner(["systemctl", "list-units", "--all", "--no-legend", "--plain", pat], 10)
                names = [ln.split()[0] for ln in o.splitlines() if ln.strip()] if code == 0 else []
            else:
                names = [pat]
            for u in names:
                _, active, _ = st.runner(["systemctl", "is-active", u], 10)
                _, enabled, _ = st.runner(["systemctl", "is-enabled", u], 10)
                out.append({"unit": u, "active": active.strip() or "unknown", "enabled": enabled.strip() or "unknown"})
        return out

    # ------------------------------------------------------------ commands
    def cmd_status(a: dict) -> dict:
        led = None
        try:
            led = ledger(); lg = {"head": led.head(), "events": led.count(), "backend": type(led).__name__}
        except Exception as exc:  # noqa: BLE001
            lg = {"error": str(exc)[:200]}
        finally:
            if led is not None:
                led.close()
        return {"host": platform.node(), "uptime_s": int(time.time() - started), "heartbeats": heartbeats(), "ledger": lg, "vekl": vekl_get("/health"), "units": units_state()}

    def cmd_ledger_status(a: dict) -> dict:
        from vati.core.events import EventKind
        led = ledger()
        try:
            ok, n = led.verify_chain()
            return {"chain_ok": ok, "events": n, "head": led.head(), "counts": {k.value: led.count(k) for k in EventKind if led.count(k)}}
        finally:
            led.close()

    def cmd_services(a: dict) -> dict:
        return {"units": units_state()}

    def cmd_restart(a: dict) -> dict:
        unit = str(a.get("unit", ""))
        if not st.unit_allowed(unit):
            raise HTTPException(403, f"unit not in allowlist: {unit}")
        code, o, e = st.runner(["systemctl", "restart", unit], 60)
        _, active, _ = st.runner(["systemctl", "is-active", unit], 10)
        return {"unit": unit, "restarted": code == 0, "active": active.strip(), "stderr": redact(e)[:300]}

    def cmd_tail(a: dict) -> dict:
        unit = str(a.get("unit", "")); lines = max(1, min(int(a.get("lines", 100)), st.max_log_lines))
        if not st.unit_allowed(unit):
            raise HTTPException(403, f"unit not in allowlist: {unit}")
        code, o, e = st.runner(["journalctl", "-u", unit, "-n", str(lines), "--no-pager", "-o", "cat"], 20)
        return {"unit": unit, "lines": redact(o).splitlines()[-lines:], "error": redact(e)[:200] if code else ""}

    def _under_data(p: str) -> Path:
        root = Path(st.data_dir).resolve()
        cand = (root / p).resolve() if not Path(p).is_absolute() else Path(p).resolve()
        if root not in cand.parents and cand != root:
            raise HTTPException(403, f"path must be under {root}")
        if not cand.is_file():
            raise HTTPException(404, f"no such file: {cand}")
        return cand

    def cmd_backtest(a: dict) -> dict:
        cfg, bars = _under_data(str(a.get("config", ""))), _under_data(str(a.get("bars", "")))
        out_path = Path(st.data_dir) / "backtests" / f"bt-{int(time.time())}.json"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        code, o, e = st.runner([st.python, "-m", "vati", "backtest", "--bars", str(bars), "--config", str(cfg), "--out", str(out_path)], st.backtest_timeout_s)
        summary = json.loads(out_path.read_text()) if out_path.is_file() else None
        return {"exit_code": code, "summary": summary, "result_path": str(out_path) if summary else None, "stderr": redact(e)[-400:], "authority": "candidate evidence only; promotion stays owner-signed"}

    def cmd_vekl(a: dict) -> dict:
        body = json.dumps({"instruction": str(a.get("instruction", "")), "affected_paths": list(a.get("affected_paths", [])), "requested_by": "commander"}).encode()
        try:
            req = Request(st.vekl_url + "/resolve", data=body, method="POST", headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {st.vekl_token}"} if st.vekl_token else {})})
            with urlopen(req, timeout=15) as r:  # noqa: S310
                return json.loads(r.read())
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(502, f"trading VEKL unavailable: {str(exc)[:200]}")

    def cmd_halt(a: dict) -> dict:
        # P0-TRADE-001 / P1-HER-005 — this accepted any non-empty string, so "x" halted
        # trading and, more to the point, so did anything that could reach this route.
        from vati.authority import OwnerAuthorityError

        try:
            verified = st.owner_authority().verify(
                str(a.get("owner_signature_ref", "")),
                act="owner-halt",
                subject="van-trading-core",
            )
        except OwnerAuthorityError as exc:
            raise HTTPException(403, f"owner-signed authority (A4) required: {exc}")
        sig = verified.ref
        from vati.core.events import EventKind, make_event
        led = ledger()
        try:
            now = int(time.time() * 1000)
            ev = make_event(EventKind.KILL_SWITCH, "van-commander", {"trigger": "OWNER_HALT", "sig": sig, "reason": str(a.get("reason", ""))[:300], "channel": "commander"}, event_time_ms=now, received_time_ms=now, correlation_id="owner")
            chain = led.append(ev)
        finally:
            led.close()
        return {"halted": True, "event_hash": ev.hash, "chain_hash": chain, "note": "sessions observe OWNER_HALT on their next loop and stop new orders; open positions keep their venue stops"}

    def cmd_doctor(a: dict) -> dict:
        du = shutil.disk_usage(st.data_dir if Path(st.data_dir).exists() else "/")
        _, node, _ = st.runner(["node", "--version"], 5)
        checks = {"python": platform.python_version(), "node": node.strip() or "missing", "disk_free_gb": round(du.free / 1e9, 2), "ledger": st.ledger.split("@")[-1] if st.ledger.startswith("postgres") else st.ledger,
                  "vekl": vekl_get("/health").get("ok", False), "heartbeats": [{"file": h.get("file"), "status": h.get("status"), "age_s": h.get("age_s")} for h in heartbeats()], "units": units_state()}
        secrets_dir = Path(st.token_file).parent
        bad = []
        if secrets_dir.is_dir():
            for p in secrets_dir.iterdir():
                if p.is_file() and stat.S_IMODE(p.stat().st_mode) & 0o077:
                    bad.append(p.name)
        checks["secret_files_with_loose_mode"] = bad
        try:
            led = ledger(); checks["ledger_reachable"] = True; checks["ledger_events"] = led.count(); led.close()
        except Exception as exc:  # noqa: BLE001
            checks["ledger_reachable"] = False; checks["ledger_error"] = str(exc)[:200]
        checks["ok"] = checks["ledger_reachable"] and not bad and du.free > 2e9
        return checks

    def _active_read_model(name: str, **kwargs) -> dict:
        """One of the GAP-F-003 ledger projections, or an explicit unavailable.

        The commander opens the same ledger the gateway does and runs the same
        projection, so Hermes and the Command Centre cannot disagree about what
        is open. A ledger that will not open answers `ledger_available: False`
        rather than raising, for the same reason `status` does: "I could not
        look" must be distinguishable from "nothing is there".
        """
        from vati.readmodels import active

        led = None
        try:
            led = ledger()
            return getattr(active, name)(led, **kwargs)
        except Exception as exc:  # noqa: BLE001 — an unreadable ledger is reported, not raised
            return active.empty({"error": str(exc)[:200]})
        finally:
            if led is not None:
                led.close()

    def cmd_positions(a: dict) -> dict:
        limit = max(1, min(int(a.get("limit", 20)), 100))
        payload = _active_read_model("positions")
        payload["positions"] = payload.get("positions", [])[:limit]
        payload["count"] = len(payload["positions"])
        return payload

    def cmd_assessment(a: dict) -> dict:
        return _active_read_model("assessment")

    def cmd_accounts(a: dict) -> dict:
        from vati.accounts import AccountRegistry
        p = Path(st.accounts_registry)
        if not p.is_file():
            return {"accounts": [], "registry": str(p), "note": "no registry yet: add one with `python -m vati accounts add`"}
        return {"accounts": AccountRegistry(p).public(), "registry": str(p)}

    capsule_dir = st.capsule_dir or str(Path(st.repo_root) / "trading" / "strategies" / "registry")
    handlers = {"status": cmd_status, "ledger_status": cmd_ledger_status, "services": cmd_services, "restart_service": cmd_restart, "tail_log": cmd_tail, "run_backtest": cmd_backtest,
                "vekl_resolve": cmd_vekl, "halt": cmd_halt, "doctor": cmd_doctor, "accounts": cmd_accounts,
                "positions": cmd_positions, "assessment": cmd_assessment,
                **build_account_handlers(replace(st.account_control, operation_ledger=st.ledger) if st.account_control else
                    AccountControlSettings(registry_path=st.accounts_registry, secrets_dir=st.secrets_dir, operation_ledger=st.ledger, lifecycle_session_sources=st.lifecycle_session_sources)),
                **build_runtime_control_handlers(st),
                **build_strategy_handlers(StrategyPromotionSettings(
                    capsule_dir=capsule_dir,
                    ledger=st.ledger,
                    owner_authority=st.owner_authority(),
                    owner_authority_keys_path=st.owner_authority_keys,
                ))}
    assert set(handlers) == set(COMMANDS) == set(TOOL_SCHEMAS)
    # Source owner integration only. No new command, HTTP route or MCP surface:
    # frozen public action binding still requires its own reviewed amendment.
    from commander.lifecycle_policies import LifecyclePolicyControls, LifecyclePolicySettings, qualification_reader
    app.state.lifecycle_policy_controls = LifecyclePolicyControls(LifecyclePolicySettings(
        ledger=st.ledger,owner_authority=st.owner_authority(),
        qualification_authority=qualification_reader(st.lifecycle_policy_qualification_keys)))

    # ------------------------------------------------------------ routes
    @app.get("/health")
    async def health():
        return {"ok": True, "service": "van-trading-commander", "commands": list(COMMANDS), "uptime_s": int(time.time() - started)}

    @app.get("/v1/tools")
    async def tools(request: FastRequest):
        ok, why, _principal = verify_request_principal(
            st.load_tokens(), request.headers, "GET", "/v1/tools", b"", nonces=nonces
        )
        if not ok:
            raise HTTPException(401, why)
        return {"tools": [{"name": n, "description": s["description"], "inputSchema": {"type": "object", "properties": s["properties"], "required": s.get("required", [])}}
                          for n, s in TOOL_SCHEMAS.items() if n not in AGENT_HIDDEN_COMMANDS]}

    @app.post("/v1/cmd/{name}")
    async def command(name: str, request: FastRequest):
        body = await request.body()
        ok, why, principal = verify_request_principal(
            st.load_tokens(), request.headers, "POST", f"/v1/cmd/{name}", body, nonces=nonces
        )
        if not ok:
            raise HTTPException(401, why)
        if name not in handlers:
            raise HTTPException(404, f"unknown command {name}; this is not a shell")
        try:
            parsed = CmdBody.model_validate_json(body or b"{}")
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(422, str(exc)[:200])
        # P1-HER-005. The principal is whichever configured token signed the request. A
        # body that claims a different one is a client bug at best and an attempt to reach
        # the credential commands at worst, so it is refused rather than ignored.
        if parsed.requested_by and parsed.requested_by.lower() != principal.lower():
            audit(name, principal, parsed.args, "refused:requested_by_mismatch")
            raise HTTPException(
                403,
                "requested_by does not match the authenticated principal; it is not the "
                "caller's to declare",
            )
        parsed.requested_by = principal
        if name in GATEWAY_ONLY_COMMANDS and principal.lower() != GATEWAY_PRINCIPAL:
            audit(name, principal, parsed.args, "refused:gateway_only")
            raise HTTPException(
                403,
                "credential and strategy mutations require the authenticated van-gateway principal",
            )
        try:
            legacy_demo=name=='deriv_create_demo' and '_native_operation' not in parsed.args
            require_resource_version(name, parsed.args,server_owned_demo=legacy_demo)
            def current_account_authority():
                current, reason, current_principal = verify_request_principal(
                    st.load_tokens(), request.headers, "POST", f"/v1/cmd/{name}",
                    body, nonces=NonceCache())
                if not current or current_principal != principal:
                    raise HTTPException(401, "command authorization expired or changed before execution: " + reason)
            def invoke():
                # Admission already consumed the one-use nonce on the event
                # loop. Recheck the signed envelope against CURRENT keys/time
                # at actual dispatch without trying to consume that nonce again.
                current_account_authority()
                values = parsed.args
                if name in {'account_upsert','account_remove','account_review','deriv_create_demo','deriv_oauth_link','ctrader_link'}:
                    values = {**values, '_account_dispatch_guard': current_account_authority}
                    if legacy_demo:
                        def admit_legacy_demo():
                            from commander.auth import HDR_TS,HDR_SIG,SKEW_S
                            from vati.core.canonical import canonical_hash
                            current_account_authority()
                            # Inert identity for this already authenticated
                            # gateway-principal command, not OwnerAuthority.
                            return {'operation_id':'legacy-demo-'+secrets.token_urlsafe(24),
                                'device_id':'commander:'+principal,
                                'authority_ref':'authenticated-commander-request:'+hashlib.sha256(request.headers[HDR_SIG].encode()).hexdigest(),
                                'expires_at_unix':int(request.headers[HDR_TS])+SKEW_S,
                                'request_digest':canonical_hash({k:v for k,v in parsed.args.items() if not k.startswith('_')})}
                        values['_server_demo_admission']=admit_legacy_demo
                return handlers[name](values)

            if name in PARALLEL_COMMANDS:
                result = await asyncio.to_thread(invoke)
            else:
                if not native_slots.acquire(blocking=False):
                    raise HTTPException(503, "native command queue is full; no command dispatched")
                try:
                    native_future = native_writes.submit(invoke)
                except RuntimeError:
                    native_slots.release()
                    raise HTTPException(503, "native command executor is shutting down; no command dispatched") from None
                # A cancelled HTTP waiter must not release a running native
                # slot or allow the next write to overtake its actual effect.
                native_future.add_done_callback(lambda _future: native_slots.release())
                waiter = asyncio.wrap_future(native_future)
                waiter.add_done_callback(lambda done: done.exception() if not done.cancelled() else None)
                # Losing an HTTP waiter is not cancellation of an admitted
                # operation. Keep queued work and its capacity until the native
                # executor resolves it; recheck authorization when it starts.
                result = await asyncio.shield(waiter)
        except HTTPException as exc:
            audit(name, parsed.requested_by, parsed.args,
                ("unknown:" if getattr(exc, "effect_state", None) == "UNKNOWN" else "refused:") + str(exc.detail))
            raise
        audit(name, parsed.requested_by, parsed.args, "ok")
        return JSONResponse({"command": name, "result": result})

    return app


app = create_app() if os.environ.get("VAN_COMMANDER_AUTOCREATE") == "1" else None
