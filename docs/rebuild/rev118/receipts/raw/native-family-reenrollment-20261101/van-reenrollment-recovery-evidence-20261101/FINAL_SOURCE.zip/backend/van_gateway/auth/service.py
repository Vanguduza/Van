from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from dataclasses import dataclass

from cryptography.fernet import Fernet, InvalidToken

from van_gateway.storage.db import Store


@dataclass
class DeviceRecord:
    device_id: str
    public_key_pem: str
    enrolled_at_unix: int
    revoked_at_unix: int | None
    label: str | None


@dataclass
class PairingTicket:
    token: str
    expires_at_unix: int
    label: str | None


@dataclass
class PairingResult:
    device: DeviceRecord
    access_token: str


class AuthError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


#: P2-SEC-008. Enrolment grants were minted with a ten-year expiry, which is a standing
#: grant with a number attached. A year is long enough that a device the owner uses is
#: never inconvenienced and short enough that one they forgot about stops working.
ENROLMENT_GRANT_SECONDS = 365 * 24 * 3600

#: How long before expiry a grant should be renewed. Renewal is the reason an expiry is
#: safe to set: without one, the only options are ten years or breaking the owner's phone.
GRANT_RENEWAL_WINDOW_SECONDS = 30 * 24 * 3600


class AuthService:
    """Device enrollment + restart-durable HMAC request authentication.

    Device HMAC secrets are encrypted at rest with a dedicated Fernet key and
    rehydrated into process memory at startup. Raw secrets never enter audit or
    capability tables. Revoked devices are never rehydrated.
    """

    def __init__(self, store: Store, secret_fernet_key: str = "") -> None:
        self.store = store
        self._device_secrets: dict[str, bytes] = {}
        self._fernet: Fernet | None = None
        if secret_fernet_key:
            try:
                self._fernet = Fernet(secret_fernet_key.encode("utf-8"))
            except (ValueError, TypeError) as exc:
                raise AuthError("device_secret_cipher_invalid", "Device secret encryption key is invalid") from exc

    def _cipher(self) -> Fernet:
        if self._fernet is None:
            raise AuthError(
                "device_secret_encryption_unconfigured",
                "Device secret encryption is not configured; refusing device authentication",
            )
        return self._fernet

    async def load_persisted_secrets(self) -> int:
        rows = await self.store.fetchall(
            "SELECT device_id, encrypted_secret FROM devices WHERE revoked_at_unix IS NULL AND encrypted_secret IS NOT NULL"
        )
        self._device_secrets.clear()
        if not rows:
            return 0
        cipher = self._cipher()
        for row in rows:
            ciphertext = str(row["encrypted_secret"] or "")
            if not ciphertext:
                continue
            try:
                secret = cipher.decrypt(ciphertext.encode("utf-8"))
            except InvalidToken as exc:
                raise AuthError(
                    "device_secret_decryption_failed",
                    f"Encrypted credential for device {row['device_id']} cannot be decrypted",
                ) from exc
            self._device_secrets[str(row["device_id"])] = secret
        return len(self._device_secrets)

    async def create_pairing_ticket(
        self,
        label: str | None = None,
        ttl_seconds: int = 600,
    ) -> PairingTicket:
        ttl = max(60, min(int(ttl_seconds), 3600))
        token = secrets.token_urlsafe(32)
        ticket_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        now = int(time.time())
        expires = now + ttl
        async with self.store.connection() as db:
            await db.execute("BEGIN IMMEDIATE")
            if label is None:
                await db.execute(
                    "UPDATE pairing_tickets SET used_at_unix = ? WHERE used_at_unix IS NULL AND expires_at_unix >= ?",
                    (now, now),
                )
            else:
                await db.execute(
                    "UPDATE pairing_tickets SET used_at_unix = ? WHERE label = ? AND used_at_unix IS NULL AND expires_at_unix >= ?",
                    (now, label, now),
                )
            await db.execute(
                "INSERT INTO pairing_tickets(ticket_hash, label, expires_at_unix, used_at_unix, created_at_unix) VALUES (?, ?, ?, NULL, ?)",
                (ticket_hash, label, expires, now),
            )
            await db.commit()
        return PairingTicket(token=token, expires_at_unix=expires, label=label)

    async def pair_device(
        self,
        pairing_token: str,
        device_id: str,
        device_secret: str,
        public_key_pem: str,
        label: str | None = None,
        *,
        device_access_token: str | None = None,
        request_hash: str | None = None,
        hardware_proved: bool = False,
        proved_binding_id: str | None = None,
    ) -> PairingResult:
        if not pairing_token:
            raise AuthError("pairing_ticket_invalid", "Pairing ticket invalid or expired")
        recoverable = device_access_token is not None
        if recoverable:
            if len(device_access_token) < 32 or not device_access_token.strip():
                raise AuthError("device_access_token_invalid", "Device access token must contain at least 32 characters")
            if not hardware_proved:
                raise AuthError("pairing_hardware_proof_required", "Pairing recovery requires a fresh hardware proof")
            if request_hash is None or len(request_hash) != 64 or any(c not in "0123456789abcdef" for c in request_hash):
                raise AuthError("pairing_request_invalid", "Pairing recovery requires an exact request digest")
        cipher = self._cipher()
        encrypted_secret = cipher.encrypt(device_secret.encode("utf-8")).decode("utf-8")
        secret_hash = hashlib.sha256(device_secret.encode("utf-8")).hexdigest()
        access_token = device_access_token if recoverable else secrets.token_urlsafe(32)
        access_token_hash = hashlib.sha256(access_token.encode("utf-8")).hexdigest()
        ticket_hash = hashlib.sha256(pairing_token.encode("utf-8")).hexdigest()
        async with self.store.connection() as db:
            await db.execute("BEGIN IMMEDIATE")
            from van_gateway.auth.retirement import require_enrollment_available, require_fresh_approval_key
            from van_gateway.auth.device_binding import DeviceBindingError
            try:
                await require_enrollment_available(db)
            except DeviceBindingError as exc:
                raise AuthError(exc.reason, "Owner device retirement is pending") from exc
            await require_fresh_approval_key(db, public_key_pem)
            # Waiting for the writer cannot extend a pairing ticket's authority.
            now = int(time.time())
            if recoverable or hardware_proved:
                # A handler's proof must still name a live hardware binding at the
                # enrollment's commit boundary. Revocation must not race a receipt retry.
                cur = await db.execute(
                    "SELECT binding_id, attestation_chain_verified FROM owner_device_bindings "
                    "WHERE device_id = ? AND owner_principal_id = 'owner' AND status = 'ACTIVE'",
                    (device_id,),
                )
                live_binding = await cur.fetchone()
                if live_binding is None:
                    await db.rollback()
                    raise AuthError("pairing_binding_inactive", "Pairing recovery requires an active hardware binding")
                if not live_binding["attestation_chain_verified"]:
                    await db.rollback()
                    raise AuthError("pairing_binding_unverified", "Pairing recovery requires a verified hardware attestation chain")
                if proved_binding_id != live_binding["binding_id"]:
                    await db.rollback()
                    raise AuthError("pairing_binding_changed", "Hardware binding changed after pairing proof")
            if recoverable:
                cur = await db.execute(
                    "SELECT device_id, request_hash, access_token_hash FROM pairing_attempts WHERE pairing_ticket_hash = ?",
                    (ticket_hash,),
                )
                attempt = await cur.fetchone()
                if attempt is not None:
                    if (
                        str(attempt["device_id"]) != device_id
                        or not hmac.compare_digest(str(attempt["request_hash"]), request_hash)
                        or not hmac.compare_digest(str(attempt["access_token_hash"]), access_token_hash)
                    ):
                        await db.rollback()
                        raise AuthError("pairing_recovery_conflict", "Pairing recovery does not match the original enrollment")
                    cur = await db.execute(
                        "SELECT device_id, public_key_pem, enrolled_at_unix, revoked_at_unix, label, access_token_hash "
                        "FROM devices WHERE device_id = ?",
                        (device_id,),
                    )
                    enrolled = await cur.fetchone()
                    if (
                        enrolled is None
                        or enrolled["revoked_at_unix"] is not None
                        or not hmac.compare_digest(str(enrolled["access_token_hash"] or ""), access_token_hash)
                    ):
                        await db.rollback()
                        raise AuthError("pairing_recovery_unavailable", "Original pairing credentials are no longer active")
                    await db.commit()
                    self._device_secrets[device_id] = device_secret.encode("utf-8")
                    return PairingResult(
                        DeviceRecord(
                            str(enrolled["device_id"]), str(enrolled["public_key_pem"]),
                            int(enrolled["enrolled_at_unix"]), None, enrolled["label"],
                        ),
                        access_token,
                    )
            cur = await db.execute(
                "SELECT label, expires_at_unix, used_at_unix FROM pairing_tickets WHERE ticket_hash = ?",
                (ticket_hash,),
            )
            ticket = await cur.fetchone()
            now = int(time.time())
            if ticket is None or ticket["used_at_unix"] is not None or int(ticket["expires_at_unix"]) <= now:
                await db.rollback()
                raise AuthError("pairing_ticket_invalid", "Pairing ticket invalid or expired")
            cur = await db.execute(
                "SELECT device_id, revoked_at_unix FROM devices WHERE device_id = ?",
                (device_id,),
            )
            existing = await cur.fetchone()
            if existing is not None:
                await db.rollback()
                code = "device_revoked" if existing["revoked_at_unix"] is not None else "already_enrolled"
                raise AuthError(code, "Device cannot be enrolled")
            effective_label = label or ticket["label"]
            # Awaited identity reads can cross expiry even after the writer was
            # acquired. Check before the first enrollment effect as well.
            now = int(time.time())
            if int(ticket["expires_at_unix"]) <= now:
                raise AuthError("pairing_ticket_invalid", "Pairing ticket invalid or expired")
            await db.execute(
                "INSERT INTO devices(device_id, public_key_pem, enrolled_at_unix, revoked_at_unix, label, encrypted_secret, access_token_hash) VALUES (?, ?, ?, NULL, ?, ?, ?)",
                (device_id, public_key_pem, now, effective_label, encrypted_secret, access_token_hash),
            )
            await db.execute(
                "INSERT INTO capability_grants(grant_id, device_id, capabilities_json, expires_at_unix, task_id, revoked_at_unix, created_at_unix) VALUES (?, ?, ?, ?, NULL, NULL, ?)",
                (
                    f"enroll-{device_id}",
                    device_id,
                    Store.dumps({"secret_sha256": secret_hash, "capabilities": ["owner"]}),
                    now + ENROLMENT_GRANT_SECONDS,
                    now,
                ),
            )
            await db.execute(
                "UPDATE pairing_tickets SET used_at_unix = ? WHERE ticket_hash = ? AND used_at_unix IS NULL",
                (now, ticket_hash),
            )
            if recoverable:
                await db.execute(
                    "INSERT INTO pairing_attempts(pairing_ticket_hash, device_id, request_hash, access_token_hash, created_at_unix) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (ticket_hash, device_id, request_hash, access_token_hash, now),
                )
            # None of these writes is public yet. Expiry during an awaited write
            # rolls back device, grant, consumed ticket and recovery receipt together.
            if int(ticket["expires_at_unix"]) <= int(time.time()):
                raise AuthError("pairing_ticket_invalid", "Pairing ticket invalid or expired")
            await db.commit()
        self._device_secrets[device_id] = device_secret.encode("utf-8")
        return PairingResult(DeviceRecord(device_id, public_key_pem, now, None, effective_label), access_token)

    async def require_access_token(self, access_token: str) -> DeviceRecord:
        if not access_token:
            raise AuthError("device_access_denied", "Device access token invalid or revoked")
        digest = hashlib.sha256(access_token.encode("utf-8")).hexdigest()
        row = await self.store.fetchone(
            "SELECT device_id, public_key_pem, enrolled_at_unix, revoked_at_unix, label FROM devices WHERE access_token_hash = ? AND revoked_at_unix IS NULL",
            (digest,),
        )
        if row is None:
            raise AuthError("device_access_denied", "Device access token invalid or revoked")
        return DeviceRecord(row["device_id"], row["public_key_pem"], int(row["enrolled_at_unix"]), None, row["label"])

    async def enroll(self, device_id: str, device_secret: str, public_key_pem: str, label: str | None = None) -> DeviceRecord:
        from van_gateway.auth.retirement import require_enrollment_available, require_fresh_approval_key
        from van_gateway.auth.device_binding import DeviceBindingError
        cipher = self._cipher()
        encrypted_secret = cipher.encrypt(device_secret.encode("utf-8")).decode("utf-8")
        secret_hash = hashlib.sha256(device_secret.encode("utf-8")).hexdigest()
        async with self.store.connection() as db:
            await db.execute("BEGIN IMMEDIATE")
            existing = await (await db.execute("SELECT revoked_at_unix FROM devices WHERE device_id=?", (device_id,))).fetchone()
            if existing is not None:
                if existing["revoked_at_unix"] is not None:
                    raise AuthError("device_revoked", "Device was revoked; re-enrollment denied")
                raise AuthError("already_enrolled", "Device already enrolled")
            try:
                await require_enrollment_available(db)
            except DeviceBindingError as exc:
                raise AuthError(exc.reason, "Owner device retirement is pending") from exc
            await require_fresh_approval_key(db, public_key_pem)
            now = int(time.time())
            await db.execute(
                "INSERT INTO devices(device_id, public_key_pem, enrolled_at_unix, revoked_at_unix, label, encrypted_secret) VALUES (?, ?, ?, NULL, ?, ?)",
                (device_id, public_key_pem, now, label, encrypted_secret),
            )
            await db.execute(
                "INSERT INTO capability_grants(grant_id, device_id, capabilities_json, expires_at_unix, task_id, revoked_at_unix, created_at_unix) VALUES (?, ?, ?, ?, NULL, NULL, ?)",
                (f"enroll-{device_id}", device_id, Store.dumps({"secret_sha256": secret_hash, "capabilities": ["owner"]}), now + ENROLMENT_GRANT_SECONDS, now),
            )
            await db.commit()
        self._device_secrets[device_id] = device_secret.encode("utf-8")
        return DeviceRecord(device_id, public_key_pem, now, None, label)

    async def grant_status(self, device_id: str, *, now: int | None = None) -> dict:
        """Where this device's enrolment grant stands: valid, due for renewal, or expired.

        P2-SEC-008 — nothing expired and nothing was rotated, so there was nothing to
        report. An expiry the owner cannot see coming is an outage waiting to happen.
        """
        stamp = int(time.time()) if now is None else now
        row = await self.store.fetchone(
            "SELECT expires_at_unix, revoked_at_unix, created_at_unix FROM capability_grants "
            "WHERE grant_id = ?",
            (f"enroll-{device_id}",),
        )
        if row is None:
            return {"device_id": device_id, "state": "ABSENT", "expires_at_unix": None}
        if row["revoked_at_unix"] is not None:
            return {"device_id": device_id, "state": "REVOKED", "expires_at_unix": int(row["expires_at_unix"])}
        expires = int(row["expires_at_unix"])
        remaining = expires - stamp
        if remaining <= 0:
            state = "EXPIRED"
        elif remaining <= GRANT_RENEWAL_WINDOW_SECONDS:
            state = "RENEW_SOON"
        else:
            state = "VALID"
        return {
            "device_id": device_id,
            "state": state,
            "expires_at_unix": expires,
            "seconds_remaining": max(0, remaining),
            "renew_within_seconds": GRANT_RENEWAL_WINDOW_SECONDS,
        }

    async def renew_grant(self, device_id: str, *, now: int | None = None) -> dict:
        """Extend a live enrolment grant. Refuses a revoked or expired one.

        An expired grant is deliberately not renewable: re-pairing is the path back, and
        silently reviving a grant the owner let lapse would make the expiry decorative.
        """
        async with self.store.connection() as db:
            await db.execute("BEGIN IMMEDIATE")
            cursor = await db.execute(
                "SELECT g.expires_at_unix, g.revoked_at_unix, "
                "d.revoked_at_unix AS device_revoked_at_unix "
                "FROM capability_grants g JOIN devices d ON d.device_id = g.device_id "
                "WHERE g.grant_id = ? AND g.device_id = ?",
                (f"enroll-{device_id}", device_id),
            )
            grant = await cursor.fetchone()
            # Check the live authority after acquiring the writer, never a pre-lock
            # status snapshot. Revocation and renewal share this same SQL boundary.
            stamp = int(time.time()) if now is None else now
            if (grant is None or grant["revoked_at_unix"] is not None
                    or grant["device_revoked_at_unix"] is not None
                    or int(grant["expires_at_unix"]) <= stamp):
                raise AuthError("grant_not_renewable", "Enrollment grant is absent, revoked or expired; pair the device again")
            await db.execute(
                "UPDATE capability_grants SET expires_at_unix = ? WHERE grant_id = ?",
                (max(int(grant["expires_at_unix"]), stamp + ENROLMENT_GRANT_SECONDS), f"enroll-{device_id}"),
            )
            # Check the original grant, not the proposed extension, after the write.
            commit_stamp = int(time.time()) if now is None else now
            if int(grant["expires_at_unix"]) <= commit_stamp:
                raise AuthError("grant_not_renewable", "Enrollment grant expired before renewal committed; pair the device again")
            await db.commit()
        return await self.grant_status(device_id, now=commit_stamp)

    async def expiring_grants(self, *, now: int | None = None) -> list[dict]:
        """Every live grant that is expired or due for renewal, for the degraded surface."""
        stamp = int(time.time()) if now is None else now
        rows = await self.store.fetchall(
            "SELECT grant_id, device_id, expires_at_unix FROM capability_grants "
            "WHERE revoked_at_unix IS NULL AND expires_at_unix <= ? ORDER BY expires_at_unix",
            (stamp + GRANT_RENEWAL_WINDOW_SECONDS,),
        )
        return [await self.grant_status(str(r["device_id"]), now=stamp) for r in rows]

    def remember_secret(self, device_id: str, device_secret: str) -> None:
        """Test/recovery helper; production restart restoration uses encrypted DB state."""
        self._device_secrets[device_id] = device_secret.encode("utf-8")

    async def revoke(self, device_id: str) -> dict:
        from van_gateway.auth.retirement import retire_device
        now = int(time.time() * 1000)
        async with self.store.connection() as db:
            await db.execute('BEGIN IMMEDIATE')
            row = await (await db.execute('SELECT public_key_pem FROM devices WHERE device_id=?', (device_id,))).fetchone()
            if row is None:
                raise AuthError("unknown_device", "Device not found")
            record = await retire_device(db, device_id=device_id, public_key_pem=row['public_key_pem'],
                                         now_ms=now, reason="device revoked")
            await db.commit()
        self._device_secrets.pop(device_id, None)
        return record

    async def require_device(self, device_id: str) -> DeviceRecord:
        row = await self.store.fetchone(
            "SELECT device_id, public_key_pem, enrolled_at_unix, revoked_at_unix, label FROM devices WHERE device_id = ?",
            (device_id,),
        )
        if row is None:
            raise AuthError("unknown_device", "Device not enrolled")
        if row["revoked_at_unix"] is not None:
            raise AuthError("device_revoked", "Device revoked")
        return DeviceRecord(
            row["device_id"],
            row["public_key_pem"],
            int(row["enrolled_at_unix"]),
            int(row["revoked_at_unix"]) if row["revoked_at_unix"] is not None else None,
            row["label"],
        )

    def sign(self, device_id: str, canonical: str) -> str:
        secret = self._device_secrets.get(device_id)
        if secret is None:
            raise AuthError("secret_unavailable", "Device secret not loaded in gateway process")
        return hmac.new(secret, canonical.encode("utf-8"), hashlib.sha256).hexdigest()

    def verify_signature(self, device_id: str, canonical: str, signature: str) -> None:
        expected = self.sign(device_id, canonical)
        if not hmac.compare_digest(expected, signature):
            raise AuthError("bad_signature", "Request signature invalid")

    @staticmethod
    def canonical_command(
        command_id: str,
        idempotency_key: str,
        device_id: str,
        issued_at_unix: int,
        text: str,
        action_class: str,
        project_id: str | None,
    ) -> str:
        """Legacy v1 canonical form retained only for default-provenance clients."""
        return "|".join(
            [
                command_id,
                idempotency_key,
                device_id,
                str(issued_at_unix),
                action_class,
                project_id or "",
                text,
            ]
        )

    @staticmethod
    def canonical_command_v3(
        *,
        command_id: str,
        idempotency_key: str,
        device_id: str,
        issued_at_unix: int,
        text: str,
        action_class: str,
        project_id: str | None,
        turn_id: str | None,
        origin_channel: str,
        principal_type: str,
        requested_by: str,
        expires_at_unix: int | None,
        nonce: str | None,
        context_capsule_revision: int | None,
        context_capsule_hash: str | None,
        speech_evidence_ref: str | None,
        speaker_evidence_milli: int | None,
        no_stale_replay: bool,
        context_trust: str,
    ) -> str:
        """Voice-aware authority envelope with deterministic fixed-point speaker evidence.

        v2 is retained byte-for-byte for existing clients. v3 adds only the signed
        speaker-evidence field; omitting it is still meaningful (UNAVAILABLE) and therefore
        cannot be rewritten in transit into a positive owner-speaker claim.
        """
        return "|".join(
            [
                "v3",
                command_id,
                idempotency_key,
                device_id,
                str(issued_at_unix),
                action_class,
                project_id or "",
                turn_id or "",
                origin_channel,
                principal_type,
                requested_by,
                str(expires_at_unix) if expires_at_unix is not None else "",
                nonce or "",
                str(context_capsule_revision) if context_capsule_revision is not None else "",
                context_capsule_hash or "",
                speech_evidence_ref or "",
                str(speaker_evidence_milli) if speaker_evidence_milli is not None else "",
                "1" if no_stale_replay else "0",
                context_trust,
                text,
            ]
        )

    @staticmethod
    def canonical_command_v2(
        *,
        command_id: str,
        idempotency_key: str,
        device_id: str,
        issued_at_unix: int,
        text: str,
        action_class: str,
        project_id: str | None,
        turn_id: str | None,
        origin_channel: str,
        principal_type: str,
        requested_by: str,
        expires_at_unix: int | None,
        nonce: str | None,
        context_capsule_revision: int | None,
        context_capsule_hash: str | None,
        speech_evidence_ref: str | None,
        no_stale_replay: bool,
        context_trust: str,
    ) -> str:
        """Rev 3.1 authority-bearing canonical form.

        Every field that can change provenance, privilege, replay behavior or
        context binding is covered by the device HMAC. ``client_context`` is
        deliberately excluded because it is a non-authoritative hint only.
        """
        return "|".join(
            [
                "v2",
                command_id,
                idempotency_key,
                device_id,
                str(issued_at_unix),
                action_class,
                project_id or "",
                turn_id or "",
                origin_channel,
                principal_type,
                requested_by,
                str(expires_at_unix) if expires_at_unix is not None else "",
                nonce or "",
                str(context_capsule_revision) if context_capsule_revision is not None else "",
                context_capsule_hash or "",
                speech_evidence_ref or "",
                "1" if no_stale_replay else "0",
                context_trust,
                text,
            ]
        )
