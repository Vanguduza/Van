from __future__ import annotations

import logging
import asyncio

from contextlib import asynccontextmanager
import base64
import binascii
import hmac
import hashlib
import json
import re
import shutil
import time
from typing import Any, Literal
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse, RedirectResponse
from pydantic import BaseModel, ConfigDict, Field, StrictBool, ValidationError

from van_gateway.action.service import ActionPolicyError
from van_gateway.artemis.console import ArtemisConsoleProxy
from van_gateway.attention.engine import AttentionEngine
from van_gateway.artifacts.api import build_artifact_router
from van_gateway.artifacts.service import ArtifactService
from van_gateway.audit.service import AuditService
from van_gateway.auth.service import AuthError, AuthService
from van_gateway.approval.service import OwnerApprovalError, OwnerApprovalService
from van_gateway.auth.control_scopes import ControlAuthority, ControlScope
from van_gateway.auth.rotation import CredentialRotation
from van_gateway.context.forget import OwnerMemory
from van_gateway.context.lifecycle import ContextLifecycle
from van_gateway.learning.feed import LearningFeed
from van_gateway.context.authoring import (
    ContextAuthoringError,
    OwnerFactAuthor,
    ProjectTruthImporter,
)
from van_gateway.auth.throttle import GLOBAL_SUBJECT, AuthThrottle, Throttled
from van_gateway.command.mission_link import CommandMissionLink
from van_gateway.briefing.service import BriefingService
from van_gateway.config import get_settings
from van_gateway.decisions.service import DecisionCreate, DecisionError, DecisionService
from van_gateway.documents.api import build_document_router
from van_gateway.documents.service import DocumentService
from van_gateway.goals.api import build_goal_router
from van_gateway.goals.service import GoalService
from van_gateway.goals.watch_runner import WatchRunner
from van_gateway.suggestions.api import build_suggestion_router
from van_gateway.suggestions.service import SuggestionService
from van_gateway.conversations.api import build_conversation_router
from van_gateway.conversations.service import ConversationService
from van_gateway.degraded.registry import DegradedRegistry
from van_gateway.dial_dev.api import build_dial_dev_router
from van_gateway.dial_dev.attention import DialDevAttentionIngest
from van_gateway.dial_dev.client import DialDevClient
from van_gateway.dial_dev.config import ACTIONS_PATH as DIAL_DEV_ACTIONS_PATH, DialDevConfig
from van_gateway.events.bus import EventBus
from van_gateway.google.control import GoogleControlAuthError, verify_internal_control
from van_gateway.google.planes import plane_health, summarise
from van_gateway.google.mesh import GoogleCapabilityRegistry, GoogleCapabilityRouter, GoogleIdentityBroker, GoogleRouteRequest
from van_gateway.google.service import GoogleAuthError, GoogleService, NARROW_SCOPES
from van_gateway.google.transport import FakeGoogleTransport, GoogleHttpTransport, GoogleOAuthTokenClient
from van_gateway.hermes.bridge import HermesBridge
from van_gateway.mtls.pki import DeviceCA, PkiError
from van_gateway.mtls.transport import mtls_device_id
from van_gateway.idempotency.service import IdempotencyService
from van_gateway.jev.client import JevProjectionClient, JevProposeActionClient
from van_gateway.jev.api import JevProjectionApi
from van_gateway.jev.advisor import JevVanAdvisor
from van_gateway.models import (
    ActionClass,
    AttentionSeverity,
    CommandRequest,
    OwnerApprovalProof,
    PrincipalType,
    ReminderCreate,
)
from van_gateway.notifications.intelligence import AppPolicy, NotificationIntelligence, PhoneNotification
from van_gateway.observability import alerts as observability_alerts
from van_gateway.observability import instruments as observability_instruments
from van_gateway.observability.correlation import for_command as correlation_for_command
from van_gateway.observability.logging import configure as configure_logging
from van_gateway.observability.metrics import REGISTRY as METRICS, render_prometheus
from van_gateway.observability.middleware import MetricsMiddleware
from van_gateway.observability.trace import CommandTracer
from van_gateway.coherence import owner_status
from van_gateway.coherence import wire_status
from van_gateway.ops import health as ops_health
from van_gateway.ops.backup import create_backup, drill as backup_drill
from van_gateway.ops.pki import scan as pki_scan
from van_gateway.ops.pki import scan_device as device_pki_scan
from van_gateway.ops.retention import RetentionService
from van_gateway.ops.scheduler import OpsScheduler, ScheduledJob
from van_gateway.ops.suppression import SuppressionChannel, SuppressionStore
from van_gateway.orchestrator import CommandOrchestrator
from van_gateway.projects.router import ProjectRouter
from van_gateway.proactive.autonomy import ActionAutonomyGate, DomainTrustService
from van_gateway.proactive.followups import ProactiveFollowUpJob
from van_gateway.trading.bridge import TradingEventBridge
from van_gateway.trading.oauth_effects import OAuthEffectUnconfirmed, OAuthTargetBlocked
from van_gateway.reminders.service import ReminderService, ReminderConflict
from van_gateway.reminders.timeparse import TimeParseError, parse_due_expression
from van_gateway.automation.api import AutomationApi
from van_gateway.automation.dispatch import AutomationDispatcher
from van_gateway.automation.worker_runtime import AutomationWorkerRuntime, WorkerWorkflowObserver
from van_gateway.automation.grants import RunGrantService
from van_gateway.automation.health import AutomationHealthApi
from van_gateway.automation.registry import AutomationRegistry, HotWorkflowIndex
from van_gateway.automation.temporal_bridge import TemporalAutomationApi
from van_gateway.browser.agent_grant import AgentGrantService
from van_gateway.browser.api import BrowserApi
from van_gateway.browser.control_lease import ControlLeaseService
from van_gateway.browser.downloads import DownloadBroker
from van_gateway.browser.downloads_api import build_download_report_router
from van_gateway.browser.interactive_api import (
    build_interactive_router,
    is_interactive_browser_owner_route,
)
from van_gateway.browser.interactive_service import InteractiveSessionService
from van_gateway.browser.producer_api import (
    build_browser_producer_router,
    is_browser_producer_consumer_route,
)
from van_gateway.browser.producer_service import BrowserProducerService
from van_gateway.browser.quality_api import QualityControllers, build_quality_router
from van_gateway.computer_use.api import build_computer_use_router
from van_gateway.computer_use.fabric import ComputerInteractionFabric, Surface
from van_gateway.computer_use.worker import DockerComputerConfig, DockerComputerWorker
from van_gateway.connectivity.provisioning import (
    build_provisioning_payload,
    sign_provisioning_payload,
    PROVISIONING_TTL_MS,
    validate_gateway_url,
)
from van_gateway.browser.stream_grants import (
    SigningKey,
    StreamGrantService,
    StreamGrantSigner,
)
from van_gateway.browser.worker import HybridBrowserWorker
from van_gateway.browser.interaction_router import (
    IndependentPostconditionVerifier,
    build_interaction_router,
    build_interaction_routes,
)
from van_gateway.session.api import build_session_router, is_session_owner_route
from van_gateway.voice.speech_stream import SpeechStreamService
from van_gateway.voice.responses import BoundSpeechResponses, build_voice_router, with_spoken_result
from van_gateway.session.router import (
    CURRENT_OPERATION,
    SessionDelegateError,
    SessionDelegates,
    SessionRouter,
)
from van_gateway.session.service import VanHermesSessionService
from van_gateway.auth.device_binding import DeviceBindingError, OwnerDeviceBindingService
from van_gateway.auth.device_proof import AttestationPolicy, DeviceProofError, verify_attestation_chain, verify_request_proof
from van_gateway.connectivity.config import ConnectivityConfigService, ConnectivityError
from van_gateway.capability.models import ReadinessSource
from van_gateway.capability.readiness import (
    AutomationReadiness,
    ExternalRuntimeReadiness,
    GoogleMeshReadiness,
    OwnerArtifactProviderReadiness,
    GatewayLocalReadiness,
)
from van_gateway.capability.registry import CapabilityRegistry
from van_gateway.capability.router import CapabilityRouter
from van_gateway.mission.api import MissionApi
from van_gateway.mission.models import MissionEventType, MissionState
from van_gateway.mission.service import MissionError
from van_gateway.mission.binding import MissionBinder
from van_gateway.understanding.api import UnderstandingApi
from van_gateway.verification.production import build_automation_verifier, build_mission_registry
from van_gateway.mission.service import MissionService
from van_gateway.command.authority import CommandAuthorityService
from van_gateway.command.standing import StandingAutomationAuthorityService
from van_gateway.runtime_api import OwnerRuntimeApi
from van_gateway.storage.db import Store
from van_gateway.trading import TradingAuthorityError, TradingControlError, TradingService
from van_gateway.visual.acceptance import VisualAcceptanceError, VisualAcceptanceService
from van_gateway.trading.accounts import ACTIONS as ACCOUNT_ACTIONS, AccountOnboarding, CommanderAccountControl, LocalAccountControl, OAuthPending, canonical_action, account_approval_text, redact as redact_account_args, requires_owner_approval
from van_gateway.trading.account_contracts import AccountChallengeResponse,AccountActionCatalog
from van_gateway.trading.strategies import StrategyPromotionGateway, canonical_strategy_promotion
from van_gateway.trading.runtime_controls import register_runtime_control_routes
from van_gateway.trading.runtime_recovery_dispatch import RuntimeRecoveryDispatcher
from van_gateway.auth.native_revocation import NativeOwnerRevocations, DeviceRevocationResponse, NativeOwnerKeyRevocationState


class VisualAcceptanceBody(BaseModel):
    token: str
    rive_sha256: str
    apk_sha256: str
    device_model: str
    android_build: str


class EnrollBody(BaseModel):
    """The device identity an enrolment establishes.

    P4-DOC-004 — these fields are documented here, once. `PairDeviceBody` inherits them
    and adds only what pairing adds, rather than restating them: the two descriptions had
    already drifted apart once, and a field whose meaning is written down twice is a field
    whose meaning is eventually written down two different ways.
    """

    device_id: str = Field(
        description="Stable identifier for this device. Chosen by the enroller, not the device.",
    )
    device_secret: str = Field(
        description=(
            "Shared HMAC secret for command signing. Stored encrypted; never returned, "
            "never logged, and never placed in a prompt."
        ),
    )
    public_key_pem: str = Field(
        description=(
            "P-256 public key for owner approval proofs (A4). The private half stays in "
            "the device's hardware keystore and never leaves it."
        ),
    )
    label: str | None = Field(
        default=None,
        description="Human-readable name for this device in the owner's device list.",
    )


class PairDeviceBody(EnrollBody):
    """Enrolment plus the ticket that authorises it.

    Pairing is enrolment performed by the owner's own device with an operator-issued
    ticket. An optional client-known access token permits a hardware-proved exact retry.
    """

    pairing_token: str = Field(
        min_length=32,
        description=(
            "Single-use ticket from POST /v1/devices/pairing-ticket. Consumed atomically "
            "with the enrolment, so a replayed pairing cannot mint a second device."
        ),
    )
    device_access_token: str | None = Field(
        default=None,
        min_length=32,
        max_length=512,
        description=(
            "Client-generated token persisted before pairing. With a fresh bound-hardware "
            "proof, an exact request retry can recover the original enrollment response."
        ),
    )


class PairingTicketCreate(BaseModel):
    label: str | None = None
    ttl_seconds: int = Field(default=600, ge=60, le=3600)


class GoogleConnectBody(BaseModel):
    refresh_token: str
    scopes: list[str] = Field(default_factory=lambda: list(NARROW_SCOPES))


class GoogleAuthorizedActionBody(BaseModel):
    execution_id: str = Field(min_length=1, max_length=256)
    parameters: dict[str, Any] = Field(default_factory=dict)


class GoogleArtifactBody(BaseModel):
    source_tool: str
    output_hash: str
    project_id: str | None = None
    tool_version: str | None = None
    input_hashes: list[str] = Field(default_factory=list)
    trust: str = "UNTRUSTED"
    validation_state: str = "PENDING"
    parent_artifact_ids: list[str] = Field(default_factory=list)


class AttentionUpsertBody(BaseModel):
    title: str
    severity: AttentionSeverity
    source: str
    dedupe_key: str
    project_id: str | None = None


class AttentionSnoozeBody(BaseModel):
    until_unix: int = Field(gt=0)


class ReminderParseBody(BaseModel):
    text: str
    due_expression: str
    idempotency_key: str
    project_id: str | None = None


class ProjectTruthBody(BaseModel):
    truth: dict
    truth_sha: str
    repo_sha: str | None = None


class DecisionResolveBody(BaseModel):
    approved: StrictBool


class AccountActionRequest(BaseModel):
    device_id: str
    issued_at_unix: int
    signature: str
    action: str
    args: dict = Field(default_factory=dict)
    #: P1-SEC-004 — required for every action that changes an account or a credential.
    #: The device signs the gateway's one-time challenge inside the biometric callback
    #: with a keystore key, so a prompt that merely succeeded is not authority.
    approval_proof: OwnerApprovalProof | None = None


class AccountActionConflictResponse(BaseModel):
    detail: str
    effect_state: Literal["REFUSED","UNKNOWN"]
    reconciliation_required: bool
    operation_id: str | None = None


class AccountOperationResponse(BaseModel):
    operation_id: str
    action: str
    effect_state: Literal["APPLIED", "REFUSED", "UNKNOWN"]
    native_phase: Literal["IN_FLIGHT", "APPLIED", "REFUSED", "UNKNOWN"]
    reconciliation_required: bool
    result: dict | None = None
    native_event_ref: str


class AccountChallengeRequest(BaseModel):
    device_id: str
    issued_at_unix: int
    signature: str
    action: str
    args: dict = Field(default_factory=dict)


class StrategyPromotionChallengeRequest(BaseModel):
    device_id: str
    issued_at_unix: int
    signature: str
    strategy_id: str = Field(min_length=1)
    target_state: str = Field(min_length=1)
    owner_signature_ref: str = Field(min_length=1)
    certificate: dict
    evidence_refs: list[str] = Field(default_factory=list)


class StrategyPromotionRequest(StrategyPromotionChallengeRequest):
    approval_proof: OwnerApprovalProof | None = None


class OwnerFactBody(BaseModel):
    subject: str = Field(min_length=1)
    predicate: str = Field(min_length=1)
    value: Any
    scope: str = "global"
    valid_until_ms: int | None = None


class DeviceTelemetrySample(BaseModel):
    """One device-produced measurement (P3-OBS-002).

    The name must be one the catalogue declares — see
    `instruments.DEVICE_HISTOGRAMS` and `DEVICE_GAUGES`. An unknown name is
    refused rather than registered, because a metric that appears at runtime with
    no declared producer is exactly the drift Gate 11 exists to stop.
    """

    name: str
    value: float
    surface: str | None = None
    #: The one dimension a series other than `aura_frame_time_ms` may carry — the
    #: storability of a queued command, today. Kept separate from `surface` because
    #: `surface` is already on the wire and shipped devices post it; renaming it here
    #: would quietly drop the aura label from every phone that had not been updated.
    dimension: str | None = None


class DeviceTelemetryBody(BaseModel):
    samples: list[DeviceTelemetrySample] = Field(default_factory=list)


class OwnerHaltRequest(BaseModel):
    owner_signature_ref: str = Field(min_length=1)
    reason: str = ""


class TicketConfirmRequest(BaseModel):
    owner_signature_ref: str = Field(min_length=1)
    fill_price: str
    filled_qty: str
    contract_note_ref: str = Field(min_length=1)


#: Google routes that require the internal-control credential at the GOOGLE scope.
#:
#: One set with two readers. `control_scope_for` decides what the middleware demands, and
#: the guard below it decides what the handler-level check expects; they held separate
#: copies of this list. A route in one and missing from the other is not an inconsistency,
#: it is a hole — an unscoped route falls through to owner-device authentication, and
#: reaching the owner's Gmail with a device token is the fall-through P0-SEC-001 closed.
#:
#: P2-GOOG-004 added the six in the middle, which had a transport, a service method and no
#: route at all.
GOOGLE_CONTROL_ROUTES: frozenset[str] = frozenset({
    "/v1/google/gmail/search",
    "/v1/google/calendar/review",
    "/v1/google/gmail/attachment/import-pdf",
    "/v1/google/gmail/thread",
    "/v1/google/actions/execute",
    "/v1/google/gmail/send",
    "/v1/google/gmail/draft",
    "/v1/google/calendar/agenda",
    "/v1/google/calendar/reschedule",
    "/v1/google/drive/search",
    "/v1/google/contacts/resolve",
    "/v1/google/tasks",
    "/v1/google/connect",
    "/v1/google/revoke",
    "/v1/google/jobs/plan",
})


class BootstrapCreateBody(BaseModel):
    note: str | None = None


class ProvisioningPayloadBody(BaseModel):
    """ADR-RB-026 — what the installer asks for, which is deliberately almost nothing.

    The installer names the Gateway the device should reach, because it is the only party
    that knows which deployment this is. Everything else — the one-time credential, the
    attestation challenge, the expiry — is the Gateway's to mint, so that an installer
    cannot extend a provisioning window or reuse a token by asking for it.
    """

    gateway_url: str = Field(min_length=1)
    note: str | None = None

class BootstrapChallengeBody(BaseModel):
    token: str

class BootstrapAttestBody(BaseModel):
    token: str
    device_id: str
    public_key_pem: str
    #: Base64 of the raw attestation extension octets from the device key's certificate.
    attestation_extension_b64: str
    attestation_chain_b64: list[str] = Field(min_length=2, max_length=8)
    attestation_root_fingerprint: str | None = None
    os_version: str | None = None
    os_patch_level: str | None = None

class BootstrapRecoverBody(BaseModel):
    token: str = Field(min_length=32, max_length=256)
    device_id: str = Field(min_length=1, max_length=128)

class CertifyBindingBody(BaseModel):
    attestation_chain_b64: list[str] = Field(min_length=2, max_length=8)

class ProvisioningStatusBody(BaseModel):
    bootstrap_token: str = Field(min_length=32, max_length=256)

class RebindBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=1, max_length=1000)
    operation_id: str | None = Field(default=None, min_length=16, max_length=128)
    expected_binding_id: str | None = None
    expected_bound_at_ms: int | None = Field(default=None, strict=True, ge=0)
    gateway_url: str | None = None


def _read_stream_signing_key(path: str) -> str:
    """Load the grant-signing key from disk (§5.5: it never leaves the Gateway host).

    A missing or unreadable file raises rather than falling back to a generated key. A
    gateway that quietly generates its own would mint grants the stream host cannot verify,
    and the failure would appear as "the browser will not connect" on the owner's phone
    rather than as a misconfiguration here.
    """
    return Path(path).read_text(encoding="utf-8")


def _parse_ice_servers(raw: str) -> list[dict]:
    """Deployment configuration. Malformed JSON is empty rather than fatal: no ICE server
    means direct connectivity only, which is a degraded browser, not a broken gateway."""
    try:
        parsed = json.loads(raw or "[]")
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []


def create_app() -> FastAPI:
    settings = get_settings()
    store = Store(settings.database_path)
    artemis_console = ArtemisConsoleProxy(
        upstream_base_url=settings.artemis_console_base_url,
        upstream_token_file=settings.artemis_console_token_file,
        public_base_url=settings.van_public_base_url,
        session_ttl_seconds=settings.artemis_console_session_ttl_seconds,
        launch_ttl_seconds=settings.artemis_console_launch_ttl_seconds,
        enabled=settings.artemis_console_enabled,
    )
    auth = AuthService(store, settings.device_secret_fernet_key)
    throttle = AuthThrottle()
    rotation = CredentialRotation(store)
    # P0-CTX-002 — writers for the authoritative epistemic tiers, which had none.
    # P0-SEC-001 — scoped privileged credentials, so one token is no longer root.
    control_authority = ControlAuthority(
        legacy_token=settings.internal_control_token,
        scoped=settings.internal_control_scoped_tokens,
        device_enrolment_token=settings.device_enrolment_token,
        observability_token=settings.observability_token,
    )
    idempotency = IdempotencyService(store)
    hermes = HermesBridge(settings.hermes_base_url, settings.hermes_bearer_token, settings.hermes_profile)
    project_registry_path = str(Path(__file__).resolve().parents[2] / "registries" / "projects.json")
    google_registry_path = str(Path(__file__).resolve().parents[2] / "registries" / "google_capabilities.json")
    projects = ProjectRouter(store, project_registry_path)
    audit = AuditService(store)
    degraded = DegradedRegistry()
    jev_advisor = JevVanAdvisor(
        base_url=settings.jev_base_url,
        token_file=settings.jev_consumer_token_file,
        enabled=settings.jev_enabled,
        timeout_seconds=min(settings.jev_timeout_seconds, 1.2),
    )
    jev_projection = JevProjectionApi(
        JevProjectionClient(
            base_url=settings.jev_base_url,
            read_token_file=settings.jev_projection_token_file,
            control_token_file=settings.jev_control_token_file,
            enabled=settings.jev_enabled,
            timeout_seconds=settings.jev_timeout_seconds,
        ),
        degraded,
    )
    attention = AttentionEngine(store, settings.attention_budget_per_hour, jev_advisor=jev_advisor)
    artifacts = ArtifactService(store)
    documents = DocumentService(store, artifacts)
    goals = GoalService(store, attention)
    suggestions = SuggestionService(store, attention)
    conversations = ConversationService(store)
    briefing = BriefingService(store, attention)
    reminders = ReminderService(store)
    decisions = DecisionService(store, attention)
    # GAP-F-003/002: the Hermes-facing runtime can read attention/briefing, create
    # reminders on the owner's behalf and (below, once constructed) read trading state.
    domain_trust = DomainTrustService(store)
    owner_runtime = OwnerRuntimeApi(
        store, settings, reminders=reminders, attention=attention, briefing=briefing,
        artifacts=artifacts, suggestions=suggestions, conversations=conversations,
        # GAP-F-008: agent-initiated mutations consult the earned/granted domain trust.
        autonomy=ActionAutonomyGate(domain_trust),
        jev_advisor=jev_advisor,
    )
    owner_runtime.bind_decisions(decisions)
    automation_registry = AutomationRegistry(store)
    automation_hot_index = HotWorkflowIndex()
    computer_worker = DockerComputerWorker(DockerComputerConfig(
        enabled=settings.computer_worker_enabled,
        image=settings.computer_worker_image,
        deployment_id=settings.computer_worker_deployment_id,
        timeout_seconds=settings.computer_worker_timeout_seconds,
        qualification_file=settings.computer_worker_qualification_file,
    ))
    computer_use = ComputerInteractionFabric(
        store,
        worker_impls=(
            {Surface.TERMINAL: computer_worker}
            if settings.computer_worker_enabled else {}
        ),
    )
    # One index, so `/v1/automation/health` reports the index work is routed
    # through rather than an empty copy of it.
    automation_health = AutomationHealthApi(
        store, settings, degraded=degraded, hot_index=automation_hot_index,
        computer_use=computer_use,
    )
    # The dispatcher shares the owner runtime's ActionRuntime and command
    # authority: an automation run must meet the same single final authority
    # check as everything else VAN does, not a second copy of it.
    automation_dispatcher = AutomationDispatcher(
        store,
        actions=owner_runtime.actions,
        authority=owner_runtime.authority,
        registry=automation_registry,
        grants=RunGrantService(store, signing_key=settings.automation_grant_signing_key),
        client=automation_health.n8n,
        enabled=settings.automation_enabled,
    )
    automation = AutomationApi(
        store,
        settings,
        registry=automation_registry,
        hot_index=automation_hot_index,
        standing=StandingAutomationAuthorityService(store, owner_runtime.authority),
        dispatcher=automation_dispatcher,
    )
    automation_worker = AutomationWorkerRuntime(
        store, grants=automation_dispatcher.grants, actions=owner_runtime.actions,
        authority=owner_runtime.authority, registry=automation_registry,
        enabled=settings.automation_enabled, settings=settings,
    )
    automation.worker = automation_worker
    # Critical durable coordination is a separate Temporal runtime, not an n8n workflow.
    # It is repository-complete even when this host has not yet supplied the deployment
    # bridge URL/token; in that state its routes fail closed and health says UNCONFIGURED.
    temporal_automation = TemporalAutomationApi(settings)
    # P2-BROW-001 — one production browser worker spans the two admitted runtimes.
    # Deterministic tiers drive Browser Harness. Semantic tiers use Stagehand to propose one
    # observed action at a time, but BrowserSubagentRunner remains the authority boundary
    # and Browser Harness independently reads the page after every semantic action.
    browser = BrowserApi(
        store, settings, decisions=decisions,
        worker=HybridBrowserWorker(
            automation_health.harness,
            automation_health.stagehand,
        ),
        # Owner decision 2026-09-29 §7 — a worker's "done" is a claim; this independent
        # read-back verifier is the only thing that turns it into COMPLETED.
        verifier=IndependentPostconditionVerifier(automation_health.harness),
    )
    # Programme B / B5 — the interaction router rides on the same harness and Stagehand
    # adapters; it has no browser of its own. The eligibility classifier (B2) is imported
    # lazily and a missing classifier or verifier disables the Jev lane with a recorded
    # reason. `browser_interaction_router_enabled` defaults False.
    browser_interaction = build_interaction_router(
        settings=settings,
        harness=automation_health.harness,
        stagehand=automation_health.stagehand,
        store=store,
        jev_client=JevProposeActionClient(
            base_url=settings.jev_base_url,
            token_file=settings.jev_consumer_token_file,
            enabled=settings.jev_enabled,
            timeout_seconds=min(settings.jev_timeout_seconds, 1.2),
        ),
    )
    browser.interaction_router = browser_interaction
    # Unit G11 (review I7 MAJOR-1) — every page lease the browser fabric gives back ends the
    # Harness's network guard for it: the page is frozen, then interception is removed.
    browser.broker.page_release_hook = getattr(automation_health.harness, "release_page", None)

    watch_runner = WatchRunner(
        goals,
        tasks=browser.tasks,
        broker=browser.broker,
        harness=automation_health.harness,
    )


    trading = TradingService(
        settings.vati_ledger_path,
        accounts_registry=settings.vati_accounts_registry,
        lake_root=settings.vati_lake_root,
        reporting_currency=settings.vati_reporting_currency,
        native_source_root=settings.vati_native_source_root,
        native_catalog_ledger_path=settings.vati_native_catalog_ledger_path,
        native_history_max_bytes=settings.vati_native_history_max_bytes,
    )
    visual_acceptance = VisualAcceptanceService(store)
    # GAP-F-003: Hermes reads the same trading read models the owner sees, through
    # /v1/runtime/trading/* (RUNTIME scope). Never a mutation.
    owner_runtime.trading = trading
    account_control = (
        CommanderAccountControl(settings.van_commander_url, settings.van_commander_token_file, settings.van_commander_ca_file)
        if settings.van_commander_url
        else LocalAccountControl(settings.vati_accounts_registry, settings.vati_secrets_dir, operation_ledger=settings.vati_ledger_path)
    )
    oauth_pending = OAuthPending(store, settings.google_token_fernet_key)
    onboarding = AccountOnboarding(account_control, oauth_pending, settings.van_public_base_url, settings.vati_deriv_app_id)
    strategy_promotions = StrategyPromotionGateway(
        account_control if settings.van_commander_url else None
    )

    google_transport = None
    google_oauth = None
    if settings.google_oauth_client_id and settings.google_oauth_client_secret:
        google_transport = GoogleHttpTransport()
        google_oauth = GoogleOAuthTokenClient(settings.google_oauth_client_id, settings.google_oauth_client_secret)
    google = GoogleService(
        store,
        settings.google_token_fernet_key,
        transport=google_transport,
        oauth=google_oauth,
        documents=documents,
    )
    google_registry = GoogleCapabilityRegistry(google_registry_path)
    google_broker = GoogleIdentityBroker(
        store,
        google_registry,
        ai_plan=settings.google_ai_plan,
        cloud_project_id=settings.google_cloud_project_id,
        gemini_runtime_configured=settings.google_gemini_runtime_configured,
        cloud_runtime_configured=settings.google_cloud_runtime_configured,
        consumer_connected_capabilities=settings.google_consumer_connected_capabilities,
    )
    # Rev 1 §7 — one canonical declaration set. Readiness is delegated to the
    # subsystems that already own it, so this registry never becomes a third
    # copy of automation or Google state.
    capability_registry = CapabilityRegistry(
        store,
        probes={
            ReadinessSource.GATEWAY_LOCAL: GatewayLocalReadiness(lambda: browser_resume),
            ReadinessSource.AUTOMATION_REGISTRY: AutomationReadiness(
                store, enabled=settings.automation_enabled
            ),
            ReadinessSource.GOOGLE_MESH: GoogleMeshReadiness(google_broker),
            ReadinessSource.EXTERNAL_RUNTIME: ExternalRuntimeReadiness(
                automation_health.runtime, enabled=settings.browser_enabled
            ),
            ReadinessSource.OWNER_ARTIFACT_PROVIDER: OwnerArtifactProviderReadiness(lambda: browser_artifacts),
        },
    )
    capability_router = CapabilityRouter(store, capability_registry)
    # Constructed before the mission service, which publishes every owner-visible
    # mission event to it (P0-EXEC-001).
    events = EventBus(store, settings.event_page_size)
    # Closed trades become owner-visible events (Activity feed, embodiment CELEBRATE
    # on GOOD_DECISION_GOOD_OUTCOME only). A projection of the ledger, never an authority.
    trading_event_bridge = TradingEventBridge(store, trading, events)
    from van_gateway.trading.monitor_service import MarketMonitorService
    from van_gateway.trading.monitor_source import LedgerMonitorSource
    market_monitors = MarketMonitorService(store, LedgerMonitorSource(trading), events=events, attention=attention)

    # Rev 1.5 §§5, 6 — the interactive browser session.
    #
    # It shares the Browser Fabric's broker and policy engine rather than constructing its
    # own: ADR-RB-005 says the existing fabric owns browser authority, and two brokers would
    # mean two answers to "who holds this profile".
    browser_control_leases = ControlLeaseService(store)
    interactive_sessions = InteractiveSessionService(
        store, browser.broker, browser_control_leases, events=events,
    )
    # §5.5 — a dedicated ES256 key, separate from owner approval and device enrolment.
    # Absent configuration means grants cannot be minted, which is the honest state of a
    # deployment with no stream host: the routes refuse rather than issuing a credential
    # nothing can verify.
    browser_stream_grants = (
        StreamGrantService(
            store,
            StreamGrantSigner(SigningKey(
                kid=settings.browser_stream_signing_kid,
                private_pem=_read_stream_signing_key(settings.browser_stream_signing_key_file),
            )),
        )
        if settings.browser_stream_signing_key_file
        else None
    )

    browser_producers = (
        BrowserProducerService(
            store=store,
            sessions=interactive_sessions,
            grants=browser_stream_grants,
            control_proxy_bindings=settings.browser_control_proxy_bindings,
        )
        if browser_stream_grants is not None else None
    )
    profile_clients = {}
    if browser_producers is not None and (settings.browser_control_client_address or
            settings.browser_control_profile_clients.strip() != "{}"):
        from services.browser_control_agent.client import BrowserControlClient, ControlClientConfig
        from van_gateway.browser.interactive_worker import InteractiveAssignmentFactory, build_profile_control_clients
        profile_clients = build_profile_control_clients(settings.browser_control_profile_clients,
            caller_common_name=settings.browser_control_client_common_name)
        browser.interactive_worker_factory = InteractiveAssignmentFactory(
            producers=browser_producers, store=store,
            client=None if profile_clients else BrowserControlClient(ControlClientConfig(
                address=settings.browser_control_client_address,
                port=settings.browser_control_client_port,
                server_name=settings.browser_control_client_server_name,
                ca_file=settings.browser_control_client_ca_file,
                cert_file=settings.browser_control_client_cert_file,
                key_file=settings.browser_control_client_key_file,
            )),
            caller_common_name=settings.browser_control_client_common_name,
            proxy_principal_sha256=settings.browser_control_proxy_principal_sha256,
            profile_clients=profile_clients,
        )

    # P0-VERIFY-001 — the registry that performs verification, rather than a receipt
    # the claimant writes. Built before the service because the service fails closed
    # without it.
    from van_gateway.browser.action_plans import BrowserActionPlanService, build_action_plan_router
    browser_action_plans = (BrowserActionPlanService(
        store=store, sessions=interactive_sessions, producers=browser_producers,
        command_authority=owner_runtime.authority, profile_clients=profile_clients,
    ) if browser_producers is not None else None)

    from cryptography.hazmat.primitives import serialization
    from van_gateway.browser.artifact_admission import (OwnerArtifactAdmissionService,
        load_artifact_provider_config, build_artifact_admission_router, build_artifact_provider_claim_router)
    from van_gateway.auth.provider_transport import (ProviderTransportAuthenticator,
        is_artifact_provider_route, load_artifact_transport_bindings)

    # The admission signer is dedicated to file effects. Connectivity and stream
    # keys cannot be reused to mint authority for a remote evidence namespace.
    excluded_artifact_signers = []
    for key_file in (settings.browser_stream_signing_key_file, settings.connectivity_signing_key_file):
        if key_file:
            key = serialization.load_pem_private_key(_read_stream_signing_key(key_file).encode(), password=None)
            excluded_artifact_signers.append(hashlib.sha256(key.public_key().public_bytes(
                serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)).hexdigest())
    artifact_config = load_artifact_provider_config(settings.browser_artifact_providers_file,
        disallowed_signer_public_sha256=tuple(excluded_artifact_signers))

    def current_artifact_configuration() -> bool:
        if not settings.browser_artifact_providers_file or not artifact_config["configuration_sha256"]:
            return False
        try:
            with Path(settings.browser_artifact_providers_file).open("rb") as configured:
                encoded = configured.read(65537)
            return (len(encoded) <= 65536 and
                    hashlib.sha256(encoded).hexdigest() == artifact_config["configuration_sha256"])
        except OSError:
            return False

    artifact_provider_auth = ProviderTransportAuthenticator(
        lambda: load_artifact_transport_bindings(settings.browser_artifact_providers_file))
    browser_artifacts = OwnerArtifactAdmissionService(store=store, sessions=interactive_sessions,
        producers=browser_producers, command_authority=owner_runtime.authority,
        providers=artifact_config["providers"], source_clients=artifact_config["source_clients"],
        signer=artifact_config["signer"], current_configuration=current_artifact_configuration)

    from van_gateway.browser.resume import BrowserResumeService
    browser_resume = BrowserResumeService(browser, owner_runtime.authority)
    browser.resume_authorizations = browser_resume

    verifiers = build_mission_registry(
        store=store, trading=trading, knowledge=owner_runtime.knowledge, google=google, browser_plans=browser_action_plans, automation=automation,
        browser_artifacts=browser_artifacts, browser_resume=browser_resume, jev=jev_projection.client,
    )
    # P1-AUTO-001 — the dispatcher was constructed with an empty observer map, so every
    # production run came back UNVERIFIABLE and owner_success could never be true; the
    # tests passed only because they injected their own observers. Assigned here rather
    # than at construction because the Google service the READ_BACK observer reads is
    # built after the dispatcher, and reordering that is a larger change than this is.
    automation_dispatcher.verifier = build_automation_verifier(store=store, google=google)
    automation_dispatcher.verifier.observers["AUTOMATION_WORKER_READ_BACK"] = WorkerWorkflowObserver(automation_worker)
    learning = LearningFeed(store)
    missions = MissionService(
        store, capabilities=capability_registry, bus=events, verifiers=verifiers,
        learning=learning,
    )
    owner_runtime.bind_missions(missions)
    mission_api = MissionApi(
        store, settings, missions=missions, registry=capability_registry,
        router=capability_router,
    )
    # §5 — one binder shared by every executor, so browser tasks and
    # automation runs become Activities as they happen rather than by a
    # later backfill.
    owner_fact_author = OwnerFactAuthor(owner_runtime.context)
    truth_importer = ProjectTruthImporter(owner_runtime.context)
    # P2-MEM-002 — the owner's ability to end what VAN concluded about them.
    owner_memory = OwnerMemory(store)
    context_lifecycle = ContextLifecycle(store, owner_runtime.context)
    mission_binder = MissionBinder(store, missions)
    from van_gateway.browser.task_preparation import BrowserTaskPreparationService
    browser_preparation = (BrowserTaskPreparationService(store=store,sessions=interactive_sessions,
        producers=browser_producers,tasks=browser.tasks,binder=mission_binder,command_authority=owner_runtime.authority)
        if browser_producers is not None else None)

    # P0-EXEC-001 — the join that makes an accepted command a durable mission.
    command_missions = CommandMissionLink(
        missions, execution_deadline_seconds=settings.execution_deadline_seconds,
    )
    browser.binder = mission_binder
    automation.binder = mission_binder
    understanding_api = UnderstandingApi(store, settings, jev_advisor=jev_advisor)
    # GAP-F-028: VAN's only self-initiated behaviour — bounded FOLLOW_UP attention items
    # for work the owner left waiting. Never opens a mission or executes an action.
    proactive_followups = ProactiveFollowUpJob(
        store, attention, missions, decisions, understanding_api.policies,
    )
    google_router = GoogleCapabilityRouter(store, google_broker)

    # VAN-DEV-001/002 (DIAL VAN-DEVCC-R1 §3.4) — the DIAL development projection proxy
    # and the Attention ingestion that follows DIAL's event stream. VAN displays DIAL
    # state and forwards typed owner commands; it forms no agent loop of its own.
    dial_dev_config = DialDevConfig.from_settings(settings)
    dial_dev_client = DialDevClient(dial_dev_config)
    dial_dev_attention = DialDevAttentionIngest(
        dial_dev_client, attention, degraded=degraded, events=events,
    )

    # P3-OPS-005 — dedupe that survives a restart, instead of a set() on the instance.
    suppressions = SuppressionStore(store)
    notifications = NotificationIntelligence(suppressions=suppressions)
    retention = RetentionService(store)
    tracer = CommandTracer(store)
    orchestrator = CommandOrchestrator(
        auth=auth,
        idempotency=idempotency,
        hermes=hermes,
        projects=projects,
        audit=audit,
        degraded=degraded,
        context=owner_runtime.context,
        authority=owner_runtime.authority,
        resolver=owner_runtime.resolver,
        owner_intent_max_age_seconds=settings.owner_intent_max_age_seconds,
        throttle=throttle,
        missions=command_missions,
        # GAP-F-001/002/005: gateway-executed typed actions (memory, reminders,
        # trading halt) run here with the same authority/action/mission ledgers.
        actions=owner_runtime.actions,
        browser_plans=browser_action_plans, browser_preparation=browser_preparation, browser_resume=browser_resume, automation=automation,
        browser_artifacts=browser_artifacts,
        owner_fact_author=owner_fact_author,
        reminders=reminders,
        trading=trading,
        market_monitors=market_monitors,
        jev=jev_projection.client,
        learning=learning,
        google=google,
    )

    # ---------------------------------------------------------- Gate 11: ops jobs
    async def _sweep_reminders() -> dict:
        """P3-OPS-004 — fire_due, actually called, and its result actually delivered.

        Firing a reminder and not telling anyone is the same as not firing it, so the
        job publishes an event the device replays and raises an attention item the
        owner sees. The attention item is keyed by reminder id, so the same reminder
        never becomes two things to look at.
        """
        fired = await reminders.fire_due()
        published = await reminders.publish_pending(events, attention)
        observability_instruments.set_queue_depth(
            "reminders_due", len(await reminders.list_open())
        )
        return {"fired": len(fired), "published": published}

    async def _expire_overdue_missions() -> dict:
        """P0-EXEC-002 — notice the commands that never came back.

        Swept on the same cadence as reminders because the failure it detects is the same
        shape: something the owner asked for that the system stopped tracking. Without
        this the deadline set at RUNNING would be a column nothing reads.
        """
        expired = await missions.expire_overdue()
        for mission_id in expired:
            await attention.upsert(
                title="VAN never heard back about this",
                severity=AttentionSeverity.BLOCKER,
                source="mission",
                dedupe_key=f"mission-expired:{mission_id}",
                payload={"mission_id": mission_id},
            )
        return {"expired": len(expired)}

    async def _run_retention() -> dict:
        results = await retention.prune()
        audit_prune = await retention.prune_audit_prefix()
        transient_retired = await automation_worker.cleanup_transient_bytes()
        return {
            "deleted": sum(result.deleted for result in results),
            "tables": len(results),
            "audit_pruned": audit_prune["pruned"],
            "automation_transient_retired": transient_retired,
        }

    async def _scan_pki() -> dict:
        report = pki_scan(settings.pki_dir) if settings.pki_dir else {"present": False, "days_remaining": None}
        app.state.ops_pki = report
        device_report = device_pki_scan(settings.mtls_dir if settings.mtls_enabled else None)
        app.state.ops_device_pki = device_report
        return {"present": report["present"], "days_remaining": report["days_remaining"],
                "device_pki": device_report}

    async def _take_backup() -> dict:
        destination = Path(settings.backup_dir) / time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        manifest = create_backup(
            database_path=settings.database_path,
            destination=destination,
            project_state_dir=str(Path(__file__).resolve().parents[2] / "docs" / "project-state"),
            document_dir=str(Path(settings.database_path).resolve().parent / "documents"),
        )
        return {"destination": str(destination), "entries": len(manifest.entries)}

    async def _mark_stale_intents() -> dict:
        """§20 — surface a standing goal nobody has mentioned, rather than acting on it.

        P2-MEM-001 — `mark_stale` had no caller, so an intent observed once stayed ACTIVE
        forever and "active goal" meant "goal ever stated". STALE is deliberately not
        abandoned: it means ask before assuming this still matters, and only the owner
        abandons a goal.
        """
        marked = await learning.intents.mark_stale()
        return {"marked_stale": marked}

    async def _demote_regressions() -> dict:
        """§41 — a strategy that stopped working loses its promotion, without being asked.

        `StrategyLearning.auto_demote` was written, tested and never called. Promotion
        needs eval evidence and an owner-visible decision; demotion needs neither, because
        the asymmetry is the safety property: it is always safe to trust something less.
        """
        demoted = await learning.strategies.auto_demote()
        for strategy_id in demoted:
            await events.publish("strategy.demoted", {"strategy_id": strategy_id})
        return {"demoted": len(demoted)}

    async def _run_backup_drill() -> dict:
        """P3-OPS-009 — prove the backup restores, not only that it was written.

        Owner decision 10 said "local only, with the drill enabled", and the drill was
        the half with no caller: `ops.backup.drill` was complete and referenced only by
        its own tests. A backup nobody has restored is a hypothesis, and the night it
        matters is the wrong time to test it.

        The drill restores into a scratch directory under the backup root and compares
        row counts, schema version and the audit chain head with the manifest. It never
        touches the live database. A failure raises an attention item rather than only
        logging, because "the backup does not restore" is a thing the owner has to act
        on before the next one is taken.
        """
        workspace = Path(settings.backup_dir) / "drill"
        if workspace.exists():
            shutil.rmtree(workspace, ignore_errors=True)
        report = backup_drill(
            database_path=settings.database_path,
            workspace=workspace,
            project_state_dir=str(Path(__file__).resolve().parents[2] / "docs" / "project-state"),
            document_dir=str(Path(settings.database_path).resolve().parent / "documents"),
        )
        app.state.ops_backup_drill = report
        if not report["ok"]:
            await attention.upsert(
                title="A backup could not be restored",
                severity=AttentionSeverity.BLOCKER,
                source="ops",
                dedupe_key="backup-drill-failed",
                payload={
                    "differing_tables": report["differing_tables"],
                    "schema_version": report["schema_version"],
                    "verification_ok": report["verification"]["ok"],
                },
            )
        # The scratch copy is a full second database; leaving it behind would double the
        # disk the deployment needs and would be read as a backup by anyone who found it.
        shutil.rmtree(workspace, ignore_errors=True)
        return {
            "ok": report["ok"],
            "tables_compared": report["tables_compared"],
            "rows_compared": report["rows_compared"],
        }

    async def _run_trading_events() -> dict:
        return await trading_event_bridge.run(int(time.time() * 1000))

    async def _run_market_monitors() -> dict:
        return await market_monitors.run()

    async def _run_proactive_followups() -> dict:
        return await proactive_followups.run(int(time.time() * 1000))

    async def _run_owner_watches() -> dict:
        # Individual watches carry their own next_run_at_ms. The scheduler tick merely
        # wakes the bounded runner; a restart therefore does not re-check every watch.
        published = await goals.publish_pending()
        result = await watch_runner.run(now_ms=int(time.time() * 1000))
        return {**result, "published": published}

    async def _reconcile_mission_publications() -> dict:
        return {"published": await missions.reconcile_terminal_projections()}

    async def _repair_mission_learning() -> dict:
        repaired = await missions.reconcile_learning_projections()
        row = await store.fetchone("SELECT COUNT(*) AS pending,SUM(attempts>0) AS retry_pending FROM mission_learning_outbox")
        return {"repaired": repaired, "pending": int(row["pending"]), "retry_pending": int(row["retry_pending"] or 0)}

    def _scheduler_jobs() -> tuple[ScheduledJob, ...]:
        jobs = [
            ScheduledJob("reminders.fire_due", settings.reminder_sweep_seconds, _sweep_reminders),
            ScheduledJob(
                "missions.expire_overdue", settings.reminder_sweep_seconds,
                _expire_overdue_missions,
            ),
            ScheduledJob("missions.publish_terminal", settings.reminder_sweep_seconds,
                         _reconcile_mission_publications),
            ScheduledJob("learning.repair_missions", settings.reminder_sweep_seconds,
                         _repair_mission_learning),
            ScheduledJob("ops.retention", settings.retention_interval_seconds, _run_retention),
            ScheduledJob("proactive.follow_ups", settings.reminder_sweep_seconds, _run_proactive_followups),
            ScheduledJob("owner.watches", settings.reminder_sweep_seconds, _run_owner_watches),
            ScheduledJob("trading.publish_closed", settings.reminder_sweep_seconds, _run_trading_events),
            ScheduledJob("trading.market_monitors", settings.reminder_sweep_seconds, _run_market_monitors),
        ]
        if settings.automation_enabled:
            jobs.append(ScheduledJob(
                "automation.standing_sweep", 15, automation.standing_runner.sweep_due,
            ))
        if settings.pki_dir or (settings.mtls_enabled and settings.mtls_dir):
            jobs.append(ScheduledJob("ops.pki_scan", settings.pki_scan_interval_seconds, _scan_pki))
        if settings.backup_enabled and settings.backup_dir:
            jobs.append(ScheduledJob("ops.backup", settings.backup_interval_seconds, _take_backup))
        if settings.backup_drill_enabled and settings.backup_dir:
            jobs.append(ScheduledJob(
                "ops.backup_drill", settings.backup_drill_interval_seconds, _run_backup_drill,
            ))
        # P1-LEARN-004 — §41 asks for regression auto-demotion and the method had no
        # caller, so a strategy that stopped working kept its promotion for as long as the
        # process ran. Demotion is automatic where promotion is not, deliberately: removing
        # trust from something that stopped working needs no ceremony, granting it does.
        jobs.append(ScheduledJob(
            "learning.auto_demote", settings.retention_interval_seconds, _demote_regressions,
        ))
        jobs.append(ScheduledJob(
            "understanding.mark_stale_intents", settings.retention_interval_seconds,
            _mark_stale_intents,
        ))
        return tuple(jobs)

    scheduler = OpsScheduler(store, _scheduler_jobs())
    started_at = time.monotonic()

    runtime_recovery_dispatcher = RuntimeRecoveryDispatcher(store=store, auth=auth, promotions=strategy_promotions)
    native_owner_revocations = NativeOwnerRevocations(store=store, promotions=strategy_promotions)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        # P3-OBS-001 — the gateway emitted no application logs at all. This is the
        # one place that installs the JSON formatter, so every module's logger
        # inherits it instead of each one deciding for itself.
        configure_logging(settings.log_level)
        await store.migrate()
        await auth.load_persisted_secrets()
        await oauth_pending.migrate()
        await owner_runtime.startup()
        await missions.reconcile_terminal_projections()
        await missions.reconcile_learning_projections(limit=8)
        # §273 — the HOT index is a cache of durable state, so it is rebuilt on
        # every boot rather than trusted to survive a restart.
        await automation_hot_index.rebuild(store)
        # §7 — the declaration set is sealed by digest and synced on boot,
        # so a manifest edit takes effect on restart and is auditable after.
        await capability_registry.sync()
        if settings.scheduler_enabled:
            await scheduler.start()
        if dial_dev_config.enabled and dial_dev_config.attention_enabled:
            dial_dev_attention.start()
        async def expire_speech_text():
            while True:
                await asyncio.sleep(60)
                speech_streams.sweep()
        speech_cleanup = asyncio.create_task(expire_speech_text())
        recovery_dispatch = asyncio.create_task(runtime_recovery_dispatcher.run())
        revocation_dispatch = asyncio.create_task(native_owner_revocations.run())
        reenrollment_dispatch = asyncio.create_task(owner_device_reenrollment.run())
        try:
            yield
        finally:
            speech_cleanup.cancel()
            recovery_dispatch.cancel()
            revocation_dispatch.cancel()
            reenrollment_dispatch.cancel()
            await asyncio.gather(speech_cleanup, recovery_dispatch, revocation_dispatch, reenrollment_dispatch, return_exceptions=True)
            speech_streams.clear()
            await dial_dev_attention.stop()
            await scheduler.stop()

    app = FastAPI(title="VAN Gateway", version="0.5.0-dev", lifespan=lifespan)
    register_runtime_control_routes(app, auth=auth, store=store, promotions=strategy_promotions, audit=audit)
    # P3-OBS-001/P3-OBS-002 — outermost, so it measures what the client waited
    # for rather than what the handler took after every other middleware.
    app.add_middleware(MetricsMiddleware)
    app.state.store = store
    app.state.artemis_console = artemis_console
    app.state.auth = auth
    # Direct mutual-TLS link (van_gateway.mtls). Loaded only when enabled; a configured but
    # unloadable CA stops the process in van_gateway.mtls.serve rather than serving without it.
    app.state.device_ca = None
    if settings.mtls_enabled and settings.mtls_dir:
        try:
            app.state.device_ca = DeviceCA(settings.mtls_dir)
        except PkiError as exc:
            logging.getLogger("van_gateway.mtls").error("device CA unavailable: %s", exc.message)
    app.state.auth_throttle = throttle
    app.state.credential_rotation = rotation
    app.state.control_authority = control_authority
    app.state.owner_fact_author = owner_fact_author
    app.state.truth_importer = truth_importer
    app.state.owner_memory = owner_memory
    app.state.learning = learning
    app.state.degraded = degraded
    app.state.artifacts = artifacts
    app.state.documents = documents
    app.state.goals = goals
    app.state.watch_runner = watch_runner
    app.state.suggestions = suggestions
    app.state.conversations = conversations
    app.state.jev_projection = jev_projection
    app.state.jev_advisor = jev_advisor
    app.state.visual_acceptance = visual_acceptance
    # Exposed like `degraded`: which jobs a build actually installs is a property of
    # the running app, and a job list that exists only inside a closure is how
    # `learning.auto_demote` went uncalled for as long as it did.
    app.state.scheduler = scheduler
    app.state.google = google
    app.state.google_broker = google_broker
    app.state.google_router = google_router
    app.state.orchestrator = orchestrator
    app.state.owner_runtime = owner_runtime
    app.state.automation_health = automation_health
    app.state.computer_use = computer_use
    app.state.computer_worker = computer_worker
    app.state.automation = automation
    app.state.automation_worker = automation_worker
    app.state.temporal_automation = temporal_automation
    app.state.automation_registry = automation_registry
    app.state.automation_hot_index = automation_hot_index
    app.state.automation_dispatcher = automation_dispatcher
    app.state.browser = browser
    app.state.browser_interaction = browser_interaction
    app.state.capability_registry = capability_registry
    app.state.capability_router = capability_router
    app.state.missions = missions
    app.state.mission_binder = mission_binder
    app.state.command_missions = command_missions
    app.state.mission_api = mission_api
    app.state.understanding_api = understanding_api
    app.state.decisions = decisions
    app.state.projects = projects
    app.state.reminders = reminders
    app.state.trading = trading
    app.state.onboarding = onboarding
    app.state.strategy_promotions = strategy_promotions
    app.state.runtime_recovery_dispatcher = runtime_recovery_dispatcher
    app.state.native_owner_revocations = native_owner_revocations
    app.state.dial_dev_config = dial_dev_config
    app.state.dial_dev_client = dial_dev_client
    app.state.dial_dev_attention = dial_dev_attention
    app.include_router(owner_runtime.router)
    if browser_action_plans is not None:
        app.include_router(build_action_plan_router(browser_action_plans))
    from van_gateway.browser.artifact_provider import build_artifact_provider_router
    app.include_router(build_artifact_provider_router(sessions=interactive_sessions,
        providers=artifact_config["providers"], admissions=browser_artifacts))
    app.include_router(build_artifact_admission_router(browser_artifacts))
    app.include_router(build_artifact_provider_claim_router(browser_artifacts, artifact_provider_auth.authenticate))
    app.state.browser_artifacts = browser_artifacts
    app.state.artifact_provider_auth = artifact_provider_auth

    from van_gateway.automation.owner_api import OwnerAutomationApi
    app.include_router(OwnerAutomationApi(automation).router)

    app.include_router(build_artifact_router(artifacts))
    app.include_router(build_document_router(documents))
    app.include_router(build_goal_router(goals))
    from van_gateway.trading.chart_api import build_chart_router
    from van_gateway.trading.chart_workspaces import ChartWorkspaceService
    chart_workspaces = ChartWorkspaceService(store)
    app.state.chart_workspaces = chart_workspaces
    app.include_router(build_chart_router(chart_workspaces))
    from van_gateway.trading.native_depth_history import build_depth_history_router
    app.include_router(build_depth_history_router(trading))
    from van_gateway.trading.instrument_catalog import build_instrument_catalog_router
    app.include_router(build_instrument_catalog_router(trading))
    from van_gateway.trading.payment_draft_api import FundingDraftService,build_funding_draft_router
    app.state.funding_drafts=FundingDraftService(trading)
    app.include_router(build_funding_draft_router(app.state.funding_drafts))
    from van_gateway.trading.monitor_api import build_monitor_router
    app.state.market_monitors = market_monitors
    app.include_router(build_monitor_router(market_monitors))
    app.include_router(build_suggestion_router(suggestions))
    app.include_router(build_conversation_router(conversations))
    app.include_router(build_computer_use_router(computer_use))
    from van_gateway.cognitive.api import build_cognitive_router
    from van_gateway.cognitive.twin import CognitiveTwinClient
    twin_client = CognitiveTwinClient(DialDevClient(DialDevConfig(
        enabled=settings.cognitive_twin_enabled, base_url=settings.cognitive_twin_base_url,
        token_file=settings.cognitive_twin_token_file)),
        projects=tuple(p.strip() for p in settings.cognitive_twin_projects.split(',') if p.strip()))
    app.include_router(build_cognitive_router(store=store, context=owner_runtime.context,
        trading=trading, require_internal=lambda token: require_internal_control(token, ControlScope.COGNITIVE),
        twin_client=twin_client))
    app.include_router(build_dial_dev_router(
        client=dial_dev_client,
        config=dial_dev_config,
        idempotency=idempotency,
        degraded=degraded,
        audit=audit,
    ))
    app.include_router(jev_projection.router)

    @app.get("/v1/browser/interaction-router")
    async def interaction_router_status() -> dict:
        """Configured lanes and their actual gate verdicts; read-only capability projection."""
        stagehand_reason = await browser_interaction._stagehand_disabled_reason()
        jev_reasons = browser_interaction.jev_lane_disabled_reasons()
        jev_gate_reason = await browser_interaction._jev_effect_gate_closed_reason()
        return {
            "jev_service": "dial-jev" if browser_interaction.jev_client is not None else None,
            "jev_lane_reachable": bool(browser_interaction.enabled and not jev_reasons
                                       and jev_gate_reason is None),
            "jev_lane_disabled_reasons": jev_reasons,
            "jev_effect_gate_reason": jev_gate_reason,
            "jev_eligibility_classifier": type(browser_interaction.eligibility_classifier).__name__,
            "deterministic_executor": browser_interaction.executor is not None,
            "stagehand_fallback": bool(browser_interaction.enabled and stagehand_reason is None),
            "stagehand_disabled_reason": stagehand_reason,
            "independent_verifier": browser_interaction.verifier is not None,
        }

    app.include_router(automation_health.router)
    app.include_router(automation.router)
    app.include_router(automation_worker.router)
    app.include_router(temporal_automation.router)
    app.include_router(browser.router)
    app.include_router(build_interaction_routes(browser, browser_interaction))
    if browser_stream_grants is not None:
        # Rev 1.5 §§22.2, 22.3 — what Hermes is handed when it drives the owner's
        # browser, and what is destroyed when the owner takes it back.
        agent_grants = AgentGrantService()
        app.state.browser_agent_grants = agent_grants
        downloads_broker = DownloadBroker(store)
        app.state.browser_downloads = downloads_broker
        # §27 — the link report. `BrowserQualityController` was written, correct and
        # called by nothing; this is the caller. The phone measures what only it can see,
        # the Gateway picks the rung, and the target travels back.
        #
        # Built before the interactive router because that router is handed its
        # `forget`: the §27.3 byte accounting and the §27.4 hysteresis are per session,
        # and a controller that outlived its session would report the previous owner's
        # data usage to the next one.
        quality_controllers = QualityControllers()
        app.state.browser_quality = quality_controllers
        app.include_router(build_interactive_router(
            sessions=interactive_sessions,
            control=browser_control_leases,
            grants=browser_stream_grants,
            agent_grants=agent_grants,
            downloads_broker=downloads_broker,
            signal_url=settings.browser_stream_signal_url,
            profile_signal_urls=settings.browser_stream_profile_signal_urls,
            ice_servers=_parse_ice_servers(settings.browser_stream_ice_servers),
            mission_binder=mission_binder,
            audit=audit,
            on_session_ended=quality_controllers.forget,
            producers=browser_producers,
            delegate_issued_for=(settings.browser_control_client_common_name
                if getattr(browser, "interactive_worker_factory", None) is not None else None),
        ))
        app.include_router(build_browser_producer_router(
            service=browser_producers,
            settings=settings,
            audit=audit,
        ))
        # §18 — the Hermes-scoped side of the same records. Separate router because
        # it is a different authority, not a different concern: the owner's phone
        # never saw the download happen.
        app.include_router(build_download_report_router(
            broker=downloads_broker,
            sessions=interactive_sessions,
            audit=audit,
        ))
        app.include_router(build_quality_router(
            controllers=quality_controllers,
            sessions=interactive_sessions,
        ))
    # Rev 1.5 §20 — the durable logical session. It holds no command authority: the
    # router delegates to the same POST /v1/commands path the phone has always used, and
    # §20.2 forbids a second one.
    van_sessions = VanHermesSessionService(store, events=events)

    async def _submit_command_through_session(payload: dict, device_id: str) -> dict:
        try:
            request = CommandRequest(**{**payload, "device_id": device_id})
        except ValidationError as exc:
            # A malformed command is the phone's mistake, not the Gateway's fault: it is
            # refused rather than raised. Left as an exception it became a 500, which the
            # client's retry policy treats as "try again" — and the same malformed payload
            # would be retried forever.
            raise SessionDelegateError("command_payload_invalid") from exc
        result = await orchestrator.handle(request)
        return result if isinstance(result, dict) else result.model_dump(mode="json")

    async def _answer_decision_through_session(payload: dict, device_id: str) -> dict:
        """§20.2 — the owner's answer, delivered to the authority that already owns it."""
        decision_id = str(payload.get("decision_id") or "")
        if not decision_id:
            raise SessionDelegateError("decision_id_required")
        if "approved" not in payload:
            # Not defaulted. An absent answer is not a "no", and guessing either way
            # decides something on the owner's behalf that they did not say.
            raise SessionDelegateError("approved_required")
        if type(payload["approved"]) is not bool:
            raise SessionDelegateError("approved_invalid")
        try:
            record = await decisions.resolve(
                decision_id, approved=payload["approved"], owner_device_id=device_id
            )
        except KeyError as exc:
            raise SessionDelegateError("decision_not_found") from exc
        except DecisionError as exc:
            raise SessionDelegateError(exc.reason) from exc
        return record.model_dump(mode="json")

    async def _cancel_mission_through_session(payload: dict, device_id: str) -> dict:
        """Stopping your own mission is yours to say — over this carrier too."""
        mission_id = str(payload.get("mission_id") or "")
        if not mission_id:
            raise SessionDelegateError("mission_id_required")
        existing = await missions.get(mission_id)
        if existing is not None and existing.state is MissionState.CANCELLED:
            return {"mission_id": existing.mission_id, "state": existing.state.value}
        try:
            mission = await missions.transition(
                mission_id,
                target=MissionState.CANCELLED,
                actor=PrincipalType.OWNER_DEVICE,
                final_outcome="cancelled by owner",
            )
        except MissionError as exc:
            # Two carriers may recover the same cancellation simultaneously. Only
            # a genuinely observed CANCELLED state can recover the second receipt.
            existing = await missions.get(mission_id)
            if existing is not None and existing.state is MissionState.CANCELLED:
                return {"mission_id": existing.mission_id, "state": existing.state.value}
            raise SessionDelegateError(str(exc)) from exc
        return {"mission_id": mission.mission_id, "state": mission.state.value}

    async def _message_mission_through_session(payload: dict, device_id: str) -> dict:
        """§2.3 — a note on the record. It does not move the mission by itself."""
        mission_id = str(payload.get("mission_id") or "")
        text = str(payload.get("text") or payload.get("message") or "")
        if not mission_id or not text:
            raise SessionDelegateError("mission_id_and_text_required")
        if await missions.get(mission_id) is None:
            raise SessionDelegateError("mission_unknown")
        operation = CURRENT_OPERATION.get()
        operation_key = (Store.dumps([operation.van_session_id, operation.idempotency_key or operation.message_id])
                         if operation is not None else None)
        event = await missions.record_event(
            mission_id=mission_id,
            event_type=MissionEventType.MISSION_MESSAGE,
            actor=PrincipalType.OWNER_DEVICE,
            summary=text[:500],
            severity="INFO",
            idempotency_key=operation_key,
        )
        return {"event_id": event.event_id, "recorded": True}

    async def _recover_session_result(envelope, device_id: str) -> dict | None:
        """Recover through the existing idempotent authority, never a new one.

        Command handoffs retain the orchestrator's unknown/expired/cancelled
        boundaries. Local controls now have exact duplicate-safe effects.
        """
        delegate = {"command.submit": _submit_command_through_session,
                    "decision.answer": _answer_decision_through_session,
                    "mission.cancel": _cancel_mission_through_session,
                    "mission.message": _message_mission_through_session}.get(envelope.kind)
        if delegate is None:
            return None
        result = await delegate(envelope.payload, device_id)
        return None if envelope.kind == "command.submit" and result.get("status") == "in_flight" else result

    async def _read_session_result(envelope, device_id: str) -> dict | None:
        """Read original domain receipts without extending execution authority.

        A matching current cancellation/decision state alone cannot prove this
        operation completed. Those cases retain pending recovery unless the
        original session result was committed.
        """
        payload = envelope.payload
        if envelope.kind == "command.submit":
            from van_gateway.models import CommandResult
            try:
                request = CommandRequest(**{**payload, "device_id": device_id})
            except ValidationError:
                return None
            row = await store.fetchone(
                "SELECT request_hash,status,response_json FROM idempotency WHERE idempotency_key=?",
                (request.idempotency_key,),
            )
            if (row is None or row["status"] != "COMPLETED"
                    or row["request_hash"] != IdempotencyService.request_hash(request.model_dump())):
                return None
            try:
                result = CommandResult(**json.loads(row["response_json"]))
            except (TypeError, ValueError):
                return None
            if result.command_id != request.command_id or result.idempotency_key != request.idempotency_key:
                return None
            if result.status in {"degraded", "in_flight"}:
                return None
            return result.model_dump(mode="json")
        if envelope.kind != "mission.message":
            return None
        mission_id = str(payload.get("mission_id") or "")
        text = str(payload.get("text") or payload.get("message") or "")
        mission = await missions.get(mission_id) if mission_id else None
        if not text or mission is None or mission.owner_principal_id != f"device:{device_id}":
            return None
        operation_key = Store.dumps([envelope.van_session_id, envelope.idempotency_key or envelope.message_id])
        event_id = f"mev_{hashlib.sha256(Store.dumps([mission_id, operation_key]).encode()).hexdigest()}"
        row = await store.fetchone("SELECT * FROM mission_events WHERE event_id=?", (event_id,))
        if (row is None or row["mission_id"] != mission_id
                or row["event_type"] != MissionEventType.MISSION_MESSAGE.value
                or row["actor"] != PrincipalType.OWNER_DEVICE.value
                or row["summary"] != text[:500] or row["activity_id"] is not None
                or row["severity"] != "INFO" or row["owner_visibility"] != 1
                or row["evidence_ref"] is not None):
            return None
        return {"event_id": event_id, "recorded": True}

    # Rev 1.5 §20.2 — all four kinds the router knows, delegated to the authorities that
    # already exist.
    #
    # Three of these were left unwired, and the effect was not a missing feature. The
    # router admitted the envelope into §20.12's table *before* discovering it had nobody
    # to hand it to, so "cancel this mission" sent over the durable session was recorded,
    # refused, and — because its idempotency key was now taken — answered ALREADY_KNOWN
    # on every retry. Acknowledged, never performed, and unrepeatable.
    session_router = SessionRouter(
        van_sessions,
        SessionDelegates(
            submit_command=_submit_command_through_session,
            answer_decision=_answer_decision_through_session,
            cancel_mission=_cancel_mission_through_session,
            message_mission=_message_mission_through_session,
            recover_result=_recover_session_result,
            read_result=_read_session_result,
        ),
    )

    async def _read_command_result(command_id: str, device_id: str) -> dict:
        if not device_id:
            raise HTTPException(status_code=404, detail="command_unknown")
        mission = await command_missions.existing_for_command(command_id)
        rows = await store.fetchall(
            "SELECT device_id, result, failure_reason, created_at_unix FROM audit "
            "WHERE command_id = ? AND device_id = ? ORDER BY COALESCE(chain_seq, 0) DESC LIMIT 1",
            (command_id, device_id),
        )
        if mission is None and not rows:
            raise HTTPException(status_code=404, detail="command_unknown")
        if mission is not None and mission.owner_principal_id != f"device:{device_id}":
            # Audit retention or a later unscoped observation cannot transfer
            # ownership of a durable command result to another paired device.
            raise HTTPException(status_code=404, detail="command_unknown")
        if mission is not None:
            status = wire_status.from_mission_state(mission.state.value)
            result = {
                "command_id": command_id,
                "correlation_id": correlation_for_command(command_id),
                "mission_id": mission.mission_id,
                "mission_state": mission.state.value,
                "owner_status": status.value,
                "sentence": owner_status.SENTENCE[status],
                "needs_you": status in owner_status.NEEDS_OWNER,
                "finished": status in owner_status.FINISHED,
                "final_outcome": mission.final_outcome,
                "verification_state": mission.verification_state.value,
                "deadline_ms": mission.deadline_ms,
                "updated_at_ms": mission.updated_at_ms,
            }
            return with_spoken_result(result)

        # Refused before a mission was opened: the audit row is the whole story.
        status = wire_status.from_command_result(str(rows[0]["result"]))
        result = {
            "command_id": command_id,
            "correlation_id": correlation_for_command(command_id),
            "mission_id": None,
            "mission_state": None,
            "owner_status": status.value,
            "sentence": owner_status.SENTENCE[status],
            "needs_you": status in owner_status.NEEDS_OWNER,
            "finished": status in owner_status.FINISHED,
            "final_outcome": rows[0]["failure_reason"],
            "verification_state": None,
            "deadline_ms": None,
            "updated_at_ms": int(rows[0]["created_at_unix"]) * 1000,
        }
        return with_spoken_result(result)

    # Rev 1.5 §21.16 — the spoken half of an answer, so a reconnect does not start it
    # again from the beginning. Held in memory deliberately: a restart loses the text of an
    # answer in flight, while the command that produced it and its result are both durable.
    speech_streams = SpeechStreamService()
    app.state.speech_streams = speech_streams
    bound_speech = BoundSpeechResponses(speech_streams, _read_command_result, owner_runtime.authority)
    app.include_router(build_voice_router(bound_speech))

    async def _resume_snapshot(
        *, device_id: str, van_session_id: str, pending_command_ids: list[str]
    ) -> dict:
        """§20.11 — what the Gateway authoritatively knows about what the client lost.

        Answered from two places, because the Gateway knows a thing in two ways and the
        client cannot tell which applies. A mission is the richer answer and is preferred.
        Failing that, `van_session_messages` is the §20.12 admission table. A
        completed result settles its message; an admitted row without a result
        remains RESULT_PENDING and must not silently leave the device outbox.

        Consulting only the mission table made every answer for an admitted-but-missionless
        message `UNKNOWN`, which the client correctly reads as *resend*. The command was
        not lost, but it was re-sent on every single resume for the life of the session,
        because nothing the client could ever receive would settle it.

        `UNKNOWN` is emitted rather than the key omitted: the client treats both as
        resend, and sending it makes "I looked and I do not have this" a statement the
        client can be tested against rather than an absence it has to infer.
        """
        states: dict[str, str] = {}
        for identity in pending_command_ids[:50]:
            mission = await command_missions.existing_for_command(identity)
            if mission is not None and mission.owner_principal_id == f"device:{device_id}":
                states[identity] = mission.state.value
                continue
            # The client asks by command id when it has one and by message id otherwise,
            # and a resubmitted envelope carries both. Matching either is what lets one
            # question be answered without the two sides agreeing in advance which
            # identity a given command happens to have.
            row = await store.fetchone(
                """
                SELECT admitted_state, result_json FROM van_session_messages
                 WHERE van_session_id = ? AND (command_id = ? OR message_id = ?)
                 LIMIT 1
                """,
                (van_session_id, identity, identity),
            )
            states[identity] = ("RESULT_PENDING" if row is not None and row["result_json"] is None else
                                row["admitted_state"] if row is not None else "UNKNOWN")
        cursor_row = await store.fetchone(
            "SELECT last_seq FROM event_cursors WHERE device_id = ?", (device_id,)
        )
        return {
            "command_states": states,
            "authoritative_event_cursor": int(cursor_row["last_seq"]) if cursor_row else 0,
            # §21.16 — where the owner actually got to in the spoken answer. Absent when
            # there is nothing in flight, which is the ordinary case.
            "response_state": await bound_speech.resume_state(device_id),
        }

    app.include_router(build_session_router(
        sessions=van_sessions, router=session_router, events=events,
        resume_snapshot=_resume_snapshot,
        require_device_binding=settings.require_device_binding,
        audit=audit,
    ))
    # Rev 1.5 §§0D.3, 5.7 — the owner-device binding.
    #
    # The policy is configuration because the signing certificate differs between a debug
    # build and the owner's release build, and pinning the debug one would mean the
    # production APK could never enrol. Absent configuration disables enrolment rather than
    # weakening it: §0E.1 D5 forbids a downgrade to a weaker binding, and an unconfigured
    # deployment is exactly where one would be tempting.
    owner_device_bindings = (
        OwnerDeviceBindingService(
            store,
            AttestationPolicy(
                expected_package=settings.owner_device_package,
                expected_signing_cert_sha256=settings.owner_device_signing_cert_sha256,
                allowed_root_fingerprints=frozenset(
                    f.strip() for f in settings.owner_device_attestation_roots.split(",") if f.strip()
                ),
            ),
        )
        if settings.owner_device_signing_cert_sha256
        else None
    )
    connectivity_config = ConnectivityConfigService(
        store,
        private_pem=(
            _read_stream_signing_key(settings.connectivity_signing_key_file)
            if settings.connectivity_signing_key_file else None
        ),
        kid=settings.connectivity_signing_kid,
    )
    from van_gateway.auth.reenrollment import OwnerDeviceReenrollment
    owner_device_reenrollment = OwnerDeviceReenrollment(store=store, auth=auth,
        native_revocations=native_owner_revocations, device_ca=lambda: app.state.device_ca,
        connectivity=connectivity_config)
    app.state.owner_device_reenrollment = owner_device_reenrollment
    app.state.owner_device_bindings = owner_device_bindings
    app.state.connectivity_config = connectivity_config
    app.state.van_sessions = van_sessions
    app.state.session_router = session_router
    app.state.browser_preparation = browser_preparation
    app.state.browser_resume = browser_resume
    app.state.browser_action_plans = browser_action_plans
    app.state.interactive_sessions = interactive_sessions
    app.state.browser_control_leases = browser_control_leases
    app.state.interaction_router = browser_interaction
    app.state.browser_stream_grants = browser_stream_grants
    app.state.browser_producers = browser_producers
    app.include_router(mission_api.router)
    app.include_router(understanding_api.router)
    from van_gateway.decisions.api import build_decision_router
    app.include_router(build_decision_router(decisions))
    from van_gateway.capability.owner_permissions import build_owner_permission_router
    app.include_router(build_owner_permission_router(store))

    def control_scope_for(
        method: str, path: str, *, internal_present: bool = False
    ) -> ControlScope | None:
        """Which privileged scope a route belongs to, or None if it is not one.

        P0-SEC-001 — one token reached all of these. Naming the scope per route is what
        makes "the Hermes runtime may drive automation but may not enrol a device"
        expressible at all.
        """
        if path.startswith("/v1/runtime/cognitive/"):
            return ControlScope.COGNITIVE
        if path.startswith("/v1/runtime/"):
            return ControlScope.RUNTIME
        # P2-CU-001 adds the computer-use fabric's health on the same terms as the other
        # two: it reports which surfaces have a worker, which is runtime shape.
        if path in {
            "/v1/automation/health", "/v1/browser/health", "/v1/computer-use/health",
        }:
            return ControlScope.RUNTIME
        # Gate 11. Device telemetry is excluded on purpose: its producer is the
        # owner's paired device, so it authenticates as a device like every other
        # device-produced payload, and an operator credential is not required to
        # report a frame time.
        if path.startswith("/v1/observability/") and path != "/v1/observability/device-telemetry":
            return ControlScope.OBSERVABILITY
        if path.startswith("/v1/automation/worker/"):
            return ControlScope.AUTOMATION_WORKER
        if path.startswith("/v1/automation/"):
            return ControlScope.AUTOMATION
        if path.startswith("/v1/missions") or path in ("/v1/needs-you", "/v1/activity",
                                                        "/v1/capabilities/status"):
            if method == "GET":
                return None
            return None if (method == "POST" and re.fullmatch(r"/v1/missions/[^/]+/(?:cancel|message|pause|resume|direction)", path)) else ControlScope.MISSIONS
        if path.startswith("/v1/understanding") or path.startswith("/v1/permissions") or (
            path in ("/v1/technology-radar", "/v1/eval", "/v1/autonomy")
        ):
            return ControlScope.UNDERSTANDING if path == "/v1/understanding/observe" else None
        if is_session_owner_route(path):
            # §20 — the logical session carries the owner's own commands, so it
            # authenticates as the owner's device. Same predicate-with-one-reader shape as
            # the interactive browser routes below.
            return None
        if is_browser_producer_consumer_route(path):
            return ControlScope.BROWSER_STREAM_PRODUCER
        if is_interactive_browser_owner_route(path):
            # Rev 1.5 §6.1 — the owner's phone creates, heartbeats and closes its own
            # browser session, so these are device-authenticated rather than Hermes-only.
            # One predicate, two readers: a route classified here and not below would fall
            # through to owner-device authentication on a Hermes surface, which is the hole
            # P0-SEC-001 closed and P2-GOOG-004 nearly reopened.
            return None
        if path.startswith("/v1/browser/"):
            if method != "GET":
                return ControlScope.BROWSER
            # The fixed browser control client needs these two task projections
            # to bind assignments and read sealed evidence. A presented internal
            # credential must hold BROWSER scope; a wrong scope cannot fall through
            # to device auth. Without one, retain the owner's existing device path.
            if internal_present and re.fullmatch(
                r"/v1/browser/tasks/[^/]+(?:/evidence)?", path
            ):
                return ControlScope.BROWSER
            return None
        if method == "PUT" and path.startswith("/v1/projects/") and path.endswith("/truth"):
            return ControlScope.PROJECTS
        if method == "POST" and path in {
            "/v1/devices/bootstrap/create", "/v1/devices/rebind",
            "/v1/devices/provisioning-payload",
            "/v1/devices/provisioning-status",
        }:
            # ADR-RB-026 — minting an enrolment credential, and replacing the owner's
            # device, are the same authority as enrolment itself.
            return ControlScope.DEVICE_ENROLMENT
        if method == "POST" and path in {"/v1/devices/enroll", "/v1/devices/pairing-ticket"}:
            # The scope that can mint owner-device authority, and the reason this module
            # exists. Not granted to the legacy token.
            return ControlScope.DEVICE_ENROLMENT
        if method == "GET" and re.fullmatch(r"/v1/devices/rebindings/[^/]+", path):
            return ControlScope.DEVICE_ENROLMENT
        if method == "GET" and re.fullmatch(r"/v1/devices/[^/]+/revocations/[^/]+", path):
            return ControlScope.DEVICE_ENROLMENT
        if method == "POST" and path.startswith("/v1/devices/") and path.endswith("/revoke"):
            return ControlScope.DEVICE_ENROLMENT
        if method == "POST" and path == "/v1/trading/halt":
            return ControlScope.TRADING
        if method == "POST" and path.startswith("/v1/trading/tickets/") and path.endswith("/confirm"):
            return ControlScope.TRADING
        if path in GOOGLE_CONTROL_ROUTES:
            return ControlScope.GOOGLE
        if path.startswith("/v1/google/jobs/"):
            return ControlScope.GOOGLE
        if path.startswith("/v1/google/gmail/drafts/") and path.endswith("/preview"):
            return ControlScope.GOOGLE
        return None

    def requires_device_proof(method: str, path: str) -> bool:
        """ADR-RB-025 — which owner requests must prove possession of the bound key.

        Reading a session or a browser tab list is not on this list; *changing* something
        is. The distinction matters because a proof costs a hardware-key signature on the
        phone, and demanding one for a polling read would put a Keystore operation in the
        battery path for no security gain.

        `require_proof` existed in `OwnerDeviceBindingService` before this predicate did,
        and nothing called it. A binding nobody checks is a fingerprint in a table: a
        stolen device token would have worked on every route, with or without a bound
        device, and `/v1/device-binding/status` would still have reported `bound: true`.
        """
        if method not in {"POST", "PUT", "PATCH", "DELETE"}:
            return False
        if path in {"/v1/devices/bootstrap/challenge", "/v1/devices/bootstrap/attest", "/v1/devices/bootstrap/recover"}:
            # The enrolment itself. There is no bound key yet to prove possession of.
            return False
        # Internal-control routes are handled before this owner gate. Every remaining
        # owner mutation proves possession; an allowlist silently omitted understanding,
        # permissions, reminders and privacy controls as those routers grew.
        return True

    async def enforce_device_proof(request: Request, device_id: str) -> JSONResponse | None:
        """Refuse a privileged request from a bound device that did not sign it.

        Fail-closed where it can be: once a device is bound, a missing or invalid proof is
        a refusal, and there is no header a caller can omit to get the old behaviour back.

        For an *unbound* device this returns None and the token alone carries the request,
        because a gateway that already has paired devices would otherwise lock its owner
        out the moment this shipped. That downgrade is visible rather than silent:
        `/v1/device-binding/status` reports `bound: false`, and `settings.require_device_
        binding` turns the fallback off for a deployment that has finished enrolling.
        """
        if owner_device_bindings is None:
            if settings.require_device_binding:
                return JSONResponse(
                    status_code=503,
                    content={"detail": "owner_device_binding_unconfigured"},
                )
            return None
        # Once *any* device is bound, the owner has one device and this is not a question
        # about the caller: a second paired phone asking to be treated as unbound is the
        # downgrade §0E.1 D5 forbids. A first version asked `for_device(device_id)`, so a
        # second paired device skipped the gate entirely by never having enrolled — the
        # proof was mandatory only for the device that had already proved itself.
        binding = await owner_device_bindings.active()
        if binding is None:
            if settings.require_device_binding:
                return JSONResponse(status_code=403, content={"detail": "device_not_bound"})
            return None
        if binding.device_id != device_id:
            return JSONResponse(
                status_code=403, content={"detail": "device_not_owner_device"}
            )
        if (settings.require_device_binding and not binding.attestation_chain_verified
                and request.url.path != "/v1/device-binding/certify"):
            return JSONResponse(status_code=403, content={"detail": "device_attestation_recertification_required"})

        signature_b64 = request.headers.get("X-Van-Device-Proof", "")
        issued_at_raw = request.headers.get("X-Van-Device-Proof-Issued-At", "")
        if not signature_b64 or not issued_at_raw:
            return JSONResponse(
                status_code=401, content={"detail": "device_proof_required"}
            )
        try:
            signature = base64.b64decode(signature_b64, validate=True)
            issued_at_ms = int(issued_at_raw)
        except (ValueError, binascii.Error):
            return JSONResponse(
                status_code=400, content={"detail": "device_proof_malformed"}
            )

        # The handler still needs this body after we have read it.
        #
        # A first version followed `await request.body()` with a hand-rolled replay that
        # reassigned `request._receive`. A mutation deleting that replay changed nothing,
        # which is how it was found to be dead: Starlette's `BaseHTTPMiddleware` already
        # wraps the request in a `_CachedRequest` whose documented behaviour is that a body
        # read in `dispatch` is cached and passed downstream. Poking a private attribute to
        # re-implement that was two mechanisms for one job, and the one I wrote was the
        # one nothing exercised.
        #
        # The dependency is real, so it is tested rather than assumed: a proved POST must
        # come back with the field it sent, which fails if this ever stops being true.
        body = await request.body()
        signed_target = request.url.path
        raw_query = request.scope.get("query_string", b"")
        if raw_query:
            signed_target += "?" + raw_query.decode("ascii")

        try:
            await owner_device_bindings.require_proof(
                device_id=device_id,
                signature=signature,
                method=request.method,
                path=signed_target,
                issued_at_ms=issued_at_ms,
                body=body,
            )
        except DeviceBindingError as exc:
            return JSONResponse(status_code=401, content={"detail": exc.reason})
        from van_gateway.command.nonce import CommandNonceService, NonceReplay
        proof_identity = hashlib.sha256(Store.dumps({
            "device_id": device_id, "method": request.method, "target": signed_target,
            "issued_at_ms": issued_at_ms, "body_sha256": hashlib.sha256(body).hexdigest(),
        }).encode()).hexdigest()
        try:
            await CommandNonceService(store).consume(
                device_id=device_id, nonce=f"device-http-proof:{proof_identity}",
                command_id=f"device-http-request:{proof_identity}",
            )
        except NonceReplay:
            return JSONResponse(status_code=401, content={"detail": "device_proof_replayed"})
        request.state.van_device_proved = True
        return None

    def throttled_response(detail: str, locked: Throttled) -> JSONResponse:
        """429 with the one header a client can actually act on."""
        return JSONResponse(
            status_code=429,
            content={"detail": detail, "retry_after_seconds": locked.retry_after_seconds},
            headers={"Retry-After": str(locked.retry_after_seconds)},
        )

    # `internal_control_route` used to live here: a second copy of the route
    # classification that once let the internal token bypass the device gate. P0-SEC-001
    # replaced that mechanism with `control_scope_for` plus scoped credentials, and left
    # this behind. A repository-wide search finds no caller — not in the middleware, not in
    # a handler, not in a test — so it has been decided-by-nobody since that closure.
    #
    # It was deleted rather than updated when the interactive browser routes were added.
    # A mutation removing the exemption I had just written into it changed nothing, which
    # is how it was found: a guard whose removal is undetectable is not protecting
    # anything. Keeping it would have meant two classifiers to edit and one of them
    # silently ignored, which is exactly how the Rev 1.3 drift this programme closed began.

    @app.middleware("http")
    async def require_ingress_auth(request: Request, call_next):
        if is_artifact_provider_route(request.scope):
            # Dedicated attested machine authority has no owner/device or legacy
            # internal-token fallback. The handler rechecks the current binding.
            try:
                request.state.van_artifact_provider_principal = await artifact_provider_auth.authenticate(request)
            except HTTPException as exc:
                return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
            return await call_next(request)
        # The embedded ARTEMIS browser surface uses a short-lived HttpOnly session
        # minted only after a normal owner-device proof. The one-use launch URL and
        # subsequent cookie-authenticated GETs do not carry Android bearer headers.
        if artemis_console.is_public_launch_request(request):
            return await call_next(request)
        if artemis_console.browser_request_authorized(request):
            return await call_next(request)
        if request.method == "POST" and request.url.path == "/v1/devices/pair":
            return await call_next(request)
        # ADR-RB-026 — a phone being enrolled has no device token yet, by definition. These
        # two are protected by the single-use bootstrap token instead, which is the whole
        # credential: short-lived, hashed at rest, and spent by the enrolment it authorises.
        if request.method == "POST" and request.url.path in {
            "/v1/devices/bootstrap/challenge", "/v1/devices/bootstrap/attest", "/v1/devices/bootstrap/recover",
        }:
            return await call_next(request)
        if request.method == "GET" and request.url.path.startswith("/v1/trading/oauth/") and request.url.path.endswith("/callback"):
            return await call_next(request)

        # Privileged local Hermes control uses an independent machine credential.
        presented_internal = request.headers.get("X-Van-Internal-Token", "")
        scope = control_scope_for(
            request.method, request.url.path, internal_present=bool(presented_internal.strip())
        )
        if scope is not None:
            if control_authority.permits(presented_internal, scope):
                request.state.van_control_scope = scope.value
                return await call_next(request)
            if not control_authority.configured:
                return JSONResponse(
                    status_code=503,
                    content={"detail": "internal_control_token_unconfigured"},
                )
            if presented_internal.strip():
                # P0-SEC-001. A wrong or under-scoped credential used to fall through to
                # ingress plus device authentication, so a route declared Hermes-only was
                # reachable with an owner device token. The check is terminal now, and
                # names the scope so an operator can tell "wrong credential" from "this
                # credential does not reach that surface".
                return JSONResponse(
                    status_code=403,
                    content={
                        "detail": "internal_control_unauthorized",
                        "required_scope": scope.value,
                    },
                )
            # Nothing was presented at all. The ingress gate below answers first, so an
            # unauthenticated stranger learns nothing about which routes exist; the scope
            # check then refuses, still without ever reaching device authentication.

        configured = settings.ingress_token.strip()
        presented = request.headers.get("X-Van-Ingress-Token", "")
        if not configured:
            return JSONResponse(status_code=503, content={"detail": "ingress_auth_unconfigured"})
        if not presented or not hmac.compare_digest(configured, presented):
            # P1-SEC-007, soft posture: the credential was already judged wrong, so counting
            # this failure can never keep a correct token out. Past the policy, further wrong
            # tokens are answered flat and the device lookup below is never reached.
            try:
                throttle.fail("ingress_token", GLOBAL_SUBJECT)
            except Throttled as locked:
                return throttled_response("ingress_auth_throttled", locked)
            return JSONResponse(status_code=401, content={"detail": "ingress_auth_failed"})
        throttle.record_success("ingress_token", GLOBAL_SUBJECT)

        # Health is the only ingress-only route, used by local/tunnel probes.
        if request.method == "GET" and request.url.path == "/health":
            return await call_next(request)

        if scope is not None:
            # Reached only when no internal credential was presented. An owner device
            # token is not an answer to a privileged control route, so this is where the
            # fall-through used to happen and no longer does.
            return JSONResponse(
                status_code=403,
                content={"detail": "internal_control_unauthorized", "required_scope": scope.value},
            )

        try:
            device = await auth.require_access_token(request.headers.get("X-Van-Device-Token", ""))
        except AuthError:
            try:
                throttle.fail("device_token", GLOBAL_SUBJECT)
            except Throttled as locked:
                return throttled_response("device_access_throttled", locked)
            return JSONResponse(status_code=401, content={"detail": "device_access_denied"})
        throttle.record_success("device_token", GLOBAL_SUBJECT)
        request.state.van_device_id = device.device_id
        certified = mtls_device_id(request.scope)
        if certified is not None and certified != device.device_id:
            # Over the direct link the device token alone is not enough: it has to belong to
            # the device the verified client certificate names.
            return JSONResponse(status_code=403, content={"detail": "client_certificate_device_mismatch"})
        if requires_device_proof(request.method, request.url.path):
            refusal = await enforce_device_proof(request, device.device_id)
            if refusal is not None:
                return refusal
        return await call_next(request)

    def require_internal_control(
        x_van_internal_token: str | None,
        scope: ControlScope | None = None,
    ) -> None:
        """Handler-level check, which must agree with the middleware's.

        P0-SEC-001 — this compared against the single internal token, so a route the
        middleware had already let through on a scoped credential would then be refused
        here. It now asks the same authority the same question. `scope` defaults to the
        one the route's path implies, so existing callers keep working.
        """
        if not control_authority.configured:
            raise HTTPException(status_code=503, detail="internal_control_token_unconfigured")
        if scope is None:
            scope = ControlScope.RUNTIME
        if not control_authority.permits(x_van_internal_token, scope):
            raise HTTPException(status_code=403, detail="internal_control_unauthorized")

    @app.get("/health")
    async def health():
        hermes_health = await hermes.health()
        hermes_ok = bool(hermes_health.get("ok"))
        if hermes_ok:
            degraded.set(__import__("van_gateway.models", fromlist=["DegradedCode"]).DegradedCode.HERMES_OFFLINE, False)
        else:
            degraded.set(__import__("van_gateway.models", fromlist=["DegradedCode"]).DegradedCode.HERMES_OFFLINE, True)
        gstatus = await google.status()
        mesh = await google_broker.mesh_status(workspace=gstatus)
        runtime_status = await owner_runtime.status()
        configured = sum(1 for item in mesh["capabilities"] if item["state"] in {"READY", "CONFIGURED"})
        ready = sum(1 for item in mesh["capabilities"] if item["state"] == "READY")
        workspace = next(
            (item for item in mesh["capabilities"] if item["capability_id"] == "workspace_api"),
            None,
        )
        if workspace:
            raw_workspace_state = workspace["state"]
            workspace_state = getattr(raw_workspace_state, "value", str(raw_workspace_state))
        else:
            workspace_state = "UNVERIFIED"
        return {
            "ok": hermes_ok,
            "service": "van-gateway",
            "hermes": hermes_health,
            "owner_runtime": runtime_status,
            "google": gstatus.model_dump(),
            "google_mesh": {
                "principal": mesh["principal"],
                "configured_capabilities": configured,
                "ready_capabilities": ready,
                "total_capabilities": len(mesh["capabilities"]),
                "workspace_api_state": workspace_state,
                "workspace_api_ready": workspace_state == "READY",
                "hermes_is_sole_agent_runtime": True,
            },
            "degraded": degraded.snapshot(),
            # P2-SEC-008 — credential age, so a token older than its policy says so
            # instead of nothing saying anything. Reporting only: rotating the ingress
            # token unattended would lock the owner out far more reliably than it would
            # stop anybody.
            "credentials": await rotation.report(
                {
                    "ingress_token": settings.ingress_token,
                    "internal_control_token": settings.internal_control_token,
                    "automation_grant_signing_key": settings.automation_grant_signing_key,
                }
            ),
            "enrolment_grants": await auth.expiring_grants(),
        }

    @app.post("/v1/artemis/console/session")
    async def create_artemis_console_session(request: Request):
        device_id = getattr(request.state, "van_device_id", "")
        if not device_id:
            raise HTTPException(status_code=401, detail="owner_device_required")
        try:
            return JSONResponse(
                artemis_console.mint(device_id),
                headers={"Cache-Control": "no-store"},
            )
        except RuntimeError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.get("/v1/artemis/console/launch/{launch_token}")
    async def launch_artemis_console(launch_token: str):
        redeemed = artemis_console.redeem(launch_token)
        if redeemed is None:
            raise HTTPException(status_code=401, detail="artemis_console_launch_invalid_or_expired")
        cookie, _session = redeemed
        response = RedirectResponse(url="/v1/artemis/console/", status_code=303)
        response.set_cookie(value=cookie, **artemis_console.launch_cookie_kwargs())
        response.headers["Cache-Control"] = "no-store"
        return response

    async def proxy_artemis_console(request: Request, resource_path: str = ""):
        return await artemis_console.proxy(request)

    async def proxy_artemis_console_api(request: Request, resource_path: str):
        return await artemis_console.proxy(request)

    async def proxy_artemis_console_images(request: Request, resource_path: str):
        return await artemis_console.proxy(request)

    async def proxy_artemis_console_videos(request: Request, resource_path: str):
        return await artemis_console.proxy(request)

    async def proxy_artemis_console_local_file(request: Request, resource_path: str):
        return await artemis_console.proxy(request)

    def register_artemis_proxy(path, handler, *, methods):
        # One APIRoute per method gives OpenAPI clients distinct operation identities.
        # The same governed handler and ingress classifiers still protect every alias.
        for method in methods:
            app.add_api_route(path, handler, methods=[method])

    for console_path in ("/v1/artemis/console", "/v1/artemis/console/", "/v1/artemis/console/{resource_path:path}"):
        register_artemis_proxy(console_path, proxy_artemis_console, methods=["GET", "HEAD", "OPTIONS", "POST"])
    register_artemis_proxy("/api/{resource_path:path}", proxy_artemis_console_api, methods=["GET", "HEAD", "OPTIONS", "POST"])
    register_artemis_proxy("/images/{resource_path:path}", proxy_artemis_console_images, methods=["GET", "HEAD", "OPTIONS"])
    register_artemis_proxy("/videos/{resource_path:path}", proxy_artemis_console_videos, methods=["GET", "HEAD", "OPTIONS"])
    register_artemis_proxy("/local_file/{resource_path:path}", proxy_artemis_console_local_file, methods=["GET", "HEAD", "OPTIONS"])

    @app.post("/v1/devices/pairing-ticket")
    async def create_pairing_ticket(
        body: PairingTicketCreate,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.DEVICE_ENROLMENT)
        ticket = await auth.create_pairing_ticket(body.label, body.ttl_seconds)
        return JSONResponse(
            {
                "pairing_token": ticket.token,
                "expires_at_unix": ticket.expires_at_unix,
            },
            headers={"Cache-Control": "no-store"},
        )

    @app.post("/v1/devices/pair")
    async def pair_device(body: PairDeviceBody, request: Request):
        import hashlib
        from van_gateway.command.nonce import CommandNonceService, NonceReplay

        ingress_token = settings.ingress_token.strip()
        if not ingress_token:
            raise HTTPException(status_code=503, detail="ingress_auth_unconfigured")
        # P1-SEC-007, hard posture. This is the only unauthenticated route in the gateway
        # and the only credential that mints owner-device authority, so the lockout is
        # checked before the ticket is looked at. See van_gateway/auth/throttle.py for why
        # this surface, and only this surface, accepts the availability cost.
        try:
            throttle.check("pairing", GLOBAL_SUBJECT)
        except Throttled as locked:
            raise HTTPException(
                status_code=429,
                detail="pairing_throttled",
                headers={"Retry-After": str(locked.retry_after_seconds)},
            ) from locked
        try:
            hardware_proved = False
            proved_binding_id = None
            request_hash = None
            if body.device_access_token is not None or settings.require_device_binding:
                binding_service = getattr(app.state, "owner_device_bindings", None)
                if binding_service is None:
                    raise HTTPException(status_code=503, detail="owner_device_binding_unconfigured")
                signature_b64 = request.headers.get("X-Van-Device-Proof", "")
                issued_at = request.headers.get("X-Van-Device-Proof-Issued-At", "")
                if not signature_b64 or not issued_at:
                    raise DeviceBindingError("device_proof_required")
                try:
                    signature = base64.b64decode(signature_b64, validate=True)
                    issued_at_ms = int(issued_at)
                except (ValueError, binascii.Error) as exc:
                    raise DeviceBindingError("device_proof_malformed") from exc
                raw_body = await request.body()
                # Original pairing recovery retains its 409 unavailable outcome when
                # paired authority was retired. Verify the archived exact proof solely
                # to report that refusal; it cannot authorize enrollment or renewal.
                retired = await store.fetchone("SELECT revoked_at_unix FROM devices WHERE device_id=?", (body.device_id,))
                if body.device_access_token is not None and retired is not None and retired["revoked_at_unix"] is not None:
                    archived = await binding_service.for_device(body.device_id)
                    if archived is not None:
                        from van_gateway.auth.device_proof import verify_request_proof, DeviceProofError
                        try:
                            verify_request_proof(public_key_pem=archived.public_key_pem, signature=signature,
                                method="POST", path="/v1/devices/pair", device_id=body.device_id,
                                issued_at_ms=issued_at_ms, body=raw_body)
                        except DeviceProofError as exc:
                            raise DeviceBindingError(exc.reason) from exc
                        raise AuthError("pairing_recovery_unavailable", "Original pairing credentials are no longer active")
                binding = await binding_service.require_proof(
                    device_id=body.device_id, signature=signature, method="POST",
                    path="/v1/devices/pair", issued_at_ms=issued_at_ms, body=raw_body,
                )
                active = await binding_service.active()
                if active is None or active.binding_id != binding.binding_id:
                    raise DeviceBindingError("device_not_owner_device")
                if not getattr(binding, "attestation_chain_verified", False):
                    raise DeviceBindingError("device_attestation_chain_unverified")
                request_hash = hashlib.sha256(raw_body).hexdigest()
                try:
                    await CommandNonceService(store).consume(
                        device_id=body.device_id, nonce=f"pairing-proof:{issued_at_ms}",
                        command_id=f"pairing:{request_hash}",
                    )
                except NonceReplay as exc:
                    raise DeviceBindingError("device_proof_replayed") from exc
                hardware_proved = True
                proved_binding_id = binding.binding_id
            result = await auth.pair_device(
                body.pairing_token,
                body.device_id,
                body.device_secret,
                body.public_key_pem,
                body.label,
                device_access_token=body.device_access_token,
                request_hash=request_hash,
                hardware_proved=hardware_proved,
                proved_binding_id=proved_binding_id,
            )
        except DeviceBindingError as exc:
            throttle.record_failure("pairing", GLOBAL_SUBJECT)
            status = 401 if exc.reason.startswith("device_proof_") else 403
            raise HTTPException(status_code=status, detail=exc.reason) from exc
        except AuthError as exc:
            # `already_enrolled` and `device_revoked` mean the ticket was genuine, so they
            # are a client mistake, not a guess, and must not count toward the lockout.
            if exc.code not in {"already_enrolled", "device_revoked"}:
                throttle.record_failure("pairing", GLOBAL_SUBJECT)
            code = 409 if exc.code in {"already_enrolled", "device_revoked", "pairing_recovery_conflict", "pairing_recovery_unavailable"} else 400
            raise HTTPException(status_code=code, detail=exc.message) from exc
        throttle.record_success("pairing", GLOBAL_SUBJECT)
        return JSONResponse(
            {
                "device_id": result.device.device_id,
                "enrolled_at_unix": result.device.enrolled_at_unix,
                "ingress_token": ingress_token,
                "device_access_token": result.access_token,
            },
            headers={"Cache-Control": "no-store"},
        )

    @app.post("/v1/devices/enroll")
    async def enroll(
        body: EnrollBody,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.DEVICE_ENROLMENT)
        try:
            device = await auth.enroll(body.device_id, body.device_secret, body.public_key_pem, body.label)
        except AuthError as exc:
            raise HTTPException(status_code=409 if exc.code == "already_enrolled" else 400, detail=exc.message) from exc
        return {"device_id": device.device_id, "enrolled_at_unix": device.enrolled_at_unix}

    @app.get("/v1/devices/{device_id}/revocations/{operation_id}", response_model=NativeOwnerKeyRevocationState)
    async def device_revocation_original(device_id: str, operation_id: str,
        x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.DEVICE_ENROLMENT)
        if not re.fullmatch(r"[0-9a-f]{64}",operation_id):
            raise HTTPException(422,"invalid original device revocation identity")
        row=await store.fetchone("SELECT value FROM runtime_meta WHERE key=?",("native_owner_revocation:"+operation_id,))
        if row is None:raise HTTPException(404,"unknown original device revocation")
        try:
            original=await native_owner_revocations.original(operation_id)
        except (ValueError,TypeError,KeyError,OSError) as exc:
            raise HTTPException(503,"original device revocation history is unavailable") from exc
        if original['device_id']!=device_id:raise HTTPException(404,"unknown original device revocation")
        return original

    @app.post("/v1/devices/{device_id}/revoke", response_model=DeviceRevocationResponse)
    async def revoke(
        device_id: str,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.DEVICE_ENROLMENT)
        try:
            native_revocation = await auth.revoke(device_id)
        except AuthError as exc:
            raise HTTPException(status_code=404, detail=exc.message) from exc
        await owner_runtime.actions.revoke_privileged_for_device(f"device:{device_id}")
        retirement = await store.fetchone("SELECT actions_retired FROM device_certificate_retirements WHERE device_id=?", (device_id,))
        revoked_executions = retirement["actions_retired"] if retirement else 0
        revoked_certificates = 0
        certificate_retirement_phase = "PENDING"
        try:
            revoked_certificates = await owner_device_reenrollment.retire_certificates(device_id) or 0
            certificate_receipt = await store.fetchone(
                "SELECT certificates_retired_at_ms FROM device_certificate_retirements WHERE device_id=?", (device_id,))
            if certificate_receipt is not None and certificate_receipt["certificates_retired_at_ms"] is not None:
                certificate_retirement_phase = "APPLIED"
        except Exception:
            # Local CA/file/marker failure cannot delay independent native retirement.
            certificate_retirement_phase = "UNKNOWN"
            logging.getLogger("van.device-retirement").warning("original device certificate retirement remains pending")
        try:
            native_revocation = await native_owner_revocations.reconcile_operation(native_revocation['operation_id'])
        except (OSError, ValueError, TypeError):
            native_revocation['phase'] = 'UNKNOWN'
        return {
            "revoked": True,
            "device_id": device_id,
            "revoked_privileged_executions": revoked_executions,
            "revoked_client_certificates": revoked_certificates,
            "certificate_retirement_phase": certificate_retirement_phase,
            "native_authority_revocation": native_revocation,
        }

    @app.post("/v1/devices/tls-certificate")
    async def issue_tls_client_certificate(request: Request):
        """The phone's client certificate for the direct mutual-TLS link.

        Reached with the ingress token, the device token and a device proof (the bound
        hardware key), with or without a current client certificate, so a phone can enrol
        and renew. The CSR's key is generated in the phone's Keystore and never leaves it;
        its commonName must be the authenticated device id. Issuing supersedes (revokes)
        the device's previous certificates.
        """
        device_ca = getattr(app.state, "device_ca", None)
        if device_ca is None:
            raise HTTPException(status_code=503, detail="mtls_not_configured")
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=401, detail="device_access_denied")
        try:
            body = await request.json()
        except Exception:
            raise HTTPException(status_code=400, detail="csr_invalid")
        csr_pem = body.get("csr_pem") if isinstance(body, dict) else None
        if not isinstance(csr_pem, str) or len(csr_pem) > 8192:
            raise HTTPException(status_code=400, detail="csr_invalid")
        try:
            # The SQL writer fences a proof checked before retirement from issuing a
            # certificate after the CA outbox has independently completed its readback.
            async with store.connection() as db:
                await db.execute("BEGIN IMMEDIATE")
                live = await (await db.execute("SELECT revoked_at_unix FROM devices WHERE device_id=?", (device_id,))).fetchone()
                if live is None or live["revoked_at_unix"] is not None:
                    raise HTTPException(403, "device_revoked")
                issued = device_ca.issue_client(csr_pem, device_id, days=settings.mtls_client_cert_days)
                await db.commit()
        except PkiError as exc:
            raise HTTPException(status_code=400, detail=exc.code) from exc
        return {
            "device_id": issued.device_id,
            "certificate_pem": issued.certificate_pem,
            "ca_pem": device_ca.ca_pem,
            "serial": issued.serial_hex,
            "not_after_unix": issued.not_after_unix,
        }

    @app.post("/v1/commands")
    async def commands(req: CommandRequest, request: Request):
        if getattr(request.state, "van_device_id", None) != req.device_id:
            raise HTTPException(status_code=403, detail="device_identity_mismatch")
        result = await orchestrator.handle(req)
        # OMV-006 — only a command that reached the point of becoming owner intent has a
        # Mission. Invalid signatures/refusals before that point must never be projected as
        # owner speech. Projection is presentation state and cannot change command outcome.
        if result.mission_id:
            try:
                main_thread = await conversations.ensure_main()
                await conversations.append_projection(
                    main_thread.thread_id,
                    projection_key=f"command:{req.command_id}:owner",
                    role="OWNER",
                    body=req.text,
                    command_id=req.command_id,
                    mission_id=result.mission_id,
                    terminal=False,
                )
            except Exception:
                logging.getLogger("van_gateway.conversations").exception(
                    "failed to project owner command %s into main thread", req.command_id
                )
        return result

    def _require_binding_service() -> OwnerDeviceBindingService:
        if owner_device_bindings is None:
            # §0E.1 D5 — no configuration means no enrolment, not a weaker one.
            raise HTTPException(status_code=503, detail="owner_device_binding_unconfigured")
        return owner_device_bindings

    @app.post("/v1/devices/bootstrap/create")
    async def create_bootstrap(body: BootstrapCreateBody):
        """ADR-RB-026 — the installer's one-time credential, for the deployment pipeline."""
        try:
            token, challenge = await _require_binding_service().create_bootstrap_token(note=body.note)
        except DeviceBindingError as exc:
            raise HTTPException(409, exc.reason) from exc
        await audit.record(
            result="ok", capability="device.bootstrap.create", after={"note": body.note}
        )
        return {"bootstrap_token": token, "attestation_challenge": challenge}

    @app.post("/v1/devices/provisioning-payload")
    async def create_provisioning_payload(
        body: ProvisioningPayloadBody,
        x_van_internal_token: str | None = Header(default=None),
    ):
        """ADR-RB-026 — the installer's one call, and the owner types nothing.

        One call rather than three, because the alternative is an installer that mints a
        token, reads a challenge and assembles a document itself — and an installer that
        assembles the document decides its expiry. §0D.2's rule survives only if the
        short-lived, single-use, signed envelope is built by the party that also enforces
        those three properties.
        """
        require_internal_control(x_van_internal_token, ControlScope.DEVICE_ENROLMENT)
        if not connectivity_config.private_pem or not connectivity_config.kid:
            # No signing key means no provisioning, not an unsigned one. A payload the
            # device cannot verify is a payload it must refuse, and handing the installer
            # one would make the failure look like the phone's.
            raise HTTPException(status_code=503, detail="connectivity_signing_unconfigured")
        if not _require_binding_service().policy.allowed_root_fingerprints:
            raise HTTPException(status_code=503, detail="attestation_roots_unconfigured")
        try:
            validated_gateway_url = validate_gateway_url(body.gateway_url)
        except ConnectivityError as exc:
            raise HTTPException(status_code=400, detail=exc.reason) from exc
        try:
            token, challenge = await _require_binding_service().create_bootstrap_token(
                note=body.note, ttl_ms=PROVISIONING_TTL_MS,
            )
        except DeviceBindingError as exc:
            raise HTTPException(409, exc.reason) from exc
        # Both credentials, minted together, because provisioning is one act. A device
        # that paired but did not bind would hold working tokens and no hardware identity,
        # which is §0D.3's failure exactly: an APK copied to another handset would work.
        ticket = await auth.create_pairing_ticket(body.note or "owner-device")
        active = await connectivity_config.active()
        try:
            payload = build_provisioning_payload(
                gateway_url=validated_gateway_url,
                pairing_token=ticket.token,
                bootstrap_token=token,
                attestation_challenge=challenge,
                manifest_version=active.manifest_version if active else 0,
            )
            signature = sign_provisioning_payload(
                payload, private_pem=connectivity_config.private_pem
            )
        except ConnectivityError as exc:
            raise HTTPException(status_code=400, detail=exc.reason) from exc
        await audit.record(
            result="ok", capability="device.provisioning.issue",
            # The token is not recorded. An audit row that carried it would be a second
            # copy of the one credential that can bind a new device, in the table a backup
            # copies — which is the reason `create_bootstrap_token` only stores its hash.
            after={"provisioning_id": payload["provisioning_id"], "note": body.note},
        )
        return JSONResponse(
            {"payload": payload, "signature": signature, "kid": connectivity_config.kid},
            headers={"Cache-Control": "no-store"},
        )

    @app.post("/v1/devices/bootstrap/challenge")
    async def bootstrap_challenge(body: BootstrapChallengeBody):
        """The challenge this enrolment must be attested against."""
        try:
            challenge = await _require_binding_service().challenge_for(body.token)
        except DeviceBindingError as exc:
            raise HTTPException(status_code=403, detail=exc.reason) from exc
        return {"attestation_challenge": challenge}

    @app.post("/v1/devices/provisioning-status")
    async def owner_device_provisioning_status(
        body: ProvisioningStatusBody,
        x_van_internal_token: str | None = Header(default=None),
    ):
        """Installer readback for one exact attempt; never grants or renews authority."""
        from van_gateway.auth.provisioning_status import provisioning_status
        require_internal_control(x_van_internal_token, ControlScope.DEVICE_ENROLMENT)
        try:
            status = await provisioning_status(store, body.bootstrap_token, app.state.device_ca)
        except DeviceBindingError as exc:
            raise HTTPException(status_code=404, detail=exc.reason) from exc
        return JSONResponse(status, headers={"Cache-Control": "no-store"})

    @app.post("/v1/devices/bootstrap/attest")
    async def bootstrap_attest(body: BootstrapAttestBody, request: Request):
        """Bind the owner's device, or refuse and record why."""
        try:
            extension = base64.b64decode(body.attestation_extension_b64, validate=True)
            chain = [base64.b64decode(item, validate=True) for item in body.attestation_chain_b64]
        except Exception as exc:
            raise HTTPException(status_code=400, detail="attestation_not_base64") from exc
        try:
            extension, verified_root = verify_attestation_chain(
                certificates_der=chain, public_key_pem=body.public_key_pem,
                policy=_require_binding_service().policy, extension=extension,
            )
            try:
                signature = base64.b64decode(request.headers.get("X-Van-Device-Proof", ""), validate=True)
                issued_at = int(request.headers.get("X-Van-Device-Proof-Issued-At", ""))
            except (ValueError, binascii.Error) as exc:
                raise DeviceBindingError("device_proof_malformed") from exc
            verify_request_proof(
                public_key_pem=body.public_key_pem, signature=signature, method="POST",
                path="/v1/devices/bootstrap/attest", device_id=body.device_id,
                issued_at_ms=issued_at, body=await request.body(),
            )
            from van_gateway.command.nonce import CommandNonceService, NonceReplay
            try:
                await CommandNonceService(store).consume(
                    device_id=body.device_id, nonce=f"bootstrap-attest:{issued_at}",
                    command_id=hashlib.sha256(body.token.encode()).hexdigest(),
                )
            except NonceReplay as exc:
                raise DeviceBindingError("device_proof_replayed") from exc
            binding = await _require_binding_service().bind(
                token=body.token,
                device_id=body.device_id,
                public_key_pem=body.public_key_pem,
                attestation_extension=extension,
                attestation_root_fingerprint=verified_root,
                attestation_chain_verified=True,
                os_version=body.os_version,
                os_patch_level=body.os_patch_level,
            )
        except (DeviceBindingError, DeviceProofError) as exc:
            await audit.record(
                result="refused", device_id=body.device_id,
                capability="device.bootstrap.attest", failure_reason=exc.reason,
            )
            raise HTTPException(status_code=403, detail=exc.reason) from exc
        await audit.record(
            result="ok", device_id=body.device_id, capability="device.bootstrap.attest",
            after={"fingerprint": binding.device_key_fingerprint},
        )
        return {
            "binding_id": binding.binding_id,
            "device_id": binding.device_id,
            "device_key_fingerprint": binding.device_key_fingerprint,
            "key_security_level": binding.key_security_level,
            "verified_boot_state": binding.verified_boot_state,
            "attestation_chain_verified": binding.attestation_chain_verified,
        }

    @app.post("/v1/devices/bootstrap/recover")
    async def bootstrap_recover(body: BootstrapRecoverBody, request: Request):
        """Recover a lost bind response; this cannot enroll or replace a phone."""
        try:
            signature = base64.b64decode(request.headers.get("X-Van-Device-Proof", ""), validate=True)
            issued_at = int(request.headers.get("X-Van-Device-Proof-Issued-At", ""))
        except (ValueError, binascii.Error) as exc:
            raise HTTPException(status_code=400, detail="device_proof_malformed") from exc
        try:
            binding = await _require_binding_service().recover_bootstrap(
                token=body.token, device_id=body.device_id, signature=signature,
                issued_at_ms=issued_at, body=await request.body(),
            )
        except DeviceBindingError as exc:
            code = 404 if exc.reason == "bootstrap_not_consumed" else 403
            raise HTTPException(status_code=code, detail=exc.reason) from exc
        return JSONResponse({
            "bound": True, "binding_id": binding.binding_id, "device_id": binding.device_id,
            "device_key_fingerprint": binding.device_key_fingerprint,
            "attestation_chain_verified": binding.attestation_chain_verified,
        }, headers={"Cache-Control": "no-store"})

    @app.post("/v1/device-binding/certify")
    async def certify_binding(body: CertifyBindingBody, request: Request):
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id or not getattr(request.state, "van_device_proved", False):
            raise HTTPException(status_code=403, detail="device_proof_required")
        try:
            chain = [base64.b64decode(item, validate=True) for item in body.attestation_chain_b64]
            binding = await _require_binding_service().certify_existing(device_id=device_id, certificates_der=chain)
        except (ValueError, binascii.Error) as exc:
            raise HTTPException(status_code=400, detail="attestation_not_base64") from exc
        except DeviceBindingError as exc:
            raise HTTPException(status_code=403, detail=exc.reason) from exc
        return {"bound": True, "device_key_fingerprint": binding.device_key_fingerprint,
                "attestation_chain_verified": binding.attestation_chain_verified}

    @app.get("/v1/device-binding/status")
    async def device_binding_status(request: Request):
        """What this device's binding looks like from the Gateway's side."""
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        if owner_device_bindings is None:
            return {"configured": False, "bound": False, "reason": "binding_unconfigured"}
        binding = await owner_device_bindings.for_device(device_id)
        if binding is None:
            return {"configured": True, "bound": False}
        approval_fingerprint = None
        try:
            paired = await auth.require_device(device_id)
        except AuthError as exc:
            raise HTTPException(403, exc.code) from None
        if paired is not None:
            try:
                approval_public = serialization.load_pem_public_key(paired.public_key_pem.encode())
                approval_fingerprint = hashlib.sha256(approval_public.public_bytes(
                    serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)).hexdigest()
            except (ValueError, TypeError):
                pass
        return {
            "configured": True,
            "bound": binding.status.value == "ACTIVE",
            "device_id": device_id,
            "binding_id": binding.binding_id,
            "owner_principal_id": binding.owner_principal_id,
            "owner_approval_key_fingerprint": approval_fingerprint,
            "status": binding.status.value,
            "device_key_fingerprint": binding.device_key_fingerprint,
            "key_security_level": binding.key_security_level,
            "verified_boot_state": binding.verified_boot_state,
            "bound_at_ms": binding.bound_at_ms,
            "attestation_chain_verified": binding.attestation_chain_verified,
            "last_proof_at_ms": binding.last_proof_at_ms,
        }

    def _rebind_error(exc):
        status = 404 if exc.reason == "rebind_operation_unknown" else 409
        if exc.reason in {"connectivity_signing_unconfigured", "device_secret_encryption_unconfigured", "rebind_original_response_unavailable"}:
            status = 503
        return HTTPException(status_code=status, detail=exc.reason)

    @app.post("/v1/devices/rebind")
    async def rebind_owner_device(body: RebindBody, x_van_internal_token: str | None = Header(default=None)):
        """Recover one exact replacement intent under the dedicated installer scope."""
        require_internal_control(x_van_internal_token, ControlScope.DEVICE_ENROLMENT)
        _require_binding_service()
        try:
            result = await owner_device_reenrollment.start(
                operator_id=hashlib.sha256(x_van_internal_token.encode()).hexdigest(),
                reason=body.reason, operation_id=body.operation_id,
                expected_binding_id=body.expected_binding_id, expected_bound_at_ms=body.expected_bound_at_ms,
                gateway_url=body.gateway_url)
        except DeviceBindingError as exc:
            raise _rebind_error(exc) from exc
        except AuthError as exc:
            raise HTTPException(503, exc.code) from exc
        except ConnectivityError as exc:
            raise HTTPException(400, exc.reason) from exc
        return JSONResponse(result, headers={"Cache-Control": "no-store"})

    @app.get("/v1/devices/rebindings/{operation_id}")
    async def original_device_rebinding(operation_id: str, x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.DEVICE_ENROLMENT)
        try:
            result = await owner_device_reenrollment.recover(operation_id=operation_id,
                operator_id=hashlib.sha256(x_van_internal_token.encode()).hexdigest(), reconcile=False)
        except DeviceBindingError as exc:
            raise _rebind_error(exc) from exc
        except AuthError as exc:
            raise HTTPException(503, exc.code) from exc
        return JSONResponse(result, headers={"Cache-Control": "no-store"})

    @app.get("/v1/connectivity/manifest")
    async def connectivity_manifest(request: Request, known_version: int = 0):
        """ADR-RB-027 — a newer signed manifest when there is one, nothing when there is not."""
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        served = await connectivity_config.serve(known_version=known_version)
        if served is None:
            return {"current": True, "manifest": None}
        return {"current": False, **served}

    @app.get("/v1/commands/{command_id}")
    async def command_status(command_id: str, request: Request):
        return await _read_command_result(command_id, getattr(request.state, "van_device_id", ""))

    @app.get("/v1/briefing")
    async def get_briefing():
        hermes_health = await hermes.health()
        gstatus = await google.status()
        deg = degraded.codes() + gstatus.degraded
        if not hermes_health.get("ok"):
            deg.append("HERMES_OFFLINE")
        calendar_items = None
        mail_items = None
        if gstatus.connected and gstatus.services.get("calendar") == "ok" and google.transport is not None:
            try:
                calendar_items = await google.calendar_agenda()
            except GoogleAuthError:
                deg.append("GOOGLE_TOKEN_EXPIRED")
        return await briefing.build(calendar_items=calendar_items, mail_items=mail_items, hermes_health=hermes_health, degraded=deg)

    @app.post("/v1/reminders")
    async def create_reminder(body: ReminderCreate):
        try:
            return await reminders.create(body)
        except ReminderConflict as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/v1/reminders")
    async def list_reminders():
        return await reminders.list_open()

    @app.post("/v1/reminders/{reminder_id}/resolve")
    async def resolve_reminder(reminder_id: str):
        try:
            await reminders.resolve(reminder_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="reminder_not_found") from exc
        except ReminderConflict as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {"resolved": True}

    @app.post("/v1/reminders/{reminder_id}/cancel")
    async def cancel_reminder(reminder_id: str):
        try:
            await reminders.cancel(reminder_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="reminder_not_found") from exc
        except ReminderConflict as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {"cancelled": True}

    @app.post("/v1/reminders/parse")
    async def parse_reminder(body: ReminderParseBody):
        try:
            due = parse_due_expression(body.due_expression)
        except TimeParseError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        try:
            return await reminders.create(
                ReminderCreate(text=body.text,due_at_unix=due,
                    idempotency_key=body.idempotency_key,project_id=body.project_id))
        except ReminderConflict as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/v1/decisions/escalate")
    async def escalate_decision(body: DecisionCreate):
        item = await decisions.escalate(body)
        await events.publish("decision.escalated", item.model_dump())
        return item

    @app.get("/v1/decisions")
    async def list_decisions():
        return await decisions.list_open()

    @app.post("/v1/decisions/{decision_id}/resolve")
    async def resolve_decision(decision_id: str, body: DecisionResolveBody, request: Request):
        try:
            return await decisions.resolve(decision_id, approved=body.approved, owner_device_id=request.state.van_device_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="decision_not_found") from exc
        except DecisionError as exc:
            raise HTTPException(status_code=409, detail=exc.reason) from exc

    @app.put("/v1/projects/{project_id}/truth")
    async def put_project_truth(
        project_id: str,
        body: ProjectTruthBody,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.PROJECTS)
        if project_id not in projects.known_projects():
            raise HTTPException(status_code=404, detail="unknown_project")
        body_project = body.truth.get("project_id") if isinstance(body.truth, dict) else None
        if body_project is not None and str(body_project) != project_id:
            raise HTTPException(status_code=400, detail="truth_project_mismatch")
        await projects.cache_truth(project_id, body.truth, body.truth_sha, body.repo_sha)
        # P0-CTX-002 — the PROJECT_TRUTH tier had no writer, so it was empty in every
        # deployment while retrieval happily excluded the one tier that did. Importing
        # here rather than on a separate route means the facts and the cache cannot
        # disagree about which SHA is current.
        loaded = await projects.load_truth(project_id)
        try:
            imported = await truth_importer.import_truth(
                project_id, {**loaded, "truth_sha": body.truth_sha}
            )
        except ContextAuthoringError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {**loaded, "facts_imported": len(imported)}

    @app.post("/v1/context/facts")
    async def state_owner_fact(request: Request, body: OwnerFactBody):
        """The owner saying something about themselves, at CANONICAL_OWNER.

        P0-CTX-002 — the only production writer was the Hermes admission route, correctly
        limited to INFERRED/MODEL_DERIVED, which is the one tier retrieval excludes. So
        the authoritative tiers were empty everywhere. This is the writer that fills them,
        and it is device-authenticated because a canonical fact about the owner can only
        come from the owner.
        """
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        record = await owner_fact_author.state(
            device_id=device_id,
            subject=body.subject,
            predicate=body.predicate,
            value=body.value,
            scope=body.scope,
            valid_until_ms=body.valid_until_ms,
        )
        await audit.record(
            result="ok", device_id=device_id, capability="context.owner_fact.state",
            after={"subject": body.subject, "predicate": body.predicate, "scope": body.scope},
        )
        return record.model_dump(mode="json")

    @app.get("/v1/context/memory")
    async def owner_memory_inventory(request: Request):
        """P2-MEM-002 — what VAN holds about the owner, before deciding to end it."""
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        return await owner_memory.inventory()

    @app.delete("/v1/context/memory", status_code=409)
    async def owner_memory_forget(request: Request, store: str | None = None):
        """Compatibility refusal: irreversible erasure uses the A4 command boundary."""
        raise HTTPException(status_code=409, detail={
            "code": "memory_erasure_requires_approved_command",
            "command": "forget all owner-derived memory" if store is None
                else f"forget owner-derived memory store {store}",
            "endpoint": "/v1/commands",
        })

    @app.get("/v1/context/export")
    async def owner_context_export(request: Request):
        """P2-CTX-003 — everything VAN holds about the owner, not a count of it.

        /v1/context/memory already reported how many rows each store held. That is the
        wrong half of the answer: the owner could see that VAN had concluded 47 things
        about how they work and could delete all 47, without ever being allowed to read
        one. This is an owner route for the same reason the erasure is — the person the
        data describes does not ask an operator for permission to see it.
        """
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        exported = await context_lifecycle.export()
        await audit.record(
            result="ok", device_id=device_id, capability="context.export",
            after={
                store: detail["rows_exported"]
                for store, detail in exported["stores"].items()
            },
        )
        return exported

    @app.get("/v1/context/history")
    async def owner_context_history(
        request: Request, subject: str, predicate: str, scope: str = "global"
    ):
        """P2-CTX-003 — what VAN believed before, and what changed its mind.

        Unauditable before migration 25: admit_fact closed the superseded record's validity
        window and dropped the link, so a correction and two independent expiries left
        identical rows.
        """
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        return await context_lifecycle.history(
            subject=subject, predicate=predicate, scope=scope
        )

    @app.get("/v1/context/conflicts")
    async def owner_context_conflicts(request: Request):
        """P2-CTX-003 — what VAN holds two contradictory answers to.

        resolve_requirement has always detected these, but only for a claim something
        asked about. A contradiction nothing queries was held silently. VAN reports both
        sides and does not choose: picking between two things the owner is recorded as
        having said is not a retrieval decision.
        """
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        return await context_lifecycle.conflicts()

    @app.delete("/v1/context/facts")
    async def forget_owner_fact(
        request: Request, subject: str, predicate: str, scope: str = "global"
    ):
        """P2-MEM-002 — the owner's own way to end a fact they stated."""
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        ended = await owner_fact_author.forget(subject=subject, predicate=predicate, scope=scope)
        await audit.record(
            result="ok", device_id=device_id, capability="context.owner_fact.forget",
            after={"subject": subject, "predicate": predicate, "ended": ended},
        )
        return {"subject": subject, "predicate": predicate, "scope": scope, "ended": ended}

    # There is deliberately no route that swaps the live Google transport for a fake.
    # /v1/google/test-transport used to do exactly that on the running production app, with
    # no undo route (finding P2-SEC-009). Tests install a fake transport directly on
    # app.state.google, which is where that capability belongs. tools/ci/maturity_gate.py
    # fails CI if the route reappears.

    def _scrubbed(payload: Any) -> Any:
        """GAP-F-020 — `scrub_for_prompt` had no production caller. Every Google read
        that reaches Hermes passes through here, recursively, so a provider payload
        can never carry credential-shaped keys into a model-visible tool result."""
        if isinstance(payload, dict):
            return {k: _scrubbed(v) for k, v in GoogleService.scrub_for_prompt(payload).items()}
        if isinstance(payload, list):
            return [_scrubbed(v) for v in payload]
        return payload

    @app.get("/v1/google/gmail/search")
    async def gmail_search(q: str, x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            return {
                "messages": _scrubbed(await google.gmail_search(q)),
                "live": google.transport is not None and not isinstance(google.transport, FakeGoogleTransport),
            }
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    async def _execute_google_action(
        execution_id: str,
        parameters: dict[str, Any],
    ):
        try:
            return await google.execute_authorized_action(
                owner_runtime.actions,
                execution_id=execution_id,
                parameters=parameters,
            )
        except ActionPolicyError as exc:
            code = 404 if str(exc) == "unknown_execution" else 409
            raise HTTPException(status_code=code, detail=str(exc)) from exc
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.get("/v1/google/gmail/thread")
    async def gmail_thread(
        thread_id: str,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            return {"thread": _scrubbed(await google.gmail_thread_get(thread_id))}
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.post("/v1/google/gmail/attachment/import-pdf")
    async def gmail_attachment_import_pdf(
        message_id: str,
        attachment_id: str,
        filename: str = "attachment.pdf",
        project_id: str | None = None,
        command_id: str | None = None,
        mission_id: str | None = None,
        execution_id: str | None = None,
        x_van_internal_token: str | None = Header(default=None),
    ):
        """Import a Gmail attachment through Document Fabric, never into model context."""
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            data = await google.gmail_attachment_get(message_id, attachment_id)
            record = await documents.import_pdf(
                filename=filename, data=data, project_id=project_id, command_id=command_id,
                mission_id=mission_id, execution_id=execution_id,
            )
            return record.model_dump(mode="json")
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except Exception as exc:
            code = getattr(exc, "code", "gmail_attachment_import_failed")
            if code == "DOCUMENT_PUBLICATION_UNKNOWN":
                raise HTTPException(status_code=503,detail={"code":code,"document_id":exc.document_id,
                    "publication_id":exc.publication_id}) from exc
            raise HTTPException(status_code=422, detail=str(code)) from exc

    @app.get("/v1/google/calendar/review")
    async def calendar_review(
        event_id: str,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            return _scrubbed(await google.calendar_event_review(event_id))
        except GoogleAuthError as exc:
            raise HTTPException(
                status_code=409 if str(exc) == "google_outcome_unknown" else 503,
                detail=str(exc),
            ) from exc

    @app.post("/v1/google/actions/execute")
    async def execute_google_action(
        body: GoogleAuthorizedActionBody,
        x_van_internal_token: str | None = Header(default=None),
    ):
        """Execute a mutation that Action Runtime already authorized.

        The caller supplies an execution id, not approval. The execution record binds the
        signed owner command, action class, parameters, principal, freshness and any A4
        biometric approval. This endpoint cannot manufacture any of them.
        """
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        return await _execute_google_action(body.execution_id, body.parameters)

    @app.post("/v1/google/gmail/send")
    async def gmail_send(
        execution_id: str,
        draft_id: str,
        draft_content_sha256: str,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        return await _execute_google_action(
            execution_id,
            {"draft_id": draft_id, "draft_content_sha256": draft_content_sha256},
        )

    @app.get("/v1/google/gmail/drafts/{draft_id}/preview")
    async def gmail_internal_draft_preview(
        draft_id: str, x_van_internal_token: str | None = Header(default=None),
    ):
        """Read the approval binding without exposing private message text to a worker."""
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            preview = await google.gmail_draft_preview(draft_id)
            return {key: value for key, value in preview.items() if key != "preview"}
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.get("/v1/owner/google/gmail/drafts/{draft_id}/preview")
    async def gmail_owner_draft_preview(draft_id: str, request: Request):
        """Private decoded content for the paired owner's approval display."""
        if not getattr(request.state, "van_device_id", None):
            raise HTTPException(status_code=403, detail="device_identity_required")
        try:
            return await google.gmail_draft_preview(draft_id)
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    # P2-GOOG-004 — six capabilities with a transport, a service method and no way in.
    #
    # gmail_draft, calendar_agenda, calendar_reschedule, drive_search, contacts_resolve and
    # tasks_list were implemented end to end in google/transport.py and google/service.py
    # and reachable from nothing. The mesh reported them as capabilities; the component
    # ledger recorded three entries of NO_ROUTE against them. A capability whose only caller
    # is its own test is not a capability the owner has.
    #
    # Each mirrors gmail_search exactly: internal control at the GOOGLE scope, and
    # GoogleAuthError to 503 because an absent or expired credential is VAN being unable
    # rather than the caller being wrong. No new authority is introduced anywhere.

    @app.post("/v1/google/gmail/draft")
    async def gmail_draft(
        execution_id: str,
        thread_id: str,
        body: str,
        x_van_internal_token: str | None = Header(default=None),
    ):
        """Create a draft through the same sealed action boundary as every other mutation."""
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        return await _execute_google_action(
            execution_id,
            {"thread_id": thread_id, "body": body},
        )

    @app.get("/v1/google/calendar/agenda")
    async def calendar_agenda(x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            return {"events": _scrubbed(await google.calendar_agenda())}
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.post("/v1/google/calendar/reschedule")
    async def calendar_reschedule(
        execution_id: str,
        event_id: str,
        new_start_unix: int,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        return await _execute_google_action(
            execution_id,
            {"event_id": event_id, "new_start_unix": new_start_unix},
        )

    @app.get("/v1/google/drive/search")
    async def drive_search(q: str, x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            return {"files": _scrubbed(await google.drive_search(q))}
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.get("/v1/google/contacts/resolve")
    async def contacts_resolve(q: str, x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            return {"contacts": _scrubbed(await google.contacts_resolve(q))}
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.get("/v1/google/tasks")
    async def tasks_list(x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            return {"tasks": _scrubbed(await google.tasks_list())}
        except GoogleAuthError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.get("/v1/google/status")
    async def google_status():
        return await google.status()

    @app.get("/v1/google/planes")
    async def google_credential_planes():
        """P2-GOOG-003 — the four Google credentials, reported one by one.

        `/v1/google/status` answers "is Google connected" with one boolean derived from the
        owner's refresh token. Four credentials reach Google and they expire
        independently: the refresh token, the model runtime's entitlement, the cloud
        project credentials for discoveryengine, and a browser profile the owner signed in
        with. So an expired cloud credential and a signed-out profile were both invisible
        there, and a revoked refresh token made the whole of Google look down when the
        enterprise notebook path was fine.

        §421 requires degradation to be scoped. A reader who cannot see which plane failed
        cannot know what still works, and the two wrong answers are symmetrical: everything
        broken because one credential lapsed, or everything fine because the one credential
        that is checked happens to be good.
        """
        knowledge = owner_runtime.knowledge
        return summarise(
            await plane_health(
                google=google,
                notebook_enterprise=knowledge.notebook_enterprise,
                notebook_consumer=knowledge.notebook_consumer,
                broker=google_broker,
            ),
            mesh=await google_broker.mesh_status(workspace=await google.status()),
        )

    @app.post("/v1/google/connect")
    async def google_connect(body: GoogleConnectBody, x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            await google.store_refresh_token("owner", body.refresh_token, body.scopes)
        except GoogleAuthError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return await google.status()

    @app.post("/v1/google/revoke")
    async def google_revoke(x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        await google.revoke()
        return await google.status()

    @app.post("/v1/google/owner-revoke")
    async def google_owner_revoke(request: Request):
        """GAP-F-024 — the owner can cut Google from the phone.

        Revocation was reachable only with the internal-control credential (an operator
        on the host). A compromised token is exactly when the owner is not at the host,
        so this route is device-authenticated and device-proofed like every other
        owner mutation. Connect stays on the host: consent needs the OAuth client secret.
        """
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")
        await google.revoke()
        await audit.record(
            result="ok", device_id=device_id, capability="google.owner_revoke",
            after={"status": "revoked"},
        )
        return await google.status()

    @app.get("/v1/google/mesh")
    async def google_mesh():
        return await google_broker.mesh_status(workspace=await google.status())

    @app.get("/v1/google/capabilities")
    async def google_capabilities():
        mesh = await google_broker.mesh_status(workspace=await google.status())
        return {"registry_version": mesh["registry_version"], "capabilities": mesh["capabilities"]}

    @app.post("/v1/google/jobs/plan")
    async def plan_google_job(body: GoogleRouteRequest, x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        return await google_router.plan(body, workspace=await google.status())

    @app.get("/v1/google/jobs/{job_id}")
    async def get_google_job(job_id: str, x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        job = await google_router.job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="google_job_not_found")
        return job

    @app.post("/v1/google/jobs/{job_id}/artifacts")
    async def record_google_artifact(
        job_id: str,
        body: GoogleArtifactBody,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.GOOGLE)
        try:
            return await google_router.record_artifact(
                job_id=job_id,
                source_tool=body.source_tool,
                output_hash=body.output_hash,
                project_id=body.project_id,
                tool_version=body.tool_version,
                input_hashes=body.input_hashes,
                trust=body.trust,
                validation_state=body.validation_state,
                parent_artifact_ids=body.parent_artifact_ids,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/attention")
    async def upsert_attention(body: AttentionUpsertBody):
        item = await attention.upsert(
            title=body.title,
            severity=body.severity,
            source=body.source,
            dedupe_key=body.dedupe_key,
            project_id=body.project_id,
        )
        await events.publish("attention.upserted", item.model_dump())
        return item

    @app.get("/v1/attention")
    async def list_attention():
        return await attention.list_open()

    @app.post("/v1/attention/{item_id}/ack")
    async def ack_attention(item_id: str):
        await attention.acknowledge(item_id)
        return {"acknowledged": True}

    @app.post("/v1/attention/{item_id}/snooze")
    async def snooze_attention(item_id: str, body: AttentionSnoozeBody):
        """Owner-device snooze route used by the Attention swipe action.

        The durable state remains in AttentionEngine; this route only validates/serialises the
        device request and emits the same event-bus evidence style as other attention changes.
        """
        try:
            changed = await attention.snooze(item_id, body.until_unix)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        if not changed:
            raise HTTPException(status_code=404, detail="attention_item_not_found")
        await events.publish(
            "attention.snoozed",
            {"item_id": item_id, "snooze_until_unix": int(body.until_unix)},
        )
        return {"snoozed": True, "snooze_until_unix": int(body.until_unix)}

    @app.post("/v1/notifications/ingest")
    async def ingest_notification(note: PhoneNotification):
        # P3-OPS-005 — the durable path. `ingest` alone deduped against a set()
        # that a restart emptied, so a restart re-showed what the owner had seen.
        filtered = await notifications.ingest_durable(note)
        if not filtered.suppressed:
            await attention.upsert(
                title=filtered.title,
                severity=__import__("van_gateway.models", fromlist=["AttentionSeverity"]).AttentionSeverity(
                    filtered.classification.value
                ),
                source=f"notification:{filtered.package}",
                dedupe_key=f"notif:{filtered.key}",
                payload={"text": filtered.text, "redacted": filtered.redacted},
            )
        return filtered

    @app.post("/v1/context/ingest")
    async def ingest_captured_context(body: dict[str, Any], request: Request):
        """Device-captured data lane. It cannot mint owner authority.

        Notifications and shares originate in other applications. The device may preserve
        and forward them, but VAN must never turn their text into an OWNER_DEVICE command.
        The Android queue therefore sends CONTEXT_INGEST records here rather than through
        /v1/commands. This route is device-authenticated, hardware-proofed when the owner
        device binding is active, bounded, explicitly UNTRUSTED_EXTERNAL, and produces only
        evidence/event/attention state.

        SESSION_ENVELOPE never reaches this route; it belongs to the durable session
        consumer. Keeping those two non-command queue classes separate is also what stops
        the generic replayer deleting a persisted session command before restore reads it.
        """
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="device_identity_required")

        if body.get("untrusted_content") is not True:
            raise HTTPException(status_code=422, detail="captured_context_must_be_untrusted")

        source = str(body.get("source") or "").strip().lower()
        context_id = str(body.get("context_id") or "").strip()
        if source not in {"notification", "share"}:
            raise HTTPException(status_code=422, detail="captured_context_source_unsupported")
        if not context_id or len(context_id) > 256:
            raise HTTPException(status_code=422, detail="captured_context_id_required")

        encoded = json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        if len(encoded.encode("utf-8")) > 65_536:
            raise HTTPException(status_code=413, detail="captured_context_too_large")

        event_payload: dict[str, Any]
        suppressed = False
        if source == "notification":
            package = str(body.get("package") or "").strip()
            if not package:
                raise HTTPException(status_code=422, detail="notification_package_required")
            priority = str(body.get("priority") or "NORMAL").strip().upper()
            posted_at_ms = int(body.get("posted_at") or 0)
            policy = AppPolicy.PRIORITY if priority == "PRIORITY" else AppPolicy.NORMAL
            note = PhoneNotification(
                key=context_id,
                package=package,
                title=str(body.get("title") or ""),
                text=str(body.get("body") or ""),
                importance=4 if policy is AppPolicy.PRIORITY else 3,
                posted_at_unix=max(0, posted_at_ms // 1000),
                policy=policy,
            )
            filtered = await notifications.ingest_durable(note)
            suppressed = filtered.suppressed
            if not filtered.suppressed:
                await attention.upsert(
                    title=filtered.title,
                    severity=AttentionSeverity(filtered.classification.value),
                    source=f"notification:{filtered.package}",
                    dedupe_key=f"notif:{filtered.key}",
                    payload={"text": filtered.text, "redacted": filtered.redacted},
                )
            event_payload = {
                "context_id": context_id,
                "source": source,
                "package": filtered.package,
                "title": filtered.title,
                "text": filtered.text,
                "classification": filtered.classification.value,
                "suppressed": filtered.suppressed,
                "redacted": filtered.redacted,
                "source_trust": "UNTRUSTED_EXTERNAL",
                "authority": "NONE",
            }
        else:
            # Share content was already secret-filtered on the handset. The gateway still
            # refuses an empty envelope rather than creating a durable event that carries
            # nothing and later looks like successful ingestion.
            text_value = str(body.get("text") or "")
            subject_value = str(body.get("subject") or "")
            uris = body.get("uris") if isinstance(body.get("uris"), list) else []
            if not text_value and not subject_value and not uris:
                raise HTTPException(status_code=422, detail="share_content_required")
            event_payload = {
                "context_id": context_id,
                "source": source,
                "share_id": str(body.get("share_id") or ""),
                "mime": str(body.get("mime") or ""),
                "kind": str(body.get("kind") or ""),
                "text": text_value,
                "subject": subject_value,
                "uris": [str(item) for item in uris[:32]],
                "source_trust": "UNTRUSTED_EXTERNAL",
                "authority": "NONE",
            }

        event_seq = await events.publish(
            f"context.{source}.ingested",
            event_payload,
            target_device_id=device_id,
            event_id=f"context:{device_id}:{context_id}",
        )
        await audit.record(
            result="ok",
            device_id=device_id,
            capability="context.data.ingest",
            after={"source": source, "context_id": context_id, "event_seq": event_seq},
        )
        return {
            "accepted": True,
            "source": source,
            "context_id": context_id,
            "event_seq": event_seq,
            "suppressed": suppressed,
            "authority": "NONE",
            "source_trust": "UNTRUSTED_EXTERNAL",
        }

    # --------------------------------------------------- Gate 11: operator surface
    @app.post("/v1/observability/device-telemetry")
    async def ingest_device_telemetry(body: DeviceTelemetryBody):
        """P3-OBS-002 — aura frame time, wake/ASR/TTS latency and the battery and
        memory indicators are measured on the device. The gateway cannot produce
        them and must not invent them, so this is where they arrive.

        Device-authenticated, not operator-authenticated: the producer is the
        owner's paired device.
        """
        accepted, refused = [], []
        for sample in body.samples[:200]:
            try:
                accepted.append(observability_instruments.record_device_sample(
                    sample.name, sample.value,
                    surface=sample.surface, dimension=sample.dimension,
                ))
            except observability_instruments.UnknownDeviceMetric:
                refused.append(sample.name)
            except observability_instruments.DeviceDimensionMissing:
                # Refused rather than recorded under a default. A depth with no
                # storability would put approval-bearing commands in the same bucket as
                # a retry queue, and an operator reading that chart would be told the
                # opposite of what is true.
                refused.append(sample.name)
        return {"accepted": len(accepted), "refused": refused}

    @app.get("/v1/observability/metrics")
    async def metrics_scrape(x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.OBSERVABILITY)
        return PlainTextResponse(
            render_prometheus(METRICS),
            media_type="text/plain; version=0.0.4; charset=utf-8",
        )

    async def _ops_health() -> dict:
        return await ops_health.collect(
            scheduler=scheduler,
            pki_dir=settings.pki_dir or None,
            device_pki_dir=settings.mtls_dir if settings.mtls_enabled else None,
            backup_root=settings.backup_dir or None,
        )

    from van_gateway.owner_api import OwnerServiceApi
    owner_services = OwnerServiceApi(
        store, knowledge=owner_runtime.knowledge, research=owner_runtime.research,
        automation_health=automation_health, ops_health=_ops_health,
    )
    app.state.owner_services = owner_services
    app.include_router(owner_services.router)

    @app.get("/v1/observability/alerts")
    async def observability_alert_state(x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.OBSERVABILITY)
        health = await _ops_health()
        firing = observability_alerts.evaluate(
            METRICS,
            uptime_seconds=time.monotonic() - started_at,
            ops_facts=ops_health.ops_facts(health),
        )
        return {
            "firing": [alert.as_dict() for alert in firing],
            "rules_evaluated": len(observability_alerts.RULES),
            "uptime_seconds": round(time.monotonic() - started_at),
        }

    @app.get("/v1/observability/health")
    async def observability_health(x_van_internal_token: str | None = Header(default=None)):
        require_internal_control(x_van_internal_token, ControlScope.OBSERVABILITY)
        health = await _ops_health()
        audit_chain = await audit.verify_chain()
        return {
            **health,
            "audit_chain": audit_chain,
            "unobserved_metrics": [m.name for m in METRICS.unobserved()],
            "uptime_seconds": round(time.monotonic() - started_at),
        }

    @app.get("/v1/observability/trace/{command_id}")
    async def observability_trace(
        command_id: str, x_van_internal_token: str | None = Header(default=None)
    ):
        """P2-OBS-001 — the join an operator used to do by hand, in one call."""
        require_internal_control(x_van_internal_token, ControlScope.OBSERVABILITY)
        trace = await tracer.trace(command_id)
        if not trace.found:
            raise HTTPException(status_code=404, detail="no_trace_for_command")
        return trace.as_dict()

    @app.get("/v1/degraded")
    async def get_degraded():
        return degraded.snapshot()

    @app.get("/v1/projects")
    async def list_projects():
        return {"projects": projects.known_projects()}

    @app.get("/v1/projects/{project_id}/truth")
    async def project_truth(project_id: str):
        return await projects.load_truth(project_id)

    @app.get("/v1/events")
    async def get_events(request: Request, device_id: str, after_seq: int = 0):
        if getattr(request.state, "van_device_id", None) != device_id:
            raise HTTPException(status_code=403, detail="device_identity_mismatch")
        return await events.replay(device_id, after_seq)

    # ------------------------------------------------------------ VATI trading
    def _trading_status_payload() -> dict:
        from van_gateway.models import DegradedCode

        try:
            status = trading.status()
        except Exception as exc:
            degraded.set(DegradedCode.TRADING_LEDGER_UNAVAILABLE, True)
            return {
                "ledger_available": False,
                "ledger_path": trading.ledger_path,
                "chain_ok": None,
                "error": str(exc),
                "degraded": degraded.codes(),
            }
        # P0-TRADE-004 — a stale ledger is unavailable for the purpose of answering, even
        # though the file opens and the chain verifies. Reporting it as available was how
        # old data came back as current.
        degraded.set(
            DegradedCode.TRADING_LEDGER_UNAVAILABLE,
            not (
                status.get("ledger_available")
                and status.get("chain_ok")
                and not status.get("ledger_stale", False)
            ),
        )
        status["degraded"] = degraded.codes()
        return status

    @app.get("/v1/trading/status")
    async def trading_status():
        return _trading_status_payload()

    @app.get("/v1/trading/trades")
    async def trading_trades(view: str = "all", limit: int = 50):
        try:
            return trading.trade_book(view=view, limit=limit)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.get("/v1/trading/portfolio")
    async def trading_portfolio():
        return trading.portfolio()

    # Trading intelligence read models (owner-device routes). Each reads the
    # hash-chained ledger directly and answers {"ledger_available": False, ...}
    # when it cannot; the device shows an honest unavailable state, never a fixture.
    @app.get("/v1/trading/positions")
    async def trading_positions():
        return trading.positions()

    @app.get("/v1/trading/events")
    async def trading_events(limit: int = 50):
        return trading.events(limit=max(1, min(limit, 500)))

    @app.get("/v1/trading/potential")
    async def trading_potential():
        return trading.potential_trades()

    @app.get("/v1/trading/history")
    async def trading_history(limit: int = 50):
        return trading.history(limit=max(1, min(limit, 500)))

    @app.get("/v1/trading/assessment")
    async def trading_assessment():
        return trading.assessment()

    @app.get("/v1/trading/accounts")
    async def trading_accounts():
        return trading.accounts()

    @app.get("/v1/trading/market-state")
    async def trading_market_state(symbol: str | None = None):
        return trading.market_state(symbol)

    @app.get("/v1/trading/risk")
    async def trading_risk():
        return trading.risk()

    @app.get("/v1/trading/cognitive-fabric/{account_alias}")
    async def trading_cognitive_fabric(account_alias: str):
        return trading.cognitive_fabric(account_alias)

    @app.post("/v1/trading/cognitive-fabric/{account_alias}/{operation}")
    async def trading_cognitive_candidate(account_alias: str, operation: str, body: dict):
        try:
            return trading.cognitive_import(account_alias, operation, body)
        except (ValueError, TypeError, KeyError) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.get("/v1/trading/cognition")
    async def trading_cognition():
        """Read-only Rev 5.1 cognition/research/evolution projection."""
        return trading.cognition()

    @app.get("/v1/trading/trades/{trade_intent_id}")
    async def trading_trade_detail(trade_intent_id: str):
        detail = trading.trade_detail(trade_intent_id)
        if detail is None:
            raise HTTPException(status_code=404, detail="unknown trade intent")
        return detail

    @app.get("/v1/trading/bars")
    async def trading_bars(symbol: str, timeframe: str = "H1", limit: int = 300, end_ms: int | None = None):
        try:
            return trading.bars(symbol, timeframe, limit=limit, end_ms=end_ms)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    async def _authenticate_account_action(request: Request, req) -> None:
        """Device identity, known action, device signature and freshness. Shared by the
        challenge route and the action route so they cannot diverge."""
        if getattr(request.state, "van_device_id", None) != req.device_id:
            raise HTTPException(status_code=403, detail="device_identity_mismatch")
        if req.action not in ACCOUNT_ACTIONS:
            raise HTTPException(status_code=404, detail="unknown account action")
        if {"_expected_resource_version", "_native_operation", "_expected_review_digest"}.intersection(req.args):
            raise HTTPException(status_code=422, detail="native resource binding is supplied by the gateway")
        try:
            await auth.require_device(req.device_id)
            auth.verify_signature(
                req.device_id,
                canonical_action(req.device_id, req.issued_at_unix, req.action, req.args),
                req.signature,
            )
        except AuthError as exc:
            await audit.record(
                result="denied",
                device_id=req.device_id,
                capability=f"trading.account.{req.action}",
                failure_reason=exc.code,
            )
            raise HTTPException(status_code=403, detail=exc.message) from exc
        import time as _time

        if abs(int(_time.time()) - req.issued_at_unix) > 300:
            raise HTTPException(status_code=403, detail="stale owner action; sign again")

    @app.get('/v1/trading/accounts/catalog',response_model=AccountActionCatalog)
    async def trading_account_catalog(request: Request):
        device_id=getattr(request.state,'van_device_id',None)
        if not device_id:
            raise HTTPException(403,'paired owner device is required')
        try:
            await auth.require_device(device_id)
        except AuthError as exc:
            raise HTTPException(403,exc.message) from None
        from commander.accounts import ACCOUNT_TOOL_SCHEMAS,BROKER_SECRET_KEYS
        from commander.account_effects import JOURNALED_COMMANDS
        import copy
        schemas={key:{'type':'object',**copy.deepcopy(value)} for key,value in ACCOUNT_TOOL_SCHEMAS.items()}
        schemas['oauth_start']={'type':'object','properties':{'broker':{'enum':['deriv','ctrader']},
            'app_id':{'type':'string'},'client_id':{'type':'string'},'client_secret':{'type':'string','writeOnly':True}},'required':['broker']}
        schemas['oauth_pending']={'type':'object','properties':{'state':{'type':'string'}},'required':['state']}
        for name in ('deriv_oauth_link','ctrader_link'):
            selection={'type':'object','properties':{'alias':{'type':'string'},'state':{'type':'string'},
                'label':{'type':'string'},'currency':{'type':'string'},
                **({'loginid':{'type':'string'}} if name=='deriv_oauth_link' else
                   {'ctid_trader_account_id':{'type':'integer'},'is_live':{'type':'boolean'}})},
                'required':['alias','state','loginid'] if name=='deriv_oauth_link' else ['alias','state','ctid_trader_account_id']}
            schemas[name]={'oneOf':[schemas[name],selection]}
        def mark_private_inputs(definition):
            for key,value in definition.get('properties',{}).items():
                if re.search(r'secret|token|password|code',key,re.I): value['writeOnly']=True
                mark_private_inputs(value)
            for option in definition.get('oneOf',[]): mark_private_inputs(option)
        for definition in schemas.values(): mark_private_inputs(definition)
        schemas['account_credentials']['properties']['secrets']['additionalProperties']={'type':'string','writeOnly':True}
        return {'schema':'van.account-actions/1',
            'actions':[{'action':action,'requires_owner_approval':requires_owner_approval(action),
                'requires_resolved_review':action in {'account_upsert','account_remove'},
                'supports_original_operation_readback':action in JOURNALED_COMMANDS,
                'input_schema':schemas[action]} for action in ACCOUNT_ACTIONS],
            'credential_keys_by_broker':{key:sorted(value) for key,value in BROKER_SECRET_KEYS.items()}}

    @app.post("/v1/trading/accounts/challenge",response_model=AccountChallengeResponse)
    async def trading_account_challenge(request: Request, req: AccountChallengeRequest):
        """P1-SEC-004 — the one-time challenge the device signs inside the biometric.

        The challenge is bound to the device, the action and a digest of the arguments, so
        an approval for "verify this account" cannot be presented for "issue me a signing
        key", and approving one set of credentials does not approve a different set.
        """
        await _authenticate_account_action(request, req)
        if not requires_owner_approval(req.action):
            raise HTTPException(
                status_code=400,
                detail="this action is read-only and needs no owner approval",
            )
        native_version,native_review = await onboarding.approval_context(req.action, req.args, owner_device_id=req.device_id)
        challenge = await app.state.orchestrator.approvals.issue(
            device_id=req.device_id,
            source_command_id=f"account:{req.action}",
            turn_id=None,
            action_id=f"trading.account.{req.action}",
            text=account_approval_text(req.device_id, req.issued_at_unix, req.action, req.args, native_version),
            project_id=None,
            parameters={'native_review':native_review} if native_review else None,
        )
        return {
            "approval_challenge_id": challenge.challenge_id,
            "approval_challenge": challenge.canonical,
            "issued_at_unix": req.issued_at_unix,
            "approval_expires_at_unix": challenge.expires_at_unix,
            "resolved_action_id": f"trading.account.{req.action}",
            "resolved_review":native_review,
        }

    @app.get("/v1/trading/accounts/operations/{operation_id}", response_model=AccountOperationResponse,
             responses={409:{"model":AccountActionConflictResponse}})
    async def trading_account_operation(request: Request, operation_id: str):
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(403, "paired owner device is required")
        try:
            await auth.require_device(device_id)
        except AuthError as exc:
            raise HTTPException(403, exc.message) from None
        if not re.fullmatch(r"[A-Za-z0-9_-]{20,128}", operation_id):
            raise HTTPException(422, "invalid account operation identity")
        try:
            return await asyncio.to_thread(onboarding.control.operation, operation_id, device_id)
        except HTTPException as exc:
            if getattr(exc, "effect_state", None) == "UNKNOWN":
                return JSONResponse(status_code=409, content=AccountActionConflictResponse(
                    detail="Original native operation is unconfirmed; do not repeat its effects",
                    effect_state="UNKNOWN", reconciliation_required=True, operation_id=operation_id).model_dump())
            raise
        except Exception:
            return JSONResponse(status_code=409, content=AccountActionConflictResponse(
                detail="Original native operation cannot be verified; do not repeat its effects",
                effect_state="UNKNOWN", reconciliation_required=True, operation_id=operation_id).model_dump())

    @app.post("/v1/trading/accounts/action", responses={409:{"model":AccountActionConflictResponse}})
    async def trading_account_action(request: Request, req: AccountActionRequest):
        await _authenticate_account_action(request, req)
        native_version = None
        native_operation = None
        native_review = None
        # P1-SEC-004. This used to be guarded on the device by a biometric prompt whose
        # only output was "the prompt succeeded", which the gateway never saw and which
        # nothing bound to this action. The strong path already existed for A4 commands;
        # trading credential changes were on the weak one.
        if requires_owner_approval(req.action):
            proof = req.approval_proof
            if proof is None or proof.algorithm != OwnerApprovalService.ALGORITHM:
                await audit.record(
                    result="denied",
                    device_id=req.device_id,
                    capability=f"trading.account.{req.action}",
                    failure_reason="approval_proof_missing",
                )
                raise HTTPException(
                    status_code=403,
                    detail="owner biometric approval proof is required for this action",
                )
            try:
                native_version,native_review = await onboarding.approval_context(req.action, req.args, owner_device_id=req.device_id)
            except HTTPException as exc:
                if exc.status_code != 409:
                    raise
                await audit.record(result="refused", device_id=req.device_id,
                    capability=f"trading.account.{req.action}", failure_reason=str(exc.detail),
                    before=redact_account_args(req.args))
                return JSONResponse(status_code=409, content=AccountActionConflictResponse(
                    detail=str(exc.detail), effect_state="REFUSED", reconciliation_required=False).model_dump())
            try:
                native_operation = await app.state.orchestrator.approvals.verify_and_consume(
                    challenge_id=proof.challenge_id,
                    source_command_id=f"account:{req.action}",
                    signature_b64=proof.signature_b64,
                    device_id=req.device_id,
                    turn_id=None,
                    action_id=f"trading.account.{req.action}",
                    text=account_approval_text(
                        req.device_id, req.issued_at_unix, req.action, req.args, native_version
                    ),
                    project_id=None,
                    parameters={'native_review':native_review} if native_review else None,
                )
            except OwnerApprovalError as exc:
                await audit.record(
                    result="denied",
                    device_id=req.device_id,
                    capability=f"trading.account.{req.action}",
                    approval="invalid",
                    failure_reason=str(exc),
                )
                raise HTTPException(status_code=403, detail=str(exc)) from exc
        try:
            result = await onboarding.run(req.action, req.args, owner_device_id=req.device_id, native_resource_version=native_version, native_operation=native_operation, native_review=native_review)
        except HTTPException as exc:
            unknown = isinstance(exc,OAuthEffectUnconfirmed) or getattr(exc, "effect_state", None) == "UNKNOWN"
            reconcile = unknown or isinstance(exc,OAuthTargetBlocked) or getattr(exc, "reconciliation_required", False)
            await audit.record(
                result="unknown" if unknown else "refused",
                device_id=req.device_id,
                capability=f"trading.account.{req.action}",
                failure_reason=str(exc.detail)[:200],
                before=redact_account_args(req.args),
            )
            if exc.status_code==409:
                response = AccountActionConflictResponse(detail=str(exc.detail),
                    effect_state="UNKNOWN" if unknown else "REFUSED",reconciliation_required=reconcile,
                    operation_id=getattr(exc, "operation_id", None))
                return JSONResponse(status_code=409,content=response.model_dump())
            raise
        await audit.record(
            result="ok",
            device_id=req.device_id,
            capability=f"trading.account.{req.action}",
            before=redact_account_args(req.args),
            after={
                k: v
                for k, v in result.items()
                if k in ("account", "alias", "state", "ready", "stored_keys", "removed", "ok")
            },
        )
        from commander.account_effects import JOURNALED_COMMANDS
        if req.action in JOURNALED_COMMANDS and native_operation:
            return {**result, "operation_id":native_operation["operation_id"], "action":req.action,
                    "effect_state":"APPLIED", "reconciliation_required":False}
        return result

    def _strategy_promotion_text(req) -> str:
        return canonical_strategy_promotion(
            req.device_id,
            req.issued_at_unix,
            strategy_id=req.strategy_id,
            target_state=req.target_state,
            owner_signature_ref=req.owner_signature_ref,
            certificate=req.certificate,
            evidence_refs=req.evidence_refs,
        )

    async def _authenticate_strategy_promotion(request: Request, req) -> None:
        if getattr(request.state, "van_device_id", None) != req.device_id:
            raise HTTPException(status_code=403, detail="device_identity_mismatch")
        try:
            await auth.require_device(req.device_id)
            auth.verify_signature(
                req.device_id,
                _strategy_promotion_text(req),
                req.signature,
            )
        except AuthError as exc:
            await audit.record(
                result="denied",
                device_id=req.device_id,
                capability="trading.strategy.promote",
                failure_reason=exc.code,
            )
            raise HTTPException(status_code=403, detail=exc.message) from exc
        import time as _time
        if abs(int(_time.time()) - req.issued_at_unix) > 300:
            raise HTTPException(status_code=403, detail="stale owner action; sign again")

    @app.get("/v1/trading/strategies/promotion-candidates")
    async def trading_strategy_promotion_candidates(request: Request):
        """Owner-device read of sealed validation evidence eligible for promotion."""
        device_id = getattr(request.state, "van_device_id", None)
        if not device_id:
            raise HTTPException(status_code=403, detail="owner_device_required")
        try:
            await auth.require_device(device_id)
            result = app.state.strategy_promotions.candidates()
        except AuthError as exc:
            raise HTTPException(status_code=403, detail=exc.message) from exc
        return result

    @app.post("/v1/trading/strategies/promotion-challenge")
    async def trading_strategy_promotion_challenge(
        request: Request, req: StrategyPromotionChallengeRequest
    ):
        """Issue an A4 challenge bound to the exact strategy, target and certificate."""
        await _authenticate_strategy_promotion(request, req)
        text = _strategy_promotion_text(req)
        challenge = await app.state.orchestrator.approvals.issue(
            device_id=req.device_id,
            source_command_id="strategy:promote",
            turn_id=None,
            action_id="trading.strategy.promote",
            text=text,
            project_id=None,
        )
        return {
            "approval_challenge_id": challenge.challenge_id,
            "approval_challenge": challenge.canonical,
            "approval_expires_at_unix": challenge.expires_at_unix,
            "resolved_action_id": "trading.strategy.promote",
        }

    @app.post("/v1/trading/strategies/promote")
    async def trading_strategy_promote(
        request: Request, req: StrategyPromotionRequest
    ):
        """Owner-device/A4 gated server-side strategy promotion workflow.

        The gateway does not mutate the capsule. It proves current owner intent and
        forwards the certificate-bound request to the private commander, which verifies
        van-oa1 authority and commits the VATI ledger event.
        """
        await _authenticate_strategy_promotion(request, req)
        proof = req.approval_proof
        if proof is None or proof.algorithm != OwnerApprovalService.ALGORITHM:
            await audit.record(
                result="denied",
                device_id=req.device_id,
                capability="trading.strategy.promote",
                failure_reason="approval_proof_missing",
            )
            raise HTTPException(
                status_code=403,
                detail="owner biometric approval proof is required for strategy promotion",
            )
        text = _strategy_promotion_text(req)
        try:
            await app.state.orchestrator.approvals.verify_and_consume(
                challenge_id=proof.challenge_id,
                source_command_id="strategy:promote",
                signature_b64=proof.signature_b64,
                device_id=req.device_id,
                turn_id=None,
                action_id="trading.strategy.promote",
                text=text,
                project_id=None,
            )
        except OwnerApprovalError as exc:
            await audit.record(
                result="denied",
                device_id=req.device_id,
                capability="trading.strategy.promote",
                approval="invalid",
                failure_reason=str(exc),
            )
            raise HTTPException(status_code=403, detail=str(exc)) from exc

        device_row = await store.fetchone(
            "SELECT public_key_pem, revoked_at_unix FROM devices WHERE device_id = ?",
            (req.device_id,),
        )
        if (
            device_row is None
            or device_row["revoked_at_unix"] is not None
            or not str(device_row["public_key_pem"] or "").strip()
        ):
            raise HTTPException(
                status_code=403,
                detail="paired owner approval key is unavailable or revoked",
            )

        try:
            enrollment = app.state.strategy_promotions.ensure_owner_authority(
                device_id=req.device_id,
                public_key_pem=str(device_row["public_key_pem"]),
            )
            result = app.state.strategy_promotions.promote(
                strategy_id=req.strategy_id,
                target_state=req.target_state,
                owner_signature_ref=req.owner_signature_ref,
                certificate=req.certificate,
                evidence_refs=req.evidence_refs,
                approved_at_unix=req.issued_at_unix,
            )
        except HTTPException as exc:
            await audit.record(
                result="refused",
                device_id=req.device_id,
                capability="trading.strategy.promote",
                failure_reason=str(exc.detail)[:200],
                before={
                    "strategy_id": req.strategy_id,
                    "target_state": req.target_state,
                    "validation_hash": req.certificate.get("validation_hash"),
                },
            )
            raise

        await audit.record(
            result="strategy_promotion_recorded",
            device_id=req.device_id,
            capability="trading.strategy.promote",
            approval=result.get("owner_authority_ref"),
            tool="van_trading_commander",
            before={
                "strategy_id": req.strategy_id,
                "target_state": req.target_state,
                "validation_hash": req.certificate.get("validation_hash"),
            },
            after={
                **{
                    k: result.get(k)
                    for k in (
                        "strategy_id", "from", "to", "capsule_hash",
                        "validation_hash", "event_hash", "registry_projection",
                    )
                },
                "owner_key_id": enrollment.get("key_id"),
            },
            evidence_pointer=result.get("event_hash"),
        )
        return result

    @app.get("/v1/trading/oauth/{broker}/callback")
    async def trading_oauth_callback(broker: str, request: Request):
        """The one HTML response in the gateway, and the only one a stranger can reach.

        P4-SEC-011: this built its markup by interpolation. Every interpolated value was a
        constant at the time, so it was not exploitable — but `broker` is a path segment
        and an HTTPException detail can carry a query parameter back, so it was one
        parameter away from being so. Escaping is cheap and the pattern is what matters:
        the next person to add a field here should not have to notice this.
        """
        import html

        from fastapi.responses import HTMLResponse

        headers = {"Cache-Control": "no-store", "Referrer-Policy": "no-referrer"}
        try:
            result = await onboarding.oauth_callback(broker, dict(request.query_params))
        except HTTPException as exc:
            title = "authorization status unconfirmed" if isinstance(exc,OAuthEffectUnconfirmed) else "authorization refused"
            return HTMLResponse(
                f"<h2>Van: {html.escape(title)}</h2><p>{html.escape(str(exc.detail))}</p>",
                status_code=exc.status_code, headers=headers,
            )
        return HTMLResponse(
            f"<h2>Van: {html.escape(str(result['broker']))} authorization received</h2>"
            "<p>Return to the Van app to choose the account. You can close this page.</p>",
            headers=headers,
        )

    @app.post("/v1/visual/acceptance")
    async def record_visual_acceptance(req: VisualAcceptanceBody, request: Request):
        if not getattr(request.state, "van_device_id", None):
            raise HTTPException(status_code=401, detail="owner_device_required")
        try:
            return await visual_acceptance.record(
                token=req.token,
                rive_sha256=req.rive_sha256,
                apk_sha256=req.apk_sha256,
                device_model=req.device_model,
                android_build=req.android_build,
            )
        except VisualAcceptanceError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc

    @app.get("/v1/visual/acceptance")
    async def latest_visual_acceptance(request: Request):
        if not getattr(request.state, "van_device_id", None):
            raise HTTPException(status_code=401, detail="owner_device_required")
        record = await visual_acceptance.latest()
        if record is None:
            raise HTTPException(status_code=404, detail="visual_acceptance_not_recorded")
        return record

    @app.get("/v1/trading/tickets")
    async def trading_tickets(status: str | None = None):
        return {"ledger_available": trading.available(), "tickets": trading.tickets(status=status)}

    @app.post("/v1/trading/halt")
    async def trading_halt(
        req: OwnerHaltRequest,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.TRADING)
        try:
            result = trading.halt(owner_signature_ref=req.owner_signature_ref, reason=req.reason)
        except TradingControlError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except FileNotFoundError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        await audit.record(
            result="owner_halt_recorded",
            capability="trading.owner_halt",
            # The verified authority's reference, never the raw token: these rows are
            # long-lived and the token is a credential (P0-TRADE-001).
            approval=result["sig"],
            tool="vati_ledger",
            after={"event_hash": result["event_hash"], "chain_hash": result["chain_hash"]},
            evidence_pointer=result["event_hash"],
        )
        return result

    @app.post("/v1/trading/tickets/{ticket_id}/confirm")
    async def trading_confirm_ticket(
        ticket_id: str,
        req: TicketConfirmRequest,
        x_van_internal_token: str | None = Header(default=None),
    ):
        require_internal_control(x_van_internal_token, ControlScope.TRADING)
        try:
            result = trading.confirm_ticket(
                ticket_id,
                owner_signature_ref=req.owner_signature_ref,
                fill_price=req.fill_price,
                filled_qty=req.filled_qty,
                contract_note_ref=req.contract_note_ref,
            )
        except TradingAuthorityError as exc:
            # Not authorised is a 403; a ticket already confirmed is the 409 below.
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except TradingControlError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        except FileNotFoundError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        await audit.record(
            result="owner_ticket_confirmed",
            capability="trading.ticket_confirm",
            approval=req.owner_signature_ref,
            tool="vati_ledger",
            after={"ticket": ticket_id, "event_hash": result["event_hash"]},
            evidence_pointer=result["event_hash"],
        )
        return result

    @app.post("/v1/events/reset")
    async def reset_events(request: Request, device_id: str):
        if getattr(request.state, "van_device_id", None) != device_id:
            raise HTTPException(status_code=403, detail="device_identity_mismatch")
        await events.reset_cursor(device_id)
        from van_gateway.models import DegradedCode

        degraded.set(DegradedCode.EVENT_CURSOR_RESET, True)
        return {"reset": True, "device_id": device_id}

    return app


from van_gateway.lazy_app import LazyGateway

app = LazyGateway(create_app)
