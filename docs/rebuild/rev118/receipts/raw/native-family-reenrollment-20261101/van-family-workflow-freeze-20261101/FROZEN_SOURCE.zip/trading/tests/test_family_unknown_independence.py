"""UNKNOWN original full-close outcome cannot cancel another leg's protection."""
from contextlib import closing
from decimal import Decimal as D

from conftest import owner_authority
from test_family_governed_workflow import admitted_source_world
from vati.core import Ledger, EventKind
from vati.lifecycle.family_action_journal import FamilyActionJournal
from vati.risk.operational_grant import OperationalOptimizationGrants, subject


def test_original_unknown_full_target_is_not_resent_and_other_full_leg_executes(tmp_path,monkeypatch):
    w,store,time,grant,plan,history=admitted_source_world(tmp_path,
        actual_runtime_lease=True,add_child=True,max_quantity='.20')
    try:
        family=w.lifecycle.families.get(plan.snapshot.family_id);close=w.adapter.close;calls=[]
        def lost_reply(pid,*args,**kwargs):
            calls.append(pid);receipt=close(pid,*args,**kwargs)
            if len(calls)==1:raise OSError('synthetic native effect happened but reply lost')
            return receipt
        monkeypatch.setattr(w.adapter,'close',lost_reply)
        result=w.lifecycle.request_family_reduction(family.family_id,action_key='unknown-full',
            action='FULL_CLOSE',now_ms=time[0])
        assert len(calls)==2 and not w.adapter.positions()
        assert result['state']=='INCOMPLETE' and result['unresolved_native_effect']
        assert D(result['confirmed_quantity'])>0 and D(result['residual_quantity'])>0
        assert sorted(t['state'] for t in result['targets'])==['CONFIRMED','UNKNOWN']
        assert not w.lifecycle.reviews and not w.learning.episodes
        time[0]+=300000
        replay=w.lifecycle.request_family_reduction(family.family_id,action_key='unknown-full',
            action='FULL_CLOSE',now_ms=time[0])
        assert replay==result and len(calls)==2
        assert w.lifecycle.preservation_blocks_new_risk
    finally:w.ledger.close()


def test_committed_other_writer_revocation_refuses_next_target_but_native_stop_survives(tmp_path,monkeypatch):
    w,store,time,grant,plan,history=admitted_source_world(tmp_path,
        actual_runtime_lease=True,add_child=True,max_quantity='.20')
    try:
        family=w.lifecycle.families.get(plan.snapshot.family_id);apply=w.lifecycle.families.apply;revoked=[]
        def apply_then_revoke(*args,**kwargs):
            result=apply(*args,**kwargs)
            if not revoked:
                with closing(Ledger(w.ledger.path)) as other:
                    peer=OperationalOptimizationGrants(other,owner_authority=store.owner,
                        qualification_authority=store.qualifier,clock=store.clock)
                    body=dict(grant_id=grant.payload['grant_id'],expected_ref=grant.hash)
                    signed=owner_authority().token(act='lifecycle-policy-revoke',subject=subject(body),
                        issued_at_unix=time[0]//1000)
                    revoked.append(peer.revoke(grant.payload['grant_id'],expected_ref=grant.hash,owner_signature=signed).hash)
            return result
        monkeypatch.setattr(w.lifecycle.families,'apply',apply_then_revoke)
        result=w.lifecycle.request_family_reduction(family.family_id,action_key='revoke-between-legs',
            action='FULL_CLOSE',now_ms=time[0])
        assert revoked and len(w.adapter.positions())==1
        assert sorted(t['state'] for t in result['targets'])==['CONFIRMED','NOT_EXECUTED']
        assert not result['unresolved_native_effect'] and result['state']=='INCOMPLETE'
        refused=next(t for t in result['targets'] if t['state']=='NOT_EXECUTED')
        outcome=next(e for e in w.ledger.iter(EventKind.EXIT_ATTEMPT) if e.hash==refused['outcome_ref'])
        assert outcome.payload['receipt_event_ref'] is None and outcome.payload['dispatch_refusal_ref']
        remaining=w.adapter.positions()[0]
        # Existing urgent protection does not require the revoked partial-policy grant.
        receipts=w.router.apply_exits('paper','EURUSD',remaining.stop_price-D('.001'),remaining.stop_price,now_ms=time[0]+1000)
        assert len(receipts)==1 and receipts[0].status=='FILLED' and not w.adapter.positions()
    finally:w.ledger.close()
