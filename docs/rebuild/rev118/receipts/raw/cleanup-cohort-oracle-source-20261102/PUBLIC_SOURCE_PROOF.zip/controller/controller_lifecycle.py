"""Owned SOURCE controller primitives; no repository or authority operations."""
import errno,os,signal,stat
from pathlib import Path


def file_sizes(root):
    """SQLite may remove journals between enumeration and stat; only that races."""
    sizes=[]
    def walk_error(error):
        if error.errno not in (errno.ENOENT,errno.ENOTDIR):raise error
    for directory,_,names in os.walk(root,onerror=walk_error,followlinks=False):
        for name in names:
            try:info=(Path(directory)/name).stat()
            except (FileNotFoundError,NotADirectoryError):continue
            if stat.S_ISREG(info.st_mode):sizes.append(info.st_size)
    return sizes


def finish_owned(process):
    """Always terminate a still-running owned group, then wait/drain its child."""
    if process is None:return {'child_pid':None,'waited':False}
    if process.poll() is None:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:process.wait(timeout=5)
        except __import__('subprocess').TimeoutExpired:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
    # These controllers use owned files, not PIPEs; communicate still waits and
    # handles any future PIPE-based invocation before the group can be released.
    process.communicate(timeout=5)
    code=process.wait()
    try:os.killpg(process.pid,0);absent=False
    except ProcessLookupError:absent=True
    return {'child_pid':process.pid,'child_exit':code,'waited':True,'group_absent':absent}
