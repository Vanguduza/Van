from pathlib import Path
import os,sys,stat,fcntl,time,json,subprocess,resource,signal,shutil,hashlib,traceback,xml.etree.ElementTree as ET
from controller_lifecycle import file_sizes,finish_owned
root=Path('/dev/shm/van-cleanup-cohort-repair-20261102');lane=root/'source';tag=sys.argv[1];cwd=lane/('backend' if sys.argv[2]=='backend' else '');selectors=sys.argv[3:];assert selectors
fd=os.open('/tmp/van-rev118-test-resource-20261102.lock',os.O_RDWR|os.O_NOFOLLOW);st=os.fstat(fd);assert stat.S_ISREG(st.st_mode) and stat.S_IMODE(st.st_mode)==0o600 and st.st_uid==os.getuid();startwait=time.monotonic()
while True:
    try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);break
    except BlockingIOError:
        assert time.monotonic()-startwait<300;time.sleep(.3)
dest=root/'evidence'/tag;dest.mkdir(mode=0o700,exist_ok=False);child=None;reason=None;code=None;error=None
try:
    reserve=2*1024**3;cap=16*1024**2;totalcap=64*1024**2
    maxmem=int(Path('/sys/fs/cgroup/memory.max').read_text());mem=Path('/sys/fs/cgroup/memory.current')
    before={'workspace_free':shutil.disk_usage('/workspace').free,'tmp_free':shutil.disk_usage('/tmp').free,'SHM_free':shutil.disk_usage(root).free,'memory_current':int(mem.read_text()),'memory_max':maxmem,'SHM_device':root.stat().st_dev}
    assert before['workspace_free']>=32*1024**2 and before['tmp_free']>=reserve and before['SHM_free']>=reserve+totalcap and maxmem-int(mem.read_text())>=4*1024**3+totalcap
    for n in ['tmp','cache']:(dest/n).mkdir(mode=0o700)
    path=lane/'backend/tests/test_account_cleanup.py';beforehash=hashlib.sha256(path.read_bytes()).hexdigest()
    env=dict(os.environ,PYTHONPATH=':'.join(str(lane/p) for p in ['backend','backend/tests','','trading','trading/tests']),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',TMPDIR=str(dest/'tmp'),XDG_CACHE_HOME=str(dest/'cache'))
    command=['/workspace/van-backend-venv-20261025/bin/python','-B','-m','pytest','-p','pytest_asyncio.plugin','-p','anyio.pytest_plugin','-p','no:cacheprovider','-o','asyncio_mode=auto','-q','--tb=short','-c',str(lane/'pytest.ini'),'--basetemp='+str(dest/'fixtures'),'--junitxml='+str(dest/'junit.xml'),*selectors]
    def limit():resource.setrlimit(resource.RLIMIT_FSIZE,(8*1024**2,8*1024**2))
    start=time.monotonic();peak=0
    with (dest/'raw.txt').open('wb') as log:
        child=subprocess.Popen(command,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limit)
        (dest/'STARTED.json').write_text(json.dumps({'pid':child.pid,'command':command,'cwd':str(cwd)},indent=2)+'\n')
        print(json.dumps({'state':'RUNNING','tag':tag,'pid':child.pid,'timeout':180,'cap':cap}),flush=True)
        while child.poll() is None:
            sizes=file_sizes(dest);peak=max(peak,sum(sizes))
            if sum(sizes)>cap or max(sizes,default=0)>8*1024**2 or sum(file_sizes(root))>totalcap:reason='OWNED_RESOURCE_CAP'
            if shutil.disk_usage('/workspace').free<32*1024**2 or shutil.disk_usage('/tmp').free<reserve or shutil.disk_usage(root).free<reserve or maxmem-int(mem.read_text())<4*1024**3:reason='GLOBAL_FLOOR'
            if time.monotonic()-start>180:reason='TIMEOUT'
            if reason:break
            time.sleep(.1)
        final=finish_owned(child);code=final['child_exit']
    assert final['waited'] and final['group_absent']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==beforehash
except BaseException as exc:
    error=type(exc).__name__;reason=reason or 'CONTROLLER_ERROR'
    (dest/'CONTROLLER_ERROR.txt').write_text(traceback.format_exc())
finally:
    try:
        final=finish_owned(child);(dest/'FINALLY_WAIT.json').write_text(json.dumps(final,indent=2)+'\n')
        if child is not None:code=final['child_exit']
        cases=[]
        if (dest/'junit.xml').exists():
            for c in ET.parse(dest/'junit.xml').getroot().iter('testcase'):
                outcome='failed' if c.find('failure') is not None else 'error' if c.find('error') is not None else 'skipped' if c.find('skipped') is not None else 'passed'
                cases.append({'id':c.get('classname')+'::'+c.get('name'),'outcome':outcome})
        result={'tag':tag,'cwd':str(cwd),'command':command if child else None,'exit':code,'reason':reason,'controller_error':error,'seconds':round(time.monotonic()-start,3) if child else None,'owned_peak_bytes':peak if child else None,'final':final,'source_before_sha256':beforehash if child else None,'source_after_sha256':hashlib.sha256((lane/'backend/tests/test_account_cleanup.py').read_bytes()).hexdigest(),'cases':cases,'counts':{k:sum(c['outcome']==k for c in cases) for k in ['passed','failed','error','skipped']},'resource_before':before,'fixtures_retained':True,'scope':'OwnedSOURCEsoftwareEC/SQLite/HTTP only; no native/hardware/provider/fullunit qualification.'}
        (dest/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['tag','exit','reason','seconds','owned_peak_bytes','counts']}),flush=True)
    finally:fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)
