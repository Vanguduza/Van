"""Reproduce the published oracle with an actual unrelated bare helper cohort."""
import importlib,json,hashlib
import pytest
from backend.tests.test_account_cleanup import client,_env,isolate
from backend.tests.test_account_cleanup import test_current_paired_cleanup_and_published_fixture_consumers_share_canonical_signing_owner as original_provenance


@pytest.mark.asyncio
async def test_published_provenance_with_unrelated_real_bare_cohort(client,tmp_path):
    canonical=importlib.import_module('backend.tests.test_trading_api')
    unrelated=importlib.import_module('test_trading_api')
    assert unrelated is not canonical
    assert unrelated.DEVICE_PEM!=canonical.DEVICE_PEM
    (tmp_path/'MODULE_PROVENANCE.json').write_text(json.dumps({
        'canonical_name':canonical.__name__,'unrelated_name':unrelated.__name__,
        'canonical_file':canonical.__file__,'unrelated_file':unrelated.__file__,
        'same_module_object':unrelated is canonical,
        'same_signing_key_object':unrelated.DEVICE_KEY is canonical.DEVICE_KEY,
        'canonical_public_pem_sha256':hashlib.sha256(canonical.DEVICE_PEM.encode()).hexdigest(),
        'unrelated_public_pem_sha256':hashlib.sha256(unrelated.DEVICE_PEM.encode()).hexdigest(),
        'no_private_key_values':True},indent=2)+'\n')
    await original_provenance(client)


@pytest.mark.asyncio
async def test_selected_cleanup_signer_with_foreign_cohort_is_rejected(client,monkeypatch):
    scope=importlib.import_module('backend.tests.test_account_cleanup')
    unrelated=importlib.import_module('test_trading_api')
    canonical=importlib.import_module('backend.tests.test_trading_api')
    assert scope.sign.__globals__['DEVICE_KEY'] is canonical.DEVICE_KEY
    monkeypatch.setattr(scope,'sign',unrelated._approval_proof)
    with pytest.raises(AssertionError):
        await scope.test_current_paired_cleanup_and_published_fixture_consumers_share_canonical_signing_owner(client)


@pytest.mark.asyncio
async def test_selected_published_consumer_with_foreign_proof_is_rejected(client,monkeypatch):
    scope=importlib.import_module('backend.tests.test_account_cleanup')
    canonical=importlib.import_module('backend.tests.test_trading_api')
    unrelated=importlib.import_module('test_trading_api')
    consumer=importlib.import_module('backend.tests.test_account_resource_binding')
    assert consumer._approval_proof is canonical._approval_proof
    monkeypatch.setattr(consumer,'_approval_proof',unrelated._approval_proof)
    with pytest.raises(AssertionError):
        await scope.test_current_paired_cleanup_and_published_fixture_consumers_share_canonical_signing_owner(client)
