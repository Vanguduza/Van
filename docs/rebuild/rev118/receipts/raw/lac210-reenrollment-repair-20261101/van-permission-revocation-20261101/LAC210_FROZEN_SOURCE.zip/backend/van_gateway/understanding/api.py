"""Rev 1 §§33, 43 — the Understanding surface and the honest scoreboard.

§33 requires the owner be able to inspect what VAN believes about how they work,
and to confirm, correct, reject, or scope it. §63.6 calls that owner agency and
§63.5 makes it mandatory that inferred understanding be reversible.

So every mutation here is the owner's, and none of them is internal-control:
Hermes may *observe*, but only the owner confirms. That asymmetry is the whole
point — a system that could confirm its own guesses about the owner would have
no owner model at all, just a memory of its own opinions.

`/v1/eval` is deliberately on this surface rather than an admin one. §41 says do
not self-award, and the most effective way to keep that honest is for the person
being claimed about to be able to read the scoreboard, including every dimension
VAN cannot measure and why.
"""

from __future__ import annotations

import json


from fastapi import APIRouter, Header, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from van_gateway.auth.control_scopes import ControlScope, require_scoped_internal
from van_gateway.attention.scoring import AttentionScorer
from van_gateway.learning.feed import LearningFeed
from van_gateway.learning.observations import ObservedLearning
from van_gateway.capability.permissions import PermissionRegistry
from van_gateway.config import Settings
from van_gateway.evolution.radar import (
    AIEvolutionRadar,
    BenchmarkHarness,
    ExternalRealityModel,
    StrategyLearning,
)
from van_gateway.evolution.vaneval import VanEval
from van_gateway.proactive.autonomy import DomainTrustService, ProactivePolicyService
from van_gateway.proactive.owner_control import ACTION_ID, COMMAND_PREFIX, SUPPORTED_LEVELS, known_autonomy_domains
from van_gateway.reasoning.kernel import CriticalReasoningKernel
from van_gateway.jev.advisor import JevVanAdvisor
from van_gateway.storage.db import Store
from van_gateway.reasoning.calibration import RelationshipCalibrationEngine
from van_gateway.understanding.memory import (
    CognitiveComplementMap,
    DecisionFingerprints,
    IntentContinuityGraph,
    SharedVocabularyRegistry,
    StrategicEntryType,
    StrategicMemory,
    SymbioticGrowthLedger,
)
from van_gateway.understanding.personal_context_resolver import (
    PersonalContextResolver,
    PersonalContextUnavailable,
    RevisionFencedCapsuleCache,
)
from van_gateway.understanding.owner_model import (
    ObservationOrigin,
    OwnerCognitiveModel,
    OwnerModelError,
    OwnerModelField,
)
from van_gateway.understanding.owner_preferences import (
    ComplementPreferenceBody,
    OwnerDeclarationStore,
    VocabularyDefinitionBody,
    normalize_domain,
    normalize_project,
    normalize_term,
)
from van_gateway.understanding.records import OwnerRecords
from van_gateway.understanding.record_models import (
    MemoryRecordView, MemoryRecordPage, MemoryRecordErasurePlan, LearningProducersView,
)


class PermissionRevocationBody(BaseModel):
    model_config=ConfigDict(extra="forbid")
    operation_id: str | None = Field(default=None,min_length=16,max_length=128)
    caller_device_id: str | None = Field(default=None,min_length=1,max_length=128)
    grant_device_id: str | None = Field(default=None,min_length=1,max_length=128)
    expected_revision: str | None = None
    expected_source_digest: str | None = None
    request_token: str | None = Field(default=None,max_length=16384)


class ObserveBody(BaseModel):
    owner_principal_id: str
    field: OwnerModelField
    value: str
    episode_ref: str
    #: Contract C1 — required, no default. Only SYSTEM_OBSERVED advances the ladder;
    #: HINDSIGHT_DERIVED / OPENVIKING_RETRIEVED / MODEL_INFERRED are recorded as provenance.
    origin: ObservationOrigin
    evidence_refs: list[str] = Field(default_factory=list)
    project_id: str | None = None


class CorrectBody(BaseModel):
    new_value: str


class StrategicMemoryBody(BaseModel):
    entry_type: StrategicEntryType
    statement: str
    rationale: str | None = None
    evidence_refs: list[str] = Field(default_factory=list)


class UnderstandingApi:
    """`/v1/understanding`, `/v1/technology-radar`, `/v1/eval`, `/v1/autonomy`."""

    def __init__(
        self, store: Store, settings: Settings, *, jev_advisor: JevVanAdvisor | None = None
    ) -> None:
        self.store = store
        self.settings = settings
        # P1-LEARN-001 — the owner-facing surface is where corrections arrive, so this is
        # the instance that has to feed the growth ledger.
        self.owner_model = OwnerCognitiveModel(store, learning=LearningFeed(store))
        # Owner decision 2026-09-29 §3: personal context is served only at the verified
        # authoritative owner_model_revision; the cache has no TTL and no error fallback.
        self.personal_context = PersonalContextResolver(
            self.owner_model, cache=RevisionFencedCapsuleCache()
        )
        self.vocabulary = SharedVocabularyRegistry(store)
        self.complement = CognitiveComplementMap(store)
        self.owner_declarations = OwnerDeclarationStore(store)
        self.records = OwnerRecords(store)
        self.observed_learning = ObservedLearning(store)
        self.growth = SymbioticGrowthLedger(store)
        self.kernel = CriticalReasoningKernel(store, jev_advisor=jev_advisor)
        # P2-DEAD-001 — §75. The engine decides how VAN says a thing and how hard it pushes,
        # never what it is willing to call true. It was complete, tested and imported by
        # nothing, so every answer came out at one fixed register regardless of how
        # consequential it was or how often VAN had recently been wrong.
        self.calibration = RelationshipCalibrationEngine(store)
        self.attention = AttentionScorer(store)
        self.trust = DomainTrustService(store)
        self.policies = ProactivePolicyService(store, self.trust)
        self.radar = AIEvolutionRadar(store)
        # P2-EVO-001 — §§22, 24, 79. Both had correct invariants and no surface: the
        # external-reality store had no producer and the benchmark harness no corpus,
        # and neither absence was reported anywhere.
        self.reality = ExternalRealityModel(store)
        self.benchmarks = BenchmarkHarness(store)
        self.eval = VanEval(store)
        self.permissions = PermissionRegistry(store)
        # P2-MEM-001 — §§65, 77, 78. Three stores with no route and no producer. The
        # producer is `LearningFeed`, on the mission path; these are the surfaces that
        # make what they hold the owner's to see and, for strategic memory, to write.
        self.intents = IntentContinuityGraph(store)
        self.fingerprints = DecisionFingerprints(store)
        self.strategic = StrategicMemory(store)
        self.router = APIRouter(prefix="/v1", tags=["understanding"])
        self._install_routes()

    def _require_internal(self, token: str | None) -> None:
        # GAP-F-009: scope-aware, same authority as the middleware.
        require_scoped_internal(self.settings, token, ControlScope.UNDERSTANDING)

    async def _prior_corrections(self) -> int:
        """GAP-F-008 — how many owner corrections the growth ledger has ever recorded.

        `symbiotic_growth` is not owner-scoped (VAN has one owner), so this is a global
        count of `record_owner_correction` rows: §71's failure mode is fluent agreement,
        and being corrected is the signal `RelationshipCalibrationEngine.calibrate` uses
        to push harder rather than softer.
        """
        row = await self.store.fetchone(
            "SELECT COUNT(*) AS n FROM symbiotic_growth WHERE reason = 'owner correction'",
            (),
        )
        return int(row["n"]) if row is not None else 0

    async def _calibration(
        self,
        owner_principal_id: str,
        *,
        consequential: bool = False,
        irreversible: bool = False,
    ) -> dict:
        """GAP-F-008 — `RelationshipCalibrationEngine.calibrate` had no caller.

        It is a pure read of already-persisted state (`owner_cognitive_model` for style
        preferences, `symbiotic_growth` for how often the owner has had to correct VAN),
        so there is nothing to persist here that the engine's own stores do not already
        hold — computing it fresh on every read is the read-back, not a cache of one.
        Called on every owner mutation to the model (confirm/correct/reject, adaptation
        confirm/revert) and on the `/v1/understanding` read, so a correction visibly
        changes VAN's calibrated style rather than only sitting in a store nothing acts
        on.
        """
        calibration = await self.calibration.calibrate(
            owner_principal_id=owner_principal_id,
            consequential=consequential,
            irreversible=irreversible,
            prior_corrections=await self._prior_corrections(),
        )
        return calibration.as_dict()

    def _install_routes(self) -> None:
        router = self.router

        def declaration_response(value: dict):
            return JSONResponse(value, headers={"Cache-Control": "no-store"})

        async def owner_record_call(request: Request, operation):
            await self.owner_declarations.require_read(request)
            try:
                return declaration_response(await operation())
            except LookupError as exc:
                raise HTTPException(404, "memory_record_not_found") from exc
            except ValueError as exc:
                raise HTTPException(422, "memory_record_selector_invalid") from exc

        @router.get("/context/records", response_model=MemoryRecordPage)
        async def memory_records(request: Request, store: str = Query(..., min_length=1, max_length=64),
                                 limit: int = Query(50, ge=1, le=100), cursor: int = Query(0, ge=0, le=1_000_000)):
            return await owner_record_call(request, lambda: self.records.list(store, limit=limit, cursor=cursor))

        @router.get("/context/records/{store}/{record_id}", response_model=MemoryRecordView)
        async def memory_record_detail(request: Request, store: str, record_id: str):
            return await owner_record_call(request, lambda: self.records.exact(store, record_id))

        @router.get("/context/records/{store}/{record_id}/export", response_model=MemoryRecordView)
        async def memory_record_export(request: Request, store: str, record_id: str):
            return await owner_record_call(request, lambda: self.records.exact(store, record_id))

        @router.get("/context/records/{store}/{record_id}/erasure-plan", response_model=MemoryRecordErasurePlan)
        async def memory_record_erasure_plan(request: Request, store: str, record_id: str):
            return await owner_record_call(request, lambda: self.records.erasure_plan(store, record_id))

        @router.get("/understanding/learning/producers", response_model=LearningProducersView)
        async def learning_producers(request: Request):
            await self.owner_declarations.require_read(request)
            import time
            now = int(time.time() * 1000)
            producers = []
            for producer_id, operation in (("decision-patterns", self.observed_learning.decisions),
                                            ("external-contradictions", self.observed_learning.external)):
                try:
                    result = await operation(now_ms=now)
                    summary = {key: value for key, value in result.items() if key not in {"patterns", "comparisons", "contradictions"}}
                    summary["comparisons"] = result.get("comparison_count", result.get("comparisons", 0))
                    producers.append(summary)
                except Exception:
                    producers.append({"id": producer_id, "active": True, "status": "DEGRADED",
                        "observations": None, "comparisons": None, "unmeasured": None,
                        "observed_at_ms": now, "evidence_refs": [], "snapshot_sha256": None,
                        "why": "Persisted observations could not be read; no result was inferred."})
            return declaration_response({"observed_at_ms": now, "producers": producers, "execution_grant": False})

        @router.get("/understanding/vocabulary")
        async def vocabulary_read(
            request: Request, term: str | None = Query(None, min_length=1, max_length=128),
            project_id: str | None = Query(None, min_length=1, max_length=64),
        ):
            await self.owner_declarations.require_read(request)
            if term is None:
                if project_id is not None:
                    raise HTTPException(422, "vocabulary_term_required_for_exact_scope")
                return declaration_response(await self.owner_declarations.all("vocabulary"))
            try:
                scope = {"term": normalize_term(term), "project_id": normalize_project(project_id)}
            except ValueError as exc:
                raise HTTPException(422, str(exc)) from exc
            # Exact readback must never substitute a global definition for a missing
            # project-specific target (the conversational resolver may still do that).
            return declaration_response(await self.owner_declarations.exact("vocabulary", scope))

        @router.put("/understanding/vocabulary")
        async def vocabulary_write(request: Request, body: VocabularyDefinitionBody):
            if body.project_id is not None and body.project_id not in request.app.state.projects.known_projects():
                raise HTTPException(404, "owner_memory_project_not_known")
            return declaration_response(await self.owner_declarations.save("vocabulary", body, request))

        @router.get("/understanding/complement/preferences")
        async def complement_preference_read(
            request: Request, domain: str | None = Query(None, min_length=1, max_length=128),
        ):
            await self.owner_declarations.require_read(request)
            if domain is None:
                return declaration_response(await self.owner_declarations.all("complement"))
            try:
                scope = {"domain": normalize_domain(domain)}
            except ValueError as exc:
                raise HTTPException(422, str(exc)) from exc
            return declaration_response(await self.owner_declarations.exact("complement", scope))

        @router.put("/understanding/complement/preferences")
        async def complement_preference_write(request: Request, body: ComplementPreferenceBody):
            return declaration_response(await self.owner_declarations.save("complement", body, request))

        @router.get("/understanding")
        async def understanding(owner_principal_id: str = "owner"):
            """§33 — what VAN believes, how firmly, and what it has adapted."""
            return {
                **await self.owner_model.understanding(owner_principal_id),
                "shared_vocabulary": [
                    v.model_dump(mode="json") for v in await self.vocabulary.all_terms()
                ],
                "cognitive_complement": await self.complement.all(),
                "recent_adaptation": await self.growth.effective(),
                "adaptation_awaiting_you": await self.growth.awaiting_owner(),
                # GAP-F-008 — the calibration engine had no caller; this is §33's
                # surface for "how VAN believes it should currently talk to you".
                "calibration": await self._calibration(owner_principal_id),
            }

        @router.get("/understanding/intents")
        async def standing_intents():
            """§77 — the owner's long-lived goals, and what each is in tension with.

            P2-MEM-001 — the graph had no producer, so this was a concept VAN could
            describe and had never seen an instance of. Every node here came from a
            mission the owner actually opened.
            """
            rows = await self.store.fetchall(
                "SELECT intent_id FROM intent_nodes ORDER BY latest_observed_ms DESC"
            )
            out = []
            for row in rows:
                node = await self.intents.get(str(row["intent_id"]))
                if node is None:
                    continue
                conflicts = await self.intents.conflicts_for(node.intent_id)
                out.append({
                    **node.model_dump(mode="json"),
                    # The point of the graph: a newer instruction that contradicts an
                    # older standing goal is visible rather than silently winning because
                    # it arrived more recently.
                    "conflicts_with": [
                        {"intent_id": c.intent_id, "owner_goal": c.owner_goal}
                        for c in conflicts
                    ],
                })
            return {
                "intents": out,
                # P2-MEM-003 — separated, because they are different things. A standing
                # goal is what the owner is trying to do; an ephemeral one is a request
                # they made once. Presenting them in one list made every calendar lookup
                # look like a long-term commitment, and gave §77's conflict detection
                # transient commands to contradict genuine goals with.
                "standing": [
                    row for row in out if row["horizon"] in ("STANDING", "PROJECT")
                ],
                "one_off_requests": [row for row in out if row["horizon"] == "EPHEMERAL"],
                "promotion_rule": {
                    "observations_for_standing": self.intents.STANDING_AFTER_OBSERVATIONS,
                    "owner_declaration_is_sufficient": True,
                    "van_never_infers_a_standing_goal_from_one_request": True,
                },
                "stale_after_days": self.intents.STALE_AFTER_MS // (24 * 60 * 60 * 1000),
                # STALE is not abandoned, and the surface says so rather than leaving the
                # word to be read as a verdict.
                "stale_means": (
                    "unmentioned for long enough that VAN will ask before assuming it "
                    "still matters; only you abandon a goal"
                ),
            }

        @router.get("/understanding/decisions")
        async def decision_fingerprints():
            """§65 — what you decided and how it turned out.

            §12 forbids treating a candidate as an unquestionable rule. The producer
            describes repeated observed choices in exact typed task contexts, reports
            counterexamples and separate independently verified outcome counts, and never
            guesses psychological reasons. Missing, generic or stale evidence stays
            unmeasured; no candidate changes permission or execution authority.
            """
            rows = await self.store.fetchall(
                "SELECT decision_id, mission_id, owner_choice, owner_stated_reason, "
                "inferred_reason, outcome, created_at_ms FROM decision_fingerprints "
                "ORDER BY created_at_ms DESC LIMIT 200"
            )
            return {
                "decisions": [dict(r) for r in rows],
                "falsified": await self.fingerprints.falsified(),
                "pattern_inference": await self.observed_learning.decisions(),
            }

        @router.get("/projects/{project_id}/strategic-memory")
        async def strategic_memory(project_id: str):
            """§78 — why this project exists and what was already tried and rejected."""
            return {
                "project_id": project_id,
                "entries": await self.strategic.for_project(project_id),
                # §21 — kept apart from Project Truth on purpose, and said on the wire so
                # a rationale is not read back as a fact about the code.
                "not_project_truth": (
                    "Project Truth is what the repository is; this is why it became that"
                ),
            }

        @router.post("/projects/{project_id}/strategic-memory")
        async def record_strategic_memory(project_id: str, body: StrategicMemoryBody):
            """The owner is the author of project rationale, so this is an owner route.

            Recording something already rejected is answered with the rejection rather
            than a second entry: `already_rejected` is the question worth asking before
            proposing anything, and the one place it can be asked today is here.
            """
            if await self.strategic.already_rejected(project_id, body.statement):
                raise HTTPException(
                    status_code=409,
                    detail={
                        "code": "STRATEGY_ALREADY_REJECTED",
                        "project_id": project_id,
                        "statement": body.statement,
                    },
                )
            entry_id = await self.strategic.record(
                project_id=project_id,
                entry_type=body.entry_type,
                statement=body.statement,
                rationale=body.rationale,
                evidence_refs=body.evidence_refs,
            )
            return {"entry_id": entry_id, "project_id": project_id}

        @router.post("/understanding/{assertion_id}/confirm")
        async def confirm(assertion_id: str):
            try:
                assertion = await self.owner_model.confirm(assertion_id)
            except OwnerModelError as exc:
                raise HTTPException(status_code=404, detail=exc.code) from exc
            calibration = await self._calibration(
                assertion.owner_principal_id, consequential=assertion.is_autonomy_bearing,
            )
            return {**assertion.model_dump(mode="json"), "calibration": calibration}

        @router.post("/understanding/{assertion_id}/correct")
        async def correct(assertion_id: str, body: CorrectBody):
            try:
                assertion = await self.owner_model.correct(
                    assertion_id, new_value=body.new_value
                )
            except OwnerModelError as exc:
                raise HTTPException(status_code=404, detail=exc.code) from exc
            # GAP-F-008 — a correction is the strongest learning signal there is (§71);
            # this is where `calibrate()` actually sees it happen, through
            # `_prior_corrections` reading the growth ledger `owner_model.correct` just
            # wrote to.
            calibration = await self._calibration(
                assertion.owner_principal_id, consequential=assertion.is_autonomy_bearing,
            )
            return {**assertion.model_dump(mode="json"), "calibration": calibration}

        @router.post("/understanding/{assertion_id}/reject")
        async def reject(assertion_id: str):
            try:
                assertion = await self.owner_model.reject(assertion_id)
            except OwnerModelError as exc:
                raise HTTPException(status_code=404, detail=exc.code) from exc
            calibration = await self._calibration(
                assertion.owner_principal_id, consequential=assertion.is_autonomy_bearing,
            )
            return {**assertion.model_dump(mode="json"), "calibration": calibration}

        @router.post("/understanding/adaptation/{change_id}/confirm")
        async def confirm_adaptation(change_id: str):
            await self.growth.confirm(change_id)
            return {
                "change_id": change_id, "confirmed": True,
                "calibration": await self._calibration("owner"),
            }

        @router.post("/understanding/adaptation/{change_id}/revert")
        async def revert_adaptation(change_id: str):
            """§63.5 — inferred understanding must be reversible, in practice."""
            reverted = await self.growth.revert(change_id)
            if not reverted:
                raise HTTPException(status_code=409, detail="ADAPTATION_NOT_REVERSIBLE")
            return {
                "change_id": change_id, "reverted": True,
                "calibration": await self._calibration("owner"),
            }

        @router.post("/understanding/observe")
        async def observe(
            body: ObserveBody, x_van_internal_token: str | None = Header(default=None)
        ):
            """Hermes observes. It never confirms — that asymmetry is the point."""
            self._require_internal(x_van_internal_token)
            try:
                assertion = await self.owner_model.observe(
                    owner_principal_id=body.owner_principal_id, field=body.field,
                    value=body.value, episode_ref=body.episode_ref, origin=body.origin,
                    evidence_refs=body.evidence_refs, project_id=body.project_id,
                )
            except OwnerModelError as exc:
                raise HTTPException(status_code=422, detail=exc.code) from exc
            return assertion.model_dump(mode="json")

        @router.get("/understanding/revision")
        async def owner_model_revision(owner_principal_id: str = "owner"):
            """Contract C2 — the live Owner Model revision a personal capsule is fenced by."""
            return await self.owner_model.revision(owner_principal_id)

        @router.get("/understanding/personal-context")
        async def personal_context(
            owner_model_revision: int,
            purpose: str,
            owner_principal_id: str = "owner",
            project_id: str | None = None,
            x_van_internal_token: str | None = Header(default=None),
        ):
            """C3 served through the revision fence: requested == authoritative, or 409
            PERSONAL_CONTEXT_UNAVAILABLE. Never a cached capsule the store cannot confirm."""
            self._require_internal(x_van_internal_token)
            try:
                return await self.personal_context.resolve(
                    owner_principal_id, requested_revision=owner_model_revision,
                    purpose=purpose, project_id=project_id,
                )
            except PersonalContextUnavailable as exc:
                raise HTTPException(status_code=409, detail=exc.as_detail()) from exc
            except ValueError as exc:
                raise HTTPException(status_code=422, detail=str(exc)) from exc

        @router.get("/permissions")
        async def permissions():
            """§36 — every standing grant, where it came from, when last used."""
            return await self.permissions.owner_view()

        @router.post("/permissions/{grant_id}/revoke")
        async def revoke_permission(grant_id: str, request: Request, body: PermissionRevocationBody | None = None):
            from van_gateway.capability.owner_permissions import permission_http_error
            from van_gateway.capability.permissions import PermissionError_
            from van_gateway.auth.service import AuthError
            try:
                result=await self.permissions.revoke_original(grant_id=grant_id,
                    device_id=getattr(request.state,"van_device_id",None),cipher=request.app.state.auth._cipher(),
                    access_token_hash=__import__('hashlib').sha256(request.headers.get("X-Van-Device-Token","").encode()).hexdigest(),
                    proof_required=getattr(request.state,"van_device_proved",False),
                    **(body or PermissionRevocationBody()).model_dump())
                return JSONResponse(result,status_code=409 if result["state"]=="REFUSED" else 200,headers={"Cache-Control":"no-store"})
            except PermissionError_ as exc:
                raise permission_http_error(exc) from exc
            except AuthError as exc:
                raise HTTPException(503,exc.code) from exc

        @router.get("/permissions/{grant_id}/revocations/{operation_id}")
        async def original_permission_revoke(grant_id: str, operation_id: str, request: Request):
            from van_gateway.capability.owner_permissions import original_permission_revocation, permission_http_error
            from van_gateway.capability.permissions import PermissionError_
            from van_gateway.auth.service import AuthError
            try:
                result=await original_permission_revocation(self.store,grant_id=grant_id,operation_id=operation_id,
                    device_id=getattr(request.state,"van_device_id",None),cipher=request.app.state.auth._cipher(),
                    access_token_hash=__import__('hashlib').sha256(request.headers.get("X-Van-Device-Token","").encode()).hexdigest())
                return JSONResponse(result,headers={"Cache-Control":"no-store"})
            except PermissionError_ as exc:
                raise permission_http_error(exc) from exc
            except AuthError as exc:
                raise HTTPException(503,exc.code) from exc

        @router.get("/technology-radar")
        async def technology_radar():
            return {
                "technologies": await self.radar.radar(),
                "deprecations": await self.radar.deprecations(),
            }

        @router.get("/autonomy")
        async def autonomy():
            """§§30-31 — what VAN may do unprompted, per domain, and why."""
            rows = await self.store.fetchall("SELECT domain FROM domain_trust ORDER BY domain")
            domains = []
            for row in rows:
                trust = await self.trust.get(str(row["domain"]))
                domains.append({
                    "domain": trust.domain,
                    "earned_ceiling": trust.earned_ceiling.value,
                    "owner_granted_ceiling": (
                        trust.owner_granted_ceiling.value
                        if trust.owner_granted_ceiling else None
                    ),
                    "effective_ceiling": trust.effective_ceiling.value,
                    "verified_successes": trust.verified_successes,
                    "false_successes": trust.false_successes,
                    "suspended_for_false_success": trust.has_unrecovered_false_success,
                })
            return {"domains": domains, "policies": await self.policies.policies(),
                "known_domains": await known_autonomy_domains(self.store),
                "supported_levels": list(SUPPORTED_LEVELS), "typed_command_prefix": COMMAND_PREFIX,
                "owner_ceiling_command": {"action_id": ACTION_ID, "text_prefix": COMMAND_PREFIX,
                    "parameter_fields": ["domain", "level"], "action_class": "A4",
                    "max_age_seconds": 30, "requires_fresh_biometric": True,
                    "changes_standing_policies": False, "overrides_native_action_authority": False}}

        @router.get("/strategies")
        async def strategies():
            """§25 / §41 — what VAN has learned about how to do each kind of work.

            P1-LEARN-003 — every row here comes from a mission that actually ran: the
            capability sequence is read back from its activities, and only a
            VERIFIED_SUCCESS counts as a success. A strategy with no runs is not shown as
            an approach VAN prefers, because it is not one.

            `max_action_class` is the ceiling the sequence was exercised under, and
            P1-LEARN-002 is why it is on the wire: a strategy is only ever offered to a
            mission whose envelope already reaches that far, so nothing here can widen
            what VAN is permitted to do.
            """
            rows = await self.store.fetchall(
                "SELECT * FROM execution_strategies ORDER BY mission_class, updated_at_ms DESC"
            )
            out = []
            for row in rows:
                runs = int(row["success_count"]) + int(row["failure_count"])
                out.append({
                    "strategy_id": str(row["strategy_id"]),
                    "mission_class": str(row["mission_class"]),
                    "capability_sequence": json.loads(str(row["capability_sequence_json"])),
                    "promotion_state": str(row["promotion_state"]),
                    "max_action_class": str(row["max_action_class"]),
                    "runs": runs,
                    "verified_successes": int(row["success_count"]),
                    "failures": int(row["failure_count"]),
                    # P1-LEARN-005 — runs that say nothing about the approach: refused,
                    # cancelled, expired, or finished without anything able to check them.
                    # Reported rather than hidden, because a strategy that keeps being
                    # cancelled is worth seeing and is not one that keeps failing. It is
                    # excluded from `runs` and from `success_rate` on purpose: including it
                    # either way would make VAN's blind spots look like evidence.
                    "inconclusive": int(row["inconclusive_count"]),
                    # None, not 0.0: a strategy nothing has exercised has no success rate,
                    # and reporting zero would read as one that keeps failing.
                    "success_rate": (
                        round(int(row["success_count"]) / runs, 3) if runs else None
                    ),
                    "eval_run_id": row["eval_run_id"],
                })
            return {
                "strategies": out,
                "promotion_rule": {
                    "preferred_min_runs": StrategyLearning.PREFERRED_MIN_RUNS,
                    "preferred_min_rate": StrategyLearning.PREFERRED_MIN_RATE,
                    "promotion_requires_eval_evidence": True,
                    "demotion_is_automatic": True,
                    "inconclusive_runs_count_toward_neither": True,
                },
            }

        @router.get("/external-reality")
        async def external_reality(subject: str | None = None):
            """§§22, 79 — what available evidence says, kept apart from what you believe.

            §22 calls that separation mandatory, to prevent personalization becoming an
            echo chamber. P2-EVO-001 — the store had no producer, so the separation was
            protecting nothing. Every observation here comes from a research result with a
            citable source; the model refuses to record one without.

            The bounded producer compares source-bound structured provider claims with
            exact current owner declarations. Headlines/prose remain unmeasured. A
            disagreement is evidence of different claims, not proof the owner is wrong,
            and neither stored assertion is rewritten by the comparison.
            """
            observations = (
                await self.reality.current(subject) if subject
                else [
                    dict(r) for r in await self.store.fetchall(
                        "SELECT * FROM external_reality WHERE superseded_by IS NULL "
                        "ORDER BY observed_at_ms DESC LIMIT 200"
                    )
                ]
            )
            return {
                "subject": subject,
                "observations": observations,
                "contradictions": (detected := await self.observed_learning.external())["contradictions"],
                "contradiction_detection": detected,
            }

        @router.get("/eval")
        async def run_eval():
            """§41 — the scoreboard, including everything it cannot score."""
            report = await self.eval.run()
            report["anti_sycophancy"] = await self.kernel.sycophancy_metrics()
            report["attention"] = await self.attention.metrics()
            # §24 — the benchmark vocabulary exists and no suite has a task corpus, which
            # is why no technology can reach ADMITTED. Reported here so that fail-closed
            # state is read from the scoreboard rather than discovered when an adoption is
            # refused.
            report["benchmarks"] = await self.benchmarks.coverage()
            return report


__all__ = ["UnderstandingApi"]
