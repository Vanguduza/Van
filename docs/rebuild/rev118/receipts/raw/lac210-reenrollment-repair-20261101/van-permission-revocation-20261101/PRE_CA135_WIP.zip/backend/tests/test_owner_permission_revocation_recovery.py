"""LAC-210 actual owner consent/revoker/effect/readback source recovery."""
import json
import pytest
from tests.test_local_typed_actions import client, _settings
from tests.test_owner_memory_erasure import _pair
from test_owner_permissions import _approved, _parameters, _begin
from van_gateway.capability import owner_permissions as permissions

pytestmark=pytest.mark.asyncio

async def grant(ac,app,*,idem='revocation-source'):
    key=await _pair(ac,app)
    params=_parameters(max_uses=3)
    command=await _approved(ac,app,key,params,idem)
    result=await ac.post('/v1/commands',json=command)
    assert result.json()['status']=='accepted',result.text
    witness=await app.state.store.fetchone('SELECT value FROM runtime_meta WHERE key=?',(permissions.WITNESS_PREFIX+command['command_id'],))
    return json.loads(witness['value'])['grant_id'],params

async def test_lost_successful_revocation_reply_recovers_instead_of_conflicting(client):
    ac,app,_=client
    grant_id,_=await grant(ac,app)
    path='/v1/permissions/'+grant_id+'/revoke'
    first=await ac.post(path,json={})
    assert first.status_code==200,first.text
    retry=await ac.post(path,json={})
    assert retry.status_code==200,retry.text
    assert retry.json()==first.json()
