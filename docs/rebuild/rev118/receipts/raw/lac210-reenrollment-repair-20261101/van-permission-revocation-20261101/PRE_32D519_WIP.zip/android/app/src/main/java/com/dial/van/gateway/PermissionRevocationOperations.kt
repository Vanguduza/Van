package com.dial.van.gateway

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

interface PermissionRevocationStore {
    fun load(): String?
    fun save(value: String): Boolean
}

data class PendingPermissionRevocation(val deviceId: String, val grantId: String, val requestBody: String) {
    val operationId: String get() = JSONObject(requestBody).getString("operation_id")
}

/** Original LAC-210 intent survives lost replies/process death; it cannot retarget a grant. */
class PermissionRevocationOperations(private val store: PermissionRevocationStore) {
    companion object {
        private val lock = Any()
        private val fingerprint = Regex("[0-9a-f]{64}")
        private val identity = Regex("[A-Za-z0-9][A-Za-z0-9._-]{15,127}")
    }
    private fun read(): List<PendingPermissionRevocation> {
        val raw = store.load() ?: return emptyList()
        check(raw.length <= 65536) { "permission_revocation_history_unreadable" }
        val rows = JSONArray(raw)
        check(rows.length() <= 64) { "permission_revocation_history_unreadable" }
        val result = (0 until rows.length()).map { index ->
            val row = rows.getJSONObject(index)
            check(row.keys().asSequence().toSet() == setOf("device_id", "grant_id", "request_body"))
            val value = PendingPermissionRevocation(row.getString("device_id"), row.getString("grant_id"), row.getString("request_body"))
            val request = JSONObject(value.requestBody)
            check(value.deviceId.isNotBlank() && value.grantId.isNotBlank())
            check(request.keys().asSequence().toSet() == setOf("operation_id", "expected_revision", "expected_source_digest"))
            check(identity.matches(request.getString("operation_id")))
            check(fingerprint.matches(request.getString("expected_revision")) && fingerprint.matches(request.getString("expected_source_digest")))
            value
        }
        check(result.map { it.deviceId to it.grantId }.toSet().size == result.size)
        check(result.map { it.operationId }.toSet().size == result.size)
        return result
    }
    private fun write(rows: List<PendingPermissionRevocation>) {
        val value = JSONArray()
        rows.forEach { value.put(JSONObject().put("device_id", it.deviceId).put("grant_id", it.grantId).put("request_body", it.requestBody)) }
        check(value.toString().length <= 65536 && rows.size <= 64)
        check(store.save(value.toString())) { "permission_revocation_original_store_failed" }
    }
    fun pending(deviceId: String, grantId: String): PendingPermissionRevocation? = synchronized(lock) {
        read().firstOrNull { it.deviceId == deviceId && it.grantId == grantId }
    }
    fun prepare(deviceId: String, grantId: String, detail: JSONObject): PendingPermissionRevocation = synchronized(lock) {
        require(deviceId.isNotBlank() && grantId.isNotBlank() && detail.getString("grant_id") == grantId)
        read().firstOrNull { it.deviceId == deviceId && it.grantId == grantId }?.let { return@synchronized it }
        check(detail.isNull("revoked_at_ms")) { "permission_original_revocation_requires_reconciliation" }
        val boundDevice = detail.opt("device_id")
        check(boundDevice == null || boundDevice === JSONObject.NULL || boundDevice == deviceId) { "permission_device_mismatch" }
        val revision = detail.getString("source_revision")
        val source = detail.getString("source_digest")
        check(fingerprint.matches(revision) && fingerprint.matches(source))
        val request = JSONObject().put("operation_id", "permission-revoke-${UUID.randomUUID()}")
            .put("expected_revision", revision).put("expected_source_digest", source)
        val original = PendingPermissionRevocation(deviceId, grantId, request.toString())
        write(read() + original) // Durable commit must precede the first HTTP mutation.
        original
    }
    /** Only the exact independently reread original result can release the local intent. */
    fun observe(original: PendingPermissionRevocation, receipt: JSONObject): Boolean = synchronized(lock) {
        val current = read().firstOrNull { it.operationId == original.operationId }
        check(current == null || current == original) { "permission_revocation_original_changed" }
        val request = JSONObject(original.requestBody)
        check(receipt.getString("operation_id") == original.operationId && receipt.getString("grant_id") == original.grantId &&
            receipt.getString("device_id") == original.deviceId && receipt.getString("expected_revision") == request.getString("expected_revision"))
        check(receipt.opt("native_authority_issued") == false)
        check(receipt.getString("source_digest") == request.getString("expected_source_digest"))
        val state = receipt.getString("state")
        val applied = state == "APPLIED"
        if (applied) {
            val timestamp = receipt.opt("revoked_at_ms")
            check(receipt.opt("revoked") == true && (timestamp is Int || timestamp is Long) && (timestamp as Number).toLong() > 0)
        } else {
            check(state == "REFUSED" && receipt.opt("revoked") == false && receipt.isNull("revoked_at_ms"))
            check(receipt.getString("reason_code") in setOf("permission_revocation_stale_revision", "permission_grant_expired"))
        }
        if (current != null) write(read().filterNot { it.operationId == original.operationId })
        applied
    }
}
