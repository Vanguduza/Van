package com.dial.van.gateway

import org.json.JSONObject
import kotlin.test.*

class PermissionRevocationOperationsTest {
    private class Store : PermissionRevocationStore {
        var value: String? = null
        var writable = true
        override fun load() = value
        override fun save(value: String): Boolean { if (!writable) return false; this.value = value; return true }
    }
    private fun detail(grant: String = "grant-one") = JSONObject().put("grant_id", grant).put("device_id", "owner-one")
        .put("source_revision", "a".repeat(64)).put("source_digest", "b".repeat(64)).put("revoked_at_ms", JSONObject.NULL)
    private fun receipt(p: PendingPermissionRevocation, applied: Boolean = true): JSONObject = JSONObject()
        .put("operation_id", p.operationId).put("grant_id", p.grantId).put("device_id", p.deviceId)
        .put("expected_revision", JSONObject(p.requestBody).getString("expected_revision"))
        .put("source_digest", JSONObject(p.requestBody).getString("expected_source_digest"))
        .put("state", if (applied) "APPLIED" else "REFUSED").put("revoked", applied)
        .put("revoked_at_ms", if (applied) 12345 else JSONObject.NULL).put("native_authority_issued", false)
        .put("reason_code", if (applied) JSONObject.NULL else "permission_revocation_stale_revision")
    @Test fun `prepare commits original before delivery and process restart preserves exact body`() {
        val store = Store(); val first = PermissionRevocationOperations(store).prepare("owner-one", "grant-one", detail())
        val resumed = PermissionRevocationOperations(store)
        assertEquals(first, resumed.pending("owner-one", "grant-one"))
        assertEquals(first, resumed.prepare("owner-one", "grant-one", detail().put("source_revision", "c".repeat(64))))
        assertNull(resumed.pending("other-owner", "grant-one"))
        assertNull(resumed.pending("owner-one", "other-grant"))
        assertTrue(resumed.observe(first, receipt(first)))
        assertTrue(resumed.observe(first, receipt(first))) // Concurrent completed observers retain the same outcome.
        assertNull(resumed.pending("owner-one", "grant-one"))
    }
    @Test fun `storage failure never returns an undurable operation to network caller`() {
        val store = Store(); store.writable = false
        assertFailsWith<IllegalStateException> { PermissionRevocationOperations(store).prepare("owner-one", "grant-one", detail()) }
        assertNull(store.value)
    }
    @Test fun `wrong original scope or incomplete receipt cannot discard pending intent`() {
        val store = Store(); val operations = PermissionRevocationOperations(store)
        val original = operations.prepare("owner-one", "grant-one", detail())
        for (changed in listOf(receipt(original).put("device_id", "other-owner"), receipt(original).put("grant_id", "other-grant"),
            receipt(original).put("operation_id", "other-operation-123456"),receipt(original).put("expected_revision", "c".repeat(64)),
            receipt(original).put("source_digest", "c".repeat(64)), receipt(original).put("state", "UNKNOWN"), receipt(original).put("revoked_at_ms", "12345"), receipt(original).put("revoked_at_ms", 12345.0))) {
            assertFails { operations.observe(original, changed) }
            assertEquals(original, operations.pending("owner-one", "grant-one"))
        }
    }
    @Test fun `authoritative terminal refusal allows a later explicit owner attempt with fresh identity`() {
        val store = Store(); val operations = PermissionRevocationOperations(store)
        val original = operations.prepare("owner-one", "grant-one", detail())
        assertFalse(operations.observe(original, receipt(original, false)))
        val fresh = operations.prepare("owner-one", "grant-one", detail().put("source_revision", "c".repeat(64)))
        assertNotEquals(original.operationId, fresh.operationId)
    }
    @Test fun `corrupt durable history refuses rather than replacing an unknown operation`() {
        val store = Store(); store.value = "[{broken]"
        assertFails { PermissionRevocationOperations(store).pending("owner-one", "grant-one") }
        assertEquals("[{broken]", store.value)
    }
    @Test fun `failed terminal cleanup retains original and old refusal cannot clear a later operation`() {
        val store = Store(); val operations = PermissionRevocationOperations(store)
        val first = operations.prepare("owner-one", "grant-one", detail())
        store.writable = false
        assertFailsWith<IllegalStateException> { operations.observe(first, receipt(first)) }
        assertEquals(first, operations.pending("owner-one", "grant-one"))
        store.writable = true
        assertFalse(operations.observe(first, receipt(first, false)))
        val second = operations.prepare("owner-one", "grant-one", detail().put("source_revision", "c".repeat(64)))
        assertFalse(operations.observe(first, receipt(first, false)))
        assertEquals(second, operations.pending("owner-one", "grant-one"))
    }

}
