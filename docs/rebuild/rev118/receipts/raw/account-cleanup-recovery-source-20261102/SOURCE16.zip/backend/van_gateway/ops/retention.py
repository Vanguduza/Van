"""A retention class for every table, and a prune that honours it.

P3-OPS-001: a repository-wide search for retention, prune, vacuum or purge found
exactly one setting in the whole system — n8n's own 168-hour execution
retention. Everything the gateway writes grew forever, in the same SQLite file
that serves live requests, on a phone-adjacent host.

The policy is expressed as a **class per table** rather than a number per table.
A list of seventy hand-chosen day counts is a list of seventy opinions nobody can
review; six classes with stated meanings can be argued about, and a new table
then has to be assigned to one. `test_retention.py` reads the live schema and
fails if any table is unassigned, so the policy cannot silently fall behind the
schema — which is how the one n8n setting ended up being the only one.

Two classes never delete, and say why rather than being omitted:

* `OWNER_STATE` is the owner's own record of their life and work. The system does
  not get to decide it has expired. Deletion of owner state is the owner's, via
  `context/forget.py`.
* `AUTHORITY_RECORD` is the hash-chained audit log. It is pruned, but only as a
  whole prefix and only with an anchor written first, so `verify_chain` still
  reconciles afterwards — see `prune_audit_prefix`.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum
from typing import Any

from van_gateway.storage.db import Store

DAY_MS = 86_400_000
DAY_S = 86_400


class RetentionClass(str, Enum):
    #: The owner's record of their own life and work. Only the owner deletes it.
    OWNER_STATE = "OWNER_STATE"
    #: The tamper-evident authority log. Prefix-pruned with an anchor, never edited.
    AUTHORITY_RECORD = "AUTHORITY_RECORD"
    #: What VAN relied on when it claimed something happened. Outlives the claim.
    EVIDENCE = "EVIDENCE"
    #: Numbers about how the system behaved. Useful in aggregate, not individually.
    TELEMETRY = "TELEMETRY"
    #: Single-use or short-lived: nonces, tickets, in-flight markers.
    EPHEMERAL = "EPHEMERAL"
    #: Rebuildable from a source of truth elsewhere.
    DERIVED = "DERIVED"
    #: Deleted when its parent row is deleted, never by age of its own.
    CHILD = "CHILD"


#: Days each class is kept. `None` means the class is never pruned by age.
RETENTION_DAYS: dict[RetentionClass, int | None] = {
    RetentionClass.OWNER_STATE: None,
    #: Two years. Long enough that any dispute about what VAN was authorised to do
    #: is still answerable; short enough that the chain does not grow without end.
    RetentionClass.AUTHORITY_RECORD: 730,
    RetentionClass.EVIDENCE: 365,
    RetentionClass.TELEMETRY: 90,
    RetentionClass.EPHEMERAL: 7,
    RetentionClass.DERIVED: 30,
    RetentionClass.CHILD: None,
}


class TimeUnit(str, Enum):
    MS = "ms"
    SECONDS = "s"


@dataclass(frozen=True)
class TablePolicy:
    table: str
    retention: RetentionClass
    #: The column that says how old a row is. Required for a pruned class.
    column: str | None = None
    unit: TimeUnit = TimeUnit.MS
    #: Why this table is in this class, when the answer is not obvious.
    note: str = ""
    #: For CHILD tables: the column that points at the parent, and the parent table.
    parent: tuple[str, str] | None = None


def _p(table, retention, column=None, unit=TimeUnit.MS, note="", parent=None):
    return TablePolicy(table=table, retention=retention, column=column, unit=unit,
                       note=note, parent=parent)


_OWNER = RetentionClass.OWNER_STATE
_EV = RetentionClass.EVIDENCE
_TEL = RetentionClass.TELEMETRY
_EPH = RetentionClass.EPHEMERAL
_DER = RetentionClass.DERIVED
_CHILD = RetentionClass.CHILD

POLICIES: tuple[TablePolicy, ...] = (
    # ---- the authority log -------------------------------------------------
    _p("audit", RetentionClass.AUTHORITY_RECORD, "created_at_unix", TimeUnit.SECONDS,
       "Hash-chained. Pruned only as an anchored prefix; see prune_audit_prefix."),

    # ---- the owner's own state ---------------------------------------------
    _p("devices", _OWNER, note="Revoking a device is the owner's act, not a timer's."),
    _p("missions", _OWNER, note="The durable record of what the owner asked for."),
    _p("hermes_result_inbox", _OWNER,
       note="Durable lifecycle reports and duplicate receipts. An age sweep must not "
            "erase a still-unbound report or permit a conflicting terminal replay."),
    _p("reminders", _OWNER),
    _p("attention", _OWNER, note="A dismissed item is dismissed by the owner, not aged out."),
    _p("decisions", _OWNER),
    _p("decision_details", _CHILD, parent=("decision_id", "decisions")),
    _p("owner_facts", _OWNER, note="Superseded revisions are the fact's history, not litter."),
    _p("owner_context_edges", _OWNER),
    _p("owner_cognitive_model", _OWNER),
    # Memory Fabric C1/C2: per-episode origin rows die with their assertion; the revision
    # counter must never be pruned or reset (a reset would let an old capsule verify again).
    _p("owner_model_episodes", _CHILD, parent=("assertion_id", "owner_cognitive_model")),
    _p("owner_model_revisions", _OWNER, note="Monotonic fence for personal capsules; never reset."),
    _p("owner_model_outbox", _EV, "created_at_ms",
       note="Correction/invalidation delivery record, with per-target receipts."),
    _p("shared_vocabulary", _OWNER),
    _p("strategic_memory", _OWNER),
    _p("symbiotic_growth", _OWNER),
    _p("cognitive_complement_map", _OWNER),
    _p("domain_trust", _OWNER, note="How much authority the owner has delegated, by domain."),
    _p("proactive_policies", _OWNER),
    _p("permission_grants", _OWNER, note="Expiry is enforced at use; the grant's history stays."),
    _p("capability_grants", _OWNER),
    _p("google_connections", _OWNER),
    _p("google_principal", _OWNER),
    _p("google_capability_connections", _OWNER),
    _p("browser_profiles", _OWNER, note="A logged-in profile is an owner credential."),
    _p("browser_scope_authorizations", _OWNER, note="What the owner let the browser touch."),
    _p("standing_automation_authorities", _OWNER),
    _p("automation_standing_intents", _OWNER),
    _p("automation_owner_plans", _OWNER,
       note="Owner proposals and durable idempotency claims survive until explicit owner retirement; expiry cannot permit a repeat proposal."),
    _p("automation_artifacts", _OWNER,
       note="Admitted immutable executable manifests remain authoritative until explicit retirement."),
    _p("automation_capabilities", _OWNER,
       note="Capability admission and withdrawal are operator/owner acts, not telemetry expiry."),
    _p("automation_runs", _OWNER,
       note="Canonical run and uncertain-effect history must not disappear or permit a repeated effect."),
    _p("automation_n8n_resources", _OWNER,
       note="Concrete resource declarations and credentials are retired explicitly."),
    _p("automation_credential_bindings", _OWNER,
       note="Admitted credential aliases are declarations, never aged into a different binding."),
    _p("intent_nodes", _OWNER),
    _p("intent_edges", _OWNER),
    _p("intent_missions", _OWNER),
    _p("schema_migrations", _OWNER, note="The database's own history. Deleting it loses the schema's provenance."),
    _p("runtime_meta", _OWNER),
    _p("project_truth_cache", _OWNER, note="Small, keyed by project; a stale row is replaced, not accumulated."),
    _p("action_definitions", _OWNER, note="The declared action catalogue, not a log."),
    # ---- OpenMuse→VAN convergence owner state (migrations 31/32) ---------
    _p("owner_artifacts", _OWNER, note="Owner-visible generated results; deletion is an owner lifecycle decision."),
    _p("documents", _OWNER, note="Source/output document provenance owned by the owner; files are not aged out silently."),
    _p("owner_goals", _OWNER),
    _p("watches", _OWNER, note="The owner decides when a standing watch stops."),
    _p("suggestions", _OWNER, note="Acceptance/dismissal is an owner decision and remains auditable."),
    _p("conversation_threads", _OWNER),
    _p("conversation_messages", _OWNER, note="Conversation history is owner state, not execution truth."),
    _p("conversation_drafts", _OWNER, note="Unsent owner-authored text must not expire by system policy."),
    _p("conversation_followups", _OWNER, note="Queued owner-facing continuation state is retained until owner lifecycle action."),
    _p("capability_registry", _OWNER, note="Declarations. Withdrawal is recorded, not deleted."),
    _p("sqlite_sequence", _OWNER, note="SQLite's own AUTOINCREMENT bookkeeping."),

    # ---- evidence -----------------------------------------------------------
    _p("action_executions", _EV, "updated_at_unix_ms"),
    _p("research_evidence", _EV, "retrieved_at_unix_ms"),
    _p("browser_evidence", _EV, "created_at_ms"),
    _p("reasoning_assessments", _EV, "created_at_ms"),
    _p("premise_assessments", _EV, "created_at_ms"),
    _p("assumption_ledger", _EV, "updated_at_ms"),
    _p("decision_fingerprints", _EV, "updated_at_ms"),
    _p("learning_outcomes", _EV, "recorded_at_ms"),
    _p("external_reality", _EV, "observed_at_ms"),
    _p("computer_operations", _EV, "started_at_ms"),
    _p("computer_worker_receipts", _EV, "created_at_ms", note="Digest-bound proof of what the subordinate worker returned."),
    _p("google_artifacts", _EV, "created_at_unix", TimeUnit.SECONDS),
    _p("automation_worker_evidence", _EV, "created_at_ms",
       note="Sealed external-source payload evidence; source trust remains untrusted."),
    _p("automation_repairs", _EV, "created_at_ms"),
    _p("automation_dead_letter", _EV, "created_at_ms"),
    _p("browser_escalations", _EV, "created_at_ms"),
    _p("context_snapshots", _EV, "compiled_at_ms",
       note="What VAN knew when it acted. Prunes with the execution it justified."),

    # ---- telemetry ----------------------------------------------------------
    _p("automation_run_telemetry", _TEL, "recorded_at_ms"),
    _p("automation_generation_telemetry", _TEL, "recorded_at_ms"),
    _p("automation_workflow_health", _TEL, "updated_at_ms"),
    _p("browser_tasks", _TEL, "updated_at_ms"),
    _p("browser_task_tombstones", _OWNER,
       note="Review I5 D1. Not owner content, but never pruned by a timer: a tombstone is what "
            "stops a terminal task_id being inserted again after retention deletes its "
            "browser_tasks row, so it must outlive that row. Triggers refuse its deletion."),
    _p("watch_runs", _TEL, "created_at_ms", note="Individual watch observations are operational history; triggered owner state lives in Attention."),

    # ---- VAN web acquisition fabric (migrations 31-32) ---------------------
    _p(
        "web_acquisition_items",
        _OWNER,
        note="Durable frontier state can remain actionable for longer than a generic "
             "retention horizon. Prune only with a future state-aware terminal-item "
             "sweeper, never by age alone.",
    ),
    _p(
        "web_domain_skills",
        _OWNER,
        note="Qualified learned skills remain active until superseded/quarantined/retired; "
             "generic age pruning could remove the current executable skill.",
    ),
    _p("web_domain_controls", _DER, "updated_at_ms",
       note="Rate/concurrency state is rebuildable from future observations."),
    _p("web_acquisition_sessions", _TEL, "updated_at_ms",
       note="Acquisition session-pool metadata is operational telemetry; no secrets live here."),
    _p("web_acquisition_events", _EV, "occurred_at_ms"),
    _p("web_acquisition_evidence", _EV, "created_at_ms",
       note="Content-addressed custody/provenance records outlive the crawl that produced them."),
    _p("web_domain_skill_canaries", _EV, "created_at_ms",
       note="Qualification/drift evidence for learned domain skills."),
    _p("web_acquisition_telemetry", _TEL, "recorded_at_ms"),


    # ---- Remote Browser Rev 1.5 (migration 27) ------------------------------
    #
    # The session is telemetry and the *binding* is owner state, which is the split that
    # matters: a browsing session is a thing that happened, and the owner's device identity
    # is a thing that is true until they say otherwise.
    _p("browser_interactive_sessions", _TEL, "created_at_ms",
       note="A session is an episode of browsing. What it produced lives in evidence and "
            "in the mission it was bound to, both of which outlive it."),
    _p("browser_control_leases", _CHILD, parent=("session_id", "browser_interactive_sessions"),
       note="Meaningless without its session: who held the keyboard during an episode "
            "nobody kept is not a fact anyone can use."),
    _p("browser_session_targets", _CHILD, parent=("session_id", "browser_interactive_sessions")),
    _p("browser_session_events", _EV, "occurred_at_ms",
       note="ADR-RB-008's durable state changes — what VAN would cite if asked why a page "
            "was open or who took control. Evidence outlives the session it describes."),
    _p("browser_stream_grants", _CHILD, parent=("session_id", "browser_interactive_sessions"),
       note="The mint row remains canonical producer admission after its redemption window expires; "
            "retain it until the session retires."),
    _p("browser_downloads", _EV, "created_at_ms",
       note="What the owner actually got out of a session."),

    # ---- owner-device binding (§5.7) ----------------------------------------
    _p("owner_device_bindings", _OWNER,
       note="§0D.3 — the cryptographic identity of the owner's handset. A timer must never "
            "delete the only record of which device is allowed to be VAN; revocation and "
            "rebinding are explicit, audited acts."),
    _p("owner_device_reenrollments", _OWNER,
       note="Original device replacement identity/expiry and protected receipt. Age pruning "
            "must not remint an old operation or remove a pending retirement barrier; "
            "classification changes no existing explicit owner erasure/lifecycle control."),
    _p("device_certificate_retirements", _OWNER,
       note="Original security retirement and independent CA/native reconciliation fence. "
            "No age sweep may convert an unknown effect into absent authority; "
            "existing owner identity lifecycle and minimal security tombstones still apply."),
    _p("device_attestation_events", _EV, "occurred_at_ms",
       note="Why a device was accepted or refused. The refusals matter most, and are "
            "exactly what an attacker would want aged out."),
    _p("owner_device_bootstrap_tokens", _EPH, "created_at_ms",
       note="Single-use enrolment tokens, stored as hashes. Short-lived by design."),
    # ---- the durable VAN-Hermes session (migration 28) ----------------------
    #
    # The session is telemetry: an episode of being connected. Its *messages* are not,
    # because they are what makes a resubmitted command effectively-once — deleting one
    # while its command is still live would turn a retry into a second execution.
    _p("van_sessions", _TEL, "created_at_ms",
       note="A logical session is an episode of connectivity. What it carried lives in "
            "missions, commands and events, all of which outlive it."),
    _p("van_session_paths", _CHILD, parent=("van_session_id", "van_sessions")),
    _p("van_session_messages", _EV, "created_at_ms",
       note="§20.12's effectively-once record. The digest here is the only thing that can "
            "tell a lost acknowledgement from a different command under the same key, so "
            "it is evidence rather than telemetry and outlives the session it belonged to."),

    _p("connectivity_config_versions", _OWNER,
       note="ADR-RB-027 — the signed manifests the device will accept. Pruning history "
            "here would remove the ability to roll back to the configuration that worked."),
    _p("capability_route_decisions", _TEL, "decided_at_ms"),
    _p("benchmark_runs", _TEL, "created_at_ms"),
    _p("eval_runs", _TEL, "created_at_ms"),
    _p("execution_strategies", _TEL, "updated_at_ms"),
    _p("technology_capabilities", _TEL, "updated_at_ms"),
    _p("google_jobs", _TEL, "updated_at_unix", TimeUnit.SECONDS),
    _p("attention_candidates", _TEL, "created_at_ms"),
    _p("automation_external_events", _TEL, "received_at_ms"),

    # ---- ephemeral ----------------------------------------------------------
    _p("command_nonces", _EPH, "consumed_at_unix", TimeUnit.SECONDS,
       "Seven days is far longer than any command's replay window, so pruning "
       "can never make a replayed command look fresh."),
    _p("automation_run_nonces", _EPH, "issued_at_ms"),
    _p("computer_worker_leases", _EPH, "updated_at_ms", note="Short-lived generation fences; receipts preserve durable evidence."),
    _p("pairing_tickets", _EPH, "created_at_unix", TimeUnit.SECONDS),
    _p("idempotency", _EPH, "updated_at_unix", TimeUnit.SECONDS,
       "Retained well past any client's retry horizon; an idempotency record that "
       "outlives its request is only holding a result nobody will ask for again."),

    # ---- derived ------------------------------------------------------------
    _p("events", _DER, "created_at_unix", TimeUnit.SECONDS,
       "Rebuildable from missions and audit; a device that has been offline for a "
       "month refetches state rather than replaying a month of events."),
    _p("event_cursors", _DER, "updated_at_unix", TimeUnit.SECONDS),

    # ---- operations' own records --------------------------------------------
    _p("audit_chain_anchors", _OWNER,
       note="Proof of how much audit log was pruned. Deleting it would hide the prune."),
    _p("notification_suppressions", _OWNER,
       note="A dismissal is the owner's decision; it expires by its own "
            "suppressed_until, not by a retention sweep."),
    _p("scheduler_runs", _TEL, "run_at_unix", TimeUnit.SECONDS),
    _p(
        "visual_acceptances",
        _OWNER,
        note="The owner's cryptographic acceptance of an exact character/APK release. "
             "Release provenance must not disappear because a retention timer elapsed.",
    ),

    # ---- children -----------------------------------------------------------
    _p("market_monitor_objects", _OWNER,
       note="Owner-authored watchlists and alert rules persist until revision-checked explicit deletion."),
    _p("market_monitor_operations", _OWNER,
       note="Minimal original request outcomes prevent stale retries recreating deleted owner rules."),
    _p("market_monitor_scan_budget", _OWNER,
       note="One bounded quota row per owner survives workers/restart and rolls forward by its fixed window."),
    _p("market_monitor_publications", _CHILD, parent=("event_seq", "events"),
       note="Existing canonical-event Attention projection; cascades with its source event."),
    _p("chart_workspaces", _OWNER,
       note="Saved chart settings belong to the owner until revision-checked deletion."),
    _p("chart_workspace_revisions", _OWNER,
       note="Owner chart history is retained until workspace deletion; its composite owner/workspace foreign key cascades deletion."),
    _p("chart_workspace_operations", _OWNER,
       note="Minimal original operation outcomes must outlive deleted workspaces to prevent stale retries recreating them."),
    _p("mission_learning_outbox", _CHILD, parent=("mission_id", "missions"),
       note="Pending native learning delivery must survive restart and age sweeps."),
    _p("mission_strategy_observations", _CHILD, parent=("mission_id", "missions"),
       note="Original projection identities prevent retry from becoming extra experience."),
    _p("mission_projection_outbox", _CHILD, parent=("mission_id", "missions"),
       note="Undelivered terminal publication must survive retries and age sweeps."),
    _p("mission_events", _CHILD, parent=("mission_id", "missions")),
    _p("mission_activities", _CHILD, parent=("mission_id", "missions")),
    _p("mission_execution_controls", _CHILD, parent=("mission_id", "missions")),
    _p("mission_control_requests", _CHILD, parent=("mission_id", "missions")),
    _p("hermes_run_bindings", _CHILD, parent=("mission_id", "missions"),
       note="Immutable observed run correlation lasts as long as the owner mission."),
    _p("pairing_attempts", _CHILD, parent=("device_id", "devices"),
       note="Hash-only exact-retry authority lasts as long as the enrolled device; "
            "pruning it must never make an earned credential unrecoverable."),
    _p("action_receipts", _CHILD, parent=("execution_id", "action_executions")),
    _p("automation_runtime_bindings", _CHILD, parent=("artifact_id", "automation_artifacts"),
       note="Exact executable/helper bindings belong to their immutable artifact."),
    _p("automation_worker_dedupe", _CHILD, parent=("artifact_id", "automation_artifacts"),
       note="Delivered checkpoints prevent lost notifications and survive ordinary age sweeps."),
    _p("automation_worker_steps", _CHILD, parent=("run_id", "automation_runs"),
       note="Completed and uncertain callback receipts remain bound to the canonical run."),
    _p("automation_worker_files", _CHILD, parent=("run_id", "automation_runs"),
       note="Retain receipt metadata; the worker separately erases expired transient bytes."),
    _p("automation_standing_firings", _CHILD, parent=("authority_id", "standing_automation_authorities"),
       note="A claimed trigger cannot become fresh again while its authority exists."),
    _p("browser_stream_producers", _CHILD, parent=("grant_id", "browser_stream_grants"),
       note="Producer admission is meaningful only while its original short-lived grant record remains."),
    _p("browser_owner_transfer_grants", _CHILD, parent=("producer_session_id", "browser_stream_producers"),
       note="One-use transfer receipts track their canonical producer and its admission grant."),
    _p("browser_control_producer_grants", _CHILD, parent=("task_id", "browser_tasks"),
       note="Budgeted producer call authority belongs to the bounded task and session."),
    _p("goal_milestones", _CHILD, parent=("goal_id", "owner_goals")),
    _p("goal_mission_links", _CHILD, parent=("goal_id", "owner_goals")),
)

BY_TABLE: dict[str, TablePolicy] = {policy.table: policy for policy in POLICIES}


class RetentionPolicyError(ValueError):
    pass


def _validate() -> None:
    for policy in POLICIES:
        days = RETENTION_DAYS[policy.retention]
        if days is not None and policy.retention is not RetentionClass.CHILD:
            if not policy.column:
                raise RetentionPolicyError(f"{policy.table} is pruned by age but names no column")
        if policy.retention is RetentionClass.CHILD and policy.parent is None:
            raise RetentionPolicyError(f"{policy.table} is a CHILD table but names no parent")


_validate()


@dataclass(frozen=True)
class PruneResult:
    table: str
    deleted: int
    cutoff: int
    retention: RetentionClass


class RetentionService:
    """Applies the policy. Reports what it deleted; never reports what it skipped as deleted."""

    def __init__(self, store: Store) -> None:
        self.store = store

    @staticmethod
    def cutoff_for(policy: TablePolicy, now_ms: int) -> int | None:
        days = RETENTION_DAYS[policy.retention]
        if days is None or policy.column is None:
            return None
        if policy.unit is TimeUnit.SECONDS:
            return int(now_ms / 1000) - days * DAY_S
        return now_ms - days * DAY_MS

    async def prune(self, *, now_ms: int | None = None,
                    tables: tuple[str, ...] | None = None) -> list[PruneResult]:
        """Delete everything past its class's horizon.

        Audit is excluded here and handled by `prune_audit_prefix`, because a
        `DELETE ... WHERE created_at_unix < ?` on a hash-chained table is exactly
        the operation that silently breaks the chain.
        """
        now_ms = now_ms if now_ms is not None else int(time.time() * 1000)
        results: list[PruneResult] = []
        selected = [
            p for p in POLICIES
            if (tables is None or p.table in tables)
            and p.retention not in (RetentionClass.AUTHORITY_RECORD, RetentionClass.CHILD)
        ]
        async with self.store.connection() as db:
            await db.execute("BEGIN IMMEDIATE")
            try:
                child_policies = [p for p in POLICIES if p.retention is RetentionClass.CHILD]
                dependencies: dict[str, set[tuple[str, str, str]]] = {}
                protected_dependencies: dict[str, set[tuple[str, str, str]]] = {}
                child_counts: dict[str, int] = {}
                for policy in POLICIES:
                    if policy.retention is RetentionClass.CHILD:
                        continue
                    cursor = await db.execute(f"PRAGMA foreign_key_list({policy.table})")
                    for fk in await cursor.fetchall():
                        protected_dependencies.setdefault(fk["table"], set()).add((policy.table, fk["from"], fk["to"]))
                for child in child_policies:
                    column, parent = child.parent
                    dependencies.setdefault(parent, set()).add((child.table, column, _PRIMARY_KEY[parent]))
                    # A producer can refer to both a session and an admission
                    # grant. CHILD lifetime follows either authoritative parent;
                    # foreign-key restrictions must not break routine retention.
                    cursor = await db.execute(f"PRAGMA foreign_key_list({child.table})")
                    for fk in await cursor.fetchall():
                        if fk["seq"] != 0:
                            raise RetentionPolicyError("composite_child_foreign_key_unsupported")
                        dependencies.setdefault(fk["table"], set()).add((child.table, fk["from"], fk["to"]))

                async def remove_children(parent, predicate, parameters, visiting=()):
                    if parent in visiting:
                        raise RetentionPolicyError("cyclic_child_retention_dependency")
                    for child_table, column, parent_column in sorted(dependencies.get(parent, set())):
                        child_predicate = f"{column} IN (SELECT {parent_column} FROM {parent} WHERE {predicate})"
                        await remove_children(child_table, child_predicate, parameters, (*visiting, parent))
                        cursor = await db.execute(f"DELETE FROM {child_table} WHERE {child_predicate}", parameters)
                        child_counts[child_table] = child_counts.get(child_table, 0) + int(cursor.rowcount or 0)

                for policy in selected:
                    cutoff = self.cutoff_for(policy, now_ms)
                    if cutoff is None:
                        continue
                    predicate = f"{policy.column} IS NOT NULL AND {policy.column} < ?"
                    parameters = (cutoff,)
                    if policy.table == "browser_interactive_sessions":
                        # A renewed session can outlive its creation timestamp.
                        # Retention is not a revocation or producer disconnect.
                        predicate += " AND (state IN ('TERMINATED','FAILED') OR expires_at_ms<=?)"
                        parameters += (now_ms,)
                    # An evidence/owner record has its own lifetime. Neither
                    # cascade deletion nor a foreign-key failure may shorten it.
                    # Retire the parent only after those records have retired.
                    for dependent, column, parent_column in sorted(protected_dependencies.get(policy.table, set())):
                        predicate += (f" AND NOT EXISTS(SELECT 1 FROM {dependent} "
                                      f"WHERE {dependent}.{column}={policy.table}.{parent_column})")
                    await remove_children(policy.table, predicate, parameters)
                    if policy.table == "van_session_messages":
                        # The original execution deadline has exactly the message's
                        # lifetime. Remove only metadata joined to this selected
                        # message and session, under the same retention writer.
                        await db.execute(
                            "DELETE FROM runtime_meta WHERE key IN ("
                            "SELECT 'session_expiry:' || message_id FROM van_session_messages "
                            f"WHERE {predicate} AND van_session_id = CASE "
                            "WHEN json_valid(runtime_meta.value) THEN "
                            "json_extract(runtime_meta.value, '$.van_session_id') END)",
                            parameters,
                        )
                    cursor = await db.execute(f"DELETE FROM {policy.table} WHERE {predicate}", parameters)
                    results.append(PruneResult(
                        table=policy.table, deleted=int(cursor.rowcount or 0),
                        cutoff=cutoff, retention=policy.retention,
                    ))
                # CHILD rows go with their parents, in the same transaction, so a
                # prune can never leave an activity pointing at a mission that is gone.
                for policy in POLICIES:
                    if policy.retention is not RetentionClass.CHILD or policy.parent is None:
                        continue
                    if tables is not None and policy.table not in tables and policy.table not in child_counts:
                        continue
                    column, parent = policy.parent
                    parent_key = BY_TABLE[parent]
                    orphan_predicate = f"{column} NOT IN (SELECT {_PRIMARY_KEY[parent]} FROM {parent})"
                    await remove_children(policy.table, orphan_predicate, ())
                    cursor = await db.execute(f"DELETE FROM {policy.table} WHERE {orphan_predicate}")
                    results.append(PruneResult(
                        table=policy.table, deleted=int(cursor.rowcount or 0) + child_counts.get(policy.table, 0),
                        cutoff=0, retention=parent_key.retention,
                    ))
                # New purpose-discriminated raw challenges/facts/counters use
                # the EXISTING 7d EPHEMERAL horizon. Minimal used/admission and
                # unresolved native references are outside this prefix.
                if tables is None or 'runtime_meta' in tables:
                    from van_gateway.approval.account_reauth import prune_ephemeral
                    cutoff=now_ms-int(RETENTION_DAYS[RetentionClass.EPHEMERAL])*DAY_MS
                    deleted=await prune_ephemeral(db,now_ms)
                    if deleted:
                        results.append(PruneResult(table='runtime_meta',deleted=deleted,
                            cutoff=cutoff,retention=RetentionClass.EPHEMERAL))
            except BaseException:
                await db.rollback()
                raise
            await db.commit()
        return results

    async def prune_audit_prefix(self, *, now_ms: int | None = None) -> dict[str, Any]:
        """Prune the oldest audit rows, leaving an anchor the chain verifies from.

        A hash chain cannot be pruned in the middle and cannot be pruned from the
        end. It *can* be pruned from the start, provided the verifier is told
        where the remaining chain begins and what hash it must link back to. That
        is the anchor: one row recording the sequence number and entry hash of the
        last pruned entry. `verify_chain` starts from the anchor when one exists,
        so a pruned log is still tamper-evident for everything it still holds —
        and the anchor itself proves how much was pruned.
        """
        now_ms = now_ms if now_ms is not None else int(time.time() * 1000)
        policy = BY_TABLE["audit"]
        cutoff = self.cutoff_for(policy, now_ms)
        assert cutoff is not None  # AUTHORITY_RECORD has a horizon and a column
        async with self.store.connection() as db:
            await db.execute("BEGIN IMMEDIATE")
            try:
                cursor = await db.execute(
                    "SELECT chain_seq, entry_hash FROM audit "
                    "WHERE chain_seq IS NOT NULL AND created_at_unix < ? "
                    "ORDER BY chain_seq DESC LIMIT 1",
                    (cutoff,),
                )
                tip = await cursor.fetchone()
                if tip is None:
                    await db.commit()
                    return {"pruned": 0, "anchor_seq": None, "cutoff": cutoff}
                anchor_seq = int(tip["chain_seq"])
                anchor_hash = str(tip["entry_hash"])
                deleted = await db.execute(
                    "DELETE FROM audit WHERE chain_seq IS NOT NULL AND chain_seq <= ?",
                    (anchor_seq,),
                )
                await db.execute(
                    "INSERT INTO audit_chain_anchors(anchor_seq, anchor_hash, pruned_rows, "
                    "created_at_unix) VALUES (?, ?, ?, ?)",
                    (anchor_seq, anchor_hash, int(deleted.rowcount or 0), int(now_ms / 1000)),
                )
            except BaseException:
                await db.rollback()
                raise
            await db.commit()
        return {"pruned": int(deleted.rowcount or 0), "anchor_seq": anchor_seq,
                "anchor_hash": anchor_hash, "cutoff": cutoff}


#: Primary keys for the CHILD orphan sweep. Listed rather than introspected so a
#: table renamed out from under this module fails loudly instead of matching nothing.
#: The parent key a CHILD policy joins against. A parent table that is not in this map
#: raises KeyError during the sweep rather than silently skipping the orphan cleanup — which
#: is how the first version of the Remote Browser policies was caught: the classes were
#: assigned, the map was not extended, and the orphan sweep failed on the first run.
_PRIMARY_KEY = {
    "events": "seq",
    "decisions": "id",
    "devices": "device_id",
    "missions": "mission_id",
    "action_executions": "execution_id",
    "browser_interactive_sessions": "session_id",
    "van_sessions": "van_session_id",
    "automation_artifacts": "artifact_id",
    "automation_runs": "run_id",
    "standing_automation_authorities": "authority_id",
    "browser_stream_grants": "grant_id",
    "browser_stream_producers": "producer_session_id",
    "browser_tasks": "task_id",
    "owner_goals": "goal_id",
    "owner_cognitive_model": "assertion_id",
}


__all__ = [
    "BY_TABLE", "POLICIES", "RETENTION_DAYS", "PruneResult", "RetentionClass",
    "RetentionPolicyError", "RetentionService", "TablePolicy", "TimeUnit",
]
