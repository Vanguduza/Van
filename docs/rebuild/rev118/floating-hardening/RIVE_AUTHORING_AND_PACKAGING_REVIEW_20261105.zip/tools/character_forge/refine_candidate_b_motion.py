"""Refine the preserved Candidate B RML mechanics; never admit an M1/M2/release gate.

The exact existing visual geometry is retained. Separate transform ownership prevents
finite actions from erasing durable poses; the body and companion get independent
ambient timelines. This candidate remains under the original mechanics lineage.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

SOURCE_SHA256 = "dfaf6ae3badb6a5e97c33a74f5825b31170734b62af58ae646f99a461fbc9749"
ORB_SECONDS = 23.7
BODY_SECONDS = 12.0
ACTION_MS = {
    "HELLO_WAVE": 1400, "ACK_NOD": 650, "POINT_LEFT": 1200,
    "POINT_RIGHT": 1200, "POINT_UP": 1200, "POINT_DOWN": 1200,
    "POINT_TARGET": 1200, "CELEBRATE": 1800, "CAUTION": 1000,
    "CONFIRM": 900, "SHRUG": 1100, "PRESENT_CARD": 1500,
    "OPEN_PANEL": 700, "CLOSE_PANEL": 700,
}
DRAW_TAGS = {"Shape", "PointsPath", "CubicDetachedVertex", "Ellipse", "Rectangle",
             "Fill", "SolidColor", "Stroke", "LinearGradient", "GradientStop"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def visual_geometry_hash(root: ET.Element) -> str:
    # Preserve authored drawing order and values independently of newly nested transforms.
    values = [(n.tag, sorted(n.attrib.items())) for n in root.iter() if n.tag in DRAW_TAGS]
    # The orb is re-ordered for safe rear travel, so compare exact drawing records as a multiset.
    return sha256(json.dumps(sorted(values), separators=(",", ":")).encode())


def keyed(animation: ET.Element, obj: int, prop: int, values: list[tuple[int, float]]) -> None:
    track = ET.SubElement(animation, "KeyedObject", objectId=f"0:{obj}")
    channel = ET.SubElement(track, "KeyedProperty", propertyKey=str(prop))
    for frame, value in values:
        ET.SubElement(channel, "KeyFrameDouble", frame=str(frame),
                      value=f"{value:.9f}", interpolationType="linear")


def loop_layer(machine: ET.Element, name: str, layer_id: int, state_id: int, animation_id: int) -> None:
    layer = ET.SubElement(machine, "StateMachineLayer", name=name, id=f"0:{layer_id}")
    entry = ET.SubElement(layer, "EntryState", x="0", y="0")
    ET.SubElement(entry, "StateTransition", stateToId=f"0:{state_id}")
    ET.SubElement(layer, "AnyState", x="0", y="-120")
    ET.SubElement(layer, "ExitState", x="480", y="-120")
    ET.SubElement(layer, "AnimationState", x="200", y="0", animationId=f"0:{animation_id}", id=f"0:{state_id}")


def smoothstep(value: float) -> float:
    t = max(0.0, min(1.0, value))
    return t * t * (3.0 - 2.0 * t)


def orb_position(phase: float) -> tuple[float, float, float]:
    """Absolute artboard coordinates, periodic with zero velocity at both side changes."""
    if not math.isfinite(phase):
        raise ValueError("Non-finite authoring phase")
    p = max(0.0, min(1.0, phase))
    if .20 <= p < .41:
        t = smoothstep((p - .20) / .21)
        return 164 + 290 * t, 205 - 68 * math.sin(math.pi * t), 2 * math.pi * smoothstep(p)
    if .69 <= p < .90:
        t = smoothstep((p - .69) / .21)
        return 454 - 290 * t, 205 - 68 * math.sin(math.pi * t), 2 * math.pi * smoothstep(p)
    right = .41 <= p < .69
    start, stop = (.41, .69) if right else ((0, .20) if p < .20 else (.90, 1.0))
    t = (p - start) / (stop - start)
    hover = 4 * math.sin(math.pi * t)**2 * math.sin(2 * math.pi * t)
    return (454 if right else 164), 205 + hover, 2 * math.pi * smoothstep(p)


def refine(source: bytes, contract: dict) -> tuple[bytes, dict]:
    if sha256(source) != SOURCE_SHA256:
        raise ValueError("Source differs from preserved reviewed mechanics baseline; reconcile before applying")
    root = ET.fromstring(source)
    art = root.find("Artboard")
    if art is None or art.get("name") != "Van":
        raise ValueError("Missing original Van artboard")
    machine = art.find("StateMachine")
    if machine is None or machine.get("name") != "VanRuntime":
        raise ValueError("Missing original VanRuntime state machine")
    before_geometry = visual_geometry_hash(root)
    input_surface = [(n.get("name"), n.tag, n.get("id")) for n in machine if n.tag.startswith("StateMachine") and n.tag != "StateMachineLayer"]
    actual_names = [name for name, _, _ in input_surface]
    expected_names = [v["name"] for v in contract["inputs"]] + contract["triggers"]
    if actual_names != expected_names:
        raise ValueError("Public input/trigger names drifted")
    nodes = {n.get("id"): n for n in art if n.tag == "Node"}
    if set(nodes) != {"0:10", "0:11", "0:12", "0:13", "0:14"}:
        raise ValueError("Unexpected top-level character geometry")
    action_nodes = {11: 801, 12: 802, 13: 803}
    original_positions = {}
    for node_id, action_id in action_nodes.items():
        node = nodes[f"0:{node_id}"]
        original_positions[node_id] = (float(node.get("x", "0")), float(node.get("y", "0")))
        inner = ET.Element("Node", name=node.get("name") + "Action", id=f"0:{action_id}")
        for child in list(node):
            node.remove(child)
            inner.append(child)
        node.append(inner)

    # The preserved source appended face controls behind opaque traced artwork,
    # and put the skin cover in front of every viseme. Correct actual draw order;
    # retain all original geometry/colours. RML's first sibling draws on top.
    head_action = nodes["0:11"].find('Node[@id="0:801"]')
    face_controls = [n for n in list(head_action) if n.get("id") in {"0:700", "0:701", "0:489"}]
    for control in face_controls:
        head_action.remove(control)
    for index, control in enumerate(face_controls):
        head_action.insert(index, control)
        if control.get("id") in {"0:700", "0:701"}:
            children = list(control)
            for child in children:
                control.remove(child)
            for child in reversed(children):
                control.append(child)
    mouth = root.find('.//Node[@id="0:489"]')
    cover = mouth.find('Shape[@id="0:490"]')
    mouth.remove(cover)
    mouth.append(cover)
    # Scale around the actual mouth centre, not the head/neck pivot. The inverse
    # child translation leaves original drawing geometry byte-equivalent.
    mouth.set("x", "3")
    mouth.set("y", "-23")
    mouth_anchor = ET.Element("Node", name="MouthGeometryAnchor", id="0:804", x="-3", y="23")
    for child in list(mouth):
        mouth.remove(child)
        mouth_anchor.append(child)
    mouth.append(mouth_anchor)
    aperture_scale = ET.Element("Node", name="MouthAmplitude", id="0:805", x="3", y="-23")
    aperture_geometry = ET.SubElement(aperture_scale, "Node", name="MouthApertures", id="0:806", x="-3", y="23")
    for shape in list(mouth_anchor):
        if shape.get("id") != "0:490":
            mouth_anchor.remove(shape)
            aperture_geometry.append(shape)
    mouth_anchor.insert(0, aperture_scale)

    body = ET.Element("Node", name="BodyAmbient", id="0:800")
    for node_id in (11, 13, 12, 10):
        node = nodes[f"0:{node_id}"]
        art.remove(node)
        body.append(node)
    # RML declaration order is front-to-back. One actual orb sits behind the body,
    # independently visible at the flanks; no duplicate mascot or cloned artboard.
    orb = nodes["0:14"]
    art.remove(orb)
    art.insert(1, body)
    art.insert(2, orb)

    animations = {n.get("name"): n for n in art.findall("LinearAnimation")}
    states = contract["durable_states"]
    actions = contract["finite_actions"]
    for name in states:
        animation = animations[name]
        # State controls posture only; the ambient layers own cyclical life motion.
        for obj in list(animation):
            if obj.get("objectId") == "0:14":
                animation.remove(obj)
                continue
            for prop in obj:
                for later in list(prop)[1:]:
                    prop.remove(later)
        animation.set("duration", "480")

    for name in actions:
        animation = animations[name]
        duration = int(round(ACTION_MS[name] * 60 / 1000))
        animation.set("duration", str(duration))
        for obj in list(animation):
            original_id = int(obj.get("objectId", "0:0").split(":")[1])
            if original_id == 14:
                animation.remove(obj)
                continue
            if original_id not in action_nodes:
                continue
            obj.set("objectId", f"0:{action_nodes[original_id]}")
            for prop in obj:
                property_id = int(prop.get("propertyKey", "0"))
                for key in prop:
                    key.set("frame", str(round(int(key.get("frame", "0")) * duration / 60)))
                    if property_id in (13, 14):
                        old = float(key.get("value", "0"))
                        offset = original_positions[original_id][property_id - 13]
                        key.set("value", f"{old-offset:.9f}")

    # Canonical ACK_NOD is an eight-degree nod, not just a vertical translation.
    # Keep the existing seven-pixel weight shift and add neck-pivot rotation.
    keyed(animations["ACK_NOD"],801,15,[(0,0.0),(6,math.radians(-1)),(14,math.radians(8)),(39,0.0)])

    neutral = animations["NO_ACTION"]
    for child in list(neutral):
        neutral.remove(child)
    for action_id in action_nodes.values():
        for prop in (13, 14, 15):
            keyed(neutral, action_id, prop, [(0, 0.0)])

    # Keep numeric action_code authoritative; a held code cannot replay after its clip.
    # Legacy triggers still play once and return when their clip ends with code zero.
    finite = machine.find('StateMachineLayer[@name="FiniteAction"]')
    if finite is None:
        raise ValueError("FiniteAction layer missing")
    for state in finite.findall("AnimationState"):
        if state.get("id") == "0:449":
            continue
        for transition in state.findall("StateTransition"):
            transition.attrib.pop("flags", None)
            transition.set("enableExitTime", "true")
            transition.set("exitTimeIsPercetange", "true")
            transition.set("exitTime", "100")
            if transition.find('TransitionNumberCondition[@inputId="0:109"]') is None:
                ET.SubElement(transition, "TransitionNumberCondition", inputId="0:109", opValue="equal", value="0")

    # Reusable head/pupil rig mechanics: continuous three-point interpolation, not
    # threshold jumps at -0.33/+0.33. Existing public attention inputs are unchanged.
    for axis, layer_id, state_id, input_id, first_animation in [
        ("X",720,721,104,710), ("Y",730,731,105,713),
    ]:
        previous = machine.find(f'StateMachineLayer[@name="Gaze{axis}"]')
        if previous is None:
            raise ValueError("Original gaze layer missing")
        index = list(machine).index(previous)
        machine.remove(previous)
        layer = ET.Element("StateMachineLayer", name=f"Gaze{axis}", id=f"0:{layer_id}")
        entry = ET.SubElement(layer,"EntryState",x="0",y="0")
        ET.SubElement(entry,"StateTransition",stateToId=f"0:{state_id}")
        ET.SubElement(layer,"AnyState",x="0",y="-120")
        ET.SubElement(layer,"ExitState",x="480",y="-120")
        blend = ET.SubElement(layer,"BlendState1DInput",inputId=f"0:{input_id}",x="200",y="0",id=f"0:{state_id}")
        for n, value in enumerate((-1,0,1)):
            ET.SubElement(blend,"BlendAnimation1D",animationId=f"0:{first_animation+n}",value=str(value))
        machine.insert(index,layer)

    # Speech controls are independent: viseme chooses a shape; measured/estimated
    # mouth_open controls only its vertical aperture, not the skin cover or location.
    for name in ("MOUTH_CLOSED", "MOUTH_OPEN"):
        for obj in animations[name].findall("KeyedObject"):
            if obj.get("objectId") == "0:489":
                obj.set("objectId", "0:805")
    for key in animations["MOUTH_CLOSED"].iter("KeyFrameDouble"):
        key.set("value", "1")
    for ident, name, value in [(830,"MOUTH_AMPLITUDE_ZERO",0.04),(831,"MOUTH_AMPLITUDE_FULL",1.28)]:
        timeline=ET.SubElement(art,"LinearAnimation",name=name,id=f"0:{ident}",duration="1",loopValue="1")
        keyed(timeline,805,17,[(0,value)])
    old_mouth_layer=machine.find('StateMachineLayer[@name="MouthOpen"]')
    mouth_index=list(machine).index(old_mouth_layer)
    machine.remove(old_mouth_layer)
    mouth_layer=ET.Element("StateMachineLayer",name="MouthOpen",id="0:749")
    entry=ET.SubElement(mouth_layer,"EntryState",x="0",y="0")
    ET.SubElement(entry,"StateTransition",stateToId="0:750")
    any_state=ET.SubElement(mouth_layer,"AnyState",x="0",y="-120")
    for state_id,comparison in [(751,"equal"),(750,"notEqual")]:
        transition=ET.SubElement(any_state,"StateTransition",stateToId=f"0:{state_id}",duration="70")
        ET.SubElement(transition,"TransitionBoolCondition",inputId="0:102",opValue=comparison)
    ET.SubElement(mouth_layer,"ExitState",x="480",y="-120")
    ET.SubElement(mouth_layer,"AnimationState",x="160",y="80",animationId="0:740",id="0:750")
    blend=ET.SubElement(mouth_layer,"BlendState1DInput",inputId="0:106",x="360",y="80",id="0:751")
    ET.SubElement(blend,"BlendAnimation1D",animationId="0:830",value="0")
    ET.SubElement(blend,"BlendAnimation1D",animationId="0:831",value="1")
    machine.insert(mouth_index,mouth_layer)
    viseme_layer=machine.find('StateMachineLayer[@name="SpeechViseme"]')
    viseme_any=viseme_layer.find("AnyState")
    for transition in viseme_any.findall("StateTransition"):
        transition.set("duration","70")
        ET.SubElement(transition,"TransitionBoolCondition",inputId="0:102",opValue="equal")
    quiet=ET.SubElement(viseme_any,"StateTransition",stateToId="0:650",duration="70")
    ET.SubElement(quiet,"TransitionBoolCondition",inputId="0:102",opValue="notEqual")
    for destination,op,value in [(651,"greaterThan",4),(650,"lessThan",0)]:
        transition=ET.SubElement(viseme_any,"StateTransition",stateToId=f"0:{destination}",duration="70")
        ET.SubElement(transition,"TransitionNumberCondition",inputId="0:108",opValue=op,value=str(value))
        ET.SubElement(transition,"TransitionBoolCondition",inputId="0:102",opValue="equal")

    body_animation = ET.SubElement(art,"LinearAnimation",name="BODY_AMBIENT",id="0:810",duration="720",loopValue="1")
    values = [(f, 3 * math.sin(2*math.pi*f/720)) for f in range(0,721,12)]
    keyed(body_animation,800,14,values)
    keyed(body_animation,800,13,[(f, 1.5 * math.sin(4*math.pi*f/720)) for f in range(0,721,12)])
    loop_layer(machine,"BodyAmbient",811,812,810)

    orb_animation = ET.SubElement(art,"LinearAnimation",name="COMPANION_AUTONOMY",id="0:820",duration="1422",loopValue="1")
    # One key every 100ms, with explicit exact transition and loop boundary frames.
    frames = sorted(set(range(0,1423,6)) | {284,583,981,1280,1422})
    samples = [(f,orb_position(f/1422)) for f in frames]
    for prop, idx in [(13,0),(14,1),(15,2)]:
        keyed(orb_animation,14,prop,[(f,value[idx]) for f,value in samples])
    loop_layer(machine,"CompanionAutonomy",821,822,820)

    ids=[n.get("id") for n in root.iter() if n.get("id")]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate explicit RML IDs")
    if visual_geometry_hash(root) != before_geometry:
        raise ValueError("Visual drawing geometry was modified")
    layers = [n.get("name") for n in machine.findall("StateMachineLayer")]
    if len(layers) != 8:
        raise ValueError("Active layer budget exceeded")
    report = {
        "status":"UNADMITTED_MECHANICS_REFINEMENT", "production_admissible":False,
        "parent_scene_sha256":SOURCE_SHA256, "geometry_sha256":before_geometry,
        "geometry_unchanged":True, "inputs_and_triggers":input_surface,
        "durable_states":len(states), "finite_actions":len(actions), "visemes":5,
        "layers":layers, "orb_cycle_seconds":ORB_SECONDS, "body_cycle_seconds":BODY_SECONDS,
        "action_durations_ms":ACTION_MS, "aura_embedded":False,
        "qualified_android_runtime":False, "device_qualified":False,
        "remaining":["M0 source confirmation", "M1 reviewed semantic vector artwork",
                     "M2/M3 independent and owner rig review", "actual Android runtime and S24 evidence"],
    }
    output=ET.tostring(root,encoding="utf-8",xml_declaration=True)+b"\n"
    report["scene_sha256"]=sha256(output)
    return output, report


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source",type=Path,required=True)
    parser.add_argument("--contract",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    repository = Path(__file__).resolve().parents[2]
    candidate_root = (repository / "visual-authority/character-forge/08-prototypes/candidate-b-mechanics").resolve()
    if candidate_root not in args.output.resolve().parents:
        raise SystemExit("Output must remain under the original unadmitted mechanics lineage; this tool cannot promote assets")
    if args.output.exists():
        raise SystemExit("Output already exists; preserve receipts and choose an explicit new revision")
    output,report=refine(args.source.read_bytes(),json.loads(args.contract.read_text()))
    args.output.mkdir(parents=True)
    (args.output/"scene.rml").write_bytes(output)
    (args.output/"rive.yaml").write_text("name: van_candidate_b_motion_r4\nentry: scene.rml\n")
    (args.output/"source-receipt.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
