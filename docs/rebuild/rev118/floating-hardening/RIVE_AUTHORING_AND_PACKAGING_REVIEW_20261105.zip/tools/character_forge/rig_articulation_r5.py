"""Additive, traceable articulation for the original Candidate B skeleton.

Original raster pixels are never repainted. Underlaps are deliberately new hidden
joint coverage, using the original jacket/glove palette. They are candidate artwork
changes requiring visual review, not historical owner-approved pixels.
"""
from __future__ import annotations
import xml.etree.ElementTree as ET

SHOULDER_REBASE = {35:(12.0,24.0,36,'arm_l_upper'),38:(-21.0,20.0,39,'arm_r_upper')}

JOINT_UNDERLAPS = {
    35: ('shoulder_l', 18.0, 16.5, 'FFCBD0D4'),
    38: ('shoulder_r', 18.0, 16.5, 'FFCBD0D4'),
    36: ('elbow_l', 15.0, 14.0, 'FFD6D1CF'),
    39: ('elbow_r', 15.0, 14.0, 'FFD6D1CF'),
}

def ellipse(parent: ET.Element, name: str, x: float, y: float,
            rx: float, ry: float, color: str) -> ET.Element:
    shape=ET.SubElement(parent,'Shape',name=name,x=str(x),y=str(y))
    ET.SubElement(shape,'Ellipse',width=str(2*rx),height=str(2*ry))
    fill=ET.SubElement(shape,'Fill')
    ET.SubElement(fill,'SolidColor',colorValue=color)
    return shape

def add_joint_underlaps(art: ET.Element) -> dict:
    # Original pivots sat outside the painted shoulder. Rebase them into the
    # actual socket while preserving every image's neutral world placement.
    for ident,(dx,dy,elbow_id,image_name) in SHOULDER_REBASE.items():
        shoulder=art.find(".//Node[@id='0:%d']"%ident)
        elbow=art.find(".//Node[@id='0:%d']"%elbow_id)
        image=art.find(".//Image[@name='%s']"%image_name)
        for node,sign in [(shoulder,1),(elbow,-1),(image,-1)]:
            for axis,offset in [('x',dx),('y',dy)]:
                node.set(axis,f"{float(node.get(axis,'0'))+sign*offset:.7f}")
        owner=art.find("Node[@name='follow_%s']"%image_name)
        clip=owner.find("Shape[@name='r5_sleeve_main_component']")
        if clip is not None:clip.set('x',str(-dx));clip.set('y',str(-dy))
    for index,(ident,(name,rx,ry,color)) in enumerate(JOINT_UNDERLAPS.items()):
        bone=art.find(".//Node[@id='0:%d']"%ident)
        if bone is None:raise ValueError('Original joint missing: '+name)
        joint=ET.SubElement(bone,'Node',name='r5_joint_underlap_'+name,id='0:'+str(1900+index))
        # Rive siblings paint front-to-back. The light inset goes in front of the
        # dark seam and all of this skeleton geometry remains behind the original
        # follow_* raster layers. Cover exactly the rotational seam, not the limb.
        ellipse(joint,name+'_inset',-1,-1,rx-1.5,ry-1.5,color)
        ellipse(joint,name+'_rim',0,0,rx,ry,'FF202A34')
    return {'joint_underlap_count':len(JOINT_UNDERLAPS),
            'joint_underlap_source':'additive palette-matched vector caps behind original raster images',
            'original_raster_bytes_modified':False,
            'shoulder_pivot_rebase':{str(k):list(v[:2]) for k,v in SHOULDER_REBASE.items()},
            'neutral_raster_world_placement_preserved':True}

# Artboard-pixel masks identify visible gloved finger pieces. The partition uses
# original PNG pixels only, keeps originals intact, and reconstructs each neutral
# source pixel exactly. This is new candidate segmentation, not new owner approval.
HAND_PARTITIONS = {
 'r': {'file':'16_hand_r.png','asset':59,'wrist':40,'image':(-0.996,32.5289),'size':(53,82),
  'polygons':{
   'index_prox':[(22,44),(32,44),(33,58),(28,62),(23,59)],
   'index_tip':[(23,59),(28,62),(27,67),(22,71),(18,75),(11,73),(9,69),(19,62)],
   'thumb':[(0,28),(16,26),(22,33),(20,43),(15,48),(13,60),(7,63),(0,61)]},
  'pivots':{'index_prox':(27,45),'index_tip':(26,59),'thumb':(17,30)},'first_node':2001,'first_asset':2110},
 'l': {'file':'13_hand_l.png','asset':56,'wrist':37,'image':(-26.9768,-18.5191),'size':(87,58),
  'polygons':{
   'index_prox':[(12,22),(24,23),(29,27),(28,40),(20,40),(15,32)],
   'index_tip':[(0,13),(12,14),(18,20),(17,26),(12,28),(4,25),(0,21)],
   'thumb':[(21,0),(31,0),(39,10),(45,17),(41,23),(32,22),(25,16),(21,9)]},
  'pivots':{'index_prox':(25,30),'index_tip':(12,23),'thumb':(40,20)},'first_node':2005,'first_asset':2114},
}


# Preserve the original three controls and source asset identities; split the
# remaining curled-finger pixels into independently controlled middle/ring/little.
HAND_PARTITIONS['r']['polygons'].update({
 'middle':[(31,44),(39,45),(40,57),(34,69),(27,75),(20,78),(17,76),(25,69),(30,57)],
 'ring':[(40,45),(46,46),(46,56),(40,68),(34,72),(31,68),(37,57)],
 'little':[(46,45),(52,47),(52,55),(47,60),(43,66),(40,65),(45,55)],
})
HAND_PARTITIONS['r']['pivots'].update(middle=(34,48),ring=(42,48),little=(48,49))
HAND_PARTITIONS['l']['polygons'].update({
 'middle':[(25,34),(28,42),(21,46),(15,42),(9,36),(5,27),(8,25),(13,33),(20,38)],
 'ring':[(26,37),(36,37),(38,50),(35,54),(29,52),(23,46)],
 'little':[(38,40),(46,42),(47,50),(43,55),(36,56),(35,51)],
})
HAND_PARTITIONS['l']['pivots'].update(middle=(24,39),ring=(31,39),little=(41,43))
EXTRA_FINGER_NODES={'r':{'middle':2700,'ring':2701,'little':2702},
                    'l':{'middle':2703,'ring':2704,'little':2705}}
EXTRA_FINGER_ASSETS={'r':{'middle':2120,'ring':2121,'little':2122},
                     'l':{'middle':2123,'ring':2124,'little':2125}}
FINGER_PARTS=('index_prox','index_tip','thumb','middle','ring','little')

def finger_node_ids():
    return (2001,2002,2003,2005,2006,2007,2700,2701,2702,2703,2704,2705)

def finger_asset(side,spec,name):
    if name in EXTRA_FINGER_ASSETS[side]:return EXTRA_FINGER_ASSETS[side][name]
    return spec['first_asset']+('palm','index_prox','index_tip','thumb').index(name)


def split_hand_pixels(source, specification):
    from PIL import Image, ImageDraw
    import numpy as np
    original=Image.open(source).convert('RGBA')
    if original.size!=specification['size']:raise ValueError('Original glove dimensions changed')
    rgba=np.array(original);assigned=np.zeros(rgba.shape[:2],dtype=bool);parts={}
    for part,poly in specification['polygons'].items():
        mask=Image.new('1',original.size);ImageDraw.Draw(mask).polygon(poly,fill=1)
        selected=np.array(mask,dtype=bool)&~assigned
        assigned|=selected
        pixels=rgba.copy();pixels[~selected]=0
        parts[part]=Image.fromarray(pixels,'RGBA')
    pixels=rgba.copy();pixels[assigned]=0;parts['palm']=Image.fromarray(pixels,'RGBA')
    # Exact RGBA partition, including antialiased source alpha. No new painted
    # glove pixels are invented by the split and no two parts own one pixel.
    summed=sum(np.asarray(im,dtype=np.uint16) for im in parts.values())
    assert np.array_equal(summed,rgba.astype(np.uint16)),'Hand partition does not reconstruct source'
    return parts

def write_articulation_assets(source_layers,output_layers):
    import hashlib
    manifest={}
    output_layers.mkdir(parents=True,exist_ok=True)
    for side,spec in HAND_PARTITIONS.items():
        source=source_layers/spec['file'];parts=split_hand_pixels(source,spec)
        for name,im in parts.items():
            target=output_layers/f'r5_hand_{side}_{name}.png'
            im.save(target,compress_level=9)
            manifest[str(target.name)]={'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
                'source_png':spec['file'],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                'part':name,'pixels_preserved':True}
    return manifest

def add_finger_rig(root,art,keyed,single):
    finger_nodes=[]
    for side,spec in HAND_PARTITIONS.items():
        owner=art.find("Node[@name='follow_hand_%s']"%side)
        image=owner.find("Image[@name='hand_%s']"%side)
        wrist=art.find(".//Node[@id='0:%d']"%spec['wrist'])
        if image is None or image.get('assetId')!='0:'+str(spec['asset']):raise ValueError('Original hand identity changed')
        for index,name in enumerate(['palm',*FINGER_PARTS]):
            root.insert(0,ET.Element('ImageAsset',file=f'layers/r5_hand_{side}_{name}.png',
                        name=f'r5_hand_{side}_{name}',id=f"0:{finger_asset(side,spec,name)}"))
        image.set('assetId','0:'+str(spec['first_asset']))
        positions={}
        for index,part in enumerate(FINGER_PARTS):
            pixel=spec['pivots'][part]
            absolute=(spec['image'][0]+pixel[0]-spec['size'][0]/2,
                      spec['image'][1]+pixel[1]-spec['size'][1]/2)
            parent=wrist
            local=absolute
            if part=='index_tip':
                parent=positions['index_prox'][0]
                local=(absolute[0]-positions['index_prox'][1][0],absolute[1]-positions['index_prox'][1][1])
            ident=EXTRA_FINGER_NODES[side].get(part,spec['first_node']+index)
            bone=ET.SubElement(parent,'Node',x=str(local[0]),y=str(local[1]),name=f'rig_{part}_{side}',id=f'0:{ident}')
            positions[part]=(bone,absolute)
            # Small glove-coloured seams remain behind the moving image parts.
            ellipse(bone,f'r5_knuckle_underlap_{side}_{part}',0,0,3.2,3.2,'FF202732')
            follow=ET.Element('Node',name=f'r5_follow_finger_{side}_{part}')
            ET.SubElement(follow,'TransformConstraint',targetId=f'0:{ident}',name=f'r5_finger_follow_{side}_{part}')
            ET.SubElement(follow,'Image',x=str(spec['image'][0]-absolute[0]),y=str(spec['image'][1]-absolute[1]),
                          assetId=f"0:{finger_asset(side,spec,part)}",name=f'r5_finger_image_{side}_{part}')
            art.insert(list(art).index(owner),follow)
            finger_nodes.append((ident,side,part))
    # Existing public action_code continues to own finite finger articulation.
    # No extra state-machine layer or mandatory new public input is added.
    neutral=art.find("LinearAnimation[@name='r5_action_neutral_full']")
    for ident,_,_ in finger_nodes:single(neutral,ident,15,0)
    for animation in art.findall('LinearAnimation'):
        name=animation.get('name','')
        if not name.startswith('action_r5_'):continue
        duration=int(animation.get('duration'));label=name.removeprefix('action_r5_')
        for ident,side,part in finger_nodes:
            value=0.0
            if part in ('middle','ring','little'):
                curl={'middle':.12,'ring':.16,'little':.20}[part]
                sign=1 if side=='r' else -1
                value=sign*(curl if label.startswith('point') or label in ('confirm','close_panel') else
                            -.5*curl if label in ('hello_wave','present_card','open_panel','shrug') else .35*curl)
            elif label.startswith('point'):
                if side=='r':value={'index_prox':0.04,'index_tip':-0.70,'thumb':-0.18}[part]
                else:value={'index_prox':0.16,'index_tip':-0.30,'thumb':0.22}[part]
            elif label in ('hello_wave','present_card','open_panel'):
                value={'index_prox':-0.10,'index_tip':-0.18,'thumb':0.14}[part]
            elif label in ('confirm','celebrate'):
                value={'index_prox':0.10,'index_tip':0.18,'thumb':-0.28}[part]
            elif label=='close_panel':value={'index_prox':0.07,'index_tip':0.16,'thumb':-0.10}[part]
            keyed(animation,ident,15,[(0,0),(max(1,round(duration*.16)),-value*.1),
                (round(duration*.40),value),(round(duration*.78),value),(duration,0)])
    return {'articulated_finger_nodes':12,'finger_source':'all five fingers independently controlled on each original glove; two index joints, one control per other finger',
            'derived_image_count':14,'finger_articulation_owner':'existing finite action layer; no public input changes'}

def add_live_pointing(art,machine,keyed,single):
    """Real two-bone IK driven by existing attention_x/y only during POINT_TARGET.

    The target ray is supplied by current, owned Android layout geometry. A
    separate invisible Bone chain solves IK; rotation adapters retarget the exact
    original sleeve Nodes without changing their coordinate conventions.
    """
    import math,copy
    shoulder=art.find(".//Node[@id='0:38']")
    elbow=art.find(".//Node[@id='0:39']")
    wrist=art.find(".//Node[@id='0:40']")
    chest=art.find(".//Node[@id='0:15']")
    first=(float(elbow.get('x')),float(elbow.get('y')))
    second=(float(wrist.get('x')),float(wrist.get('y')))
    h1,h2=math.atan2(first[1],first[0]),math.atan2(second[1],second[0])
    x,y=float(shoulder.get('x')),float(shoulder.get('y'))
    axis=ET.SubElement(chest,'Node',name='r5_live_point_x_axis',id='0:2222',x=str(x+17.1234),y=str(y))
    target=ET.SubElement(axis,'Node',name='r5_live_point_target',id='0:2221',x='0.001',y='9.8765')
    root=ET.SubElement(chest,'RootBone',name='r5_point_upper_solver',id='0:2210',
        x=str(x),y=str(y),length=str(math.hypot(*first)),rotation=str(h1))
    fore=ET.SubElement(root,'Bone',name='r5_point_fore_solver',id='0:2211',
        length=str(math.hypot(*second)),rotation=str(h2-h1))
    ET.SubElement(fore,'IKConstraint',name='r5_two_bone_live_ik',id='0:2234',
        targetId='0:2221',parentBoneCount='1',invertDirection='true')
    ET.SubElement(root,'Node',name='r5_point_upper_rotation_adapter',id='0:2212',rotation=str(-h1))
    ET.SubElement(fore,'Node',name='r5_point_fore_rotation_adapter',id='0:2213',rotation=str(-h2))
    for original,target_id,ident in [(shoulder,2212,2232),(elbow,2213,2233)]:
        ET.SubElement(original,'RotationConstraint',name='r5_live_point_rotation',id=f'0:{ident}',
            targetId=f'0:{target_id}',sourceSpaceValue='world',destSpaceValue='world',strength='0')
    for index,(old_name,axis,value,old_id) in enumerate([
        ('gaze_x_neg',13,-1,120),('gaze_x_mid',13,0,121),('gaze_x_pos',13,1,122),
        ('gaze_y_neg',14,-1,125),('gaze_y_mid',14,0,126),('gaze_y_pos',14,1,127)]):
        clip=copy.deepcopy(art.find("LinearAnimation[@name='%s']"%old_name))
        clip.set('name','r5_target_'+old_name);clip.set('id','0:'+str(2240+index))
        single(clip,2222 if axis==13 else 2221,axis,(x if axis==13 else 0)+100*value)
        art.append(clip)
        for blend in machine.findall(".//BlendAnimation1D[@animationId='0:%d']"%old_id):
            blend.set('animationId','0:'+str(2240+index))
    for layer_name in ['Gaze x','Gaze y']:
        blend=machine.find("StateMachineLayer[@name='%s']/BlendState1DInput"%layer_name)
        blend.set('reset','true')
        for entry in list(blend):
            if entry.tag=='BlendAnimation1D' and entry.get('value')=='0':blend.remove(entry)
    # A neutral target value has no supplied point. Preserve the original static
    # gesture rather than folding an IK arm onto its own shoulder.
    dynamic=art.find("LinearAnimation[@name='action_r5_point_target']")
    static=copy.deepcopy(dynamic);static.set('id','0:2260');static.set('name','r5_point_without_target')
    art.append(static)
    for animation in art.findall('LinearAnimation'):
        name=animation.get('name','')
        if name.startswith('action_r5_') or name in ('r5_action_neutral_full','r5_point_without_target'):
            length=int(animation.get('duration'))
            for ident in [2232,2233]:
                if name=='action_r5_point_target':
                    keyed(animation,ident,172,[(0,0),(round(length*.25),1),(round(length*.82),1),(length,0)])
                else:single(animation,ident,172,0)
    layer=machine.find("StateMachineLayer[@name='Action']")
    state=layer.find("AnimationState[@id='0:1607']")
    missing=copy.deepcopy(state);missing.set('id','0:1867');missing.set('animationId','0:2260')
    layer.append(missing)
    absent=ET.SubElement(state,'StateTransition',stateToId='0:1867',duration='80')
    for input_id in [90,91]:
        ET.SubElement(absent,'TransitionNumberCondition',inputId=f'0:{input_id}',opValue='greaterThan',value='-0.0001')
        ET.SubElement(absent,'TransitionNumberCondition',inputId=f'0:{input_id}',opValue='lessThan',value='0.0001')
    for input_id in [90,91]:
        for op,value in [('lessThan',-0.0001),('greaterThan',0.0001)]:
            present=ET.SubElement(missing,'StateTransition',stateToId='0:1607',duration='80')
            ET.SubElement(present,'TransitionNumberCondition',inputId=f'0:{input_id}',opValue=op,value=str(value))
    trigger=layer.find("AnimationState[@id='0:1807']")
    if trigger is not None:trigger.set('animationId','0:2260')
    return {'live_pointing':'actual two-bone IK from existing attention direction during POINT_TARGET',
            'live_pointing_reach_artboard_px':100,'live_pointing_arm':'right; original left directional gesture unchanged',
            'live_pointing_input_extension':False,'live_pointing_invalid_zero':'original static pointing clip; no folded IK'}
