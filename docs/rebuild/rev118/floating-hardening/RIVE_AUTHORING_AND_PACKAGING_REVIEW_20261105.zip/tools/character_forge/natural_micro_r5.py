"""Independent natural face channels, preserving all historical clips and input IDs.

This is new candidate acting, not an owner visual acceptance or device test.
"""
from __future__ import annotations
import copy
import xml.etree.ElementTree as ET


def wrap(art,node_id,new_id,name):
    node=art.find(".//Node[@id='0:%d']"%node_id)
    assert node is not None,name
    parent=next(p for p in art.iter() if node in list(p))
    wrapper=ET.Element('Node',id=f'0:{new_id}',name=name)
    at=list(parent).index(node);parent.remove(node);wrapper.append(node);parent.insert(at,wrapper)
    return wrapper


def add_natural_face(art,machine,keyed,single,state_names):
    wrap(art,21,2800,'r5_head_gaze_left_right')
    wrap(art,21,2801,'r5_head_gaze_up_down')
    wrap(art,32,2802,'r5_soft_smile')
    for ident,new,name in [(26,2803,'r5_eye_saccade_l'),(27,2804,'r5_eye_saccade_r')]:
        wrap(art,ident,new,name)
    # Real head pose and gaze share the original attention coordinates. New
    # properties have their own nodes: no conflict with pointing-target X/Y.
    for axis,target in [('x',2800),('y',2801)]:
        for suffix,value in [('neg',-1),('mid',0),('pos',1)]:
            clip=art.find("LinearAnimation[@name='r5_target_gaze_%s_%s']"%(axis,suffix))
            assert clip is not None
            single(clip,target,13 if axis=='x' else 14,value*(1.8 if axis=='x' else 1.3))
            single(clip,target,15,value*(.025 if axis=='x' else .018))
    ambient=art.find("LinearAnimation[@name='r5_ambient_and_micro']")
    assert ambient is not None
    # Brief irregular paired micro-saccades every ~1.3–2.4s, well below6% eye width.
    frames=[87,208,331,448,585,706,832,955,1088,1211,1355]
    for ident in [2803,2804]:
        for prop in [13,14]:
            values=[(0,0)]
            for index,frame in enumerate(frames):
                v=([.45,-.55,.25,-.35][index%4] if prop==13 else [.18,-.2,.12][index%3])
                values += [(frame-3,0),(frame,v),(frame+5,v),(frame+8,0)]
            values.append((1422,0));keyed(ambient,ident,prop,values)
    # 36-second deterministic blink programme: ordinary single blinks and two
    # brief double-blink events. Original six-second blink source stays untouched.
    blink=ET.SubElement(art,'LinearAnimation',name='r5_natural_blink',id='0:2810',
        loopValue='loop',fps='60',duration='2160')
    centers=[360*cycle+peak for cycle in range(6) for peak in [142,280]]+[360*2+160,360*5+160]
    centers.sort()
    for ident,prop,kind in [(24,17,'lid'),(25,17,'lid'),(80,18,'over'),(85,18,'over'),(81,18,'cover'),(86,18,'cover')]:
        rest=.02 if kind=='lid' else 1 if kind=='cover' else 0
        values={0:rest,2160:rest}
        for center in centers:
            seq=[(-4,.02),(0,1),(6,.02)] if kind=='lid' else [(-2,0),(0,1),(3,0)] if kind=='over' else [(-4,1),(-2,0),(3,0),(6,1)]
            for delta,value in seq:values[center+delta]=value
        keyed(blink,ident,prop,sorted(values.items()))
    machine.find("StateMachineLayer[@name='Blink']/AnimationState[@id='0:107']").set('animationId','0:2810')
    # Each durable state explicitly owns the small smile-scale channel, so a
    # verified-success expression cannot leak into an error or pending approval.
    layer=machine.find("StateMachineLayer[@name='State']");by_code={}
    for state in layer.findall('AnimationState'):
        for transition in state.findall('StateTransition'):
            for condition in transition.findall("TransitionNumberCondition[@inputId='0:87']"):
                by_code[int(condition.get('value'))]=transition.get('stateToId')
    assert set(by_code)==set(range(18))
    for code,name in enumerate(state_names):
        node=layer.find("AnimationState[@id='%s']"%by_code[code])
        original=art.find("LinearAnimation[@id='%s']"%node.get('animationId'))
        copy_clip=copy.deepcopy(original);copy_clip.set('id',f'0:{2820+code}');copy_clip.set('name','r5_expression_'+name.lower())
        single(copy_clip,2802,16,1.08 if name=='SUCCESS' else 1)
        single(copy_clip,2802,17,1.06 if name=='SUCCESS' else 1)
        art.append(copy_clip);node.set('animationId',copy_clip.get('id'))
    return {'natural_face_channels':['single_blink','occasional_double_blink','paired_micro_saccades',
        'head_left','head_right','head_up','head_down','state_bound_soft_smile'],
        'blink_loop_seconds':36,'blink_closures_per_loop':14,'double_blink_events_per_loop':2,
        'original_core_blink_and_state_clips_preserved':True,
        'micro_catalogue':[
            {'name':'breathing','owner':'original idle_breathe and r5_ambient_and_micro'},
            {'name':'hover','owner':'original rig_body active-time channel'},
            {'name':'single_blink','owner':'r5_natural_blink'},
            {'name':'occasional_double_blink','owner':'r5_natural_blink'},
            {'name':'eye_saccades','owner':'r5_eye_saccade_l/r'},
            {'name':'smooth_gaze_return','owner':'Android VanRiveAvatar bounded gaze interpolation'},
            {'name':'head_left','owner':'r5_head_gaze_left_right'},
            {'name':'head_right','owner':'r5_head_gaze_left_right'},
            {'name':'head_up','owner':'r5_head_gaze_up_down'},
            {'name':'head_down','owner':'r5_head_gaze_up_down'},
            {'name':'brow_raise','owner':'original state brow poses and r5_micro brow nodes'},
            {'name':'brow_lower','owner':'original state brow poses and r5_micro brow nodes'},
            {'name':'soft_smile','owner':'r5_soft_smile verified-success-only scale'},
            {'name':'shoulder_settle','owner':'r5_micro_left/right_shoulder_settle'},
            {'name':'drag_counterlean','owner':'Android VanLiveInteractionResponse'},
            {'name':'docking_return','owner':'Android VanLiveInteractionResponse damped return'},
        ]}
