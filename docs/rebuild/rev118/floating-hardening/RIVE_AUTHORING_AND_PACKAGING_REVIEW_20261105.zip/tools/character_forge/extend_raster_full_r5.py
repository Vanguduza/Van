"""Create-only, unadmitted R5 full-catalogue *candidate* on exact recovered R4 art.

M0-M5 owner, artwork and device gates are NOT changed by this generator.
Retains all approved raster images, mesh, constraints, original core clips,
input and trigger identities, and independent orb animation. New clips are
pose-based Rive previews, NOT finished M3 finger-IK or S24-tested quality.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET
import yaml
try:
    from .rig_articulation_r5 import add_joint_underlaps, add_finger_rig, write_articulation_assets, add_live_pointing
except ImportError:
    from rig_articulation_r5 import add_joint_underlaps, add_finger_rig, write_articulation_assets, add_live_pointing
try:
    from .context_motion_r5 import add_context_motion, add_secondary_micro_motion
except ImportError:
    from context_motion_r5 import add_context_motion, add_secondary_micro_motion
try:
    from .natural_micro_r5 import add_natural_face
except ImportError:
    from natural_micro_r5 import add_natural_face

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'visual-authority/character-forge/08-prototypes/candidate-b-mechanics'
R4 = BASE / 'raster-core-r4'
EXPECTED_R4_SHA = 'dd6f3b1cd812e267a56998d60e606ad10cb8b4b6c6b4ab8423726a5ce7a21c61'
CONTRACT = ROOT / 'visual-authority/rive_contract.json'
ACTIONS = ROOT / 'visual-authority/character-forge/00-source/asset-pack/STATE_ACTION_MATRIX.yaml'

# Explicit source-state to existing core-rig retargeting. This extends the old four
# states, not a second character. Values are neck radians, brow rise in scene px,
# eye horizontal/vertical offset in scene px.
STATE_POSES = {
    'OFFLINE':(-0.10,2.5,0.0,2.0),
    'CONNECTING':(0.04,-1.5,0.0,0.0),
    'IDLE':(0.00,0.0,0.0,0.0),
    'ATTENTIVE':(0.065,-1.8,0.0,-1.0),
    'LISTENING':(0.0873,-2.0,0.0,0.0),
    'THINKING':(-0.0698,-1.0,2.0,-2.2),
    'SEARCHING':(0.055,-1.4,2.4,-0.8),
    'WORKING':(0.08,-1.4,0.0,2.0),
    'DELEGATING':(0.075,-1.6,2.5,0.3),
    'SPEAKING':(0.0349,-1.5,0.0,0.0),
    'WAITING':(-0.032,0.5,0.0,0.8),
    'WAITING_FOR_OWNER':(0.12,-2.5,0.0,-1.5),
    'DEGRADED':(-0.055,1.7,0.0,1.0),
    'WARNING':(-0.095,2.5,0.0,0.6),
    'ERROR':(-0.15,3.6,0.0,3.0),
    'SUCCESS':(0.085,-0.9,0.0,-0.8),
    'URGENT':(0.14,-3.5,0.0,-2.0),
    'SLEEPING':(-0.17,3.8,0.0,2.0),
}

# Degree->rad based synthetic posture references. Includes anticipation,
# legible action and return rather than a label-only empty timeline.
# keys are object ids for the existing original arm skeleton.
ACTION_POSES = {
    'POINT_LEFT':{35:0.84,36:1.05,37:-0.18,19:-0.035},
    'POINT_RIGHT':{38:-0.87,39:-0.65,40:0.15,19:0.035},
    'POINT_UP':{38:-1.35,39:-0.88,40:0.06,19:-0.05},
    'POINT_DOWN':{38:0.55,39:-0.32,40:0.28,19:0.042},
    'CELEBRATE':{35:0.90,36:0.50,38:-1.1,39:-0.65,19:0.075},
    'CAUTION':{35:0.52,36:0.80,38:-0.42,19:-0.09},
    'CONFIRM':{38:-0.82,39:-0.90,40:0.21,19:0.09},
    'SHRUG':{35:0.53,36:0.38,38:-0.56,39:-0.48,19:-0.06},
    'PRESENT_CARD':{38:-0.78,39:-0.82,40:0.36,19:0.035},
    'OPEN_PANEL':{38:-0.42,39:-0.22,40:0.15},
    'CLOSE_PANEL':{38:0.33,39:0.24,40:-0.15},
}

CORE_STATES = {
    'IDLE':'state_idle', 'LISTENING':'state_listening',
    'THINKING':'state_thinking', 'SPEAKING':'state_speaking',
}
CORE_ACTIONS = {
    'HELLO_WAVE':'action_hello_wave',
    'ACK_NOD':'action_ack_nod',
    'POINT_TARGET':'action_point_target',
}
ACTION_KEYS = {35,36,37,38,39,40,19}
IMAGE_TAGS = ('Image','Mesh','Skin','Weight','TransformConstraint')
UPSTREAM_TRACKS = (
    'idle_breathe', 'blink', 'state_idle', 'state_listening',
    'state_thinking', 'state_speaking', 'action_hello_wave',
    'action_hello_wave_hold', 'action_ack_nod', 'action_ack_nod_hold',
    'action_point_target', 'action_point_target_hold',
)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def get_inputs(root: ET.Element) -> list[tuple[str,str,str]]:
    machine=root.find('Artboard/StateMachine')
    return [(n.tag,n.get('name'),n.get('id')) for n in machine
            if n.tag.startswith('StateMachine') and n.tag!='StateMachineLayer']

def keyed(parent: ET.Element, ident: int, prop: int, values: list[tuple[int,float]]) -> None:
    obj=ET.SubElement(parent,'KeyedObject',objectId=f'0:{ident}')
    track=ET.SubElement(obj,'KeyedProperty',propertyKey=str(prop))
    for frame,value in values:
        ET.SubElement(track,'KeyFrameDouble',frame=str(int(frame)),value=f'{value:.9f}',interpolationType='linear')

def single(parent: ET.Element, ident: int, prop: int, value: float) -> None:
    keyed(parent,ident,prop,[(0,value)])

def make_state(art: ET.Element, code: int, name: str) -> ET.Element:
    rot, brow, gx, gy=STATE_POSES[name]
    animation=ET.SubElement(art,'LinearAnimation',
         loopValue='oneShot',fps='60',duration='1',
         name='state_r5_'+name.lower(),id=f'0:{1200+code}')
    single(animation,18,15,rot)
    single(animation,30,14,-83.1205 + brow)
    single(animation,31,14,-90.5205 + brow)
    single(animation,26,13,4.1923 + gx)
    single(animation,26,14,-0.75 + gy)
    single(animation,27,13,-3.5 + gx)
    single(animation,27,14,-0.4 + gy)
    return animation

def resampled_core(art: ET.Element, code: int, name: str, ms: int) -> ET.Element:
    old=art.find("LinearAnimation[@name='%s']"%CORE_ACTIONS[name])
    assert old is not None, name
    original_frames=int(old.get('duration'))
    new_frames=round(ms*60/1000)
    animation=copy.deepcopy(old)
    animation.set('name','action_r5_'+name.lower())
    animation.set('id',f'0:{1400+code}')
    animation.set('loopValue','oneShot')
    animation.set('duration',str(new_frames))
    for k in animation.findall('.//KeyFrameDouble'):
        position=float(k.get('frame','0'))/original_frames
        k.set('frame',str(round(position*new_frames)))
    art.append(animation)
    return animation

def solve_pointing_pose(name: str) -> dict[int, float]:
    """Two-bone endpoint solution in the original measured arm coordinates.

    Directional wrist placement only; this does not invent an index-finger rig
    or claim dynamic screen-target IK. Original image and bone lengths remain.
    """
    configurations = {
        'POINT_LEFT': (35, 36, (-42.0058, 30.9711), (-20.0434, 25.0246), (-79.0, 3.0), -1),
        'POINT_RIGHT': (38, 39, (39.0272, 41.9685), (3.9731, 55.9792), (106.0, 7.0), 1),
        'POINT_UP': (38, 39, (39.0272, 41.9685), (3.9731, 55.9792), (32.0, -100.0), 1),
        'POINT_DOWN': (38, 39, (39.0272, 41.9685), (3.9731, 55.9792), (26.0, 103.0), -1),
    }
    shoulder, elbow, first, second, target, sign = configurations[name]
    length1, length2 = math.hypot(*first), math.hypot(*second)
    distance = min(math.hypot(*target), length1 + length2 - 0.01)
    bend = sign * math.acos(max(-1.0, min(1.0,
        (distance*distance-length1*length1-length2*length2)/(2*length1*length2))))
    heading = math.atan2(target[1], target[0]) - math.atan2(
        length2*math.sin(bend), length1+length2*math.cos(bend))
    first_heading = math.atan2(first[1], first[0])
    second_heading = math.atan2(second[1], second[0])
    return {shoulder: heading-first_heading,
            elbow: bend+first_heading-second_heading, 19:0.0}


def normalized_protected_images(tree: ET.Element) -> list[bytes]:
    """Only the exact reviewed sleeve-fragment clip is an allowed Image delta."""
    images = []
    for source in tree.iter('Image'):
        if source.get('name','').startswith('r5_finger_image_'):continue
        node = copy.deepcopy(source)
        expected={'hand_r':('0:2110','0:59'),'hand_l':('0:2114','0:56')}
        if node.get('name') in expected and node.get('assetId')==expected[node.get('name')][0]:
            node.set('assetId',expected[node.get('name')][1])
        for child in list(node):
            if child.tag == 'ClippingShape' and child.get('name') == 'r5_hide_detached_sleeve_fragment':
                if node.get('name') != 'arm_l_upper' or child.attrib != {
                    'sourceId':'0:1740', 'name':'r5_hide_detached_sleeve_fragment'}:
                    raise AssertionError('Unexpected original-image modification')
                node.remove(child)
        original_positions={'arm_l_upper':('-14.526','27.4766',12.0,24.0),
                            'arm_r_upper':('2.5043','38.9766',-21.0,20.0)}
        if node.get('name') in original_positions:
            x,y,dx,dy=original_positions[node.get('name')]
            actual=(float(node.get('x')),float(node.get('y')))
            expected=(float(x)-dx,float(y)-dy)
            if actual!=(float(x),float(y)):
                if any(abs(a-b)>1e-6 for a,b in zip(actual,expected)):
                    raise AssertionError('Unreviewed sleeve image shift')
                node.set('x',x);node.set('y',y)
        images.append(ET.tostring(node))
    return images


def repair_visible_behaviour(art: ET.Element, machine: ET.Element) -> None:
    # Keep the original blink timeline untouched. A sleeping state selects the
    # original closed-lid geometry instead of repeatedly reopening the eyes.
    blink = machine.find("StateMachineLayer[@name='Blink']")
    awake = blink.find("AnimationState[@id='0:107']")
    asleep_clip = ET.SubElement(art,'LinearAnimation',loopValue='oneShot',fps='60',
        duration='1',name='r5_sleep_eyes_closed',id='0:1710')
    for target, prop, value in [(24,17,1),(25,17,1),(80,18,1),(85,18,1),(81,18,0),(86,18,0)]:
        single(asleep_clip,target,prop,value)
    sleep = ET.SubElement(blink,'AnimationState',animationId='0:1710',x='420',y='0',id='0:1711')
    condition(ET.SubElement(awake,'StateTransition',stateToId='0:1711',duration='180'),87,17)
    condition(ET.SubElement(sleep,'StateTransition',stateToId='0:107',duration='180'),87,17,equal=False)

    # The historical left upper-arm PNG contains a disconnected 420-pixel trim
    # fragment where the stationary orb previously concealed it. Clip only that
    # disconnected corner; retain the original PNG bytes and every primary-sleeve
    # pixel. Coordinate conversion is the original 86x106 image's centred origin.
    owner = art.find("Node[@name='follow_arm_l_upper']")
    image = owner.find("Image[@name='arm_l_upper']")
    if image is None or image.get('assetId') != '0:54':
        raise AssertionError('Unexpected approved sleeve source')
    shape = ET.SubElement(owner,'Shape',name='r5_sleeve_main_component',id='0:1740')
    outline = ET.SubElement(shape,'PointsPath',isClosed='true',name='r5_sleeve_clip')
    left, top = float(image.get('x'))-43, float(image.get('y'))-53
    for x,y in [(45,0),(86,0),(86,106),(0,106),(0,44),(45,44)]:
        ET.SubElement(outline,'StraightVertex',x=f'{left+x:.7f}',y=f'{top+y:.7f}')
    ET.SubElement(image,'ClippingShape',sourceId='0:1740',name='r5_hide_detached_sleeve_fragment')

    # Neutral resets both arms, not just the original right-arm core. This stops
    # a left-arm gesture leaking into the next idle or right-arm gesture.
    old_neutral = art.find("LinearAnimation[@name='action_none']")
    reset = copy.deepcopy(old_neutral)
    reset.set('id','0:1750');reset.set('name','r5_action_neutral_full')
    for target in (35,36,37):single(reset,target,15,0)
    art.append(reset)
    machine.find("StateMachineLayer[@name='Action']/AnimationState[@id='0:144']").set('animationId','0:1750')


def authored_action(art:ET.Element,code:int,name:str,ms:int)->ET.Element:
    duration=round(ms*60/1000)
    animation=ET.SubElement(art,'LinearAnimation',
        loopValue='oneShot',fps='60',duration=str(duration),
        name='action_r5_'+name.lower(),id=f'0:{1400+code}')
    pose=solve_pointing_pose(name) if name in {'POINT_LEFT','POINT_RIGHT','POINT_UP','POINT_DOWN'} else ACTION_POSES[name]
    for ident,angle in sorted(pose.items()):
        anticipated=max(2,round(duration*0.14))
        peak=max(anticipated+2,round(duration*0.35))
        hold=max(peak+1,round(duration*0.77))
        keyed(animation,ident,15,[
            (0,0),(anticipated,-0.12*angle),(peak,angle),
            (hold,angle if name.startswith('POINT_') else angle*0.90),(duration,0),
        ])
    return animation

def condition(transition:ET.Element,input_id:int,value:int,equal:bool=True)->None:
    ET.SubElement(transition,'TransitionNumberCondition',inputId=f'0:{input_id}',
                  opValue='equal' if equal else 'notEqual',value=str(value))

def state_transition(target: ET.Element, to_id: int, value: int)->None:
    trans=ET.SubElement(target,'StateTransition',stateToId=f'0:{to_id}',duration='250')
    condition(trans,87,value)

def action_transition(neutral:ET.Element,to_id:int,value:int)->None:
    trans=ET.SubElement(neutral,'StateTransition',stateToId=f'0:{to_id}',duration='100')
    condition(trans,95,value)

def generate(src:bytes,contract:dict,spec:dict)->tuple[bytes,dict]:
    if sha(src)!=EXPECTED_R4_SHA:
        raise ValueError('Original raster-core R4 scene changed; re-evaluate exact source')
    source=ET.fromstring(src);tree=copy.deepcopy(source)
    art=tree.find('Artboard');machine=art.find('StateMachine')
    origart=source.find('Artboard')
    assert art is not None and machine is not None and art.get('name')=='Van'
    original_inputs=get_inputs(source)
    expected=[i['name'] for i in contract['inputs']]+contract['triggers']
    if [x[1] for x in original_inputs]!=expected:raise ValueError('Canonical Rive input surface drift')
    states=list(contract['durable_states']);actions=list(contract['finite_actions'])
    if states!=list(STATE_POSES):raise ValueError('State codes and pose map order diverge')
    if set(actions)!=set(CORE_ACTIONS)|set(ACTION_POSES):raise ValueError('Action pose coverage incomplete')
    if len(states)!=18 or len(actions)!=14:raise ValueError('Unexpected canonical state/action dimensions')
    milliseconds={a['code']:a['duration_ms'] for a in spec['actions'].values()}
    for code,name in enumerate(actions,1):
        if spec['actions'][name]['code']!=code:raise ValueError('Action wire code drift')
        duration=int(spec['actions'][name]['duration_ms'])
        if not 600<=duration<=1800:raise ValueError('Canonical finite duration outside budget')
        if name in CORE_ACTIONS:
            resampled_core(art,code,name,duration)
        else:
            authored_action(art,code,name,duration)
    for code,name in enumerate(states):
        if name not in CORE_STATES:
            make_state(art,code,name)

    # All 18 durable states are reachable from every other state, not merely
    # animation entries that are never selected by runtime inputs.
    layer=machine.find("StateMachineLayer[@name='State']")
    if layer is None:raise ValueError('Original State layer missing')
    for child in list(layer):
        if child.tag=='AnimationState':
            for trans in list(child):
                if trans.tag=='StateTransition':child.remove(trans)
    nodes={}
    for code,name in enumerate(states):
        original=layer.find("AnimationState[@animationId='%s']"%{
            'IDLE':'0:114','LISTENING':'0:115',
            'THINKING':'0:116','SPEAKING':'0:117'
        }.get(name,'_'))
        if original is None:
            original=ET.SubElement(layer,'AnimationState',
                animationId=f'0:{1200+code}',x=str(140+code*85),y='320',
                id=f'0:{1300+code}')
        nodes[code]=original
    for code,entry in nodes.items():
        for next_code in range(18):
            if next_code!=code:
                state_transition(entry,int(nodes[next_code].get('id').split(':')[-1]),next_code)

    # Keep the old original R4 core animations byte-equivalent, but use canonical
    # retimed clips in the action state machine (rather than an untested
    # separate state machine or changing approved original core clips).
    actionlayer=machine.find("StateMachineLayer[@name='Action']")
    if actionlayer is None:raise ValueError('Original Action layer missing')
    entry=actionlayer.find('EntryState')
    if entry is None:raise ValueError('Original Action entry missing')
    neutral=actionlayer.find("AnimationState[@id='0:144']")
    if neutral is None:raise ValueError('Original neutral Action state missing')
    for child in list(actionlayer):
        if child.tag=='AnimationState' and child is not neutral:
            actionlayer.remove(child)
    for trans in list(neutral):
        if trans.tag=='StateTransition':neutral.remove(trans)
    trigger_map={
        'HELLO_WAVE':100,'ACK_NOD':97,'POINT_TARGET':96,
        'CELEBRATE':98,'CAUTION':99,'SHRUG':101,
        'PRESENT_CARD':102,'OPEN_PANEL':103,
    }
    for code,name in enumerate(actions,1):
        action_id=1600+code
        state=ET.SubElement(actionlayer,'AnimationState',
            animationId=f'0:{1400+code}',reset='true',
            x=str(120+code*65),y='340',id=f'0:{action_id}')
        action_transition(neutral,action_id,code)
        if name in trigger_map:
            # Legacy trigger-only playback has no nonzero action_code to clear.
            # Keep it on a distinct internal state so adding prompt code-clear
            # cancellation does not immediately cancel a standalone wave trigger.
            triggered=ET.SubElement(actionlayer,'AnimationState',
                animationId=f'0:{1400+code}',reset='true',
                x=str(120+code*65),y='540',id=f'0:{1800+code}')
            trans=ET.SubElement(neutral,'StateTransition',stateToId=f'0:{1800+code}',duration='80')
            ET.SubElement(trans,'TransitionTriggerCondition',inputId=f'0:{trigger_map[name]}')
            condition(trans,95,0)
            ET.SubElement(triggered,'StateTransition',stateToId='0:144',duration='80',
                enableExitTime='true',exitTimeIsPercetange='true',exitTime='100')
            for accepted in range(1,15):
                condition(ET.SubElement(triggered,'StateTransition',
                    stateToId=f'0:{1600+accepted}',duration='80'),95,accepted)
        # A clear is an explicit cancellation, not a request to wait for exitTime.
        # The local director already arbitrates priorities before changing the code.
        returning=ET.SubElement(state,'StateTransition',stateToId='0:144',duration='80')
        condition(returning,95,0)
        for accepted in range(1,15):
            if accepted!=code:
                condition(ET.SubElement(state,'StateTransition',
                    stateToId=f'0:{1600+accepted}',duration='80'),95,accepted)
        for operator,value in [('lessThan',0),('greaterThan',14)]:
            invalid=ET.SubElement(state,'StateTransition',stateToId='0:144',duration='80')
            ET.SubElement(invalid,'TransitionNumberCondition',inputId='0:95',
                opValue=operator,value=str(value))

    repair_visible_behaviour(art,machine)
    articulation = add_joint_underlaps(art)
    articulation.update(add_finger_rig(tree,art,keyed,single))
    articulation.update(add_live_pointing(art,machine,keyed,single))
    articulation.update(add_context_motion(art,machine,keyed,single))
    articulation.update(add_secondary_micro_motion(art,machine,keyed))
    articulation.update(add_natural_face(art,machine,keyed,single,states))
    # Original image bytes, placement, mesh and constraints remain; only one
    # explicitly checked clip removes detached sleeve trim.
    origimages=[ET.tostring(n) for n in source.findall('ImageAsset')]
    if origimages!=[ET.tostring(n) for n in tree.findall('ImageAsset') if not n.get('name','').startswith('r5_hand_')]:
        raise AssertionError('Raster asset identity changed')
    for tag in IMAGE_TAGS:
        original=normalized_protected_images(source) if tag=='Image' else [ET.tostring(n) for n in source.iter(tag)]
        current=normalized_protected_images(tree) if tag=='Image' else [ET.tostring(n) for n in tree.iter(tag) if not (tag=='TransformConstraint' and n.get('name','').startswith('r5_finger_follow_'))]
        if original!=current:raise AssertionError('Artwork/mesh/constraints were modified: '+tag)
    for name in UPSTREAM_TRACKS:
        a=origart.find("LinearAnimation[@name='%s']"%name)
        b=art.find("LinearAnimation[@name='%s']"%name)
        if ET.tostring(a)!=ET.tostring(b):raise AssertionError('Original core clip modified: '+name)
    if get_inputs(source)!=get_inputs(tree):raise AssertionError('Public input IDs/types modified')
    if len(machine.findall('StateMachineLayer'))!=8:raise AssertionError('Layer budget changed')
    ids=[n.get('id') for n in tree.iter() if n.get('id')]
    if len(ids)!=len(set(ids)):raise AssertionError('Rive ids not unique')
    for animation in art.findall("LinearAnimation"):
        if animation.get('name','').startswith('action_r5_'):
            if '0:41' in [o.get('objectId') for o in animation.findall('KeyedObject')]:
                raise AssertionError('Action commandeers orb home')
            if '0:42' in [o.get('objectId') for o in animation.findall('KeyedObject')]:
                raise AssertionError('Action commandeers orb motion')
    raw=ET.tostring(tree,encoding='utf-8',xml_declaration=True)+b'\n'
    receipt={
        'status':'R5_FULL_CATALOGUE_RASTER_SOURCE_CANDIDATE_UNADMITTED',
        'derived_from_r4_scene_sha256':EXPECTED_R4_SHA,
        'r5_scene_sha256':sha(raw),
        'image_assets_unchanged':True,
        'original_mesh_constraint_records_preserved':True,
        'additional_geometry_and_rig_changes':'four joint underlaps, rebased shoulder pivots, fourteen original-pixel glove partitions, twelve finger nodes, live arm IK and the complete sixteen-category micro-motion catalogue',
        'original_core_clips_unchanged':True,
        'public_input_triggers_unchanged':True,
        'state_count':18,'finite_action_count':14,
        'new_state_poses':14,'new_canonical_timed_action_clips':14,
        'head_and_brow_morphs':'pose offset channels (NOT M3 full facial review)',
        'finger_ik_and_real_point_target':'candidate: all five fingers per hand, twelve finger nodes and live two-bone arm IK; native/S24 qualification outstanding',
        'companion_orb_autonomous_cycle':'R4 original preserved',
        'raster_layer_identity':'original 38 images preserved by SHA256',
        'rive_layer_count':8,
        'native_android_status':'NOT_VERIFIED',
        'owner_gate_status':'M0–M5 UNCHANGED/NOT ACCEPTED',
        'production_admissible':False,
        'visual_repair_revision':2,
        'numeric_action_clear_transition_ms':80,
        'legacy_trigger_one_shots_preserved':True,
        'directional_arm_solution':'measured original two-bone endpoint angles; not finger IK',
        'sleep_eyelids':'state-selected original closed-eye geometry',
        'sleeve_artifact_fix':'explicit clip; original 38 PNG bytes unchanged',
        'neutral_left_arm_reset':True,
        **articulation,
    }
    return raw,receipt

def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    out=args.output.resolve()
    if BASE.resolve() not in out.parents or out.exists():
        raise SystemExit('Create-only R5 prototype inside original mechanics lineage required; cannot promote production asset')
    intake=json.loads((R4/'source-receipt.json').read_text())
    if intake.get('scene_sha256')!=EXPECTED_R4_SHA:raise ValueError('R4 receipt changed')
    for rel,expected in intake.get('image_sha256',{}).items():
        p=Path(rel)
        if p.is_absolute() or '..' in p.parts or sha((R4/p).read_bytes())!=expected:
            raise ValueError('R4 art provenance mismatch: '+rel)
    scene,receipt=generate((R4/'scene.rml').read_bytes(),
                            json.loads(CONTRACT.read_text()),yaml.safe_load(ACTIONS.read_text()))
    out.mkdir(parents=True)
    (out/'layers').mkdir()
    for rel in intake['image_sha256']:
        shutil.copyfile(R4/rel,out/rel)
    receipt['derived_finger_assets']=write_articulation_assets(R4/'layers',out/'layers')
    receipt['image_sha256']={
        path:sha((out/path).read_bytes()) for path in sorted(intake['image_sha256'])
    }
    (out/'scene.rml').write_bytes(scene)
    (out/'rive.yaml').write_text('name: van_raster_full_r5_unadmitted\nentry: scene.rml\n')
    (out/'source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
    return 0

if __name__=='__main__':raise SystemExit(main())
