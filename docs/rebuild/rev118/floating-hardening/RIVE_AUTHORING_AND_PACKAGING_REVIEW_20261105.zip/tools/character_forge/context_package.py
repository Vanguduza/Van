"""Optional hash-bound contextual motion metadata for the original Forge workflow.

No function in this module admits artwork, qualifies a device or bypasses a gate.
The original fourteen action codes are never changed. Missing metadata is legacy.
"""
from __future__ import annotations
import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

SCHEMA = 'van.character.context/1'
MAX_BYTES = 16_384
MAX_RIVE_BYTES = 8 * 1_024 * 1_024
# Same stable optional extension as VanContextGesture.kt. A contract test binds
# every tuple to the native declaration so the two implementations cannot drift.
GESTURES = (
    (15,'EXPLAIN_OPEN_PALMS',1400,2), (16,'COMPARE_OPTIONS',1800,2),
    (17,'THINK_CHIN',1500,2), (18,'INSPECT_TARGET',1300,7),
    (19,'LISTEN_EMPHASIS',1000,2), (20,'POLITE_REFUSAL',1100,11),
    (21,'ACKNOWLEDGE_ERROR',1200,9), (22,'YIELD_TO_INTERRUPTION',650,14),
    (23,'REQUEST_CLARIFICATION',1300,9), (24,'HANDOFF_RESULT',1500,12),
    (25,'RECOVERY_READY',1000,10), (26,'GUIDE_NEXT_STEP',1500,7),
)


def _unique(pairs):
    result = {}
    for name,value in pairs:
        if name in result: raise ValueError('duplicate metadata property: '+name)
        result[name] = value
    return result


def validate_metadata(data: bytes, rive_sha256: str) -> dict[str, Any]:
    if not 0 < len(data) <= MAX_BYTES: raise ValueError('context metadata exceeds its byte bound or is empty')
    try: value=json.loads(data.decode('utf-8'),object_pairs_hook=_unique,
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError('nonfinite JSON value')))
    except (UnicodeError,json.JSONDecodeError,RecursionError) as exc: raise ValueError('invalid context JSON') from exc
    if not isinstance(value,dict) or value.get('schema')!=SCHEMA: raise ValueError('unknown context schema')
    if value.get('asset_sha256')!=rive_sha256: raise ValueError('context manifest is not bound to the exact Rive binary')
    rows=value.get('gestures')
    if not isinstance(rows,list) or len(rows)!=len(GESTURES): raise ValueError('all twelve context gestures are required')
    expected={row[0]:row for row in GESTURES};seen=set()
    for row in rows:
        if not isinstance(row,dict): raise ValueError('gesture record must be an object')
        for key in ('code','duration_ms','legacy_action'):
            if type(row.get(key)) is not int: raise ValueError('context '+key+' must be an integer')
        code=row['code'];actual=(code,row.get('name'),row['duration_ms'],row['legacy_action'])
        if code in seen or expected.get(code)!=actual: raise ValueError('unsupported, duplicate or changed context gesture')
        seen.add(code)
    return value


def _bounded_read(path: Path) -> bytes:
    if path.is_symlink() or not path.is_file(): raise ValueError('context metadata must be a real file')
    with path.open('rb') as source:data=source.read(MAX_BYTES+1)
    if len(data)>MAX_BYTES:raise ValueError('context metadata exceeds its byte bound')
    return data


def _rive_bytes(candidate: Path) -> bytes:
    if candidate.is_symlink() or not candidate.is_file():raise ValueError('Rive candidate must be a real file')
    with candidate.open('rb') as source:data=source.read(MAX_RIVE_BYTES+1)
    if len(data)>MAX_RIVE_BYTES:raise ValueError('Rive candidate exceeds native memory limit')
    return data


def receipt_fields(candidate: Path, metadata: Path | None, root: Path, allowed_root: Path) -> dict:
    if metadata is None: return {}
    # Resolve only inside the existing working area; do not follow a substituted
    # leaf symlink or adopt an unreceipted adjacent file automatically.
    if metadata.is_symlink():raise ValueError('context metadata symlink refused')
    metadata=metadata.resolve()
    try:metadata.relative_to(allowed_root.resolve());relative=metadata.relative_to(root.resolve()).as_posix()
    except ValueError as exc:raise ValueError('context metadata must remain under the original Rive working area') from exc
    data=_bounded_read(metadata)
    validate_metadata(data,hashlib.sha256(_rive_bytes(candidate)).hexdigest())
    return {'context_metadata_path':relative,'context_metadata_sha256':hashlib.sha256(data).hexdigest(),
            'context_metadata_bytes':len(data),'context_schema':SCHEMA}


def receipted_metadata(candidate: Path, receipt: dict, root: Path, allowed_root: Path) -> bytes | None:
    keys=('context_metadata_path','context_metadata_sha256','context_metadata_bytes','context_schema')
    present=[k for k in keys if receipt.get(k) is not None]
    if not present:return None
    if len(present)!=len(keys):raise ValueError('incomplete context packaging receipt')
    relative=receipt['context_metadata_path']
    if not isinstance(relative,str) or Path(relative).is_absolute() or '..' in Path(relative).parts:
        raise ValueError('invalid context receipt path')
    path=root/relative
    observed=receipt_fields(candidate,path,root,allowed_root)
    if any(observed[k]!=receipt[k] for k in keys):raise ValueError('context metadata changed after export receipt')
    data=_bounded_read(path)
    if hashlib.sha256(data).hexdigest()!=receipt['context_metadata_sha256'] or len(data)!=receipt['context_metadata_bytes']:
        raise ValueError('context metadata changed while reading packaging receipt')
    validate_metadata(data,hashlib.sha256(_rive_bytes(candidate)).hexdigest())
    return data


def metadata_sha(data: bytes | None) -> str | None:
    return hashlib.sha256(data).hexdigest() if data is not None else None


def package_matches(binary: Path, sidecar: Path, binary_sha: str, metadata: bytes | None) -> bool:
    if binary.is_symlink() or not binary.is_file() or hashlib.sha256(binary.read_bytes()).hexdigest()!=binary_sha:return False
    if metadata is None:return not sidecar.exists() and not sidecar.is_symlink()
    return not sidecar.is_symlink() and sidecar.is_file() and sidecar.read_bytes()==metadata


def install_pair(candidate: Path, binary: Path, sidecar: Path, metadata: bytes | None, *, expected_binary_sha: str | None = None) -> None:
    """Same-directory atomic files, safe even if interrupted between replacements.

    A new sidecar is installed last; readers bind it to the loaded binary SHA.
    Legacy staging explicitly removes a previously staged extension. The caller
    alone is responsible for the original receipt and admission gates.
    """
    raw=_rive_bytes(candidate);digest=hashlib.sha256(raw).hexdigest()
    if expected_binary_sha is not None and digest!=expected_binary_sha:raise ValueError('Rive candidate changed after package validation')
    if metadata is not None:validate_metadata(metadata,digest)
    if binary.parent.resolve()!=sidecar.parent.resolve():raise ValueError('binary and sidecar must share a package directory')
    if binary.is_symlink() or sidecar.is_symlink():raise ValueError('package target symlink refused')
    binary.parent.mkdir(parents=True,exist_ok=True)
    pending=[]
    try:
        def prepare(data):
            descriptor,name=tempfile.mkstemp(prefix='.van-package-',dir=binary.parent)
            path=Path(name);pending.append(path)
            with os.fdopen(descriptor,'wb') as target:target.write(data);target.flush();os.fsync(target.fileno())
            return path
        temp_binary=prepare(raw);temp_sidecar=prepare(metadata) if metadata is not None else None
        # Remove the previous capability first; interrupted writes are legacy,
        # never an old capability attached to the wrong binary.
        sidecar.unlink(missing_ok=True)
        os.replace(temp_binary,binary)
        if temp_sidecar is not None:os.replace(temp_sidecar,sidecar)
        if not package_matches(binary,sidecar,digest,metadata):raise OSError('Rive package readback mismatch')
    finally:
        for path in pending:path.unlink(missing_ok=True)
