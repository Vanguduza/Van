"""Optional, explicit-version contextual motion extension to the existing rig.

Original 18 states, 14 actions, nine inputs and eight triggers stay intact.
Codes15-26 are emitted only when a hash-bound renderer capability record permits
this extension; an old character receives the mapped original finite action.
"""
from __future__ import annotations
import copy,math
import xml.etree.ElementTree as ET
try:
    from .rig_articulation_r5 import finger_node_ids
except ImportError:
    from rig_articulation_r5 import finger_node_ids


CONTEXT_GESTURES = [
 (15,'EXPLAIN_OPEN_PALMS',1400,2),
 (16,'COMPARE_OPTIONS',1800,2),
 (17,'THINK_CHIN',1500,2),
 (18,'INSPECT_TARGET',1300,7),
 (19,'LISTEN_EMPHASIS',1000,2),
 (20,'POLITE_REFUSAL',1100,11),
 (21,'ACKNOWLEDGE_ERROR',1200,9),
 (22,'YIELD_TO_INTERRUPTION',650,14),
 (23,'REQUEST_CLARIFICATION',1300,9),
 (24,'HANDOFF_RESULT',1500,12),
 (25,'RECOVERY_READY',1000,10),
 (26,'GUIDE_NEXT_STEP',1500,7),
]
POSES={
 15:{35:.25,36:.40,38:-.45,39:-.30,19:.025},
 16:{35:.40,36:.50,38:-.55,39:-.42},
 17:{38:-1.60,39:-1.20,40:.32,19:-.035},
 18:{19:.07,38:-.40,39:-.30},
 19:{19:.055,38:-.50,39:-.68,40:.15},
 20:{19:.11,35:.15,38:-.12},
 21:{19:.10,35:-.10,38:.10},
 22:{19:-.025,38:-.40,39:-.22,40:.15},
 23:{35:.30,36:.50,38:-.25,19:-.045},
 24:{38:-.78,39:-.82,40:.36,19:.035},
 25:{19:.08,35:.18,38:-.20},
 26:{19:.035,38:-.50,39:-.40},
}

def add_context_motion(art,machine,keyed,single):
    layer=machine.find("StateMachineLayer[@name='Action']")
    neutral=layer.find("AnimationState[@id='0:144']")
    original_states=list(layer.findall('AnimationState'))
    for code,name,duration_ms,fallback in CONTEXT_GESTURES:
        frames=round(duration_ms*60/1000)
        clip=ET.SubElement(art,'LinearAnimation',id=f'0:{2300+code}',name='context_'+name.lower(),
                          fps='60',duration=str(frames),loopValue='oneShot')
        for target,angle in POSES[code].items():
            timeline=[(0,0),(round(frames*.16),-angle*.1),(round(frames*.38),angle),
                      (round(frames*.75),angle*.9),(frames,0)]
            if code==20 and target==19:
                timeline=[(0,0),(round(frames*.25),-.11),(round(frames*.50),.11),(round(frames*.72),-.07),(frames,0)]
            if code==16:
                left=target in (35,36)
                timeline=[(0,0),(round(frames*.23),angle if left else 0),
                          (round(frames*.48),angle*.15),(round(frames*.70),0 if left else angle),(frames,0)]
            keyed(clip,target,15,timeline)
        for ident in finger_node_ids():
            rotation=(-.65 if ident in (2002,2006) else .10) if code in (18,26) else (-.15 if ident in (2003,2007) else -.06)
            keyed(clip,ident,15,[(0,0),(round(frames*.35),rotation),(round(frames*.8),rotation),(frames,0)])
        for ident in (2232,2233):
            if code in (18,26):keyed(clip,ident,172,[(0,0),(round(frames*.20),1),(round(frames*.82),1),(frames,0)])
            else:single(clip,ident,172,0)
        state=ET.SubElement(layer,'AnimationState',id=f'0:{2400+code}',animationId=f'0:{2300+code}',reset='true',x=str(code*80),y='760')
        transition=ET.SubElement(neutral,'StateTransition',stateToId=state.get('id'),duration='80')
        ET.SubElement(transition,'TransitionNumberCondition',inputId='0:95',opValue='equal',value=str(code))
    all_states=list(layer.findall('AnimationState'))
    def destination(code):return '0:'+str(1600+code if code<=14 else 2400+code)
    for state in all_states:
        ident=int(state.get('id').split(':')[-1])
        if ident==144:continue
        is_new=2415<=ident<=2426
        # Only invalidate genuinely unsupported codes. Old clients still emit 0..14.
        for transition in state.findall('StateTransition'):
            for condition in transition.findall('TransitionNumberCondition'):
                if condition.get('inputId')=='0:95' and condition.get('opValue')=='greaterThan' and condition.get('value')=='14':
                    condition.set('value','26')
        if is_new:
            clear=ET.SubElement(state,'StateTransition',stateToId='0:144',duration='80')
            ET.SubElement(clear,'TransitionNumberCondition',inputId='0:95',opValue='equal',value='0')
            for op,value in [('lessThan',0),('greaterThan',26)]:
                invalid=ET.SubElement(state,'StateTransition',stateToId='0:144',duration='80')
                ET.SubElement(invalid,'TransitionNumberCondition',inputId='0:95',opValue=op,value=str(value))
        desired=range(1,27) if is_new else range(15,27)
        for code in desired:
            if state.get('id')==destination(code):continue
            transition=ET.SubElement(state,'StateTransition',stateToId=destination(code),duration='80')
            ET.SubElement(transition,'TransitionNumberCondition',inputId='0:95',opValue='equal',value=str(code))
    return {'context_extension_schema':'van.character.context/1',
            'context_gestures':[{'code':c,'name':n,'duration_ms':d,'legacy_action':f} for c,n,d,f in CONTEXT_GESTURES],
            'context_artwork_status':'new candidate gesture poses require motion review; no owner acceptance'}


def add_secondary_micro_motion(art,machine,keyed):
    # Parent transforms give breathing/secondary motion separate property ownership
    # from durable poses, eye gaze, speech, arm actions and the independent orb.
    channels=[
        ('head_settle',18,15,.009,3,0),
        ('left_shoulder_settle',35,15,.007,2,.4),
        ('right_shoulder_settle',38,15,-.007,2,.8),
        ('left_brow_life',30,14,.40,4,.2),
        ('right_brow_life',31,14,.35,4,.5),
    ]
    ids=[]
    for index,(name,target,prop,amplitude,cycles,phase) in enumerate(channels):
        node=art.find(".//Node[@id='0:%d']"%target)
        parent=next(p for p in art.iter() if node in list(p))
        wrapper=ET.Element('Node',name='r5_micro_'+name,id='0:'+str(2500+index))
        if target in (35,38):
            wrapper.set('x',node.get('x','0'));wrapper.set('y',node.get('y','0'));node.set('x','0');node.set('y','0')
        at=list(parent).index(node);parent.remove(node);wrapper.append(node);parent.insert(at,wrapper)
        ids.append((2500+index,prop,amplitude,cycles,phase))
    original=art.find("LinearAnimation[@name='idle_breathe']")
    clip=copy.deepcopy(original);clip.set('id','0:2510');clip.set('name','r5_ambient_and_micro')
    total=int(clip.get('duration'))
    for ident,prop,amplitude,cycles,phase in ids:
        values=[]
        for f in range(0,total+1,6):
            t=f/total
            # Seamless exact-zero boundary keeps constructor/first-frame neutral.
            v=amplitude*math.sin(2*math.pi*cycles*t+phase)*math.sin(math.pi*t)**2
            values.append((f,v))
        if values[-1][0]!=total:values.append((total,0))
        keyed(clip,ident,prop,values)
    art.append(clip)
    machine.find("StateMachineLayer[@name='Breathe']/AnimationState").set('animationId','0:2510')
    return {'additional_micro_motion_channels':[x[0] for x in channels],
            'micro_motion_layer_budget_unchanged':True,'original_ambient_orb_clip_preserved':True}
