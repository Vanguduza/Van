"""Preserve the recovered, historically accepted raster artwork and refine core motion.

This source-derived candidate never grants M2 owner acceptance or promotes van.riv.
All source PNG bytes, meshes, constraints, public inputs and core gestures are preserved.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

EXPECTED_SCENE = '985129dab4a30cd0c0797527a3969884df3d559fdb8c9f68295dd20dd11d552d'
PERIOD_FRAMES = 1422


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def smooth(value: float) -> float:
    x=max(0.0,min(1.0,value))
    return x*x*(3-2*x)


def orbit(phase: float) -> tuple[float,float,float]:
    if not math.isfinite(phase):raise ValueError('Invalid authoring phase')
    p=max(0.0,min(1.0,phase))
    if .20<=p<.41:
        t=smooth((p-.20)/.21)
        return 290*t,-68*math.sin(math.pi*t),2*math.pi*smooth(p)
    if .69<=p<.90:
        t=smooth((p-.69)/.21)
        return 290*(1-t),-68*math.sin(math.pi*t),2*math.pi*smooth(p)
    right=.41<=p<.69
    a,b=(.41,.69) if right else ((0,.20) if p<.20 else (.90,1))
    t=(p-a)/(b-a)
    return (290.0 if right else 0.0),4*math.sin(math.pi*t)**2*math.sin(2*math.pi*t),2*math.pi*smooth(p)


def channel(animation: ET.Element, identifier: str, property_key: int, values: list[tuple[int,float]]) -> None:
    obj=ET.SubElement(animation,'KeyedObject',objectId=identifier)
    prop=ET.SubElement(obj,'KeyedProperty',propertyKey=str(property_key))
    for frame,value in values:
        ET.SubElement(prop,'KeyFrameDouble',frame=str(frame),value=f'{value:.9f}',interpolationType='linear')


def refine(source: bytes) -> tuple[bytes,dict]:
    if hashlib.sha256(source).hexdigest()!=EXPECTED_SCENE:
        raise ValueError('Recovered core source hash differs; reconcile before modifying')
    tree=ET.fromstring(source);art=tree.find('Artboard')
    if art is None or art.get('name')!='Van':raise ValueError('Original artboard missing')
    machine=art.find('StateMachine')
    wire=[(n.tag,sorted(n.attrib.items())) for n in machine if n.tag!='StateMachineLayer']
    assets=[dict(n.attrib) for n in tree.findall('ImageAsset')]
    body=art.find('Node[@id="0:14"]');home=body.find('Node[@id="0:41"]')
    if home is None:raise ValueError('Unexpected orb parent')
    original_home=(float(body.get('x'))+float(home.get('x')),float(body.get('y'))+float(home.get('y')))
    body.remove(home);home.set('x',f'{original_home[0]:.7f}');home.set('y',f'{original_home[1]:.7f}')
    art.insert(list(art).index(body)+1,home)
    # Keep exactly one shell and core. Rear depth is explicit and never crosses
    # in front of the owner's face; at each flank it is visible independently.
    follows=[art.find('Node[@name="follow_orb_core"]'),art.find('Node[@name="follow_orb_shell"]')]
    for n in follows:
        if n is None:raise ValueError('Orb image owner missing')
        art.remove(n)
    index=list(art).index(body)
    for n in follows:art.insert(index,n);index+=1
    # Durable poses may still look at the companion but cannot move its home.
    for animation in art.findall('LinearAnimation'):
        if animation.get('name')=='idle_breathe':continue
        for obj in list(animation):
            if obj.get('objectId') in {'0:41','0:42'}:animation.remove(obj)
    ambient=art.find('LinearAnimation[@name="idle_breathe"]')
    if ambient is None:raise ValueError('Existing ambient owner missing')
    for n in list(ambient):ambient.remove(n)
    ambient.set('duration',str(PERIOD_FRAMES))
    frames=sorted(set(range(0,PERIOD_FRAMES+1,6))|{284,583,981,1280,PERIOD_FRAMES})
    # Separate channel frequencies in the existing Breathe layer retain the
    # eight-layer budget and prevent motion resetting when state/action changes.
    torso=[(f,1+.012*(.5-.5*math.cos(12*math.pi*f/PERIOD_FRAMES))) for f in frames]
    head=[(f,-45.0087-.6*(.5-.5*math.cos(12*math.pi*f/PERIOD_FRAMES))) for f in frames]
    channel(ambient,'0:16',17,torso);channel(ambient,'0:17',14,head)
    channel(ambient,'0:14',13,[(f,296.5+1.2*math.sin(4*math.pi*f/PERIOD_FRAMES)) for f in frames])
    channel(ambient,'0:14',14,[(f,366.474+1.7*math.sin(6*math.pi*f/PERIOD_FRAMES)) for f in frames])
    positions=[(f,orbit(f/PERIOD_FRAMES)) for f in frames]
    for prop,axis in [(13,0),(14,1),(15,2)]:channel(ambient,'0:42',prop,[(f,v[axis]) for f,v in positions])
    assert assets==[dict(n.attrib) for n in tree.findall('ImageAsset')]
    assert wire==[(n.tag,sorted(n.attrib.items())) for n in machine if n.tag!='StateMachineLayer']
    assert len(machine.findall('StateMachineLayer'))==8
    original=ET.fromstring(source)
    for tag in ['Image','Mesh','Skin','Weight','TransformConstraint']:
        before=sorted(ET.tostring(n,encoding='unicode').strip() for n in original.iter(tag))
        after=sorted(ET.tostring(n,encoding='unicode').strip() for n in tree.iter(tag))
        assert before==after,f'{tag} visual geometry changed'
    for name in ['blink','action_hello_wave','action_hello_wave_hold','action_ack_nod','action_ack_nod_hold','action_point_target','action_point_target_hold']:
        assert ET.tostring(original.find(f'.//LinearAnimation[@name="{name}"]'))==ET.tostring(tree.find(f'.//LinearAnimation[@name="{name}"]')),name
    output=ET.tostring(tree,encoding='utf-8',xml_declaration=True)+b'\n'
    report={'status':'RECOVERED_RASTER_CORE_MOTION_CANDIDATE','parent_scene_sha256':EXPECTED_SCENE,'scene_sha256':hashlib.sha256(output).hexdigest(),'historical_source_riv_sha256':'597e63d8993f30a4ee51729435e8d72de2bdabb90b66dc6e3e9194c04c1307a3','original_core_actions_unchanged':True,'original_blink_unchanged':True,'image_mesh_and_constraint_geometry_unchanged':True,'public_contract_unchanged':True,'layer_count':8,'orb_home_absolute':original_home,'orbit_seconds':PERIOD_FRAMES/60,'actual_state_coverage':'original four-state core only; M3 remains open','actual_action_coverage':'original wave/nod/point-target core only; full catalogue remains open','owner_core_verdict':'NOT_RECORDED_FOR_THIS_NEW_CANDIDATE','android_native_validation':'NOT_RUN_FOR_THIS_NEW_CANDIDATE','physical_device_qualified':False,'production_asset_promoted':False}
    return output,report


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-project',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[2]
    lineage=(root/'visual-authority/character-forge/08-prototypes/candidate-b-mechanics').resolve()
    if lineage not in a.output.resolve().parents or a.output.exists():raise SystemExit('Create-only candidate output in original mechanics lineage required; no production promotion')
    intake=json.loads((a.source_project/'INTAKE_RECEIPT.json').read_text())
    for name,expected in intake['files'].items():
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts:raise ValueError('Unsafe intake path')
        if digest(a.source_project/rel)!=expected:raise ValueError('Intake hash mismatch '+name)
    output,receipt=refine((a.source_project/'scene.rml').read_bytes())
    a.output.mkdir(parents=True)
    for image in ET.fromstring(output).findall('ImageAsset'):
        rel=Path(image.get('file'));target=a.output/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(a.source_project/rel,target)
    (a.output/'scene.rml').write_bytes(output)
    (a.output/'rive.yaml').write_text('name: van_raster_core_motion_r4\nentry: scene.rml\n')
    receipt['image_sha256']={str(v.relative_to(a.output)):digest(v) for v in sorted((a.output/'layers').glob('*.png'))}
    (a.output/'source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
    return 0

if __name__=='__main__':raise SystemExit(main())
