import fs from 'node:fs/promises';import assert from 'node:assert/strict';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {createRuntime,loadBinary,Scene} from './rive_host.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const [fileArg,outputArg]=process.argv.slice(2);
if(!fileArg||!outputArg)throw new Error('Usage: node behavior_suite.mjs <candidate.riv> <new-result.json>');
const file=path.resolve(fileArg),output=path.resolve(outputArg);
const parent=await fs.realpath(path.dirname(output));
if(parent===root||!parent.startsWith(root+path.sep)||!/(\.git|receipts|evidence)/.test(parent))throw new Error('Evidence output must be inside a repository evidence or working area');
await fs.access(output).then(()=>{throw new Error('Refusing existing receipt')},e=>{if(e.code!=='ENOENT')throw e;});
const contract=JSON.parse(await fs.readFile(root+'/visual-authority/rive_contract.json','utf8'));
const rt=await createRuntime();const loaded=await loadBinary(rt,file);const cases=[];
function test(name,body) {try{body();cases.push({name,passed:true});}catch(e){cases.push({name,passed:false,error:String(e)});console.error('FAIL',name,e.message);}}
function withScene(fn){let s=new Scene(rt,loaded.file);try{fn(s);}finally{s.close();}}
const core=Object.fromEntries(Object.keys(contract.durable_states).map(name=>[name,'r5_expression_'+name.toLowerCase()]));
const times=[1400,650,1200,1200,1200,1200,1200,1800,1000,900,1100,1500,700,700];
try {
 test('exact public 9-input and 8-trigger surface',()=>withScene(s=>assert.deepEqual(Object.keys(s.inputs).sort(),[...contract.inputs.map(i=>i.name),...contract.triggers].sort())));
 for(const [code,name]of Object.keys(contract.durable_states).entries()) {
  test('actual state route '+name,()=>withScene(s=>{
   s.set({state:code});s.step(60);let result=s.draw();assert(result.metrics.visiblePixels>70000);
   if(code!==2)assert(s.events.includes(core[name]??('state_r5_'+name.toLowerCase())),JSON.stringify(s.events));
  }));
 }
 for(const [index,name]of Object.keys(contract.finite_actions).entries()) {
  test('actual gesture and 100ms clear '+name,()=>withScene(s=>{
   s.set({state:2,action_code:0});s.step(20);s.set({action_code:index+1});s.step(Math.round(times[index]*0.6*60/1000));
   assert(s.events.includes('action_r5_'+name.toLowerCase()) || (name==='POINT_TARGET' && s.events.includes('r5_point_without_target')),JSON.stringify(s.events));assert(s.draw().metrics.visiblePixels>60000);
   s.set({action_code:0});s.step(6);let t=s.transforms();
   for(let key of ['rig_shoulder_l','rig_elbow_l','rig_shoulder_r','rig_elbow_r','rig_nod'])assert(Math.abs(t[key].rotation)<0.05,key+' '+t[key].rotation);
  }));
 }
 test('standalone legacy wave trigger remains animated',()=>withScene(s=>{
  s.set({state:2,action_code:0});s.step(20);s.inputs.wave.fire();s.step(30);
  assert(s.events.includes('action_r5_hello_wave'));assert(s.transforms().rig_shoulder_r.rotation < -0.7);
  s.step(90);assert(Math.abs(s.transforms().rig_shoulder_r.rotation)<0.05);
 }));
 test('critical caution preempts an active wave',()=>withScene(s=>{
  s.set({state:2,action_code:1});s.step(25);s.set({state:16,action_code:9});s.step(6);assert(s.events.includes('action_r5_caution'));
 }));
 test('sleep closes eyes and waking restores blinking',()=>withScene(s=>{
  s.set({state:17});s.step(60);assert(Math.abs(s.transforms().rig_eyelid_l.scaleY-1)<0.01);assert(Math.abs(s.transforms().rig_eyelid_r.scaleY-1)<0.01);
  s.set({state:2});s.step(20);assert(s.transforms().rig_eyelid_l.scaleY<0.05);
 }));
 for(const [code,side,x,y]of [[3,'l',-79,3],[4,'r',106,7],[5,'r',32,-100],[6,'r',26,103]]) {
  test('actual endpoint for direction '+code,()=>withScene(s=>{
   s.set({state:2});s.step(20);s.set({action_code:code});s.step(43);let t=s.transforms(),a=t['rig_shoulder_'+side],b=t['rig_wrist_'+side];
   assert(Math.abs(b.tx-a.tx-x)<0.5);assert(Math.abs(b.ty-a.ty-y)<0.5);
  }));
 }
 test('orb makes full independent left-right-left circuit and rotation',()=>withScene(s=>{
  s.set({state:2});let first=s.transforms().rig_orb;s.step(711);let other=s.transforms().rig_orb;
  assert(other.tx-first.tx>289);assert(Math.abs(other.rotation-Math.PI)<0.02);
  s.step(711);let last=s.transforms().rig_orb;assert(Math.abs(last.tx-first.tx)<0.01);assert(Math.abs(last.rotation-2*Math.PI)<0.02);
 }));
 test('task and gesture changes do not reset companion orbit',()=>{
  let a=new Scene(rt,loaded.file),b=new Scene(rt,loaded.file);
  try{a.set({state:2});b.set({state:2});a.step(250);b.step(250);b.set({state:9,action_code:1});a.step(175);b.step(175);
   const x=a.transforms().rig_orb,y=b.transforms().rig_orb;assert(Math.abs(x.tx-y.tx)<0.001);assert(Math.abs(x.rotation-y.rotation)<0.0001);
  }finally{a.close();b.close();}
 });
 test('paused advancement draws a stable frame',()=>withScene(s=>{s.step(50);const a=s.draw().metrics.pixelDigest,b=s.draw().metrics.pixelDigest;assert.equal(a,b);}));
 for(const unknown of [-1,99])test('invalid action clears safely '+unknown,()=>withScene(s=>{s.set({state:2,action_code:1});s.step(30);s.set({action_code:unknown});s.step(6);assert(Math.abs(s.transforms().rig_shoulder_r.rotation)<0.05);}));
} finally {loaded.file.delete();}
const result={status:cases.every(t=>t.passed)?'BINARY_BEHAVIOUR_PASSED':'FAILED',candidateSha:loaded.sha256,renderer:'Official Rive Canvas2D WASM 2.49.4 with napi-rs Canvas host 1.1.0',nativeAndroid:false,deviceQualified:false,ownerAccepted:false,tests:cases.length,passed:cases.filter(t=>t.passed).length,cases};
await fs.writeFile(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({...result,cases:undefined}));if(result.passed!==result.tests)process.exitCode=1;
