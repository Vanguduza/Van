import fs from 'node:fs/promises';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
import {createRuntime,loadBinary,Scene,digest} from './rive_host.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const [binaryArg,outputArg]=process.argv.slice(2);if(!binaryArg||!outputArg)throw new Error('candidate and NEW evidence directory required');
const binary=path.resolve(binaryArg),output=path.resolve(outputArg);
if(!output.startsWith(root+path.sep)||!/(\.git|receipts|evidence)/.test(output))throw new Error('Repository evidence area required');
await fs.mkdir(output,{recursive:false});
const rt=await createRuntime(),loaded=await loadBinary(rt,binary),tests=[],captures=[];
const source=JSON.parse(await fs.readFile(path.join(path.dirname(path.dirname(binary)),'source-receipt.json'),'utf8'));
const contexts=source.context_gestures;assert.equal(contexts.length,12);
function check(name,fn){try{fn();tests.push({name,passed:true});}catch(e){tests.push({name,passed:false,error:String(e)});console.error('FAIL',name,e.message);}}
function withScene(fn){let s=new Scene(rt,loaded.file);try{fn(s);}finally{s.close();}}
function matrix(scene,name){const node=scene.board.node(name);assert(node,name+' missing');const m=node.worldTransform();return {x:m.tx,y:m.ty,xx:m.xx,xy:m.xy,yx:m.yx,yy:m.yy,rotation:node.rotation};}
function alphaAt(scene,x,y){const size=scene.canvas.width;if(x<0||y<0||x>=size||y>=size)return 0;return scene.canvas.getContext('2d').getImageData(Math.round(x),Math.round(y),1,1).data[3];}
function mainComponent(scene){
 const size=scene.canvas.width,data=scene.canvas.getContext('2d').getImageData(0,0,size,size).data;
 const seen=new Uint8Array(size*size),queue=new Int32Array(size*size);let start=300*size+296;
 assert(data[start*4+3]>32,'torso seed is transparent');let head=0,tail=1;queue[0]=start;seen[start]=1;
 while(head<tail){const n=queue[head++],x=n%size,y=(n/size)|0;
  for(const k of [n-1,n+1,n-size,n+size,n-size-1,n-size+1,n+size-1,n+size+1]){
   if(k<0||k>=seen.length||seen[k])continue;const xx=k%size,yy=(k/size)|0;if(Math.abs(xx-x)>1||Math.abs(yy-y)>1)continue;
   if(data[k*4+3]>32){seen[k]=1;queue[tail++]=k;}
  }
 }
 return (x,y)=>{for(let yy=Math.floor(y)-4;yy<=Math.ceil(y)+4;yy++)for(let xx=Math.floor(x)-4;xx<=Math.ceil(x)+4;xx++)if(xx>=0&&yy>=0&&xx<size&&yy<size&&seen[yy*size+xx])return true;return false;};
}
async function capture(scene,label){let d=scene.draw();await fs.writeFile(path.join(output,label+'.png'),d.png,{flag:'wx'});captures.push({label,...d.metrics,png_sha256:digest(d.png)});}
try {
 for(const side of ['l','r'])for(const part of ['index_prox','index_tip','thumb','middle','ring','little'])check('independent original-art finger '+part+' '+side,()=>withScene(s=>{
  s.set({state:2});s.step(20);let initial=matrix(s,'rig_'+part+'_'+side).rotation;s.set({action_code:4});s.step(43);let moved=matrix(s,'rig_'+part+'_'+side).rotation;
  assert(Math.abs(moved-initial)>.02,'finger did not articulate');s.set({action_code:0});s.step(6);assert(Math.abs(matrix(s,'rig_'+part+'_'+side).rotation)<.01,'finger did not reset');
 }));
 for(let i=0;i<16;i++)check('actual continuous IK direction '+i,()=>withScene(s=>{
  const angle=i*2*Math.PI/16,x=Math.cos(angle),y=Math.sin(angle);s.set({state:2,attention_x:x,attention_y:y});s.step(20);s.set({action_code:7});s.step(42);
  const a=matrix(s,'rig_shoulder_r'),w=matrix(s,'rig_wrist_r'),target=matrix(s,'r5_live_point_target');
  assert(Math.hypot(w.x-target.x,w.y-target.y)<.05,'wrist missed solver target');
  assert(Math.abs((target.x-a.x)-100*x)<.05,'nonlinear horizontal mapping');assert(Math.abs((target.y-a.y)-100*y)<.05,'nonlinear vertical mapping');
 }));
 check('retarget within one live pointing gesture without a new clip',()=>withScene(s=>{
  s.set({state:2,attention_x:1,attention_y:0});s.step(20);s.set({action_code:7});s.step(24);
  const before=s.events.filter(x=>x==='action_r5_point_target').length;
  for(const [x,y]of [[.6,-.8],[-.8,.6],[0,1]]){
   s.set({attention_x:x,attention_y:y});s.step(5);const w=matrix(s,'rig_wrist_r'),t=matrix(s,'r5_live_point_target');assert(Math.hypot(w.x-t.x,w.y-t.y)<.05);
  }
  assert.equal(before,s.events.filter(x=>x==='action_r5_point_target').length);
  s.set({action_code:0});s.step(6);assert(Math.abs(s.board.node('rig_elbow_r').rotation)<.01);
 }));
 const stateFor={15:9,16:3,17:5,18:6,19:4,20:13,21:14,22:4,23:11,24:15,25:3,26:3};
 for(const c of contexts){
  check('contextual clip and prompt reset '+c.name,()=>withScene(s=>{
   s.set({state:stateFor[c.code],attention_x:.8,attention_y:-.6,action_code:0});s.step(20);s.set({action_code:c.code});s.step(Math.round(c.duration_ms*.60*60/1000));
   assert(s.events.includes('context_'+c.name.toLowerCase()),JSON.stringify(s.events));assert(s.draw().metrics.visiblePixels>60000);
   s.set({action_code:0});s.step(6);for(const bone of ['rig_shoulder_l','rig_elbow_l','rig_shoulder_r','rig_elbow_r','rig_nod'])assert(Math.abs(s.board.node(bone).rotation)<.05,bone);
  }));
  let s=new Scene(rt,loaded.file);s.set({state:stateFor[c.code],attention_x:.8,attention_y:-.6});s.step(20);s.set({action_code:c.code});s.step(Math.round(c.duration_ms*.60*60/1000));await capture(s,'context-'+c.code+'-'+c.name);s.close();
 }
 for(const micro of source.additional_micro_motion_channels)check('independent micro channel '+micro,()=>withScene(s=>{
  s.set({state:2});let n=s.board.node('r5_micro_'+micro);assert(n);let a=n.rotation+n.y;s.step(173);assert(Math.abs(n.rotation+n.y-a)>1e-5);assert(!s.events.some(e=>e.startsWith('action_')));
 }));
 check('orb unchanged by contextual actions and new micro channels',()=>{
  let a=new Scene(rt,loaded.file),b=new Scene(rt,loaded.file);
  try{a.set({state:2});b.set({state:2});a.step(250);b.step(250);b.set({state:9,action_code:15});a.step(400);b.step(400);let x=matrix(a,'rig_orb'),y=matrix(b,'rig_orb');assert(Math.hypot(x.x-y.x,x.y-y.y)<.0001);assert(Math.abs(x.rotation-y.rotation)<.0001);}finally{a.close();b.close();}
 });
 const legacyMs=[1400,650,1200,1200,1200,1200,1200,1800,1000,900,1100,1500,700,700];
 let worst=0;
 for(let code=1;code<=26;code++){
  const duration=code<=14?legacyMs[code-1]:contexts.find(x=>x.code===code).duration_ms;
  for(const fraction of [.25,.45,.65,.8])check('connected shoulder/arm '+code+' @'+fraction,()=>withScene(s=>{
   s.set({state:2,attention_x:.8,attention_y:-.6});s.step(20);s.set({action_code:code});s.step(Math.round(duration*fraction*60/1000));s.draw();
   const connected=mainComponent(s);
   for(const bone of ['rig_shoulder_l','rig_elbow_l','rig_shoulder_r','rig_elbow_r','rig_wrist_l','rig_wrist_r']){
    const n=matrix(s,bone);assert(connected(n.x,n.y),bone+' disconnected from torso');
   }
  }));
 }
 for(const code of [3,4,5,8,17,26]){let s=new Scene(rt,loaded.file);s.set({state:2,attention_x:.8,attention_y:-.6});s.step(20);s.set({action_code:code});s.step(40);await capture(s,'joint-review-'+code);s.close();}
 const failed=tests.filter(t=>!t.passed);
 const result={status:failed.length?'FAILED':'ARTICULATION_BINARY_PASSED',candidateSha:loaded.sha256,tests:tests.length,passed:tests.length-failed.length,contexts:contexts.map(c=>c.code),captures,checks:tests,nativeAndroid:false,physicalS24:false,ownerAccepted:false};
 await fs.writeFile(path.join(output,'receipt.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,captures:captures.length,checks:undefined}));if(failed.length)process.exitCode=1;
} finally {loaded.file.delete();}
