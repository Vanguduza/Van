import fs from 'node:fs/promises';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
import {createRuntime,loadBinary,Scene} from './rive_host.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const [binaryArg,outputArg]=process.argv.slice(2);if(!binaryArg||!outputArg)throw new Error('candidate and NEW evidence directory required');
const output=path.resolve(outputArg);if(!output.startsWith(root+path.sep)||!/(\.git|receipts|evidence)/.test(output))throw new Error('Repository evidence path required');
await fs.mkdir(output,{recursive:false});const rt=await createRuntime(),loaded=await loadBinary(rt,path.resolve(binaryArg));const checks=[];
function test(name,fn){try{fn();checks.push({name,passed:true});}catch(e){checks.push({name,passed:false,error:String(e)});console.error('FAILED',name,e.message);}}
function using(fn){const s=new Scene(rt,loaded.file);try{fn(s)}finally{s.close();}}
const node=(s,name)=>{const v=s.board.node(name);assert(v,name);return v;};
try{
 let recordedPeaks=[];
 test('36-second natural blink contains single and two double-blink events',()=>using(s=>{
  s.set({state:2});let wasClosed=false;
  for(let frame=0;frame<=2160;frame++){
   if(frame)s.step(1);const closed=node(s,'rig_eyelid_l').scaleY>.9;
   if(closed&&!wasClosed)recordedPeaks.push(frame);wasClosed=closed;
   assert(Math.abs(node(s,'rig_eyelid_l').scaleY-node(s,'rig_eyelid_r').scaleY)<.001);
  }
  assert.equal(recordedPeaks.length,14,JSON.stringify(recordedPeaks));
  assert.equal(recordedPeaks.slice(1).filter((p,i)=>p-recordedPeaks[i]<30).length,2);
 }));
 test('sleep holds eyes shut throughout multiple natural blink cycles',()=>using(s=>{
  s.set({state:17});s.step(60);
  for(let i=0;i<50;i++){s.step(50);assert(node(s,'rig_eyelid_l').scaleY>.99);assert(node(s,'rig_eyelid_r').scaleY>.99);}
  s.set({state:2});s.step(20);assert(node(s,'rig_eyelid_l').scaleY<.05);
 }));
 for(const [name,x,y]of [['left',-1,0],['right',1,0],['up',0,-1],['down',0,1]]){
  test('head direction '+name+' follows gaze without a task/action',()=>using(s=>{
   s.set({state:2,attention_x:x,attention_y:y});s.step(50);
   assert(Math.abs(node(s,'r5_head_gaze_left_right').x-x*1.8)<.01);
   assert(Math.abs(node(s,'r5_head_gaze_up_down').y-y*1.3)<.01);
   s.set({attention_x:0,attention_y:0});s.step(10);
   assert(Math.abs(node(s,'r5_head_gaze_left_right').x)<.01);assert(Math.abs(node(s,'r5_head_gaze_up_down').y)<.01);
  }));
 }
 test('micro-saccades are paired and stay within authored small bounds',()=>using(s=>{
  s.set({state:2});let moving=0;
  for(let f=0;f<1422;f++){
   s.step(1);const a=node(s,'r5_eye_saccade_l'),b=node(s,'r5_eye_saccade_r');
   assert(Math.abs(a.x-b.x)<.001 && Math.abs(a.y-b.y)<.001);
   assert(Math.abs(a.x)<=.551 && Math.abs(a.y)<=.201);if(Math.abs(a.x)>.05)moving++;
  }
  assert(moving>=55&&moving<150,moving);
 }));
 test('soft smile belongs only to verified-success pose and clears on warning',()=>using(s=>{
  s.set({state:15});s.step(30);assert(node(s,'r5_soft_smile').scaleX>1.075);
  for(const code of [13,14,11,0,2,4,9]){s.set({state:code});s.step(30);assert(Math.abs(node(s,'r5_soft_smile').scaleX-1)<.001);}
 }));
 for(const side of ['l','r'])for(const finger of ['middle','ring','little'])test('separate '+side+' '+finger+' control returns to rest',()=>using(s=>{
  s.set({state:2,action_code:4});s.step(43);assert(Math.abs(node(s,'rig_'+finger+'_'+side).rotation)>.05);
  s.set({action_code:0});s.step(6);assert(Math.abs(node(s,'rig_'+finger+'_'+side).rotation)<.01);
 }));
 for(const [state,action]of [[2,1],[7,12],[9,2],[11,9],[13,9],[15,8],[3,16],[5,17],[9,15],[3,26]]){
  test('speech, gaze and action remain layered '+state+'/'+action,()=>using(s=>{
   s.set({state,action_code:action,speaking:true,mouth_open:.8,viseme:3,attention_x:.6,attention_y:-.8});s.step(30);
   const frame=s.draw();assert(frame.metrics.visiblePixels>60000);
   const mouth=node(s,'rig_mouth_open');const before=mouth.scaleY;
   s.set({mouth_open:.2,viseme:4});s.step(6);assert(Math.abs(mouth.scaleY-before)>.03,'mouth input did not reach rig');
   assert(node(s,'rig_orb').rotation>0);s.set({action_code:0});s.step(6);
  }));
 }
 const result={status:checks.every(c=>c.passed)?'NATURAL_MOTION_BINARY_PASSED':'FAILED',candidateSha:loaded.sha256,
   tests:checks.length,passed:checks.filter(c=>c.passed).length,blink_peaks:recordedPeaks,checks,
   measured_scope:'Original compiled Rive binary in official WASM runtime; Android interpolation and physical devices not claimed',physical_test:false};
 await fs.writeFile(path.join(output,'receipt.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,checks:undefined}));
 if(result.passed!==result.tests)process.exitCode=1;
}finally{loaded.file.delete();}
