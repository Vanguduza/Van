# Actual Rive binary validation (not Android acceptance)

This isolated tool runs the original compiled candidate through the official Rive Canvas2D WASM runtime, with native Canvas2D host bindings. It is not a fake state machine or a drawing reconstructed from RML. The app dependencies are not changed.

Use Node 22 or newer. Install locally with `npm ci --ignore-scripts --no-audit --no-fund` inside this directory. Then run from the repository root:

    node tools/character_forge/runtime_validation/behavior_suite.mjs PATH_TO_CANDIDATE.riv .git/NEW_BINARY_RECEIPT.json

The output is create-only. It never copies a candidate to production or debug Android assets. For a previously installed exact validator module directory, set VAN_RIVE_VALIDATION_MODULE_ROOT to that directory (the one containing package.json and node_modules). Package integrity is pinned in package-lock.json.

The 45 checks cover original public input/trigger identities, actual state and gesture selection, 100ms numeric cancellation, legacy standalone triggers, sleep/wake eyelids, real directional wrist endpoints, independent orbit across state changes, stable paused frames and unknown numeric actions. All render geometry is evaluated by the compiled binary. These checks do NOT establish physical Android timing, S24 frame/power budgets, final visual quality, owner acceptance, finger articulation or dynamic live target pointing.

Control: the execution record separately uses the official published vehicles.riv (SHA256 46bb250cde0b0223a15faddac33d08fa00d4b6acebc2e4e827391ae0113768a3). This control is never adopted into VAN artwork. Original image decode uses memory-backed blob data only; runtime CDN asset loading is disabled.
