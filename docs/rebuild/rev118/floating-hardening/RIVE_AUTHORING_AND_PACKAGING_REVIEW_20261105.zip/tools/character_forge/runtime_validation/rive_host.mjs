import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const moduleRoot=process.env.VAN_RIVE_VALIDATION_MODULE_ROOT;
const resolve=createRequire(moduleRoot?path.join(path.resolve(moduleRoot),'package.json'):import.meta.url);
const canvasKit=resolve('@napi-rs/canvas');
const {default:RiveFactory}=await import(pathToFileURL(resolve.resolve('@rive-app/canvas-advanced')).href);

// Host adapters only. All geometry/state transitions are evaluated by official Rive WASM.
// No browser sandbox, host service, production asset or device setting is changed.
for(const key of ['Path2D','DOMMatrix','ImageData']) if(canvasKit[key])globalThis[key]=canvasKit[key];
globalThis.Image=class extends canvasKit.Image {
 set src(value) {
  if(typeof value==='string'&&value.startsWith('blob:')) {
    fetch(value).then(r=>r.arrayBuffer()).then(buffer=>{super.src=Buffer.from(buffer);})
     .catch(error=>{console.error('PNG_DECODE_FAILED',error);this.onerror?.(error);});
  } else super.src=value;
 }
 get src(){return super.src;}
};
globalThis.OffscreenCanvas=class {constructor(w,h){return canvasKit.createCanvas(w,h);}};
globalThis.createImageBitmap=async blob=>canvasKit.loadImage(Buffer.from(await blob.arrayBuffer()));
globalThis.requestAnimationFrame=fn=>setTimeout(()=>fn(performance.now()),16);
globalThis.cancelAnimationFrame=id=>clearTimeout(id);
globalThis.document={createElement:tag=>{if(tag==='canvas')return canvasKit.createCanvas(593,593);throw new Error('Unexpected DOM '+tag);}};
globalThis.window=globalThis;
export const digest=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
export async function createRuntime() {
 const location=path.dirname(resolve.resolve('@rive-app/canvas-advanced'));
 return await RiveFactory({wasmBinary:new Uint8Array(await fs.readFile(location+'/rive.wasm')),locateFile:name=>path.join(location,name)});
}
export async function loadBinary(runtime,filename) {
 const bytes=await fs.readFile(filename);
 let timer;
 try {
  const file=await Promise.race([runtime.load(new Uint8Array(bytes),undefined,false),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Binary import timeout')),20000);})]);
  if(!file)throw new Error('Binary rejected '+filename);
  return {file,sha256:digest(bytes)};
 } finally {clearTimeout(timer);}
}
export class Scene {
 constructor(runtime,file,size=593) {
  this.runtime=runtime;this.board=file.defaultArtboard();this.canvas=canvasKit.createCanvas(size,size);
  this.renderer=runtime.makeRenderer(this.canvas);this.frames=0;this.events=[];
  this.machine=this.board.stateMachineCount()>0?new runtime.StateMachineInstance(this.board.stateMachineByIndex(0),this.board):null;
  this.machine?.advance(0);this.board.advance(0);
 this.inputs={};this.types={};
  if(this.machine)for(let i=0;i<this.machine.inputCount();i++) {
   const x=this.machine.input(i);this.types[x.name]=x.type;
   this.inputs[x.name]=x.type===runtime.SMIInput.number?x.asNumber():x.type===runtime.SMIInput.bool?x.asBool():x.asTrigger();
  }
 }
 set(values) {for(const [name,value]of Object.entries(values)){if(!this.inputs[name])throw new Error('Missing input '+name);this.inputs[name].value=value;}}
 step(frames) {
  for(let i=0;i<frames;i++){
   this.machine?.advance(1/60);this.board.advance(1/60);this.frames++;
   if(this.machine)for(let j=0;j<this.machine.stateChangedCount();j++)this.events.push(this.machine.stateChangedNameByIndex(j));
  }
 }
 transforms() {
  const result={};
  for(const name of ['rig_neck','rig_nod','rig_head','rig_brow_l','rig_brow_r','rig_shoulder_l','rig_elbow_l','rig_shoulder_r','rig_elbow_r','rig_wrist_l','rig_wrist_r','rig_eyelid_l','rig_eyelid_r','rig_orb','rig_body']) {
   const n=this.board.node(name);if(!n)continue;
   const m=n.worldTransform();result[name]={x:n.x,y:n.y,rotation:n.rotation,scaleX:n.scaleX,scaleY:n.scaleY,xx:m.xx,xy:m.xy,yx:m.yx,yy:m.yy,tx:m.tx,ty:m.ty};
  }
  return result;
 }
 draw() {
  const r=this.renderer,s=this.canvas.width;
  r.clear();r.save();r.align(this.runtime.Fit.contain,this.runtime.Alignment.center,{minX:0,minY:0,maxX:s,maxY:s},this.board.bounds);
  this.board.draw(r);r.restore();this.runtime.resolveAnimationFrame();
  const pixels=this.canvas.getContext('2d').getImageData(0,0,s,s).data;
  let opaque=0,minX=s,minY=s,maxX=-1,maxY=-1;
  for(let j=3;j<pixels.length;j+=4)if(pixels[j]>20){opaque++;const n=(j-3)/4,x=n%s,y=Math.floor(n/s);minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
  return {png:this.canvas.toBuffer('image/png'),metrics:{visiblePixels:opaque,pixelDigest:digest(pixels),bounds:[minX,minY,maxX,maxY],frames:this.frames,events:this.events.slice(-20),transforms:this.transforms()}};
 }
 close(){this.machine?.delete();this.renderer.delete();this.board.delete();}
}
