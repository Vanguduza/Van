"""R5 source-bound tests. Not native/device/owner gate evidence."""
import copy
import json
import unittest
import xml.etree.ElementTree as ET
import yaml
from tools.character_forge.extend_raster_full_r5 import (
    ACTION_POSES, ACTIONS, CONTRACT, CORE_ACTIONS, CORE_STATES,
    EXPECTED_R4_SHA, R4, STATE_POSES, UPSTREAM_TRACKS, generate, sha,
)

class RasterFullR5Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=(R4/'scene.rml').read_bytes()
        cls.contract=json.loads(CONTRACT.read_text())
        cls.spec=yaml.safe_load(ACTIONS.read_text())
        cls.output,cls.receipt=generate(cls.source,cls.contract,cls.spec)
        cls.root=ET.fromstring(cls.output)
        cls.art=cls.root.find('Artboard')
        cls.machine=cls.art.find('StateMachine')
        cls.prior=ET.fromstring(cls.source).find('Artboard')

    def test_exact_source_and_determinism(self):
        self.assertEqual(EXPECTED_R4_SHA,sha(self.source))
        self.assertEqual((self.output,self.receipt),generate(self.source,self.contract,self.spec))

    def test_mutation_and_contract_drift_fail_closed(self):
        with self.assertRaises(ValueError):generate(self.source+b' ',self.contract,self.spec)
        changed=copy.deepcopy(self.contract);changed['inputs'][0]['name']='BAD'
        with self.assertRaises(ValueError):generate(self.source,changed,self.spec)

    def test_all_18_states_are_reachable_from_any_other(self):
        layer=self.machine.find("StateMachineLayer[@name='State']")
        nodes=layer.findall('AnimationState')
        self.assertEqual(18,len(nodes))
        for node in nodes:
            destinations={t.get('stateToId') for t in node.findall('StateTransition')}
            self.assertEqual({n.get('id') for n in nodes if n is not node},destinations)
        self.assertEqual(18,len(self.contract['durable_states']))

    def test_all_14_actions_have_real_motion_and_exact_durations(self):
        self.assertEqual(14,len(self.contract['finite_actions']))
        for code,name in enumerate(self.contract['finite_actions'],1):
            an=self.art.find("LinearAnimation[@name='action_r5_%s']"%name.lower())
            self.assertIsNotNone(an,name)
            target=round(self.spec['actions'][name]['duration_ms']*60/1000)
            self.assertEqual(target,int(an.get('duration')),name)
            frames=an.findall('.//KeyFrameDouble')
            self.assertGreater(len(frames),2,name)
            self.assertTrue(any(abs(float(f.get('value','0')))>.00001 for f in frames),name)
            self.assertLessEqual(max(int(f.get('frame')) for f in frames),target,name)
            ids={obj.get('objectId') for obj in an.findall('KeyedObject')}
            self.assertFalse({'0:14','0:41','0:42'} & ids,name)

    def test_all_new_actions_end_at_neutral_pose(self):
        for name in ACTION_POSES:
            an=self.art.find("LinearAnimation[@name='action_r5_%s']"%name.lower())
            for keyed in an.findall('KeyedObject/KeyedProperty'):
                self.assertAlmostEqual(0,float(keyed.findall('KeyFrameDouble')[-1].get('value')),places=7)

    def test_original_action_clips_preserved_and_new_canonical_clips_distinct(self):
        for name in CORE_ACTIONS:
            original=CORE_ACTIONS[name]
            self.assertEqual(
                ET.tostring(self.prior.find("LinearAnimation[@name='%s']"%original)),
                ET.tostring(self.art.find("LinearAnimation[@name='%s']"%original)),name)
            self.assertIsNotNone(self.art.find("LinearAnimation[@name='action_r5_%s']"%name.lower()))

    def test_state_poses_not_empty_or_reused(self):
        poses=set()
        for name in STATE_POSES:
            if name in CORE_STATES:continue
            an=self.art.find("LinearAnimation[@name='state_r5_%s']"%name.lower())
            self.assertIsNotNone(an,name)
            keys=tuple((a.get('objectId'),p.get('propertyKey'),f.get('value'))
                for a in an.findall('KeyedObject')
                for p in a.findall('KeyedProperty') for f in p.findall('KeyFrameDouble'))
            self.assertGreaterEqual(len(keys),6,name)
            self.assertNotIn(keys,poses,name)
            poses.add(keys)
        self.assertEqual(14,len(poses))

    def test_runtime_action_code_reaches_all_14_clips(self):
        layer=self.machine.find("StateMachineLayer[@name='Action']")
        neutral=layer.find("AnimationState[@id='0:144']")
        clips=[n for n in layer.findall('AnimationState') if 1601<=int(n.get('id').split(':')[-1])<=1614]
        self.assertEqual(14,len(clips))
        mapping={int(cond.get('value')):t.get('stateToId')
            for t in neutral.findall('StateTransition') if t.find('TransitionTriggerCondition') is None
            for cond in t.findall('TransitionNumberCondition')}
        self.assertEqual(set(range(1,27)),set(mapping))
        for code in range(1,15):
            state=layer.find("AnimationState[@id='0:%d']"%(1600+code))
            self.assertEqual(mapping[code],state.get('id'))
            clear=[t for t in state.findall('StateTransition') if t.get('stateToId')=='0:144' and t.find("TransitionNumberCondition[@opValue='equal'][@value='0']") is not None]
            self.assertEqual(1,len(clear))
            self.assertEqual('80',clear[0].get('duration'))
            self.assertIsNone(clear[0].get('enableExitTime'))

    def test_critical_caution_preemption_after_real_code(self):
        layer=self.machine.find("StateMachineLayer[@name='Action']")
        for code in range(1,15):
            state=layer.find("AnimationState[@id='0:%d']"%(1600+code))
            if code==9:continue
            self.assertTrue(state.find("StateTransition[@stateToId='0:1609']") is not None)

    def test_core_and_autonomous_orb_animations_unchanged(self):
        for name in UPSTREAM_TRACKS:
            self.assertEqual(
                ET.tostring(self.prior.find("LinearAnimation[@name='%s']"%name)),
                ET.tostring(self.art.find("LinearAnimation[@name='%s']"%name)),name)
        old=self.prior.find("LinearAnimation[@name='idle_breathe']")
        self.assertTrue(old.findall("KeyedObject[@objectId='0:42']"))
        self.assertEqual(8,len(self.machine.findall('StateMachineLayer')))

    def test_real_raster_art_bytes_and_public_inputs_unchanged(self):
        r4=json.loads((R4/'source-receipt.json').read_text())
        self.assertEqual(38,len(r4['image_sha256']))
        for path,digest in r4['image_sha256'].items():
            self.assertEqual(digest,sha((R4/path).read_bytes()),path)
        for tag in ('Image','Mesh','Skin','Weight','TransformConstraint'):
            current=[]
            for element in self.art.iter(tag):
                if tag=='Image' and element.get('name','').startswith('r5_finger_image_'):continue
                if tag=='TransformConstraint' and element.get('name','').startswith('r5_finger_follow_'):continue
                node=copy.deepcopy(element)
                if tag=='Image' and node.get('name') in ['hand_l','hand_r']:
                    expected={'hand_r':('0:2110','0:59'),'hand_l':('0:2114','0:56')}[node.get('name')]
                    self.assertEqual(expected[0],node.get('assetId'));node.set('assetId',expected[1])
                if tag=='Image' and node.get('name')=='arm_l_upper':
                    clips=node.findall('ClippingShape')
                    self.assertEqual(1,len(clips))
                    self.assertEqual({'sourceId':'0:1740','name':'r5_hide_detached_sleeve_fragment'},clips[0].attrib)
                    node.remove(clips[0])
                if tag=='Image' and node.get('name') in ('arm_l_upper','arm_r_upper'):
                    original={'arm_l_upper':('-14.526','27.4766',12.0,24.0),
                              'arm_r_upper':('2.5043','38.9766',-21.0,20.0)}[node.get('name')]
                    x,y,dx,dy=original
                    self.assertAlmostEqual(float(x)-dx,float(node.get('x')),places=5)
                    self.assertAlmostEqual(float(y)-dy,float(node.get('y')),places=5)
                    node.set('x',x);node.set('y',y)
                current.append(ET.tostring(node))
            self.assertEqual([ET.tostring(n) for n in self.prior.iter(tag)],current,tag)
        for tag in ('StateMachineNumber','StateMachineBool','StateMachineTrigger'):
            self.assertEqual(
                [ET.tostring(n) for n in self.prior.find('StateMachine').findall(tag)],
                [ET.tostring(n) for n in self.machine.findall(tag)],tag)

    def test_command_cannot_publish_into_production_assets(self):
        import subprocess,sys
        from pathlib import Path
        target=Path('android/app/src/main/assets/van.riv')
        existed=target.exists()
        result=subprocess.run([sys.executable,'tools/character_forge/extend_raster_full_r5.py',
            '--output',str(target)],capture_output=True,text=True,timeout=15)
        self.assertNotEqual(0,result.returncode)
        self.assertIn('cannot promote production asset',result.stderr)
        self.assertEqual(existed,target.exists())

    def test_command_does_not_overwrite_an_existing_r5_candidate(self):
        import subprocess,sys
        candidate=R4.parent/'raster-full-r5'
        original=(candidate/'source-receipt.json').read_bytes()
        result=subprocess.run([sys.executable,'tools/character_forge/extend_raster_full_r5.py',
            '--output',str(candidate)],capture_output=True,text=True,timeout=15)
        self.assertNotEqual(0,result.returncode)
        self.assertEqual(original,(candidate/'source-receipt.json').read_bytes())

    def test_sleep_selects_closed_eyes_without_editing_original_blink(self):
        layer=self.machine.find("StateMachineLayer[@name='Blink']")
        normal=layer.find("AnimationState[@id='0:107']")
        self.assertIsNotNone(normal.find("StateTransition/TransitionNumberCondition[@value='17']"))
        clip=self.art.find("LinearAnimation[@name='r5_sleep_eyes_closed']")
        self.assertIsNotNone(clip)
        for node in ('0:24','0:25'):
            value=clip.find("KeyedObject[@objectId='%s']/KeyedProperty/KeyFrameDouble"%node).get('value')
            self.assertEqual(1.0,float(value))

    def test_directional_poses_solve_original_two_bone_endpoint(self):
        import math
        from tools.character_forge.extend_raster_full_r5 import solve_pointing_pose
        cases={
            'POINT_LEFT':(35,36,(-42.0058,30.9711),(-20.0434,25.0246),(-79,3)),
            'POINT_RIGHT':(38,39,(39.0272,41.9685),(3.9731,55.9792),(106,7)),
            'POINT_UP':(38,39,(39.0272,41.9685),(3.9731,55.9792),(32,-100)),
            'POINT_DOWN':(38,39,(39.0272,41.9685),(3.9731,55.9792),(26,103)),
        }
        for name,(s,e,v1,v2,target) in cases.items():
            angles=solve_pointing_pose(name)
            def rotate(v,angle):
                return (v[0]*math.cos(angle)-v[1]*math.sin(angle),v[0]*math.sin(angle)+v[1]*math.cos(angle))
            a=rotate(v1,angles[s]);b=rotate(v2,angles[s]+angles[e])
            self.assertAlmostEqual(target[0],a[0]+b[0],places=5,msg=name)
            self.assertAlmostEqual(target[1],a[1]+b[1],places=5,msg=name)

    def test_neutral_resets_both_arms_after_any_gesture(self):
        state=self.machine.find("StateMachineLayer[@name='Action']/AnimationState[@id='0:144']")
        clip=self.art.find("LinearAnimation[@id='%s']"%state.get('animationId'))
        for ident in (35,36,37,38,39,40):
            self.assertEqual(0.0,float(clip.find("KeyedObject[@objectId='0:%d']/KeyedProperty/KeyFrameDouble"%ident).get('value')))

    def test_sleeve_clip_keeps_every_main_component_pixel(self):
        from PIL import Image
        im=Image.open(R4/'layers/11_arm_l_upper.png').convert('RGBA')
        mask={(x,y) for y in range(im.height) for x in range(im.width) if im.getpixel((x,y))[3]>16}
        groups=[]
        while mask:
            origin=mask.pop();stack=[origin];group=[origin]
            while stack:
                x,y=stack.pop()
                for n in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                    if n in mask:mask.remove(n);stack.append(n);group.append(n)
            groups.append(group)
        groups.sort(key=len,reverse=True)
        self.assertEqual(3010,len(groups[0]))
        self.assertEqual(420,len(groups[1]))
        self.assertTrue(all(x>=45 or y>=44 for x,y in groups[0]))
        self.assertTrue(all(x<45 and y<44 for x,y in groups[1]))
        self.assertIsNotNone(self.art.find("Node/Shape[@id='0:1740']"))

    def test_legacy_triggers_play_separately_from_numeric_clear(self):
        layer=self.machine.find("StateMachineLayer[@name='Action']")
        triggers=[s for s in layer.findall('AnimationState') if 1801<=int(s.get('id').split(':')[-1])<=1814]
        self.assertEqual(8,len(triggers))
        for state in triggers:
            exit=state.find("StateTransition[@stateToId='0:144']")
            self.assertEqual('true',exit.get('enableExitTime'))
            self.assertFalse(exit.findall('TransitionNumberCondition'))
            codes={int(c.get('value')) for t in state.findall('StateTransition') for c in t.findall('TransitionNumberCondition')}
            self.assertEqual(set(range(1,27)),codes)

    def test_unique_ids_and_no_gate_promotion(self):
        ids=[n.get('id') for n in self.root.iter() if n.get('id')]
        self.assertEqual(len(ids),len(set(ids)))
        self.assertFalse(self.receipt['production_admissible'])
        self.assertEqual('NOT_VERIFIED',self.receipt['native_android_status'])
        self.assertIn('native/S24 qualification outstanding',self.receipt['finger_ik_and_real_point_target'])

if __name__=='__main__':unittest.main(verbosity=2)
