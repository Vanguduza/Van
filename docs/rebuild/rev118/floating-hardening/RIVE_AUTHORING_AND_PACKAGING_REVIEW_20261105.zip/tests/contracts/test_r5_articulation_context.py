"""Source and original-pixel tests supplement, not replace, actual Rive playback."""
import hashlib,json,math,unittest,copy
from pathlib import Path
import xml.etree.ElementTree as E
import numpy as np
import yaml
from tools.character_forge.extend_raster_full_r5 import generate,R4,CONTRACT,ACTIONS
from tools.character_forge.rig_articulation_r5 import HAND_PARTITIONS,split_hand_pixels,SHOULDER_REBASE,JOINT_UNDERLAPS
from tools.character_forge.context_motion_r5 import CONTEXT_GESTURES

class R5ArticulationContextTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw,cls.report=generate((R4/'scene.rml').read_bytes(),json.loads(CONTRACT.read_text()),yaml.safe_load(ACTIONS.read_text()))
        cls.tree=E.fromstring(cls.raw);cls.art=cls.tree.find('Artboard');cls.sm=cls.art.find('StateMachine')
        cls.original=E.parse(R4/'scene.rml').getroot().find('Artboard')

    def test_original_glove_partitions_reconstruct_every_rgba_pixel(self):
        from PIL import Image
        for side,spec in HAND_PARTITIONS.items():
            parts=split_hand_pixels(R4/'layers'/spec['file'],spec)
            self.assertEqual({'palm','index_prox','index_tip','thumb','middle','ring','little'},set(parts))
            source=np.array(Image.open(R4/'layers'/spec['file']).convert('RGBA'),dtype=np.uint16)
            self.assertTrue(np.array_equal(source,sum(np.array(v,dtype=np.uint16) for v in parts.values())))
            for name,im in parts.items():self.assertGreater(np.count_nonzero(np.array(im)[:,:,3]),20,(side,name))

    def test_both_hands_have_true_proximal_distal_and_thumb_chains(self):
        for side in ['l','r']:
            first=self.art.find(".//Node[@name='rig_index_prox_%s']"%side)
            self.assertIsNotNone(first.find("Node[@name='rig_index_tip_%s']"%side))
            self.assertIsNotNone(self.art.find(".//Node[@name='rig_thumb_%s']"%side))
            for part in ['index_prox','index_tip','thumb']:
                image=self.art.find("Node[@name='r5_follow_finger_%s_%s']/Image"%(side,part));self.assertIsNotNone(image)

    def test_every_finite_action_has_finger_keys_and_neutral_resets_them(self):
        ids={2001,2002,2003,2005,2006,2007,2700,2701,2702,2703,2704,2705}
        neutral=self.art.find("LinearAnimation[@name='r5_action_neutral_full']")
        for ident in ids:self.assertIsNotNone(neutral.find("KeyedObject[@objectId='0:%d']"%ident))
        for clip in self.art.findall('LinearAnimation'):
            if clip.get('name','').startswith('action_r5_'):
                actual={int(n.get('objectId').split(':')[-1]) for n in clip.findall('KeyedObject')}
                self.assertTrue(ids<=actual,clip.get('name'))

    def test_original_38_image_bytes_and_asset_definitions_survive(self):
        receipt=json.loads((R4/'source-receipt.json').read_text())
        self.assertEqual(38,len(receipt['image_sha256']))
        for path,digest in receipt['image_sha256'].items():self.assertEqual(digest,hashlib.sha256((R4/path).read_bytes()).hexdigest())
        added=[x for x in self.tree.findall('ImageAsset') if x.get('name','').startswith('r5_hand_')]
        self.assertEqual(14,len(added))

    def test_shoulder_rebase_preserves_neutral_raster_world_placement(self):
        def translation(root,node):
            parents={c:p for p in root.iter() for c in p};x=y=0
            while node is not None:
                if node.tag in ['Node','Image']:
                    x+=float(node.get('x','0'));y+=float(node.get('y','0'))
                node=parents.get(node)
            return x,y
        for ident,(dx,dy,elbow,name) in SHOULDER_REBASE.items():
            before=self.original.find(".//Node[@id='0:%d']"%ident)
            after=self.art.find(".//Node[@id='0:%d']"%ident)
            b=translation(self.original,before);a=translation(self.art,after)
            self.assertAlmostEqual(b[0]+dx,a[0],places=5);self.assertAlmostEqual(b[1]+dy,a[1],places=5)
            original=self.original.find(".//Image[@name='%s']"%name);current=self.art.find(".//Image[@name='%s']"%name)
            self.assertAlmostEqual(b[0]+float(original.get('x')),a[0]+float(current.get('x')),places=5)
            self.assertAlmostEqual(b[1]+float(original.get('y')),a[1]+float(current.get('y')),places=5)

    def test_joint_underlaps_exist_only_at_four_original_rotational_seams(self):
        names=[n.get('name') for n in self.art.findall('.//Node') if n.get('name','').startswith('r5_joint_underlap_')]
        self.assertEqual(4,len(names));self.assertEqual(4,self.report['joint_underlap_count'])
        for ident in JOINT_UNDERLAPS:
            owner=self.art.find(".//Node[@id='0:%d']"%ident)
            self.assertTrue(any(n.get('name','').startswith('r5_joint_underlap_') for n in owner))

    def test_live_target_uses_real_two_bone_ik_and_original_attention_inputs(self):
        chain=self.art.find(".//RootBone[@id='0:2210']/Bone[@id='0:2211']/IKConstraint")
        self.assertIsNotNone(chain);self.assertEqual('1',chain.get('parentBoneCount'));self.assertEqual('0:2221',chain.get('targetId'))
        for layer,inputid in [('Gaze x','0:90'),('Gaze y','0:91')]:
            b=self.sm.find("StateMachineLayer[@name='%s']/BlendState1DInput"%layer)
            self.assertEqual(inputid,b.get('inputId'));self.assertEqual('true',b.get('reset'))
            self.assertEqual(['-1','1'],[x.get('value') for x in b.findall('BlendAnimation1D')])
        self.assertIsNotNone(self.art.find(".//Node[@id='0:2222']/Node[@id='0:2221']"))

    def test_no_target_keeps_static_point_instead_of_folding_the_arm(self):
        layer=self.sm.find("StateMachineLayer[@name='Action']")
        self.assertIsNotNone(layer.find("AnimationState[@id='0:1867']"))
        self.assertIsNotNone(layer.find("AnimationState[@id='0:1607']/StateTransition[@stateToId='0:1867']"))
        self.assertEqual('0:2260',layer.find("AnimationState[@id='0:1807']").get('animationId'))

    def test_only_pointing_and_target_context_clips_enable_ik(self):
        for clip in self.art.findall('LinearAnimation'):
            keys=[k for n in clip.findall("KeyedObject[@objectId='0:2232']") for p in n.findall('KeyedProperty') for k in p.findall('KeyFrameDouble')]
            if any(float(k.get('value'))>0 for k in keys):
                self.assertIn(clip.get('name'),['action_r5_point_target','context_inspect_target','context_guide_next_step'])

    def test_twelve_context_clips_preserve_the_original_wire_contract(self):
        self.assertEqual(list(range(15,27)),[g[0] for g in CONTEXT_GESTURES])
        self.assertEqual(12,len(self.report['context_gestures']))
        for code,name,duration,legacy in CONTEXT_GESTURES:
            clip=self.art.find("LinearAnimation[@name='context_%s']"%name.lower());self.assertIsNotNone(clip)
            self.assertEqual(round(duration*.06),int(clip.get('duration')))
            self.assertGreater(len(clip.findall('.//KeyFrameDouble')),10)
            self.assertTrue(1<=legacy<=14)
        inputs=[n for n in self.sm if n.tag in ('StateMachineNumber','StateMachineBool','StateMachineTrigger')]
        self.assertEqual(17,len(inputs));self.assertEqual(8,len(self.sm.findall('StateMachineLayer')))

    def test_context_clips_are_reachable_and_clear_without_exit_wait(self):
        layer=self.sm.find("StateMachineLayer[@name='Action']")
        neutral=layer.find("AnimationState[@id='0:144']")
        for code,_,_,_ in CONTEXT_GESTURES:
            target='0:'+str(2400+code)
            self.assertIsNotNone(neutral.find("StateTransition[@stateToId='%s']"%target))
            state=layer.find("AnimationState[@id='%s']"%target)
            clear=state.find("StateTransition[@stateToId='0:144']")
            self.assertEqual('80',clear.get('duration'));self.assertIsNone(clear.get('enableExitTime'))

    def test_micro_motions_have_separate_nodes_and_preserve_original_orb_track(self):
        self.assertEqual(5,len(self.report['additional_micro_motion_channels']))
        clip=self.art.find("LinearAnimation[@name='r5_ambient_and_micro']")
        self.assertEqual('0:2510',self.sm.find("StateMachineLayer[@name='Breathe']/AnimationState").get('animationId'))
        for name in self.report['additional_micro_motion_channels']:
            node=self.art.find(".//Node[@name='r5_micro_%s']"%name)
            self.assertIsNotNone(node)
            track=clip.find("KeyedObject[@objectId='%s']"%node.get('id'))
            self.assertIsNotNone(track)
            values=[float(k.get('value')) for k in track.findall('.//KeyFrameDouble')]
            self.assertAlmostEqual(0,values[0],places=7);self.assertAlmostEqual(0,values[-1],places=7)
            self.assertGreater(max(values)-min(values),.001)
        original=self.original.find("LinearAnimation[@name='idle_breathe']")
        for ob in original.findall("KeyedObject[@objectId='0:42']"):
            self.assertIn(E.tostring(ob),[E.tostring(v) for v in clip.findall("KeyedObject[@objectId='0:42']")])

    def test_no_owner_or_native_device_gate_is_self_promoted(self):
        self.assertFalse(self.report['production_admissible']);self.assertEqual('NOT_VERIFIED',self.report['native_android_status'])

if __name__=='__main__':unittest.main(verbosity=2)
