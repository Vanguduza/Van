"""Executable guards for the exact existing Candidate B motion refinement.

These are source/artifact tests, not owner artwork, native Android or device acceptance.
"""
from pathlib import Path
import copy
import json
import math
import subprocess
import sys
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from tools.character_forge.refine_candidate_b_motion import (
    ACTION_MS, SOURCE_SHA256, orb_position, refine, sha256, visual_geometry_hash,
)


class CandidateBMotionRefinementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (ROOT / "visual-authority/character-forge/08-prototypes/candidate-b-mechanics/scene.rml").read_bytes()
        cls.contract = json.loads((ROOT / "visual-authority/rive_contract.json").read_text())
        cls.output, cls.report = refine(cls.source, cls.contract)
        cls.tree = ET.fromstring(cls.output)
        cls.machine = cls.tree.find("Artboard/StateMachine")

    def test_original_source_hash_is_exact(self):
        self.assertEqual(SOURCE_SHA256, sha256(self.source))

    def test_changed_parent_source_is_rejected(self):
        with self.assertRaises(ValueError):
            refine(self.source + b" ", self.contract)

    def test_changed_public_contract_is_rejected(self):
        contract = copy.deepcopy(self.contract)
        contract["inputs"][0]["name"] = "new_unauthorized_state"
        with self.assertRaises(ValueError):
            refine(self.source, contract)

    def test_generation_is_deterministic(self):
        again, receipt = refine(self.source, self.contract)
        self.assertEqual(self.output, again)
        self.assertEqual(self.report, receipt)

    def test_every_original_vector_geometry_and_colour_is_preserved(self):
        self.assertEqual(visual_geometry_hash(ET.fromstring(self.source)), visual_geometry_hash(self.tree))
        self.assertEqual(len(ET.fromstring(self.source).findall('.//PointsPath')), len(self.tree.findall('.//PointsPath')))

    def test_exact_original_inputs_and_triggers_remain(self):
        entries=[n.get('name') for n in self.machine if n.tag.startswith('StateMachine') and n.tag!='StateMachineLayer']
        self.assertEqual([i['name'] for i in self.contract['inputs']]+self.contract['triggers'], entries)

    def test_eight_layer_budget_with_separate_body_and_companion_owners(self):
        names=[n.get('name') for n in self.machine.findall('StateMachineLayer')]
        self.assertEqual(len(names),8)
        self.assertIn('BodyAmbient',names)
        self.assertIn('CompanionAutonomy',names)
        for name in ['BodyAmbient','CompanionAutonomy']:
            layer=self.machine.find(f'StateMachineLayer[@name="{name}"]')
            self.assertFalse(layer.findall('.//TransitionNumberCondition'))
            self.assertFalse(layer.findall('.//TransitionBoolCondition'))

    def test_all_existing_states_and_actions_survive(self):
        names={n.get('name') for n in self.tree.findall('Artboard/LinearAnimation')}
        self.assertTrue(set(self.contract['durable_states']) <= names)
        self.assertTrue(set(self.contract['finite_actions']) <= names)
        self.assertEqual(len(self.contract['durable_states']),18)
        self.assertEqual(len(self.contract['finite_actions']),14)

    def test_actions_do_not_overwrite_original_durable_transform_nodes(self):
        for name in self.contract['finite_actions']:
            animation=self.tree.find(f'.//LinearAnimation[@name="{name}"]')
            self.assertFalse({n.get('objectId') for n in animation}.intersection({'0:11','0:12','0:13','0:14'}),name)

    def test_durable_states_cannot_control_companion_position(self):
        for name in self.contract['durable_states']:
            animation=self.tree.find(f'.//LinearAnimation[@name="{name}"]')
            self.assertNotIn('0:14',{n.get('objectId') for n in animation},name)

    def test_canonical_action_durations_are_not_one_generic_second(self):
        for name,milliseconds in ACTION_MS.items():
            animation=self.tree.find(f'.//LinearAnimation[@name="{name}"]')
            self.assertEqual(round(milliseconds*60/1000),int(animation.get('duration')),name)

    def test_latched_action_return_requires_actual_clear(self):
        layer=self.machine.find('StateMachineLayer[@name="FiniteAction"]')
        for state in layer.findall('AnimationState'):
            if state.get('id')=='0:449':continue
            transition=state.find('StateTransition')
            self.assertEqual('true',transition.get('enableExitTime'))
            self.assertIsNotNone(transition.find('TransitionNumberCondition[@inputId="0:109"][@value="0"]'))

    def test_subthreshold_gaze_has_continuous_blend_controls(self):
        for axis,input_id in [('X','0:104'),('Y','0:105')]:
            layer=self.machine.find(f'StateMachineLayer[@name="Gaze{axis}"]')
            state=layer.find('BlendState1DInput')
            self.assertEqual(input_id,state.get('inputId'))
            self.assertEqual(['-1','0','1'],[n.get('value') for n in state])

    def test_face_controls_are_in_front_of_opaque_head_trace(self):
        node=self.tree.find('.//Node[@id="0:801"]')
        self.assertEqual({'0:700','0:701','0:489'},{n.get('id') for n in list(node)[:3]})
        anchor=self.tree.find('.//Node[@id="0:804"]')
        self.assertEqual('0:490',list(anchor)[-1].get('id'))
        self.assertEqual('0:805',list(anchor)[0].get('id'))

    def test_mouth_amplitude_has_its_own_fixed_pivot(self):
        mouth=self.tree.find('.//Node[@id="0:805"]')
        self.assertEqual(('3','-23'),(mouth.get('x'),mouth.get('y')))
        state=self.machine.find('.//BlendState1DInput[@id="0:751"]')
        self.assertEqual('0:106',state.get('inputId'))

    def test_acknowledgement_includes_actual_eight_degree_rotation(self):
        timeline=self.tree.find('.//LinearAnimation[@name="ACK_NOD"]')
        values=[float(n.get('value')) for p in timeline.findall('KeyedObject/KeyedProperty[@propertyKey="15"]') for n in p]
        self.assertAlmostEqual(math.radians(8),max(values),places=7)

    def test_companion_path_crosses_both_sides_and_returns_continuously(self):
        self.assertEqual(164,orb_position(0)[0])
        self.assertEqual(454,orb_position(.55)[0])
        self.assertEqual(164,orb_position(1)[0])
        for boundary in [.2,.41,.69,.90]:
            a,b=orb_position(boundary-1e-6),orb_position(boundary+1e-6)
            self.assertLess(abs(a[0]-b[0]),.001)
            self.assertLess(abs(a[1]-b[1]),.001)
        self.assertAlmostEqual(2*math.pi,orb_position(1)[2])

    def test_companion_path_never_leaves_canvas_and_rejects_nonfinite_values(self):
        for frame in range(1423):
            x,y,_=orb_position(frame/1422)
            self.assertTrue(60<x<533 and 60<y<533)
        for value in [float('nan'),float('inf'),float('-inf')]:
            with self.assertRaises(ValueError):orb_position(value)

    def test_explicit_rml_ids_remain_unique(self):
        ids=[n.get('id') for n in self.tree.iter() if n.get('id')]
        self.assertEqual(len(ids),len(set(ids)))

    def test_no_report_claims_production_or_device_acceptance(self):
        self.assertFalse(self.report['production_admissible'])
        self.assertFalse(self.report['device_qualified'])
        self.assertFalse(self.report['qualified_android_runtime'])
        self.assertFalse(self.report['aura_embedded'])

    def test_command_cannot_write_into_production_asset_path(self):
        result=subprocess.run([sys.executable,str(ROOT/'tools/character_forge/refine_candidate_b_motion.py'),
            '--source',str(ROOT/'visual-authority/character-forge/08-prototypes/candidate-b-mechanics/scene.rml'),
            '--contract',str(ROOT/'visual-authority/rive_contract.json'),
            '--output',str(ROOT/'android/app/src/main/assets/refinement-refusal-probe')],
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=10)
        self.assertNotEqual(0,result.returncode)
        self.assertIn('cannot promote',result.stderr)
        self.assertFalse((ROOT/'android/app/src/main/assets/refinement-refusal-probe').exists())

if __name__=='__main__':
    unittest.main(verbosity=2)
