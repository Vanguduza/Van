"""Source-artifact consistency and exact original pixels; no owner/device admission claim."""
from pathlib import Path
import hashlib,json,unittest
import xml.etree.ElementTree as E
import numpy as np
from PIL import Image
from tools.character_forge.rig_articulation_r5 import HAND_PARTITIONS,split_hand_pixels
ROOT=Path(__file__).resolve().parents[2]
R5=ROOT/'visual-authority/character-forge/08-prototypes/candidate-b-mechanics/raster-full-r5'
class R5NaturalMotionClosure(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.receipt=json.loads((R5/'source-receipt.json').read_text());cls.art=E.parse(R5/'scene.rml').getroot().find('Artboard')
    def test_catalogue_contains_all_sixteen_declared_micro_behaviours(self):
        expected={'breathing','hover','single_blink','occasional_double_blink','eye_saccades','smooth_gaze_return','head_left','head_right','head_up','head_down','brow_raise','brow_lower','soft_smile','shoulder_settle','drag_counterlean','docking_return'}
        entries=self.receipt['micro_catalogue'];self.assertEqual(16,len(entries));self.assertEqual(expected,{x['name'] for x in entries})
        self.assertTrue(all(x['owner'] for x in entries))
    def test_all_five_fingers_have_independent_controls_in_both_hands(self):
        self.assertEqual(12,self.receipt['articulated_finger_nodes'])
        for side in ['l','r']:
            for part in ['index_prox','index_tip','thumb','middle','ring','little']:
                self.assertIsNotNone(self.art.find(".//Node[@name='rig_%s_%s']"%(part,side)))
    def test_all_fourteen_glove_derivatives_sum_back_to_original_rgba(self):
        self.assertEqual(14,len(self.receipt['derived_finger_assets']))
        for side,spec in HAND_PARTITIONS.items():
            source=R5/'layers'/spec['file'];parts=split_hand_pixels(source,spec)
            expected=np.array(Image.open(source).convert('RGBA'),dtype=np.uint16)
            self.assertEqual(7,len(parts));self.assertTrue(np.array_equal(expected,sum(np.array(p,dtype=np.uint16) for p in parts.values())))
            for label,image in parts.items():
                actual=Image.open(R5/'layers'/f'r5_hand_{side}_{label}.png').convert('RGBA')
                self.assertTrue(np.array_equal(np.array(actual),np.array(image)))
    def test_original_identity_bytes_still_match_all_thirty_eight_hashes(self):
        self.assertEqual(38,len(self.receipt['image_sha256']))
        for f,h in self.receipt['image_sha256'].items():self.assertEqual(h,hashlib.sha256((R5/f).read_bytes()).hexdigest(),f)
    def test_optional_context_caps_bind_exact_current_binary_and_clips(self):
        caps=json.loads((R5/'van.context.json').read_text());binary=R5/'build/van_raster_full_r5_unadmitted.riv'
        self.assertEqual(caps['asset_sha256'],hashlib.sha256(binary.read_bytes()).hexdigest())
        self.assertEqual(caps['source_rml_sha256'],hashlib.sha256((R5/'scene.rml').read_bytes()).hexdigest())
        self.assertEqual(list(range(15,27)),[g['code'] for g in caps['gestures']])
        self.assertEqual(self.receipt['context_gestures'],caps['gestures'])
    def test_natural_blink_and_expression_cannot_overwrite_historical_clips(self):
        for name in ['blink','r5_natural_blink','state_idle','state_listening','state_thinking','state_speaking']:
            self.assertIsNotNone(self.art.find("LinearAnimation[@name='%s']"%name))
        self.assertEqual(2160,int(self.art.find("LinearAnimation[@name='r5_natural_blink']").get('duration')))
        self.assertEqual(8,len(self.art.find('StateMachine').findall('StateMachineLayer')))
    def test_production_and_owner_acceptance_remain_false(self):
        self.assertFalse(self.receipt['production_admissible']);self.assertEqual('NOT_VERIFIED',self.receipt['native_android_status'])
if __name__=='__main__':unittest.main(verbosity=2)
