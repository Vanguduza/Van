"""Temporary-fixture tests of real Forge package code; no repository gates are admitted.

The fixture RIVE bytes are inert digest inputs, NOT claimed to be a working rig.
Actual Rive runtime tests are a separate source-bound suite.
"""
from __future__ import annotations
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import hashlib, inspect, json, re, tempfile, unittest
from tools.character_forge import cli, gates, receipts
from tools.character_forge.manifest import sha256_file, source_tree_sha256
from tools.character_forge.context_package import (
    GESTURES, MAX_BYTES, SCHEMA, validate_metadata, receipt_fields,
    receipted_metadata, install_pair, package_matches, metadata_sha,
)

def payload(candidate: Path):
    return {'schema':SCHEMA,'asset_sha256':sha256_file(candidate),
            'gestures':[{'code':c,'name':n,'duration_ms':d,'legacy_action':a} for c,n,d,a in GESTURES]}

class ContextPackageTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.allowed=self.root/'working';self.allowed.mkdir()
        self.candidate=self.allowed/'candidate.riv';self.candidate.write_bytes(b'RIVE'+b'digest-fixture-only'*100)
        self.metadata=self.allowed/'candidate.context.json';self.value=payload(self.candidate)
        self.raw=json.dumps(self.value).encode();self.metadata.write_bytes(self.raw)
        self.out=self.root/'assets';self.riv=self.out/'van.riv';self.sidecar=self.out/'van.context.json'
    def test_exact_twelve_gestures_validate_against_binary(self):
        self.assertEqual(self.value,validate_metadata(self.raw,sha256_file(self.candidate)))
    def test_wrong_binary_schema_missing_gesture_or_duplicate_refused(self):
        for field,value in [('asset_sha256','0'*64),('schema','future'),('gestures',self.value['gestures'][:-1]),('gestures',[self.value['gestures'][0]]*12)]:
            bad={**self.value,field:value}
            with self.subTest(field=field,value=str(value)[:20]),self.assertRaises(ValueError):validate_metadata(json.dumps(bad).encode(),sha256_file(self.candidate))
    def test_numeric_string_boolean_fractional_values_not_coerced(self):
        for key in ['code','duration_ms','legacy_action']:
            for bad in ['15',True,15.5,None]:
                value=payload(self.candidate);value['gestures'][0][key]=bad
                with self.subTest(key=key,bad=bad),self.assertRaises(ValueError):validate_metadata(json.dumps(value).encode(),sha256_file(self.candidate))
    def test_wrong_name_duration_and_fallback_refused(self):
        for key,bad in [('name','UNAPPROVED'),('duration_ms',999),('legacy_action',8)]:
            value=payload(self.candidate);value['gestures'][0][key]=bad
            with self.assertRaises(ValueError):validate_metadata(json.dumps(value).encode(),sha256_file(self.candidate))
    def test_malformed_oversized_nonfinite_and_duplicate_keys_refused(self):
        for raw in [b'',b'{',b'[]',b'\xff',b'x'*(MAX_BYTES+1),b'{"schema":"x","schema":"y"}',b'{"schema":NaN}']:
            with self.subTest(raw=raw[:20]),self.assertRaises(ValueError):validate_metadata(raw,sha256_file(self.candidate))
    def test_receipt_binds_path_bytes_size_schema_and_exact_binary(self):
        row=receipt_fields(self.candidate,self.metadata,self.root,self.allowed)
        self.assertEqual(hashlib.sha256(self.raw).hexdigest(),row['context_metadata_sha256'])
        self.assertEqual(len(self.raw),row['context_metadata_bytes']);self.assertEqual(SCHEMA,row['context_schema'])
        self.assertEqual(self.raw,receipted_metadata(self.candidate,row,self.root,self.allowed))
    def test_legacy_receipt_does_not_implicitly_adopt_adjacent_metadata(self):
        self.assertEqual({},receipt_fields(self.candidate,None,self.root,self.allowed))
        self.assertIsNone(receipted_metadata(self.candidate,{},self.root,self.allowed))
    def test_context_changed_after_receipt_is_rejected_even_if_semantically_equal(self):
        row=receipt_fields(self.candidate,self.metadata,self.root,self.allowed)
        self.metadata.write_bytes(self.raw+b'\n')
        with self.assertRaisesRegex(ValueError,'changed after'):receipted_metadata(self.candidate,row,self.root,self.allowed)
    def test_receipt_rejects_missing_partial_or_escaping_paths(self):
        row=receipt_fields(self.candidate,self.metadata,self.root,self.allowed)
        for bad in [{k:v for k,v in row.items() if k!='context_schema'}, {**row,'context_metadata_path':'../outside.json'}, {**row,'context_metadata_path':'/tmp/outside.json'}]:
            with self.assertRaises(ValueError):receipted_metadata(self.candidate,bad,self.root,self.allowed)
    def test_export_cannot_adopt_an_outside_or_symlink_metadata_file(self):
        external=self.root/'external.json';external.write_bytes(self.raw)
        linked=self.allowed/'link.json';linked.symlink_to(self.metadata)
        for path in [external,linked]:
            with self.assertRaises(ValueError):receipt_fields(self.candidate,path,self.root,self.allowed)
    def test_pair_copies_exact_bytes_without_modifying_source(self):
        before=self.candidate.read_bytes();install_pair(self.candidate,self.riv,self.sidecar,self.raw)
        self.assertTrue(package_matches(self.riv,self.sidecar,sha256_file(self.candidate),self.raw))
        self.assertEqual(before,self.candidate.read_bytes());self.assertEqual(self.raw,self.metadata.read_bytes())
        self.assertFalse(list(self.out.glob('.van-package-*')))
    def test_legacy_staging_removes_obsolete_extension(self):
        install_pair(self.candidate,self.riv,self.sidecar,self.raw)
        install_pair(self.candidate,self.riv,self.sidecar,None)
        self.assertFalse(self.sidecar.exists());self.assertTrue(package_matches(self.riv,self.sidecar,sha256_file(self.candidate),None))
    def test_bad_metadata_does_not_touch_existing_package(self):
        install_pair(self.candidate,self.riv,self.sidecar,self.raw)
        old=(self.riv.read_bytes(),self.sidecar.read_bytes())
        with self.assertRaises(ValueError):install_pair(self.candidate,self.riv,self.sidecar,b'{}')
        self.assertEqual(old,(self.riv.read_bytes(),self.sidecar.read_bytes()))
    def test_interrupted_second_replace_cannot_leave_enabled_wrong_extension(self):
        import tools.character_forge.context_package as implementation
        install_pair(self.candidate,self.riv,self.sidecar,self.raw)
        original=implementation.os.replace;calls=0
        def replace(src,dst):
            nonlocal calls
            calls+=1
            if calls==2:raise OSError('simulated disk failure')
            original(src,dst)
        with patch.object(implementation.os,'replace',side_effect=replace),self.assertRaises(OSError):
            install_pair(self.candidate,self.riv,self.sidecar,self.raw)
        self.assertFalse(self.sidecar.exists());self.assertFalse(list(self.out.glob('.van-package-*')))
    def test_package_target_symlink_refused(self):
        self.out.mkdir();self.riv.symlink_to(self.candidate)
        with self.assertRaises(ValueError):install_pair(self.candidate,self.riv,self.sidecar,self.raw)
    def test_legacy_binary_change_after_validation_is_not_installed(self):
        digest=sha256_file(self.candidate);self.candidate.write_bytes(b'changed original')
        with self.assertRaisesRegex(ValueError,'changed after'):
            install_pair(self.candidate,self.riv,self.sidecar,None,expected_binary_sha=digest)
        self.assertFalse(self.riv.exists())
    def test_context_changed_between_receipt_checks_is_refused(self):
        import tools.character_forge.context_package as module
        receipt=receipt_fields(self.candidate,self.metadata,self.root,self.allowed)
        original=module._bounded_read;calls=0
        def read(path):
            nonlocal calls
            calls+=1
            value=original(path)
            return value if calls==1 else value+b' '
        with patch.object(module,'_bounded_read',side_effect=read),self.assertRaisesRegex(ValueError,'changed while'):
            receipted_metadata(self.candidate,receipt,self.root,self.allowed)
    def test_oversized_candidate_is_rejected_before_package_mutation(self):
        with self.candidate.open('wb') as f:f.truncate(8*1024*1024+1)
        with self.assertRaisesRegex(ValueError,'memory limit'):
            install_pair(self.candidate,self.riv,self.sidecar,None)
        self.assertFalse(self.riv.exists())

    def test_runtime_native_enum_and_python_metadata_contract_match(self):
        root=Path(__file__).resolve().parents[2]
        text=(root/'android/app/src/main/java/com/dial/van/visual/VanContextGesture.kt').read_text()
        legacy={'ACK_NOD':2,'POINT_TARGET':7,'SHRUG':11,'CAUTION':9,'CLOSE_PANEL':14,'PRESENT_CARD':12,'CONFIRM':10}
        actual=[(int(code),name,int(duration.replace('_','')),legacy[action])
            for name,code,duration,action in re.findall(r'^    (\w+)\((\d+), ([\d_]+), VanFiniteAction\.(\w+)',text,re.M)]
        self.assertEqual(list(GESTURES),actual)

class ForgeContextWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.stack=ExitStack();self.addCleanup(self.stack.close)
        self.working=self.root/'visual-authority/character-forge/09-rive-working';self.working.mkdir(parents=True)
        self.project=self.working/'rml/fixture';self.project.mkdir(parents=True);(self.project/'scene.rml').write_text('<Rive/>')
        self.candidate=self.working/'full_fixture.riv';self.candidate.write_bytes(b'RIVE'+b'test-fixture-not-runtime'*80)
        self.metadata=self.working/'context.json';self.raw=json.dumps(payload(self.candidate)).encode();self.metadata.write_bytes(self.raw)
        self.contract=self.root/'contract.json';self.contract.write_text('{}');self.layer=self.root/'layer.svg';self.layer.write_text('<svg/>')
        self.artifacts={'artifacts':[{'kind':'layer_svg','sha256':sha256_file(self.layer)}],'receipts':[]}
        self.status={'core_rig':{},'full_rig':{},'performance':{}}
        self.status_saves=[]
        settings={'ROOT':self.root,'WORKING_DIR':self.working,'RML_ROOT':self.working/'rml','CONTRACT_PATH':self.contract,
          'ANDROID_TEST_ASSETS':self.root/'test-assets','ANDROID_DEBUG_ASSETS':self.root/'debug-assets',
          'SOURCE_RIV':self.root/'source/van_runtime.riv','APP_RIV':self.root/'main/van.riv','EVIDENCE_DIR':self.root/'evidence'}
        for name,value in settings.items():self.stack.enter_context(patch.object(cli,name,value))
        self.stack.enter_context(patch.object(receipts,'ROOT',self.root))
        self.stack.enter_context(patch.object(cli,'rel',side_effect=lambda p:p.resolve().relative_to(self.root).as_posix()))
        self.stack.enter_context(patch.object(cli,'load_yaml',side_effect=lambda:self.artifacts))
        self.stack.enter_context(patch.object(cli,'load_status',side_effect=lambda:self.status))
        self.stack.enter_context(patch.object(cli,'_save',side_effect=lambda m,s:self.status_saves.append(dict(s))))
        self.stack.enter_context(patch.object(cli,'_yaml',return_value={'critical_path':{'rive_cli':{'version':'1.1.1'}}}))
        self.stack.enter_context(patch.object(cli,'_pinned_tool',return_value='1.1.1'))
        self.evaluated=[];self.allow=True
        def gate(name):self.evaluated.append(name);return SimpleNamespace(passed=self.allow,reasons=('fixture not admitted',))
        self.stack.enter_context(patch.object(cli,'evaluate',side_effect=gate))
        self.receipt_args=SimpleNamespace(candidate=str(self.candidate),stage='full_rig',svg_sha=sha256_file(self.layer),authoring_version='1.1.1',source_project=str(self.project),rive_file_id='fixture',rive_revision='one',artist='unit-test',notes='',actor='unit-test',context_manifest=str(self.metadata))
        self.stage_args=SimpleNamespace(riv=str(self.candidate),stage='full_rig',actor='unit-test')
        self.integrate_args=SimpleNamespace(candidate=str(self.candidate),actor='unit-test')
        baseline=self.root/'evidence/core_baseline';baseline.mkdir(parents=True);(baseline/'fixture.png').write_bytes(b'not-an-acceptance-image')
    def receipt(self):self.assertEqual(0,cli.cmd_rive_receipt(self.receipt_args));return json.loads((self.working/'full_fixture.receipt.json').read_text())
    def stage(self):self.receipt();self.assertEqual(0,cli.cmd_rive_stage(self.stage_args))
    def test_receipt_persists_exact_optional_metadata_and_provenance(self):
        row=self.receipt();self.assertEqual(metadata_sha(self.raw),row['context_metadata_sha256'])
        self.assertIn(metadata_sha(self.raw),self.artifacts['receipts'][-1]['inputs'])
    def test_full_stage_gate_cannot_be_skipped_by_context_metadata(self):
        self.receipt();self.allow=False
        self.assertEqual(1,cli.cmd_rive_stage(self.stage_args));self.assertIn('m2',self.evaluated)
        self.assertFalse((self.root/'debug-assets/van_candidate.riv').exists())
    def test_two_candidate_asset_sets_receive_byte_identical_sidecars(self):
        self.stage()
        for target in ['test-assets','debug-assets']:
            self.assertTrue(package_matches(self.root/target/'van_candidate.riv',self.root/target/'van_candidate.context.json',sha256_file(self.candidate),self.raw))
        self.assertEqual(metadata_sha(self.raw),self.status['full_rig']['context_metadata_sha256'])
        self.assertEqual('NOT_RUN',self.status['full_rig']['emulator_validation'])
    def test_stale_metadata_rejected_before_stage_can_modify_any_assets(self):
        self.receipt();self.metadata.write_bytes(self.raw+b'\n')
        self.assertEqual(1,cli.cmd_rive_stage(self.stage_args));self.assertFalse((self.root/'debug-assets').exists())
    def test_missing_receipt_and_changed_rml_remain_refused(self):
        self.assertEqual(1,cli.cmd_rive_stage(self.stage_args));self.receipt()
        (self.project/'scene.rml').write_text('<Rive changed="true"/>')
        self.assertEqual(1,cli.cmd_rive_stage(self.stage_args));self.assertFalse((self.root/'debug-assets').exists())
    def test_no_change_checks_sidecar_not_only_binary(self):
        self.stage();prior=len(self.status_saves);self.assertEqual(0,cli.cmd_rive_stage(self.stage_args));self.assertEqual(prior,len(self.status_saves))
        (self.root/'debug-assets/van_candidate.context.json').write_bytes(b'bad')
        self.assertEqual(0,cli.cmd_rive_stage(self.stage_args));self.assertGreater(len(self.status_saves),prior)
        self.assertEqual(self.raw,(self.root/'debug-assets/van_candidate.context.json').read_bytes())
    def test_legacy_rereceipt_removes_old_staged_extension(self):
        self.stage();self.receipt_args.context_manifest=None;self.receipt()
        self.assertEqual(0,cli.cmd_rive_stage(self.stage_args))
        self.assertFalse((self.root/'debug-assets/van_candidate.context.json').exists())
        self.assertIsNone(self.status['full_rig']['context_metadata_sha256'])
    def test_integrate_requires_original_m3_first(self):
        self.stage();self.allow=False;self.assertEqual(1,cli.cmd_integrate(self.integrate_args))
        self.assertEqual('m3',self.evaluated[-1]);self.assertFalse((self.root/'main/van.riv').exists())
    def test_integration_carries_sidecar_and_removes_candidate_residue(self):
        self.stage();self.assertEqual(0,cli.cmd_integrate(self.integrate_args))
        for binary in [self.root/'source/van_runtime.riv',self.root/'main/van.riv']:
            self.assertTrue(package_matches(binary,binary.parent/'van.context.json',sha256_file(self.candidate),self.raw))
        self.assertFalse((self.root/'debug-assets/van_candidate.context.json').exists())
        self.assertEqual(metadata_sha(self.raw),self.status['production']['context_metadata_sha256'])
        self.assertEqual('NOT_RUN',self.status['production']['emulator_validation'])
    def test_restaged_metadata_cannot_reuse_old_validated_context(self):
        self.stage();self.metadata.write_bytes(self.raw+b'\n');self.receipt()
        self.assertEqual(1,cli.cmd_integrate(self.integrate_args));self.assertFalse((self.root/'main/van.riv').exists())
    def test_legacy_integration_removes_stale_production_capabilities(self):
        self.receipt_args.context_manifest=None;self.stage()
        for target in ['source','main']:
            folder=self.root/target;folder.mkdir();(folder/'van.context.json').write_bytes(self.raw)
        self.assertEqual(0,cli.cmd_integrate(self.integrate_args))
        self.assertFalse((self.root/'main/van.context.json').exists());self.assertFalse((self.root/'source/van.context.json').exists())
    def test_debug_lab_uses_same_hash_bound_catalogue_and_keeps_legacy_mode(self):
        root=Path(__file__).resolve().parents[2]
        lab=(root/'android/app/src/debug/java/com/dial/van/visual/CharacterRigLab.kt').read_text()
        host=(root/'android/app/src/debug/java/com/dial/van/visual/RiveCandidateHostActivity.kt').read_text()
        self.assertIn('candidateActions(supportedContextCodes)',lab)
        self.assertIn('VanRiveContextCapabilities.resolve(it, metadata)',host)
        self.assertIn('supportedContextCodes = supportedContexts',host)
        self.assertIn('extension disabled',lab)
    def test_all_original_mutators_still_record_receipts(self):
        for fn in [cli.cmd_rive_receipt,cli.cmd_rive_stage,cli.cmd_integrate,cli.cmd_release]:self.assertIn('append_receipt',inspect.getsource(fn))

if __name__=='__main__':unittest.main(verbosity=2)
