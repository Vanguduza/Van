"""A second alias cannot ignore another alias's still-pending stop risk."""
from dataclasses import replace
from decimal import Decimal as D
from types import SimpleNamespace as N

import pytest

from conftest import NOW,intent,mandate_dict
from test_native_risk_history_inputs import native_facts
from test_native_risk_history_index import other_context
from test_physical_order_exposure import command,receipt
from test_physical_snapshot_producers import producer
from vati.risk import TradingMandate,RiskAuthority


@pytest.mark.parametrize('kind',['single','account'])
def test_second_alias_cannot_reuse_pending_risk_capacity_at_the_actual_snapshot_owner(tmp_path,eurusd,kind):
    ledger,adapter,account,_,facts=native_facts(tmp_path,eurusd)
    _,first=command(ledger,facts,'first-pending-risk')
    receipt(ledger,first,status='ACCEPTED')
    b=other_context(ledger,adapter,account,facts,alias='second_alias')
    current=replace(account,account_alias=b.account_alias,
        funding_mark=replace(account.funding_mark,account_alias=b.account_alias),
        used_margin=D(0),free_margin=account.equity,margin_level_pct=None)
    service=producer(kind,ledger,adapter,current,b)
    now=NOW*1000+100
    if kind=='single':
        snapshot=service.snapshot(now_ms=now,quote_age_ms=0,strategy_id=intent().strategy_id)
    else:
        service.clock=lambda:now
        snapshot=service._snapshot_for(N(symbol='EURUSD',strategy_id=intent().strategy_id))
    assert snapshot.reconciliation_ok and not snapshot.preservation_blocks_new_risk, snapshot
    assert snapshot.open_positions==()
    grant=TradingMandate.from_mapping(mandate_dict(account_alias=b.account_alias,venue=adapter.venue,
        max_open_stop_risk='0.005',max_positions_per_instrument=10,max_total_positions=20))
    result=RiskAuthority(grant).evaluate_safe(intent(account_alias=b.account_alias,venue=adapter.venue),snapshot)
    assert result.decision.value=='REJECTED' and result.reason_code=='PORTFOLIO_HEAT',result
