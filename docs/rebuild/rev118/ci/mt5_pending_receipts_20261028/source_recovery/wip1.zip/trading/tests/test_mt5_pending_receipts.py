"""Original native pending acknowledgements, never invented fills or retries."""
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal as D
import json,time
import pytest
from fastapi.testclient import TestClient

from test_mql_native_function_bodies import ea
from vati.execution.base import OrderCommand,StopMode
from vati.execution.mt5_identity import Mt5Identity
from vati.execution.mt5_pull import BridgeQueue,Mt5PullAdapter,create_pull_app,sign_poll
from vati.risk.contracts import Direction,LossModel

KEY=b'p'*32


def command():
    return OrderCommand('fixture','0000007b'+'0'*56,'pending-original','mt5_ea','mt5','EURUSD',
        Direction.LONG,'MARKET',D('.00123456'),D('1.123456789012345'),D('1.12'),
        StopMode.VENUE,LossModel.STOP_DISTANCE,targets=(D('1.2'),),max_slippage=D('.0002')).sealed()


def test_actual_ea_pending_ack_keeps_original_order_and_no_invented_fill(ea,tmp_path):
    native=ea('entry-market-accepted')['results'][0]
    assert native['status']=='ACCEPTED' and native['sl_confirmed'] is True
    q=BridgeQueue(tmp_path/'receipt.sqlite')
    try:
        receipt=Mt5PullAdapter(q)._entry_receipt(command(),native,now_ms=1700000000000)
        assert receipt.status=='ACCEPTED' and receipt.broker_order_id=='11'
        assert receipt.filled_qty==0 and receipt.average_fill is None and receipt.broker_position_id==''
        assert receipt.protective_stop_confirmed and receipt.protective_stop_price==D('1.12')
        assert receipt.broker_time_unix_ms==0  # Original ack has no native clock.
    finally:q.close()


def test_real_signed_poll_sql_ack_reopen_and_expired_replay_keep_first_completion(ea,tmp_path):
    path=tmp_path/'bridge.sqlite';q=BridgeQueue(path);reopened=None
    now={'ms':1700000000000};native=ea('snapshot')['account'];cmd=command();counter={'n':0}
    app=create_pull_app(q,lambda alias:KEY if alias=='mt5_ea' else None,clock=lambda:now['ms'])
    def poll(client,results):
        counter['n']+=1;nonce='pending-'+str(counter['n']);ts=str(now['ms']//1000)
        body=json.dumps({'account':native,'positions':[],'orders':[],'results':results}).encode()
        return client.post('/ea/v1/mt5_ea/poll',content=body,headers={'content-type':'application/json',
            'x-van-ts':ts,'x-van-nonce':nonce,'x-van-signature':sign_poll(KEY,ts,nonce,'mt5_ea',body)})
    try:
        with TestClient(app) as client:
            assert poll(client,[]).status_code==200
            adapter=Mt5PullAdapter(q,clock=lambda:now['ms'],timeout_s=3,poll_s=.005,
                identity=Mt5Identity('12345678','broker-demo','USD',True))
            with ThreadPoolExecutor(max_workers=1) as pool:
                task=pool.submit(adapter.submit,cmd,now_ms=now['ms'])
                deadline=time.monotonic()+2
                while not q.native_entries('mt5_ea') and time.monotonic()<deadline:time.sleep(.005)
                offered=poll(client,[]);assert offered.status_code==200 and '|MARKET|' in offered.text
                cid=int(offered.text.split('|')[0]);now['ms']+=50
                response=ea('entry-market-accepted')['results'][0]|{'id':cid}
                assert poll(client,[response]).status_code==200
                receipt=task.result(timeout=3)
            assert receipt.status=='ACCEPTED' and receipt.filled_qty==0
            assert receipt.received_time_unix_ms==now['ms'] and receipt.broker_time_unix_ms==0
            now['ms']+=60000;reopened=BridgeQueue(path)
            recovered=Mt5PullAdapter(reopened,clock=lambda:now['ms']).recover_entry(cmd,now_ms=now['ms'])
            assert recovered==receipt and len(reopened.native_entries('mt5_ea'))==1
            assert Mt5PullAdapter(reopened,clock=lambda:now['ms']).submit(cmd,now_ms=now['ms'])==receipt
    finally:
        if reopened is not None:reopened.close()
        q.close()
