"""Actual signed entry protocol over explicit native SDK cash fixtures."""
from decimal import Decimal as D
import pytest

from test_mt5_expected_margin_worker import MarginSdk
from test_mt5_worker_funding import connection
from vati.execution.base import OrderCommand,StopMode
from vati.risk.contracts import Direction,LossModel


class EntryCashSdk(MarginSdk):
    def __init__(self,*,equity,credit,used,reported_free):
        super().__init__();self.entry_equity=equity;self.credit=credit
        self.entry_used=used;self.entry_reported_free=reported_free
    def account_info(self):
        a=super().account_info();a.equity=self.entry_equity;a.margin=self.entry_used
        a.margin_free=self.entry_reported_free;return a


def command(alias,*,intent='cash-entry',expiry=None):
    return OrderCommand(intent,'d'*64,intent,alias,'mt5','EURUSD',Direction.LONG,'MARKET',
        D('.10'),D('1.10008'),D('1.09800'),StopMode.VENUE,LossModel.STOP_DISTANCE,
        max_slippage=D('.0002'),expires_at_ms=expiry).sealed()


@pytest.mark.parametrize('facts',[{'equity':100.,'credit':95.,'used':0.,'reported_free':100.},
    {'equity':100.,'credit':0.,'used':90.,'reported_free':100.}])
def test_original_signed_entry_cannot_spend_credit_or_more_than_cash_free_capacity(tmp_path,facts):
    sdk,worker,adapter,now=connection(tmp_path,EntryCashSdk(**facts));sdk.margin_value=33.25
    receipt=adapter.submit(command(adapter.account_alias),now_ms=now['ms'])
    assert not sdk.sent,'actual native order_send was reached despite insufficient cash-backed margin'
    assert receipt.status=='REJECTED' and receipt.filled_qty==0


def test_original_signed_entry_with_sufficient_native_cash_retains_fill_and_protection(tmp_path):
    sdk,worker,adapter,now=connection(tmp_path,EntryCashSdk(equity=1000.,credit=0.,used=10.,reported_free=990.))
    receipt=adapter.submit(command(adapter.account_alias),now_ms=now['ms'])
    assert receipt.status=='FILLED' and receipt.filled_qty==D('.10') and receipt.protective_stop_confirmed
    assert len(sdk.sent)==1 and sdk.sent[0]['sl']==1.098
