"""Original pending terms cannot hide a higher current account-currency loss."""
from dataclasses import replace
from decimal import Decimal as D
from types import SimpleNamespace as N
import pytest

from conftest import NOW,intent,mandate_dict
from test_native_risk_history_inputs import native_facts
from test_native_risk_history_index import other_context
from test_physical_order_exposure import command,receipt
from test_physical_snapshot_producers import producer
from vati.risk import TradingMandate,RiskAuthority


@pytest.mark.parametrize('kind',['single','account'])
def test_actual_native_owner_revalues_pending_loss_with_higher_current_contract(tmp_path,eurusd,kind):
    ledger,adapter,account,_,original=native_facts(tmp_path,eurusd)
    _,first=command(ledger,original,'before-contract-change');receipt(ledger,first,status='ACCEPTED')
    b=other_context(ledger,adapter,account,original,alias='second_alias')
    current=replace(account,account_alias=b.account_alias,
        funding_mark=replace(account.funding_mark,account_alias=b.account_alias),
        used_margin=D(0),free_margin=account.equity,margin_level_pct=None)
    # Existing risk owner receives a changed current contract for this symbol;
    # no broker, native conversion or external account qualification is claimed.
    terms=replace(eurusd,tick_value=eurusd.tick_value*2)
    b=replace(b,symbol_contract=terms)
    owner=producer(kind,ledger,adapter,current,b);now=NOW*1000+100
    if kind=='single':facts=owner.snapshot(now_ms=now,quote_age_ms=0,strategy_id=intent().strategy_id)
    else:
        owner.clock=lambda:now
        facts=owner._snapshot_for(N(symbol='EURUSD',strategy_id=intent().strategy_id))
    assert facts.symbol_contract.tick_value==terms.tick_value
    assert facts.reconciliation_ok and not facts.preservation_blocks_new_risk and not facts.open_positions
    grant=TradingMandate.from_mapping(mandate_dict(account_alias=b.account_alias,
        max_open_stop_risk='0.012',max_positions_per_instrument=10,max_total_positions=20))
    result=RiskAuthority(grant).evaluate_safe(intent(account_alias=b.account_alias),facts)
    assert result.reason_code=='PORTFOLIO_HEAT' and result.decision.value=='REJECTED',result
