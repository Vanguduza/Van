"""The decision cycle (Rev 2 §61): one pass per bar/tick for one instrument.

   VERIFY DATA → MARKET STATE → OPPORTUNITY → RISK AUTHORITY → ROUTER →
   PROTECT → (marks) → RECONCILE → TCA → REVIEW → VTIL PROPOSE

The same class drives backtests (PaperAdapter over historical bars) and live
sessions (real adapter over a feed), which is what makes backtest-to-live parity
a property of the code rather than a hope."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from contextlib import contextmanager
from decimal import Decimal
from typing import Callable, Optional, Sequence

from vati.arbiter import OpportunityEngine
from vati.core.canonical import canonical_hash
from vati.core.events import EventKind, make_event
from vati.core.ledger import Ledger
from vati.execution.base import StopMode, VenueAdapter
from vati.execution.policy import ExecutionBucket, ExecutionPolicyEngine
from vati.execution.protection import ProtectionManager
from vati.execution.pretrade import MarketReference, PreTradeControls
from vati.execution.route_registry import RouteRegistry
from vati.execution.style_selector import ExecutionStyleSelector, LiquidityView
from vati.execution.router import ExecutionRouter, RouterError
from vati.execution.review import review_trade, closed_trade_pnl, initial_risk_from_ledger, STRATEGY_LEARNING_OUTCOMES
from vati.execution.tca import compute_tca
from vati.execution.reconciliation import LedgerPosition, reconcile
from vati.intelligence.events import EventMatrix, EventWindowState
from vati.intelligence.market_state import MarketState, build_market_state
from vati.intelligence.regimes import RegimeEngine
from vati.learning.episodes import LessonStore, lesson_from_verdict
from vati.execution.review import native_economic_maturity
from vati.learning.hooks import LearningHooks, to_payload
from vati.lifecycle.scale_policy import (
    Adjustment, AdjustmentPolicyRegistry, PositionAdjustmentEngine, ScalePolicyRegistry,
)
from vati.lifecycle.thesis import ThesisEngine, ThesisInputs, thesis_from_capsule
from vati.lifecycle.trade_health import PositionHealthInputs, TradeHealthEngine
from vati.cognition.attribution import DecisionQualityInputs, DecisionQualityLedger
from vati.market_data.bars import Bar
from vati.market_data.calendars import MarketCalendar
from vati.observability import metrics
from vati.risk.lockouts import DRAWDOWN_RESUME_EVENT, LockoutPolicy, LossStreakGovernor, relative_top_state, restore_peak_equity, restore_equity_baselines
from vati.risk.history_scope import RiskHistoryScopeError
from vati.risk import Decision, KillSwitch, MarketIntegrityState, OpenPosition, RiskAuthority, RiskSnapshot, SymbolContract, TradingMandate
from vati.risk.contracts import Direction, KillSwitchTrigger, LossModel, StrategyState
from vati.risk.serde import intent_to_dict, snapshot_to_dict
from vati.strategies.base import StrategyContext
from vati.arbiter.strategy_arbiter import ACTIVE_STATES
from vati.vtil import AdmissionLedger

ZERO = Decimal("0")


@dataclass
class SessionConfig:
    symbol: str
    base: str
    quote: str
    venue: str
    account_alias: str
    contract: SymbolContract
    mandate_dict: dict
    #: Explicit market-state identity. Production services always set this from
    #: ServiceConfig; UNKNOWN is retained only for legacy/research callers.
    timeframe: str = "UNKNOWN"
    warmup_bars: int = 60
    max_quote_age_ms: int = 5000
    targets_from_signal: bool = True
    time_in_force: str = "DAY"
    session_id: str = "session"
    activation_id: str = "vtil-act-unresolved"
    software_stops: bool = False   # ZSE: no venue stop


@dataclass
class CycleResult:
    bar_end_ms: int
    state_hash: str
    decision: str            # NO_TRADE | WAIT | SKIP | REJECTED:<code> | APPROVED | REDUCED | ROUTER_REFUSED
    reason: str
    approved_size: Decimal = ZERO


class DecisionCycle:
    def __init__(self, *, cfg: SessionConfig, adapter: VenueAdapter, ledger: Ledger, engine: OpportunityEngine, cost_fn: Callable[[MarketState], Decimal],
                 calendar: MarketCalendar, events: EventMatrix, regime_engine: Optional[RegimeEngine] = None, kill_switch: Optional[KillSwitch] = None,
                 admission: Optional[AdmissionLedger] = None, ctx_fn: Optional[Callable[[MarketState, Decimal], StrategyContext]] = None,
                 learning: Optional[LearningHooks] = None, runtime_lease=None, lease_clock=None,
                 lease_permission: Callable[[], bool] = lambda: True, research_environment=None) -> None:
        self.cfg, self.adapter, self.ledger, self.engine, self.cost_fn, self.calendar, self.events = cfg, adapter, ledger, engine, cost_fn, calendar, events
        self.learning = learning
        self.runtime_lease = runtime_lease
        self._lease_clock, self._lease_permission = lease_clock, lease_permission
        if runtime_lease is not None and not callable(lease_clock):
            raise ValueError("native runtime lease requires a current clock")
        self.regime = regime_engine or RegimeEngine()
        self.kill = kill_switch or KillSwitch()
        self.mandate = TradingMandate.from_mapping(cfg.mandate_dict)
        from vati.learning.runtime_cohort import execution_cohort_for
        self.execution_cohort = execution_cohort_for(adapter, self.mandate.mode,
            research_environment=research_environment)
        if learning is not None and learning.environment is not self.execution_cohort.environment:
            raise ValueError('learning cohort differs from the actual runtime execution cohort')
        if self.mandate.temperament_enabled:
            raise RuntimeError("DecisionCycle single-symbol path does not admit temperament profiles")
        self.authority = RiskAuthority(self.mandate)
        self.protection = ProtectionManager()
        self.routes = RouteRegistry(ledger=ledger)
        self.routes.refresh(
            account_alias=cfg.account_alias,
            adapter_id=cfg.venue,
            contracts={cfg.symbol.upper(): cfg.contract},
            now_ms=0,
            source="decision_cycle_init",
        )
        self.pretrade = PreTradeControls(routes=self.routes, ledger=ledger)
        self.style_selector = ExecutionStyleSelector(ledger=ledger)
        self.execution_policy = ExecutionPolicyEngine()
        self.router = ExecutionRouter(
            ledger=ledger, adapters={cfg.venue: adapter}, kill_switch=self.kill,
            protection=self.protection, route_registry=self.routes,
            lease_fence=(lambda epoch: lease_permission() and runtime_lease.fence(epoch, now_ms=lease_clock(), min_validity_ms=2_000)) if runtime_lease else None,
            lease_submission_guard=self._runtime_submission_guard if runtime_lease else None,
            pretrade_controls=self.pretrade, style_selector=self.style_selector,
            enforce_rev51_controls=True, clock=lease_clock,
            current_risk_facts_provider=self._current_risk_facts,
            current_risk_authority=self.authority)
        self.admission = admission or AdmissionLedger()
        self.ctx_fn = ctx_fn or (lambda st, cost: StrategyContext(round_trip_cost_pct=cost))
        self.peak_equity = ZERO
        self.day_start_equity = ZERO
        self.week_start_equity = ZERO
        self._period_baselines_restored = False
        self.consecutive_losses = 0
        # P1-TRADE-RISK-005: lockouts and the high-water mark are rebuilt from the ledger,
        # so a restart can neither reset a losing-streak lock nor re-baseline the peak.
        self.streaks = LossStreakGovernor.rebuild(LockoutPolicy(self.mandate.max_consecutive_losses), ledger.iter(), account_alias=cfg.account_alias)
        try:
            restored_peak = restore_peak_equity(ledger.iter(), account_alias=cfg.account_alias)
        except RiskHistoryScopeError:
            restored_peak = None
        if self.streaks.recovery_issue or (self.learning is not None and self.learning.recovery_issue):
            self.kill.trip(KillSwitchTrigger.RECONCILIATION_FAILURE, 0)
        if restored_peak is not None and restored_peak > ZERO:
            self.peak_equity = restored_peak
        self.integrity = MarketIntegrityState.NORMAL
        self.reviews: list = []
        self._closed_seen = 0
        self._entries: dict[str, dict] = {}   # trade_intent_id → {entry, stop, direction, strategy_id, cost_pct}
        self.recovery_unresolved: tuple[str, ...] = ()
        self.unresolved_entry_attempts: set[str] = set()
        # GAP-F-003. Active-trade intelligence on the single-symbol runtime.
        # Same components the account runtime uses, so backtest-to-live parity
        # covers the thesis path too rather than only the order path.
        self.thesis = ThesisEngine(ledger=ledger)
        self.trade_health = TradeHealthEngine(ledger=ledger)
        self.adjustment_policies = AdjustmentPolicyRegistry()
        self.adjustments = PositionAdjustmentEngine(
            ledger=ledger, policies=self.adjustment_policies)
        self.scale_policies = ScalePolicyRegistry()
        learning_scope = self.learning.resolver(ledger).scope if self.learning is not None else None
        self.decision_quality = DecisionQualityLedger(ledger=ledger, scope=learning_scope)
        self.decision_quality.restore_from_ledger(ledger)
        self.lessons = LessonStore(ledger=ledger, scope=learning_scope)
        self.lessons.restore_from_ledger(ledger)
        self.engine.lessons = self.lessons
        if self.learning is not None and self.learning.recovery_issue:
            self.kill.trip(KillSwitchTrigger.RECONCILIATION_FAILURE, 0)
        #: Headline ingress (events/news_ingress.py) when the runtime has one.
        #: Reduce-only; the calendar keeps the blackout authority.
        self.news = None
        self.proposals: list = []

    # --------------------------------------------------------------- helpers
    def _current_risk_facts(self, intent, *, now_ms, market_reference):
        from vati.execution.risk_refresh import CurrentRiskFacts
        age=market_reference.mark_age_ms if market_reference is not None else -1
        snapshot=self.snapshot(now_ms=now_ms,quote_age_ms=age,strategy_id=intent.strategy_id)
        return CurrentRiskFacts(snapshot,self._risk_snapshot_ms)

    @contextmanager
    def _runtime_submission_guard(self, epoch):
        if not self._lease_permission():
            yield False
            return
        with self.runtime_lease.submission_guard(epoch, now_ms=self._lease_clock()) as valid:
            # Recheck native stop/renewal policy after acquiring authority. A
            # control arriving after the early check must still block entry.
            yield valid and self._lease_permission()

    def _log(self, kind: EventKind, payload: dict, *, now_ms: int, corr: str = "") -> None:
        if kind in {EventKind.SESSION, EventKind.RISK_DECISION}:
            payload = {**payload, "account_alias": self.cfg.account_alias}
        if kind is EventKind.RISK_DECISION:
            payload = {**payload, "execution_cohort": self.execution_cohort.as_dict()}
        if kind is EventKind.CAPSULE_STATE and self.learning is not None:
            payload = {**payload, "account_alias": self.cfg.account_alias,
                       "learning_environment": self.learning.environment.value}
        self.ledger.append(make_event(kind, "vati-cycle", payload, event_time_ms=now_ms, received_time_ms=now_ms, correlation_id=corr or self.cfg.session_id))

    def _open_positions(self, *, include_pending=True) -> tuple[OpenPosition, ...]:
        from vati.risk.positions import project_open_position
        out = list(DecisionCycle._legacy_pending_positions(self)) if include_pending else []
        c = self.cfg.contract
        for p in self.adapter.positions():
            stop = p.stop_price if p.stop_price is not None else self.protection.rules.get(p.position_id, None)
            stop_price = stop.stop if hasattr(stop, "stop") else stop
            out.append(project_open_position(symbol=p.symbol, direction=p.direction,
                quantity=p.quantity, entry=p.entry_price, stop=stop_price,
                contract=c, loss_model=p.loss_model,broker_position_id=p.position_id))
        return tuple(out)

    def _legacy_pending_positions(self):
        from vati.risk.positions import project_open_position
        out=[]
        c=self.cfg.contract
        # Resting entries reserve their worst-case risk until they fill or expire.
        for row in self._entries.values():
            if row.get("pending") and row.get("stop") is not None:
                out.append(project_open_position(symbol=row['symbol'], direction=row['direction'],
                    quantity=row['pending_quantity'], entry=row['entry'], stop=row['stop'],
                    contract=c, loss_model=c.loss_model))
        return tuple(out)

    def _reconciliation_ok(self, *, account_verified: bool) -> bool:
        """P0-TRADE-002 — this was hardcoded True, so RECONCILIATION_FAILED could not fire.

        Reconciled per bar against what the venue reports now, not once at startup. The
        ledger positions come from the entries this cycle actually opened, which is the
        only set the cycle can speak for; a position the venue holds that this cycle never
        opened is an orphan, and `reconcile` already treats it as blocking.
        """
        if self.recovery_unresolved or self.unresolved_entry_attempts:
            return False
        ledger_positions = [
            LedgerPosition(
                trade_intent_id=iid,
                symbol=self.cfg.symbol,
                quantity=entry.get("quantity", ZERO),
                stop_price=entry.get("stop"),
                software_stop=bool(self.cfg.software_stops),
            )
            for iid, entry in self._entries.items()
            if entry.get("open", True)
        ]
        try:
            report = reconcile(
                ledger_positions, self.adapter.positions(), account_verified=account_verified
            )
        except Exception:  # noqa: BLE001 — a reconciliation that cannot run has not passed
            return False
        return report.permit_new_orders

    def _risk_store_ok(self) -> bool:
        """P0-TRADE-002 — hardcoded True, so RISK_STORE_UNAVAILABLE could not fire.

        The risk store is the ledger: without it the authority cannot know what is open,
        what has been lost today, or whether this decision has already been made. A ledger
        that will not answer is a risk store that is unavailable.

        Incremental (P1-TRADE-LEDGER-001): a full verify from genesis on every decision
        made decision latency grow with the ledger. `verify_incremental` checks only the
        rows written since the last check, against an anchor that cannot move unnoticed,
        and re-verifies from genesis at least hourly.
        """
        try:
            return bool(self.ledger.verify_incremental()[0])
        except Exception:  # noqa: BLE001 — an unreadable ledger is not a healthy one
            return False

    def _tier1_blackout(self, *, now_ms: int) -> bool:
        """P0-TRADE-002 — hardcoded False, so EVENT_BLACKOUT could not fire.

        The event matrix already computes this and the market state already carries it;
        nothing joined the two to the snapshot the authority reads.
        """
        try:
            window, _event = self.events.state_at(now_ms, self.cfg.base, self.cfg.quote)
        except Exception:  # noqa: BLE001 — an event matrix that cannot answer fails closed
            return True
        return window in (EventWindowState.PRE_BLACKOUT, EventWindowState.POST_BLACKOUT)

    def _drawdown_top_state(self):
        """Highest promotion state among the strategies this mandate allows."""
        states = []
        for sid in self.mandate.allowed_strategies:
            try:
                states.append(self.engine.registry.get(sid).state)
            except Exception:  # noqa: BLE001 — a strategy not in the registry has no state
                continue
        return relative_top_state(states)

    def restore_risk_baselines(self, now_ms: int) -> None:
        if self._period_baselines_restored:
            return
        try:
            peak, day, week = restore_equity_baselines(self.ledger.iter(), now_ms, account_alias=self.cfg.account_alias)
        except RiskHistoryScopeError as exc:
            self.streaks.recovery_issue = str(exc)
            self.kill.trip(KillSwitchTrigger.RECONCILIATION_FAILURE, now_ms)
        else:
            if peak is not None:
                self.peak_equity = max(peak, self.peak_equity)
            if day is not None and self.day_start_equity == ZERO:
                self.day_start_equity = day
            if week is not None and self.week_start_equity == ZERO:
                self.week_start_equity = week
        self._period_baselines_restored = True

    def snapshot(self, *, now_ms: int, quote_age_ms: int, strategy_id: str = "") -> RiskSnapshot:
        started_ms = now_ms
        self.restore_risk_baselines(now_ms)
        acct = self.adapter.sync_account()
        hb = self.adapter.heartbeat(now_ms=now_ms)
        positions = self._open_positions(include_pending=False)
        reconciled = self._reconciliation_ok(account_verified=acct.verified)
        store_ok = self._risk_store_ok()
        if callable(getattr(self, "_lease_clock", None)):
            now_ms = max(now_ms, self._lease_clock())
        self._risk_snapshot_ms = now_ms
        if quote_age_ms >= 0:
            quote_age_ms += now_ms - started_ms
        from vati.funding.risk_fence import funding_risk_fence
        from vati.funding.mt5_runtime import capture_cached_mt5
        native_capture = capture_cached_mt5(self.ledger, acct, now_ms=now_ms)
        funding = funding_risk_fence(self.ledger, self.adapter, acct, now_ms=now_ms)
        from vati.risk.account_context import context_with_funding_hold
        native_context, funding = context_with_funding_hold(self.ledger, self.adapter, acct, funding,
            now_ms=now_ms, mt5_capture=native_capture)
        # A held observation remains visible, but cannot seed or increase the
        # baselines used by later decisions after native evidence recovers.
        basis_ref = None
        pending_risk = ()
        if funding.available and native_context is not None:
            from vati.risk.physical_runtime import project_native_risk
            from vati.funding.risk_fence import FundingRiskFence
            basis_ref, values, streaks, issue = project_native_risk(self, self.ledger,
                native_context, self.streaks.policy, now_ms=now_ms, producer='vati-cycle')
            if issue:
                funding = FundingRiskFence(False, issue)
            else:
                self.peak_equity, self.day_start_equity, self.week_start_equity = values.peak, values.day, values.week
                self.streaks = streaks
                from vati.risk.physical_pending import project_pending_risk
                pending_risk, issue = project_pending_risk(self,self.ledger,native_context,positions,now_ms=now_ms)
                if issue:
                    funding = FundingRiskFence(False,issue)
        elif funding.available:
            if self.peak_equity == ZERO:
                self.peak_equity = acct.equity
            if self.day_start_equity == ZERO:
                self.day_start_equity = acct.equity
            if self.week_start_equity == ZERO:
                self.week_start_equity = acct.equity
            self.peak_equity = max(self.peak_equity, acct.equity)
        streak = self.streaks.verdict(strategy_id, now_ms) if strategy_id or self.streaks.recovery_issue else None
        if native_context is None:
            positions += self._legacy_pending_positions()
        return RiskSnapshot(now_unix=now_ms // 1000, account_alias=acct.account_alias, account_verified=acct.verified, equity=acct.equity, balance=acct.balance,
                            peak_equity=self.peak_equity, day_start_equity=self.day_start_equity, week_start_equity=self.week_start_equity,
                            consecutive_losses=streak.losses if streak else 0,
                            loss_streak_lock=(self.learning.recovery_issue if self.learning is not None else "") or (streak.lock if streak else ""),
                            loss_streak_multiplier=streak.risk_multiplier if streak else Decimal("1"),
                            drawdown_top_state=self._drawdown_top_state(),
                            open_positions=positions, symbol_contract=self.cfg.contract, quote_age_ms=quote_age_ms, max_quote_age_ms=self.cfg.max_quote_age_ms,
                            broker_connected=hb.connected,
                            reconciliation_ok=reconciled,
                            clock_sync_ok=abs(hb.server_offset_ms) < 2000,
                            risk_store_ok=store_ok,
                            market_integrity=self.integrity,
                            tier1_event_blackout_active=self._tier1_blackout(now_ms=now_ms),
                            margin_level_pct=acct.margin_level_pct,
                            free_margin=acct.free_margin, used_margin=acct.used_margin,
                            native_account_context=native_context,
                            native_risk_basis_ref=basis_ref,
                            pending_risk_commitments=pending_risk,
                            preservation_blocks_new_risk=not funding.available,
                            preservation_reason=funding.reason,
                            kill_switch_triggers=frozenset(self.kill.active))

    def roll_day(self, equity: Decimal, *, new_week: bool = False) -> None:
        self.day_start_equity = equity
        if new_week:
            self.week_start_equity = equity

    # --------------------------------------------------------------- one step
    def step(self, bars: Sequence[Bar], *, now_ms: int, last_quote_ms: int) -> CycleResult:
        cfg = self.cfg
        if len(bars) < cfg.warmup_bars:
            return CycleResult(bars[-1].end_ms if bars else now_ms, "", "NO_TRADE", "warmup")
        state = build_market_state(symbol=cfg.symbol, base=cfg.base, quote=cfg.quote, bars=bars, regime_engine=self.regime, calendar=self.calendar, events=self.events,
                                   integrity=self.integrity, now_ms=now_ms, last_quote_ms=last_quote_ms, activation_id=cfg.activation_id,
                                   timeframe=cfg.timeframe)
        cost = self.cost_fn(state)
        self._log(EventKind.MARKET_STATE, {"state": state.as_dict(), "cost_pct": str(cost)}, now_ms=now_ms)
        ctx = self.ctx_fn(state, cost)
        regime_label = ctx.zse.currency_regime.value if ctx.zse is not None else state.regime.trend.value
        oa = self.engine.assess(state, ctx, regime_label=state.regime.trend.value, currency_regime_label=(ctx.zse.currency_regime.value if ctx.zse is not None else None),
                                account_alias=cfg.account_alias, venue=cfg.venue,
                                # P0-TRADE-005 — this was f"{cfg.session_id}:{state.as_of_ms}",
                                # and session_id embeds the process start timestamp. A crash
                                # and restart on the same bar produced a different key, so
                                # neither the in-process set nor the ledger-seeded router set
                                # recognised the duplicate and the order could be placed twice.
                                # The seed is now the account, the symbol and the bar, all of
                                # which are the same on both sides of a restart.
                                idempotency_seed=f"{cfg.account_alias}:{cfg.symbol}:{state.as_of_ms}")
        self._log(EventKind.OPPORTUNITY_ASSESSMENT, {"symbol": cfg.symbol, "decision": oa.decision, "reason": oa.abstain_reason, "candidates": list(oa.candidates), "assessment_hash": oa.assessment_hash}, now_ms=now_ms)
        metrics.inc("vati_cycles_total", symbol=cfg.symbol)
        if oa.intent is None:
            return CycleResult(state.as_of_ms, state.state_hash, oa.decision, oa.abstain_reason)
        intent = oa.intent
        snap = self.snapshot(now_ms=now_ms, quote_age_ms=state.quote_age_ms, strategy_id=intent.strategy_id)
        now_ms = max(now_ms, getattr(self, "_risk_snapshot_ms", now_ms))
        decision = self.authority.evaluate_safe(intent, snap)
        from vati.risk.mandate_source import capture_mandate_source
        original_policy = capture_mandate_source(self.authority.mandate, cfg.mandate_dict, now_ms=now_ms)
        self._log(EventKind.RISK_DECISION, {"inputs": {"intent": intent_to_dict(intent), "snapshot": snapshot_to_dict(snap),
            "mandate": cfg.mandate_dict, "original_mandate_source": original_policy}, "decision": decision.to_dict()}, now_ms=now_ms, corr=intent.trade_intent_id)
        metrics.inc("vati_decisions_total", outcome=decision.decision.value)
        if decision.decision is Decision.REJECTED:
            return CycleResult(state.as_of_ms, state.state_hash, f"REJECTED:{decision.reason_code}", decision.reason_detail)
        # P1-TRADE-007 and P4-TRADE-009 — this used to be an empty assignment, a loop
        # with a bare `pass`, and a single target re-derived from expected_gross_move_pct,
        # which discarded whatever exit plan the winning strategy had actually produced.
        # The assessment now carries the signal's own targets.
        targets = tuple(oa.targets)
        if not targets and intent.expected_gross_move_pct is not None:
            # A strategy that declares an expected move and no explicit target still gets
            # one, which is the behaviour the old code always applied. It is a fallback
            # now rather than the rule.
            t = intent.entry * (Decimal(1) + intent.expected_gross_move_pct) if intent.direction is Direction.LONG else intent.entry * (Decimal(1) - intent.expected_gross_move_pct)
            targets = (t,)
        try:
            # Refresh route truth at the decision instant so the registry cannot
            # age out while the session continues to run.
            self.routes.refresh(
                account_alias=cfg.account_alias, adapter_id=cfg.venue,
                contracts={cfg.symbol.upper(): cfg.contract}, now_ms=now_ms,
                source="decision_cycle",
            )
            execution_bucket = ExecutionBucket(
                broker=cfg.venue,
                account_alias=cfg.account_alias,
                symbol=cfg.symbol,
                session=state.session.value,
                volatility_bucket=state.regime.vol.value,
                event_proximity=state.event_window.value,
                direction=intent.direction.value,
            )
            policy_decision = self.execution_policy.select(
                candidate_id=intent.trade_intent_id,
                bucket=execution_bucket,
                event_state=state.event_window.value,
                entry_type=oa.entry_type,
            )
            prepared_setup=None
            if intent.stop is not None:
                from vati.app.entry_setup import prepare_setup
                prepared_setup=prepare_setup(self,intent,decision,state,targets,now_ms=now_ms)
            # Durable before dispatch: restart may not invent the old setup
            # from today's state, capsule, costs or policy.
            entry_context = {
                'symbol':cfg.symbol, 'strategy_id':intent.strategy_id,
                'direction':intent.direction.value, 'cost_pct':str(cost),
                'original_approved_risk_pct':str(decision.approved_risk_pct),
                'session':state.session.value, 'regime':state.regime.trend.value,
                'event_window':state.event_window.value,
                'opened_in_blackout':state.event_window.value in ('PRE_BLACKOUT','POST_BLACKOUT'),
                'event_certified':bool(intent.is_event_certified),
                'execution_policy_applied':True, 'targets':[str(t) for t in targets],
                'prepared_setup':prepared_setup,
            }
            self._log(EventKind.SESSION,{'event':'ENTRY_CONTEXT','schema':'vati.entry-context/2',
                'decision_hash':decision.decision_hash,'context':entry_context,
                'context_hash':canonical_hash(entry_context)},now_ms=now_ms,corr=intent.trade_intent_id)
            rec = self.router.execute(
                intent, decision, self.mandate, now_ms=now_ms,
                stop_mode=StopMode.SOFTWARE if cfg.software_stops else StopMode.VENUE,
                targets=targets, time_in_force=cfg.time_in_force, entry_type=oa.entry_type,
                execution_policy_decision=policy_decision,
                lease_epoch=self.runtime_lease.epoch if self.runtime_lease else None,
                market_reference=MarketReference(
                    last_price=state.features.close,
                    mark_age_ms=snap.quote_age_ms,
                    max_mark_age_ms=cfg.max_quote_age_ms,
                ),
                liquidity=LiquidityView(),
            )
        except Exception as exc:
            from vati.app.entry_recovery import command_outcome_unconfirmed
            if command_outcome_unconfirmed(self,intent.trade_intent_id):
                rec=None  # caller failure is not a fabricated provider receipt
            elif isinstance(exc,RouterError):
                self._log(EventKind.SESSION, {"router_refused": str(exc)}, now_ms=now_ms, corr=intent.trade_intent_id)
                return CycleResult(state.as_of_ms, state.state_hash, "ROUTER_REFUSED", str(exc), decision.approved_size)
            else:
                raise
        uncertain=rec is None or rec.status in {'UNKNOWN','PARTIAL'}
        if uncertain or (rec.status == "ACCEPTED" and rec.reject_reason == "PENDING" and rec.filled_qty == ZERO):
            # P1-TRADE-EXEC-004: a resting entry (an untriggered STOP, a LIMIT away from the
            # market) is not a position. It reserves its worst-case risk until it fills or
            # expires (_open_positions), and is excluded from venue reconciliation.
            self._entries[intent.trade_intent_id] = {
                "pending": True, "open": False, "entry": intent.entry, "stop": intent.stop,
                "direction": intent.direction, "strategy_id": intent.strategy_id, "cost_pct": cost,
                "decision_price": intent.entry, "quantity": ZERO, "pending_quantity": decision.approved_size,
                "broker_order_id": rec.broker_order_id if rec is not None else '', "broker_position_id": "", "opened_ms": now_ms,
                "targets": tuple(targets), "original_approved_risk_pct": decision.approved_risk_pct,
                "protective_stop_confirmed": False, "event_certified": bool(intent.is_event_certified),
                "execution_policy_applied": True, "regime": state.regime.trend.value,
                "session": state.session.value, "symbol": cfg.symbol,
                "opened_in_blackout": state.event_window.value in ("PRE_BLACKOUT", "POST_BLACKOUT"),
                "best_price": intent.entry, "worst_price": intent.entry,
                "event_window": state.event_window.value,
                # In memory only: the fill seals the thesis from the approval that admitted it.
                "_approval": (intent, decision, state, tuple(targets)),
                "_prepared_setup": prepared_setup,
            }
            if uncertain:
                self._entries[intent.trade_intent_id]['recovery_context_complete']=False
                self.unresolved_entry_attempts.add(intent.trade_intent_id)
                self._log(EventKind.SESSION,{'event':'ENTRY_UNKNOWN','entry_type':oa.entry_type,
                    'reason':rec.reject_reason if rec is not None else 'native dispatcher outcome unconfirmed',
                    'approved_quantity':str(decision.approved_size)},
                    now_ms=now_ms,corr=intent.trade_intent_id)
                return CycleResult(state.as_of_ms,state.state_hash,
                    'PARTIAL' if rec is not None and rec.status=='PARTIAL' else 'UNKNOWN',
                    'original native entry outcome unresolved; reconciliation required',decision.approved_size)
            self._log(EventKind.SESSION, {"event": "ENTRY_RESTING", "entry_type": oa.entry_type, "order": rec.broker_order_id},
                      now_ms=now_ms, corr=intent.trade_intent_id)
            return CycleResult(state.as_of_ms, state.state_hash, decision.decision.value, "pending", decision.approved_size)
        if rec.status in ("FILLED", "PARTIAL", "ACCEPTED", "OWNER_EXECUTED"):
            entry_price = rec.average_fill or intent.entry
            self._entries[intent.trade_intent_id] = {
                "entry": entry_price, "stop": intent.stop, "direction": intent.direction,
                "strategy_id": intent.strategy_id, "cost_pct": cost,
                "decision_price": intent.entry,
                "quantity": rec.filled_qty, "fees": rec.fees,
                "_prepared_setup": prepared_setup,
                "broker_position_id": rec.broker_position_id,
                "opened_ms": now_ms,
                "best_price": entry_price, "worst_price": entry_price,
                "original_approved_risk_pct": decision.approved_risk_pct,
                "protective_stop_confirmed": bool(
                    rec.protective_stop_confirmed or cfg.software_stops),
                "opened_in_blackout": state.event_window.value in (
                    "PRE_BLACKOUT", "POST_BLACKOUT"),
                "event_certified": bool(intent.is_event_certified),
                "execution_policy_applied": True,
                "regime": state.regime.trend.value,
                "session": state.session.value,
                "symbol": cfg.symbol,
            }
            self._seal_thesis(intent, decision, state, targets, entry_price, now_ms)
            self._record_tca(rec, intent.direction, cost, state.session.value, state.event_window.value, now_ms=now_ms)
        if rec.status in {"REJECTED","CANCELLED","EXPIRED"}:
            return CycleResult(state.as_of_ms,state.state_hash,rec.status,rec.reject_reason,decision.approved_size)
        return CycleResult(state.as_of_ms, state.state_hash, decision.decision.value, "", decision.approved_size)

    # ------------------------------------------------- owner-signed recovery (A4)
    def reset_loss_streak(self, scope: str, *, owner_signature_ref: str, authority, now_ms: int) -> None:
        """Clear a losing-streak suspension. `scope` is a strategy id or ACCOUNT_SCOPE."""
        verified = authority.verify(owner_signature_ref, act="loss-streak-reset", subject=f"{self.cfg.account_alias}:{scope}", now_unix=now_ms // 1000)
        metadata = self._direct_native_control_metadata(owner_signature_ref, verified, now_ms)
        if metadata:
            with self._direct_native_control_writer(verified, now_ms) as applied_ms:
                self._refuse_reused_native_control(owner_signature_ref)
                self._log(EventKind.SESSION, {"event":"LOSS_STREAK_RESET", "scope":scope,
                    "owner_signature_ref":owner_signature_ref, **metadata}, now_ms=applied_ms)
            self._restore_direct_native_control(metadata, applied_ms)
        else:
            self._log(EventKind.SESSION, {**self.streaks.reset(scope), "owner_signature_ref": owner_signature_ref}, now_ms=now_ms)

    def resume_after_drawdown(self, *, owner_signature_ref: str, authority, now_ms: int) -> None:
        """Owner decision to resume after the suspending drawdown tier: re-baseline the peak."""
        verified = authority.verify(owner_signature_ref, act="drawdown-resume", subject=self.cfg.account_alias, now_unix=now_ms // 1000)
        account = self.adapter.sync_account()
        from vati.funding.mt5_runtime import capture_cached_mt5
        from vati.funding.risk_fence import funding_risk_fence
        capture_cached_mt5(self.ledger, account, now_ms=now_ms)
        funding = funding_risk_fence(self.ledger, self.adapter, account, now_ms=now_ms)
        if not funding.available:
            raise ValueError('drawdown baseline unavailable: ' + funding.reason)
        metadata = self._direct_native_control_metadata(owner_signature_ref, verified, now_ms, account=account)
        equity = account.equity
        old = self.peak_equity
        if metadata:
            with self._direct_native_control_writer(verified, now_ms) as applied_ms:
                self._refuse_reused_native_control(owner_signature_ref)
                self._log(EventKind.SESSION, {"event":DRAWDOWN_RESUME_EVENT,
                    "old_peak_equity":str(old),"new_peak_equity":str(equity),
                    "owner_signature_ref":owner_signature_ref, **metadata}, now_ms=applied_ms)
            self._restore_direct_native_control(metadata, applied_ms)
            return
        self.peak_equity = equity
        self._log(EventKind.SESSION, {"event": DRAWDOWN_RESUME_EVENT, "old_peak_equity": str(old), "new_peak_equity": str(equity),
                                      "owner_signature_ref": owner_signature_ref}, now_ms=now_ms)

    def _direct_native_control_metadata(self, token, verified, now_ms, *, account=None):
        from vati.execution.ctrader.adapter import CtraderAdapter
        from vati.execution.mt5_bridge import Mt5BridgeAdapter
        from vati.execution.mt5_pull import Mt5PullAdapter
        if not isinstance(self.adapter, (CtraderAdapter,Mt5BridgeAdapter,Mt5PullAdapter)):
            return {}
        from vati.app.runtime_control_actor import _native_control_metadata
        from vati.risk.control_archive import archive_verified_control
        metadata = _native_control_metadata(self, account or self.adapter.sync_account(), now_ms)
        if 'native_account_context' not in metadata:
            raise ValueError('native owner control source unavailable; no effect applied')
        metadata['original_owner_control'] = archive_verified_control(token, verified)
        return metadata

    def _refuse_reused_native_control(self, token):
        if any(e.payload.get('owner_signature_ref') == token for e in self.ledger.iter(EventKind.SESSION)
                if e.payload.get('event') in {'LOSS_STREAK_RESET',DRAWDOWN_RESUME_EVENT}):
            raise ValueError('original native owner control already applied')

    @contextmanager
    def _direct_native_control_writer(self, verified, now_ms):
        from contextlib import nullcontext
        from vati.core.file_lock import exclusive_state_lock
        binding = verified._verified_key_binding
        issuer = exclusive_state_lock(binding.registry_path) if binding.registry_path else nullcontext()
        with issuer, self.ledger.atomic():
            applied_ms = max(now_ms, self._lease_clock()) if callable(getattr(self,'_lease_clock',None)) else now_ms
            if not binding.is_current() or applied_ms//1000 >= verified.expires_at_unix:
                raise ValueError('native owner control expired or its original issuer changed before apply')
            yield applied_ms

    def _restore_direct_native_control(self, metadata, now_ms):
        from vati.risk.contracts import NativeAccountRiskContext
        from vati.risk.physical_runtime import PhysicalRiskRuntime
        context = NativeAccountRiskContext(**metadata['native_account_context'])
        runtime = PhysicalRiskRuntime(self.ledger, context, self.streaks.policy, now_ms=now_ms)
        self._physical_risk_runtime = runtime
        self.streaks = runtime.streaks
        values = runtime.book.projection(now_ms)
        if values.peak is not None:
            self.peak_equity = values.peak

    # ------------------------------------------------------- marks and exits
    def mark(self, bid: Decimal, ask: Decimal, *, now_ms: int) -> None:
        cfg = self.cfg
        # PROTECT stage. Thesis assessment runs before exits are applied, so an
        # invalidated claim is acted on in the same mark rather than waiting for
        # a stop that may be further away than the reason for holding.
        self._review_open_theses(bid, ask, now_ms=now_ms)
        receipts = list(self.router.apply_exits(cfg.venue, cfg.symbol, bid, ask, now_ms=now_ms))
        if hasattr(self.adapter, "mark"):
            receipts += self.adapter.mark(cfg.symbol, bid, ask, now_ms=now_ms)  # type: ignore[attr-defined]
        for r in receipts:
            row = self._entries.get(r.trade_intent_id)
            if row is not None and row.get("pending"):
                self._settle_pending(r, row, now_ms=now_ms)
                continue
            if r.status == "FILLED" and r.trade_intent_id in self._entries and r.reject_reason not in ("TRAIL", "BREAK_EVEN"):
                self._on_close(r.trade_intent_id, r.average_fill, r.reject_reason, now_ms)
                if r.trade_intent_id not in self._entries:
                    self.protection.forget(r.broker_position_id)

    def _record_tca(self, rec, direction, cost: Decimal, session: str, event_window: str, *, now_ms: int) -> None:
        cfg = self.cfg
        if rec.average_fill is None or rec.filled_qty <= ZERO:
            return
        tca = compute_tca(rec, direction=direction, qty=rec.filled_qty, value_per_unit=cfg.contract.value_per_price_unit_per_lot if cfg.contract.loss_model is LossModel.STOP_DISTANCE else Decimal(1), modelled_cost_pct=cost)
        tca_payload = tca.as_dict()
        if self.learning is not None:
            tca_payload |= {
                "learning_environment": self.learning.environment.value,
                "broker": self.learning.broker,
                "symbol": cfg.symbol,
                "session": session,
                "event_window": event_window,
                "rejected": False,
            }
        original=[e for e in self.ledger.iter(EventKind.TCA_RECORD,correlation_id=rec.trade_intent_id)
                  if e.producer=='vati-cycle' and e.hash==canonical_hash(e.body())]
        if original:
            core=tca.as_dict()
            if any(any(e.payload.get(k)!=v for k,v in core.items()) for e in original):
                raise ValueError('original cost measurement conflicts; use native correction/reconciliation')
        else:
            self._log(EventKind.TCA_RECORD, tca_payload, now_ms=now_ms, corr=rec.trade_intent_id)
        self._entries[rec.trade_intent_id]["cost_ratio"] = tca.cost_ratio
        if self.learning is not None:
            self.learning.on_tca(self.ledger, trade_intent_id=rec.trade_intent_id, symbol=cfg.symbol, session=session, event_window=event_window, cost_ratio=tca.cost_ratio, slippage=tca.slippage)
            self.engine.m.broker_liquidity[cfg.symbol] = self.learning.broker_liquidity(cfg.symbol)

    def _settle_pending(self, r, row: dict, *, now_ms: int, native_observation: bool = False) -> None:
        """A resting entry filled (becomes a position) or expired (reserves nothing)."""
        payload={k: (v.value if hasattr(v, "value") else v) for k, v in asdict(r).items()}
        if native_observation:
            payload['native_entry_observation']={'schema':'vati.native-entry-observation/1',
                'command_hash':row['_native_command'].command_hash,
                'source':'ORIGINAL_NATIVE_RESULT'}
        self._log(EventKind.EXECUTION_RECEIPT, payload,
                  now_ms=now_ms, corr=r.trade_intent_id)
        if r.status == "FILLED" and (r.reject_reason == "PENDING_FILLED" or native_observation):
            row.update({"pending": False, "open": True, "entry": r.average_fill, "quantity": r.filled_qty,
                        "fees": r.fees,
                        "broker_position_id": r.broker_position_id,
                        "protective_stop_confirmed": bool(r.protective_stop_confirmed or self.cfg.software_stops),
                        "best_price": r.average_fill, "worst_price": r.average_fill})
            if row.get("stop") is not None and not native_observation:
                self.router.protection.register(r.broker_position_id, symbol=self.cfg.symbol, direction=row["direction"], entry=r.average_fill,
                                                stop=row["stop"], target=row["targets"][0] if row.get("targets") else None, opened_ms=now_ms,
                                                software_stop=bool(self.cfg.software_stops))
            self._log(EventKind.SESSION, {"event": "ENTRY_FILLED_FROM_REST", "fill": str(r.average_fill), "position": r.broker_position_id},
                      now_ms=now_ms, corr=r.trade_intent_id)
            approval = row.get("_approval")
            if row.get('_prepared_setup') is not None:
                from vati.app.entry_setup import publish_prepared_thesis
                publish_prepared_thesis(self,row['_prepared_setup'],r.average_fill,now_ms=now_ms)
            elif approval is not None:
                intent, decision, state, targets = approval
                self._seal_thesis(intent, decision, state, targets, r.average_fill, now_ms)
            self._record_tca(r, row["direction"], row["cost_pct"], row["session"], row.get("event_window", ""), now_ms=now_ms)
            if not native_observation:row.pop('_approval',None)
        elif r.status in ("EXPIRED", "CANCELLED", "REJECTED"):
            self._entries.pop(r.trade_intent_id, None)
            self._log(EventKind.SESSION, {"event": "ENTRY_REST_ENDED", "status": r.status, "reason": r.reject_reason},
                      now_ms=now_ms, corr=r.trade_intent_id)

    # ------------------------------------------ active-trade intelligence
    def _seal_thesis(self, intent, decision, state, targets, entry_price: Decimal,
                     now_ms: int) -> None:
        """Seal the claim this position is making (GAP-F-003).

        Written once, at approval, and never edited afterwards
        (INV-REPLAY-001). It also fixes `original_approved_risk_pct`, the
        ceiling every later ADD is measured against.
        """
        if intent.stop is None:
            return
        prepared=self._entries.get(intent.trade_intent_id,{}).get('_prepared_setup')
        if prepared is not None:
            from vati.app.entry_setup import publish_prepared_thesis
            publish_prepared_thesis(self,prepared,entry_price,now_ms=now_ms)
            return
        capsule_data: dict = {}
        capsule_hash = ""
        try:
            capsule = self.engine.registry.get(intent.strategy_id)
            capsule_data, capsule_hash = dict(capsule.data), capsule.capsule_hash
        except Exception:  # noqa: BLE001 — a missing capsule is not a reason to skip
            pass
        spread_pct = getattr(state.features, "spread_percentile", None)
        try:
            self.thesis.seal(thesis_from_capsule(
                trade_intent_id=intent.trade_intent_id,
                symbol=self.cfg.symbol,
                strategy_id=intent.strategy_id,
                direction=intent.direction,
                capsule_hash=capsule_hash,
                market_state_hash=intent.market_snapshot_hash,
                entry=entry_price,
                original_stop=intent.stop,
                original_approved_risk_pct=decision.approved_risk_pct,
                created_ms=now_ms,
                capsule_data=capsule_data,
                expected_gross_move_pct=intent.expected_gross_move_pct,
                targets=tuple(targets),
                regime_label=state.regime.trend.value,
                entry_volatility=getattr(state.features, "atr", None),
                entry_liquidity=(None if spread_pct is None
                                 else Decimal("1") - Decimal(str(spread_pct))),
                event_sensitivity=(self.cfg.base, self.cfg.quote),
            ), now_ms=now_ms)
        except Exception as exc:  # noqa: BLE001 — a thesis fault never blocks a trade
            self._log(EventKind.SESSION,
                      {"event": "THESIS_NOT_SEALED", "error": str(exc)[:300]},
                      now_ms=now_ms, corr=intent.trade_intent_id)

    def _review_open_theses(self, bid: Decimal, ask: Decimal, *, now_ms: int) -> None:
        """Assess every open position's claim and act on what the policy allows."""
        for intent_id, row in list(self._entries.items()):
            if row.get('recovery_context_complete') is False:
                continue  # retain native protection; no invented adaptive setup
            if row.get("pending"):
                continue   # a resting entry is not a position yet
            thesis = self.thesis.thesis_for(intent_id)
            if thesis is None:
                continue
            direction = row["direction"]
            mark = bid if direction is Direction.LONG else ask
            row["best_price"] = (
                max(Decimal(str(row.get("best_price", mark))), mark)
                if direction is Direction.LONG
                else min(Decimal(str(row.get("best_price", mark))), mark))
            row["worst_price"] = (
                min(Decimal(str(row.get("worst_price", mark))), mark)
                if direction is Direction.LONG
                else max(Decimal(str(row.get("worst_price", mark))), mark))
            position_id = str(row.get("broker_position_id") or "")
            rule = self.protection.rules.get(position_id)
            current_stop = rule.stop if rule is not None else row.get("stop")
            try:
                health = self.trade_health.assess(PositionHealthInputs(
                    trade_intent_id=intent_id, symbol=self.cfg.symbol,
                    direction=direction,
                    entry_price=Decimal(str(row["entry"])),
                    current_price=mark,
                    original_stop=thesis.original_stop,
                    current_stop=(None if current_stop is None else Decimal(str(current_stop))),
                    has_confirmed_stop=bool(
                        row.get("protective_stop_confirmed")
                        or (rule is not None and rule.software_stop)),
                    opened_ms=int(row.get("opened_ms") or now_ms),
                    now_ms=now_ms,
                    expected_horizon_ms=int(row.get("expected_horizon_ms") or 0),
                    worst_price=Decimal(str(row["worst_price"])),
                    best_price=Decimal(str(row["best_price"])),
                    spread=max(ZERO, ask - bid),
                ))
            except Exception:  # noqa: BLE001 — health is advisory here; exits still run
                continue

            materiality, refs = ZERO, ()
            if self.news is not None:
                try:
                    impacts = self.news.assess_subject(
                        subject_kind="POSITION", subject_id=intent_id,
                        symbol=self.cfg.symbol, direction=direction.value, now_ms=now_ms)
                    materiality, refs = type(self.news).peak(impacts)
                except Exception:  # noqa: BLE001
                    materiality, refs = ZERO, ()

            confirmations: list[str] = []
            first_target = thesis.confirmation.get("first_target")
            if first_target is not None:
                level = Decimal(str(first_target))
                if (mark >= level if direction is Direction.LONG else mark <= level):
                    confirmations.append("first_target")

            assessment = self.thesis.assess(ThesisInputs(
                thesis=thesis, health=health, current_price=mark, now_ms=now_ms,
                current_stop=(None if current_stop is None else Decimal(str(current_stop))),
                adverse_present=tuple(
                    s for s in thesis.adverse_signals
                    if s.upper() in {r.upper() for r in health.reasons}),
                confirmations_met=tuple(confirmations),
                event_materiality=materiality, event_refs=refs,
            ))

            protection_be = (
                current_stop is not None
                and (Decimal(str(current_stop)) >= thesis.entry
                     if direction is Direction.LONG
                     else Decimal(str(current_stop)) <= thesis.entry))
            original_risk = row.get("original_approved_risk_pct")
            original_risk = None if original_risk is None else Decimal(str(original_risk))
            proposal = self.adjustments.propose(
                assessment, health=health,
                original_approved_risk_pct=original_risk,
                current_risk_pct=(ZERO if protection_be else (original_risk or ZERO)),
                protection_at_break_even=protection_be,
                scale_policy=self.scale_policies.policy_for(str(row.get("strategy_id") or "")),
                scale_ins_used=int(row.get("scale_ins_used", 0)),
                proposed_stop=(thesis.entry if not protection_be else None),
                now_ms=now_ms,
            )
            self.proposals.append(proposal)
            row["last_proposal"] = proposal.action.value
            # Only the two adjustments that cannot add exposure execute on this
            # runtime: the single-symbol cycle has no account-level snapshot to
            # put a delta intent through, and an add without RiskAuthority is
            # not an add this system is willing to make (INV-AUTH-001).
            if position_id and proposal.action is Adjustment.MOVE_PROTECTION \
                    and proposal.new_stop is not None:
                try:
                    self.router.apply_preservation(
                        self.cfg.venue, position_id=position_id,
                        trade_intent_id=intent_id, action="TIGHTEN_STOP",
                        now_ms=now_ms, new_stop=proposal.new_stop,
                        reason="THESIS_" + proposal.thesis_state)
                    row["stop"] = proposal.new_stop
                except Exception:  # noqa: BLE001 — a refused tighten leaves the stop as is
                    pass
            elif position_id and proposal.action is Adjustment.EXIT:
                try:
                    receipt = self.router.apply_preservation(
                        self.cfg.venue, position_id=position_id,
                        trade_intent_id=intent_id, action="FULL_CLOSE", now_ms=now_ms,
                        reason="THESIS_" + proposal.thesis_state)
                except Exception:  # noqa: BLE001
                    receipt = None
                if receipt is not None and receipt.status in (
                    "FILLED", "OWNER_EXECUTED", "BROKER_CONFIRMED"
                ):
                    self._on_close(intent_id, receipt.average_fill, "EXIT", now_ms)
                    if intent_id not in self._entries:
                        self.protection.forget(position_id)

    def _classify_decision(self, intent_id: str, entry: dict, rv, now_ms: int, *, outcome_known: bool = True):
        """Decision quality x outcome, and the lesson it teaches (GAP-F-003)."""
        thesis = self.thesis.thesis_for(intent_id)
        inputs = DecisionQualityInputs(
            trade_intent_id=intent_id,
            strategy_id=str(entry.get("strategy_id") or ""),
            thesis_sealed=thesis is not None,
            thesis_falsifiable=bool(thesis is not None and thesis.invalidation),
            approved_risk_pct=Decimal(str(entry.get("original_approved_risk_pct", ZERO) or ZERO)),
            mandate_max_risk_pct=self.mandate.max_risk_per_trade,
            protective_stop_confirmed=bool(entry.get("protective_stop_confirmed", True)),
            execution_policy_applied=bool(entry.get("execution_policy_applied", True)),
            cost_ratio=(None if entry.get("cost_ratio") is None
                        else Decimal(str(entry["cost_ratio"]))),
            opened_in_blackout=bool(entry.get("opened_in_blackout")),
            event_certified=bool(entry.get("event_certified")),
        )
        verdict = self.decision_quality.record(
            inputs, symbol=self.cfg.symbol, r_multiple=rv.r_multiple, now_ms=now_ms,
            outcome_known=outcome_known,
            evidence_refs=(rv.artifact_hash,) + ((thesis.seal,) if thesis else ()))
        if self.learning is not None and outcome_known:
            self.lessons.record(lesson_from_verdict(
                verdict, symbol=self.cfg.symbol,
                regime=str(entry.get("regime", "")), session=str(entry.get("session", "")),
                environment=self.learning.environment, now_ms=now_ms,
                evidence_refs=(rv.artifact_hash,)), now_ms=now_ms)
        self.thesis.forget(intent_id)
        return verdict

    def _on_close(self, intent_id: str, exit_price: Optional[Decimal], reason: str, now_ms: int) -> None:
        e = self._entries.get(intent_id)
        if e is None:
            return
        if not isinstance(exit_price, Decimal) or not exit_price.is_finite():
            self._log(EventKind.SESSION, {"event": "CLOSE_PRICE_UNRESOLVED",
                "reason": reason, "position_id": e.get("broker_position_id")}, now_ms=now_ms, corr=intent_id)
            return
        self._entries.pop(intent_id)
        e["trade_intent_id"] = intent_id
        measured = closed_trade_pnl(e, exit_price, self.cfg.contract, getattr(self.adapter, "closed", None))
        maturity = native_economic_maturity(self.adapter, intent_id, measured)
        pnl = measured.amount if measured.amount is not None else ZERO
        initial_risk = initial_risk_from_ledger(self.ledger, intent_id,
            available_cutoff_ms=int(e.get("opened_ms") or 0) or None)
        if measured.amount is None:
            self.streaks.recovery_issue = "unresolved closed-trade money outcome; native reconciliation required"
            self.kill.trip(KillSwitchTrigger.RECONCILIATION_FAILURE, now_ms)
        else:
            from vati.execution.review import economic_outcome_final
            for lock_event in self.streaks.on_close(e["strategy_id"], pnl, now_ms,
                profit_final=economic_outcome_final(maturity, measured.basis,
                    account_currency=self.cfg.contract.account_currency)):
                self._log(EventKind.SESSION, lock_event, now_ms=now_ms, corr=intent_id)
        self.consecutive_losses = self.streaks.verdict(e["strategy_id"], now_ms).losses
        rv = review_trade(trade_intent_id=intent_id, strategy_id=e["strategy_id"], entry=e["entry"], exit_price=exit_price, stop=e["stop"] or e["entry"], direction_long=e["direction"] is Direction.LONG,
                          pnl=pnl, thesis_correct=pnl > ZERO, process_ok=True, exit_reason=reason,
                          broker_ok=measured.amount is not None,
                          initial_money_risk=initial_risk.amount if initial_risk else None,
                          initial_risk_evidence_ref=initial_risk.evidence_ref if initial_risk else None,
                          pnl_basis=measured.basis, thesis_evidence_basis="PNL_SIGN_PROXY_NOT_SETUP_VALIDATION",
                          account_alias=self.cfg.account_alias,
                          maturity=maturity)
        self.reviews.append(rv)
        self._log(EventKind.TRADE_REVIEW, {k: (v.value if hasattr(v, "value") else (str(v) if isinstance(v, Decimal) else (list(v) if isinstance(v, tuple) else v))) for k, v in asdict(rv).items()}, now_ms=now_ms, corr=intent_id)
        self.admission.propose(rv.artifact_hash, knowledge_class="TRADE_EXPERIENCE", proposed_by=rv.proposed_by, trust_tier="T0_VAN_TRADING_POLICY")
        metrics.inc("vati_trades_closed_total", outcome=rv.outcome.value)
        verdict = None
        try:
            if e.get('recovery_context_complete') is not False:
                verdict = self._classify_decision(intent_id, e, rv, now_ms, outcome_known=measured.amount is not None)
        except Exception as exc:  # noqa: BLE001 — classification never blocks a close
            self._log(EventKind.SESSION,
                      {"event": "DECISION_QUALITY_FAULT", "error": str(exc)[:300]},
                      now_ms=now_ms, corr=intent_id)
        if self.learning is not None and rv.outcome in STRATEGY_LEARNING_OUTCOMES and e.get('recovery_context_complete') is not False:
            self._learn(intent_id, rv, e.get("cost_ratio", Decimal(1)), now_ms,
                        process_ok=(verdict is None or not verdict.faults))

    # ------------------------------------------------------------ learning
    def _learn(self, intent_id: str, rv, cost_ratio: Decimal, now_ms: int,
               *, process_ok: Optional[bool] = None) -> None:
        """Observe the closed trade; apply only LearningBoundary-checked, reduce-only effects.

        GAP-F-003. `process_ok` now carries the decision-quality verdict rather
        than the review's constant, and the quadrant multiplier is combined
        with `min` below — so a lucky bad decision reduces capsule health and
        an unlucky good one does not, while nothing here can raise it
        (INV-RISK-001).
        """
        assert self.learning is not None
        ep, adj = self.learning.on_review(self.ledger, trade_intent_id=intent_id, strategy_id=rv.strategy_id, r_multiple=rv.r_multiple,
                                          process_ok=(rv.process_ok if process_ok is None else process_ok), cost_ratio=cost_ratio)
        if ep is not None:
            self._log(EventKind.TRADE_EXPERIENCE_ARTIFACT, to_payload(ep), now_ms=now_ms, corr=intent_id)
            self.admission.propose(ep.artifact_hash, knowledge_class="TRADE_EXPERIENCE", proposed_by="vati-learning", trust_tier="T0_VAN_TRADING_POLICY")
        if adj is None:
            return
        self.engine.m.capsule_health[rv.strategy_id] = min(
            adj.multiplier, self.decision_quality.health_multiplier(rv.strategy_id))
        if adj.demote_to:
            cap = self.engine.registry.get(rv.strategy_id)
            # Live capsules step down to SHADOW (observe, no orders); pre-live capsules become DEGRADED (inactive).
            target = StrategyState.SHADOW if cap.state in (StrategyState.LIMITED_LIVE, StrategyState.CERTIFIED_LIVE) else StrategyState.DEGRADED
            if cap.state in ACTIVE_STATES and cap.state is not target:
                new = self.engine.registry.demote(rv.strategy_id, target, reason=f"learning health {adj.multiplier}: {'; '.join(self.learning.health.verdict(rv.strategy_id).reasons)}")
                self.learning.demotions.append((rv.strategy_id, target.value))
                self._log(EventKind.CAPSULE_STATE, {"strategy_id": rv.strategy_id, "from": cap.state.value, "to": target.value, "capsule_hash": new.capsule_hash, "supersedes": cap.capsule_hash,
                                                    "capsule": new.data, "by": "vati-learning", "authority": "AUTOMATIC_DEMOTION_ONLY"}, now_ms=now_ms, corr=intent_id)
                metrics.inc("vati_capsule_demotions_total", strategy=rv.strategy_id, to=target.value)
