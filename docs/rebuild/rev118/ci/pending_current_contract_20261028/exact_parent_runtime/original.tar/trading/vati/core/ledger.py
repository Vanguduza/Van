"""Append-only event ledger with a hash chain and decision replay.

Storage is SQLite (stdlib) so the ledger is a single file, transactional and
queryable; JSONL export is available for the evidence bundle. Each row stores
prev_hash and chain_hash = sha256(prev_hash || event.hash), so tampering with
any row breaks verification of every later row. Nothing is ever updated or
deleted; corrections are new events."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Iterator, Optional

from vati.core.canonical import canonical_hash, canonical_json
from vati.core.events import Event, EventKind

GENESIS = "0" * 64

#: A full re-verification from genesis runs at least this often, even when every
#: incremental check passes. The incremental check proves the new rows chain onto an
#: anchor that has not moved and that nothing at or below the anchor was deleted; an
#: in-place edit of an old row that leaves its stored chain_hash alone is only caught
#: by recomputing from genesis, so this bounds how long such an edit can go unseen.
FULL_REVERIFY_EVERY_S = 3600.0


class LedgerError(RuntimeError):
    pass


def require_committed_source_read(ledger):
    """An owned writer's staged rows are not committed source evidence."""
    connection=getattr(ledger,'_conn',None)
    if connection is None:
        raise LedgerError('committed_source_transaction_state_unavailable')
    if hasattr(connection,'in_transaction'):
        active=connection.in_transaction
    elif hasattr(connection,'info'):
        active=connection.info.transaction_status!=0
    else:
        raise LedgerError('committed_source_transaction_state_unavailable')
    depth=getattr(ledger,'_read_snapshot_depth',0)
    if active and not (type(depth) is int and depth>0):
        raise LedgerError('committed_source_read_requires_idle_or_readonly_snapshot')


@contextmanager
def committed_source_snapshot(ledger):
    require_committed_source_read(ledger)
    with ledger.read_snapshot():
        # Recheck after acquisition; a nested writer must never masquerade as
        # the committed read snapshot requested at this boundary.
        require_committed_source_read(ledger)
        yield ledger


def history_through(ledger, correlation_id: str, anchor: str):
    """Fully read a subject's journal, then retain its original availability.

    A hash addresses the first publication of an immutable record; replaying
    identical bytes later cannot move that record's original availability.
    """
    rows = list(ledger.iter(correlation_id=correlation_id))
    for index, event in enumerate(rows):
        if event.hash == anchor:
            if event.hash != canonical_hash(event.body()):
                raise LedgerError("evidence availability anchor seal mismatch")
            return rows[:index+1]
    raise LedgerError("evidence availability anchor missing from requested trade scope")


@dataclass(frozen=True)
class ReplayReport:
    checked: int
    identical: int
    divergent: list[dict]

    @property
    def ok(self) -> bool:
        return not self.divergent


def _check_row(prev: str, r) -> bool:
    """r = (event_hash, prev_hash, chain_hash, payload_json, kind, producer, correlation_id,
    event_time_ms, received_time_ms, decision_time_ms, schema_version, ...)."""
    ev = Event(EventKind(r[4]), r[5], r[7], r[8], json.loads(r[3]), r[10], r[9], r[6], r[0])
    return (canonical_hash(ev.body()) == r[0] and r[1] == prev
            and hashlib.sha256((prev + r[0]).encode()).hexdigest() == r[2])


class IncrementalChainVerifier:
    """Per-decision ledger check whose cost does not grow with the ledger.

    Before, every risk snapshot called `verify_chain()`, which re-hashes the whole
    ledger from genesis: decision latency grew with every event ever written (a
    2,000-bar backtest spent 149 of 164 s there, and a live session would slow the
    same way). This keeps an anchor (seq, chain_hash, row count) from the last
    successful verification and, on each call:

    1. re-reads the anchor row: a chain recomputed from any earlier row changes it;
    2. counts the rows up to the anchor: a deleted row changes the count;
    3. verifies only the rows appended since, chaining from the anchor.

    A full verification from genesis runs on first use and again whenever
    `full_every_s` has passed, which also catches an in-place edit of an old row.
    Any failure drops the anchor, so the next call is a full verification again.
    """

    def __init__(self, ledger, *, full_every_s: float = FULL_REVERIFY_EVERY_S, clock: Callable[[], float] = time.monotonic) -> None:
        self.ledger, self.full_every_s, self.clock = ledger, full_every_s, clock
        self._anchor: Optional[tuple[int, str, int]] = None   # (seq, chain_hash, rows up to seq)
        self._last_full = 0.0
        self.last_rows_checked = 0
        self.full_verifications = 0

    def verify(self) -> tuple[bool, int]:
        now = self.clock()
        if self._anchor is None or now - self._last_full >= self.full_every_s:
            ok, n, seq, head = self.ledger._verify_from(0, GENESIS)
            self.full_verifications += 1
            self.last_rows_checked = n
            self._anchor = (seq, head, n) if ok else None
            self._last_full = now
            return ok, n
        seq, chain, n = self._anchor
        if seq and (self.ledger._chain_at(seq) != chain or self.ledger._count_upto(seq) != n):
            self._anchor = None
            self.last_rows_checked = 0
            return False, n
        ok, added, new_seq, head = self.ledger._verify_from(seq, chain)
        self.last_rows_checked = added
        if not ok:
            self._anchor = None
            return False, n + added
        self._anchor = (new_seq, head, n + added)
        return True, n + added


class Ledger:
    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        self._conn = sqlite3.connect(self.path, isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL") if self.path != ":memory:" else None
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS events (
                 seq INTEGER PRIMARY KEY AUTOINCREMENT,
                 kind TEXT NOT NULL, producer TEXT NOT NULL, correlation_id TEXT NOT NULL,
                 event_time_ms INTEGER NOT NULL, received_time_ms INTEGER NOT NULL, decision_time_ms INTEGER,
                 schema_version INTEGER NOT NULL, payload_json TEXT NOT NULL,
                 event_hash TEXT NOT NULL, prev_hash TEXT NOT NULL, chain_hash TEXT NOT NULL UNIQUE)"""
        )
        self._conn.execute("CREATE INDEX IF NOT EXISTS ix_events_corr ON events(correlation_id)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS ix_events_kind ON events(kind)")

    # ------------------------------------------------------------------ write
    @contextmanager
    def atomic(self):
        """Serialize a read/validate/append operation with every ledger writer."""
        if getattr(self,'_read_snapshot_depth',0):
            raise LedgerError('cannot acquire a writer inside a read-only ledger snapshot')
        if self._conn.in_transaction:
            yield self
            return
        self._conn.execute("BEGIN IMMEDIATE")
        try:
            yield self
            self._conn.commit()
        except BaseException:
            try:
                self._conn.rollback()
            finally:
                # A verifier may have observed staged rows in this writer.
                # Their rolled-back head cannot remain a durable cache anchor.
                self._incremental=None
            raise

    @contextmanager
    def read_snapshot(self):
        """Consistent WAL read without reserving the protective/order writer."""
        if self._conn.in_transaction:
            yield self
            return
        previous=self._conn.execute('PRAGMA query_only').fetchone()[0]
        self._conn.execute('PRAGMA query_only=ON')
        self._read_snapshot_depth=1
        try:
            self._conn.execute('BEGIN')
            yield self
        finally:
            self._conn.rollback()
            self._read_snapshot_depth=0
            self._conn.execute('PRAGMA query_only='+('ON' if previous else 'OFF'))

    def append(self, event: Event) -> str:
        if not event.hash or event.hash != canonical_hash(event.body()):
            raise LedgerError("event hash missing or does not match body")
        with self.atomic():
            row = self._conn.execute("SELECT chain_hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
            prev = row[0] if row else GENESIS
            chain = hashlib.sha256((prev + event.hash).encode()).hexdigest()
            self._conn.execute(
                "INSERT INTO events(kind, producer, correlation_id, event_time_ms, received_time_ms, decision_time_ms, schema_version, payload_json, event_hash, prev_hash, chain_hash) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (event.kind.value, event.producer, event.correlation_id, event.event_time_ms, event.received_time_ms, event.decision_time_ms,
                 event.schema_version, canonical_json(event.payload), event.hash, prev, chain),
            )
        return chain

    # ------------------------------------------------------------------- read
    def _row_to_event(self, r: sqlite3.Row | tuple) -> Event:
        return Event(EventKind(r[1]), r[2], r[4], r[5], json.loads(r[8]), r[7], r[6], r[3], r[9])

    def iter(self, kind: Optional[EventKind] = None, correlation_id: Optional[str] = None) -> Iterator[Event]:
        q = "SELECT seq, kind, producer, correlation_id, event_time_ms, received_time_ms, decision_time_ms, schema_version, payload_json, event_hash FROM events"
        cond, args = [], []
        if kind is not None:
            cond.append("kind = ?"); args.append(kind.value)
        if correlation_id is not None:
            cond.append("correlation_id = ?"); args.append(correlation_id)
        if cond:
            q += " WHERE " + " AND ".join(cond)
        q += " ORDER BY seq"
        for r in self._conn.execute(q, args):
            yield self._row_to_event(r)

    def count(self, kind: Optional[EventKind] = None) -> int:
        if kind is None:
            return self._conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        return self._conn.execute("SELECT COUNT(*) FROM events WHERE kind = ?", (kind.value,)).fetchone()[0]

    def iter_after(self, seq: int):
        """Ordered original rows after a retained cursor, without an OFFSET scan."""
        if type(seq) is not int or seq < 0:
            raise ValueError('ledger cursor must be a nonnegative integer')
        for row in self._conn.execute(
                'SELECT seq, kind, producer, correlation_id, event_time_ms, received_time_ms, decision_time_ms, schema_version, payload_json, event_hash FROM events WHERE seq > ? ORDER BY seq', (seq,)):
            yield row[0], self._row_to_event(row)

    def head(self) -> str:
        row = self._conn.execute("SELECT chain_hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        return row[0] if row else GENESIS

    # ----------------------------------------------------------------- verify
    def verify_chain(self) -> tuple[bool, int]:
        """Full verification from genesis. For audits, startup and evidence."""
        ok, n, _seq, _head = self._verify_from(0, GENESIS)
        return ok, n

    def verify_incremental(self) -> tuple[bool, int]:
        """Per-decision check: cost proportional to rows added since the last check
        (see IncrementalChainVerifier), with a periodic full verification."""
        if getattr(self, "_incremental", None) is None:
            self._incremental = IncrementalChainVerifier(self)
        return self._incremental.verify()

    def _verify_from(self, after_seq: int, prev: str) -> tuple[bool, int, int, str]:
        """Verify rows with seq > after_seq chaining from `prev`. Returns
        (ok, rows verified, last good seq, last good chain hash)."""
        n, seq = 0, after_seq
        for r in self._conn.execute("SELECT event_hash, prev_hash, chain_hash, payload_json, kind, producer, correlation_id, event_time_ms, received_time_ms, decision_time_ms, schema_version, seq FROM events WHERE seq > ? ORDER BY seq", (after_seq,)):
            if not _check_row(prev, r):
                return False, n, seq, prev
            prev, seq = r[2], r[11]
            n += 1
        return True, n, seq, prev

    def _chain_at(self, seq: int) -> Optional[str]:
        row = self._conn.execute("SELECT chain_hash FROM events WHERE seq = ?", (seq,)).fetchone()
        return row[0] if row else None

    def _count_upto(self, seq: int) -> int:
        return self._conn.execute("SELECT COUNT(*) FROM events WHERE seq <= ?", (seq,)).fetchone()[0]

    def replay_decisions(self, recompute: Callable[[dict], dict]) -> ReplayReport:
        """Feed each RISK_DECISION's stored inputs (payload['inputs']) to `recompute`
        and compare the returned decision_hash to the stored one."""
        checked = identical = 0
        divergent: list[dict] = []
        for ev in self.iter(EventKind.RISK_DECISION):
            inputs = ev.payload.get("inputs")
            stored = ev.payload.get("decision", {}).get("decision_hash")
            if inputs is None or stored is None:
                continue
            checked += 1
            got = recompute(inputs).get("decision_hash")
            if got == stored:
                identical += 1
            else:
                divergent.append({"correlation_id": ev.correlation_id, "stored": stored, "recomputed": got})
        return ReplayReport(checked, identical, divergent)

    def export_jsonl(self, path: str | Path) -> int:
        n = 0
        with open(path, "w", encoding="utf-8") as f:
            for ev in self.iter():
                f.write(canonical_json({**ev.body(), "hash": ev.hash}) + "\n")
                n += 1
        return n

    def close(self) -> None:
        self._conn.close()
