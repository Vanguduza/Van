"""MT5 bridge client (Rev 2 §5.2). The Linux core never imports the MetaTrader5
library; it speaks a narrow signed request protocol to the Windows worker over
mTLS. This module holds the contract, request signing and replay protection.
Without a transport it fails closed (VenueUnavailable)."""

from __future__ import annotations

import hmac
import hashlib
import time
import secrets
import threading
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Callable, Optional, ClassVar

from vati.core.canonical import canonical_json
from vati.execution.base import AccountState, ExecutionReceipt, Health, OrderCommand, VenuePosition, VenueUnavailable
from vati.execution.mt5_identity import Mt5Identity
from vati.risk.contracts import Direction, LossModel

OPS = ("sync_account", "sync_symbols", "symbol_contract", "expected_margin", "order_check", "order_send", "order_send_expiring", "positions", "orders", "history", "modify_sl_tp", "close")
ZERO = Decimal("0")


@dataclass(frozen=True)
class BridgeRequest:
    op: str
    nonce: int
    issued_ms: int
    body: dict[str, Any]
    signature: str = ""

    def payload(self) -> dict[str, Any]:
        return {"op": self.op, "nonce": self.nonce, "issued_ms": self.issued_ms, "body": self.body}


class Mt5BridgeClient:
    def __init__(self, *, signing_key: bytes, transport: Optional[Callable[[dict], dict]] = None, max_skew_ms: int = 5000) -> None:
        if not signing_key:
            raise ValueError("signing key required")
        self._key, self._transport, self.max_skew_ms = signing_key, transport, max_skew_ms
        # Worker replay protection persists across its restarts. Core clients
        # use independent 96-bit namespaces and a 32-bit local sequence.
        # A fresh connection gets its own random namespace; calls keep a
        # locked local sequence rather than reusing another client's nonce 1.
        self._nonce = secrets.randbits(96) << 32
        self._nonce_lock = threading.Lock()
        self.sent: list[BridgeRequest] = []

    def sign(self, req: BridgeRequest) -> BridgeRequest:
        sig = hmac.new(self._key, canonical_json(req.payload()).encode(), hashlib.sha256).hexdigest()
        return BridgeRequest(req.op, req.nonce, req.issued_ms, req.body, sig)

    def verify(self, req: BridgeRequest) -> bool:
        return hmac.compare_digest(self.sign(BridgeRequest(req.op, req.nonce, req.issued_ms, req.body)).signature, req.signature)

    def call(self, op: str, body: dict[str, Any], *, now_ms: int) -> dict[str, Any]:
        if op not in OPS:
            raise ValueError(f"op not in bridge contract: {op}")
        if self._transport is None:
            raise VenueUnavailable("MT5 bridge transport not configured; fail closed")
        with self._nonce_lock:
            if self._nonce & 0xffffffff==0xffffffff:
                self._nonce=secrets.randbits(96)<<32
            self._nonce += 1
            nonce = self._nonce
        req = self.sign(BridgeRequest(op, nonce, now_ms, body))
        self.sent.append(req)
        resp = self._transport(req.__dict__)
        if resp.get("nonce") != req.nonce:
            raise VenueUnavailable("bridge response nonce mismatch (replay?)")
        if abs(int(resp.get("worker_time_ms", now_ms)) - now_ms) > self.max_skew_ms:
            raise VenueUnavailable("bridge clock skew beyond limit")
        return resp


@dataclass
class Mt5BridgeAdapter:
    #: P1-TRADE-EXEC-004: the entry types this venue really executes (the worker sends MARKET as a deal and every other type as a pending limit).
    #: The router refuses anything else instead of sending it as a different order.
    supported_entry_types: ClassVar[tuple] = ("MARKET", "LIMIT", "PASSIVE_LIMIT")
    client: Mt5BridgeClient
    account_alias: str = "fx_primary"
    venue: str = "mt5"
    clock: Callable[[], int] = field(default=lambda: int(time.time() * 1000))   # reads are signed with real time too: a worker rejects issued_ms=0 as skew
    identity: Mt5Identity | None = None

    def _call(self, op, body, *, now_ms):
        if self.identity is not None:
            # A legacy worker must refuse admission before an effectful call.
            # Every new worker also verifies this same binding inside its lock.
            if op != 'sync_account':
                self._call('sync_account', {'alias': self.account_alias}, now_ms=now_ms)
            body = {**body, 'expected_account': self.identity.as_dict()}
        response = self.client.call(op, body, now_ms=now_ms)
        if not isinstance(response, dict) or 'error' in response:
            raise VenueUnavailable('MT5 worker account operation refused or unavailable')
        if self.identity is not None:
            if response.get('identity_binding') != self.identity.as_dict():
                raise VenueUnavailable('MT5 worker did not acknowledge the registered physical account binding')
            if op == 'sync_account':
                self.identity.validate(response.get('account'))
        return response

    def symbol_contract(self,symbol,*,context,deadline_ms):
        from vati.execution.mt5_symbol_contract import read_symbol_contract
        return read_symbol_contract(self,symbol,context=context,deadline_ms=deadline_ms)

    def expected_margin(self,symbol,lots,*,price,direction,context,deadline_ms):
        from vati.execution.mt5_expected_margin import read_bridge_expected_margin
        return read_bridge_expected_margin(self,symbol,lots,price=price,direction=direction,
            context=context,deadline_ms=deadline_ms)

    def sync_account(self) -> AccountState:
        r = self._call("sync_account", {"alias": self.account_alias}, now_ms=self.clock())
        a = r["account"]
        verified=a.get('verified',False);hedging=a.get('hedging',True)
        if type(verified) is not bool or type(hedging) is not bool:
            raise VenueUnavailable('MT5 account verification and topology require explicit boolean facts')
        from vati.funding.mt5 import frame_from_poll, amount, text
        mark = None
        try:
            mark = frame_from_poll(self.account_alias, a, received_ms=self.clock(),
                                   nonce=str(r['nonce']), source_kind='MT5_SIGNED_MTLS_READ')
        except (KeyError, TypeError, ValueError, ArithmeticError):
            self._funding_issue = 'MT5_NATIVE_CASH_HISTORY_UNAVAILABLE'
        else:
            self._funding_issue = None
        from vati.execution.native_margin import mt5_margin, mt5_risk_equity
        used,free,level=mt5_margin(a)
        try:
            from vati.execution.mt5_observation import observe_mt5_account
            observed_ms=self.clock()
            observation=observe_mt5_account(self.account_alias,self.identity,a,
                source_kind='MT5_SIGNED_MTLS_READ',source_nonce=str(r['nonce']),
                source_received_at_ms=observed_ms,observed_at_ms=observed_ms)
            equity = mark.net_equity if mark is not None else mt5_risk_equity(a)
            return AccountState(self.account_alias, equity, amount(a['balance']), text(a['currency']),
                                verified, hedging, int(a.get('server_time_ms', 0)), funding_mark=mark,used_margin=used,free_margin=free,margin_level_pct=level,native_observation=observation)
        except (KeyError, TypeError, ValueError, ArithmeticError):
            raise VenueUnavailable('MT5 native account amounts unavailable') from None

    def positions(self) -> list[VenuePosition]:
        r = self._call("positions", {"alias": self.account_alias}, now_ms=self.clock())
        return [VenuePosition(str(p["ticket"]), p["symbol"], Direction.LONG if p["type"] == "BUY" else Direction.SHORT, Decimal(str(p["volume"])), Decimal(str(p["price_open"])),
                              Decimal(str(p["sl"])) if p.get("sl") else None, str(p.get("comment", "")).replace("vati:", ""), LossModel.STOP_DISTANCE) for p in r.get("positions", [])]

    def heartbeat(self, *, now_ms: int) -> Health:
        try:
            r = self._call("sync_account", {"alias": self.account_alias}, now_ms=now_ms)
            return Health(True, int(r.get("worker_time_ms", now_ms)) - now_ms, now_ms)
        except VenueUnavailable:
            return Health(False, 0, now_ms)

    def orders(self) -> list[dict]:
        response=self._call('orders',{'alias':self.account_alias},now_ms=self.clock())
        if not isinstance(response.get('orders'),list):
            raise VenueUnavailable('MT5 native pending orders unavailable')
        return response['orders']

    def submit(self, cmd: OrderCommand, *, now_ms: int) -> ExecutionReceipt:
        def entry_rejected(reason):
            return ExecutionReceipt(cmd.trade_intent_id,cmd.decision_hash,self.venue,'REJECTED',ZERO,None,
                cmd.entry_price,cmd.entry_price,cmd.entry_price,False,now_ms,now_ms,reject_reason=reason).sealed()
        if cmd.account_alias != self.account_alias or cmd.venue != self.venue:
            return entry_rejected('native command target differs from the configured account or venue; not dispatched')
        expiry=cmd.expires_at_ms
        if expiry is not None:
            if type(expiry) is not int or not 0<expiry<2**63 or expiry<=max(now_ms,self.clock()):
                return entry_rejected('explicit native entry deadline is invalid or expired; not dispatched')
            try:
                support=self._call('sync_account',{'alias':self.account_alias},now_ms=now_ms).get('entry_constraints')
            except VenueUnavailable:
                return entry_rejected('native entry deadline support unavailable; not dispatched')
            if support!={'schema':'van.mt5.entry-constraints/1','explicit_deadline':True,'required_op':'order_send_expiring'} or type(support.get('explicit_deadline')) is not bool:
                return entry_rejected('native worker cannot enforce the explicit entry deadline; not dispatched')
        if cmd.protective_stop is None:
            return ExecutionReceipt(cmd.trade_intent_id, cmd.decision_hash, self.venue, "REJECTED", ZERO, None, cmd.entry_price, cmd.entry_price, cmd.entry_price, False, now_ms, now_ms, reject_reason="MT5 orders require SL in the same request").sealed()
        body = {"alias": self.account_alias, "symbol": cmd.symbol, "type": "BUY" if cmd.direction is Direction.LONG else "SELL", "volume": str(cmd.quantity), "price": str(cmd.entry_price),
                "sl": str(cmd.protective_stop), "tp": str(cmd.targets[0]) if cmd.targets else None, "deviation": str(cmd.max_slippage) if cmd.max_slippage else None,
                "comment": f"vati:{cmd.trade_intent_id}", "magic": int(cmd.decision_hash[:8], 16) % 2_147_483_647, "order_type": cmd.entry_type}
        if expiry is not None:body['expires_at_ms']=expiry
        chk = self._call("order_check", body, now_ms=now_ms)
        if chk.get("ok") is not True:
            return ExecutionReceipt(cmd.trade_intent_id, cmd.decision_hash, self.venue, "REJECTED", ZERO, None, cmd.entry_price, cmd.entry_price, cmd.entry_price, False, now_ms, now_ms, reject_reason=str(chk.get("reason", "order_check failed"))).sealed()
        if expiry is not None and expiry<=self.clock():
            return entry_rejected('explicit native entry deadline expired during precheck; not dispatched')
        # A typed operation also fences a worker rollback between capability
        # read and dispatch: legacy workers refuse the unknown operation.
        r = self._call("order_send_expiring" if expiry is not None else "order_send", body, now_ms=now_ms)
        filled = Decimal(str(r.get("volume", "0")))
        stop_confirmed=r.get('sl_confirmed') is True
        return ExecutionReceipt(cmd.trade_intent_id, cmd.decision_hash, self.venue, r.get("status", "UNKNOWN"), filled, Decimal(str(r["price"])) if r.get("price") else None,
                                cmd.entry_price, Decimal(str(r.get("arrival") or cmd.entry_price)), cmd.entry_price, stop_confirmed, int(r.get("server_time_ms", now_ms)), now_ms,
                                broker_order_id=str(r.get("order") or ''), broker_position_id=str(r.get("position") or ''), protective_stop_price=cmd.protective_stop if stop_confirmed else None,
                                reject_reason=str(r.get("reason") or r.get("error") or "") if r.get("status", "UNKNOWN") in ("REJECTED", "UNKNOWN") else "").sealed()

    def modify_stop(self, position_id: str, new_stop: Decimal, *, now_ms: int) -> ExecutionReceipt:
        r = self._call("modify_sl_tp", {"alias": self.account_alias, "position": position_id, "sl": str(new_stop)}, now_ms=now_ms)
        ok=r.get('ok');status='ACCEPTED' if ok is True else 'REJECTED' if ok is False else 'UNKNOWN'
        return ExecutionReceipt("", "", self.venue, status, ZERO, None, ZERO, ZERO, ZERO, ok is True, now_ms, now_ms, broker_position_id=position_id, protective_stop_price=new_stop if ok is True else None).sealed()

    def close(self, position_id: str, quantity: Optional[Decimal], *, now_ms: int, reason: str) -> ExecutionReceipt:
        r = self._call("close", {"alias": self.account_alias, "position": position_id, "volume": str(quantity) if quantity else None, "reason": reason}, now_ms=now_ms)
        return ExecutionReceipt("", "", self.venue, r.get("status", "UNKNOWN"), Decimal(str(r.get("volume", "0"))), Decimal(str(r["price"])) if r.get("price") else None, ZERO, ZERO, ZERO, r.get('sl_confirmed') is True, now_ms, now_ms, broker_position_id=position_id, reject_reason=reason).sealed()
