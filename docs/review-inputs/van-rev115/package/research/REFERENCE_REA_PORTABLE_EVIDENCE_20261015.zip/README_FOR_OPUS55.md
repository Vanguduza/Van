# VAN REA evidence and implementation handoff for Opus 5.5

**Status:** STATIC_RESEARCH_RECORDED / PRODUCT_ADOPTION_PROPOSED. This is research, not live trading or Android device qualification.

## Entry points
1. Read `VAN_REA_MT5_TRADINGVIEW_FULL_RESEARCH_20261015.md` entirely. It is the interpreted technical report and design/architecture recommendations.
2. Review `analysis/tradingview_targeted_symbol_contracts.json` for chart/market/news/alerts/trading symbols.
3. Review `evidence/tv_js_bridge_methods.csv` and `evidence/tv_js_bridge_subscriptions.csv` for the 167 method contracts and 49 subscriptions extracted directly from the uploaded APK.
4. Inspect `analysis/tradingview_derived_overview.json` and `evidence/tradingview_apk_metadata.json` for original APK provenance, raw DEX counts and signing facts.
5. The **full pack** additionally contains `tradingview_class_inventory.jsonl`, `tradingview_method_inventory.jsonl`, and `tradingview_field_inventory.jsonl` with exhaustive DEX metadata from the user's exact upload. The **compact pack** omits these very large line-oriented inventories.
6. For **true REA/JADX** evidence from both apps, retrieve `/opt/van-rea-lab/evidence/OPUS55_REA_VM_EVIDENCE_INDEX_20261015.json` on `van-trading-core` via Global DIAL MCP. The VM evidence index SHA-256 is `829af2ed8c9784da2a6affd5d093bd22e6e7dd1066c6a05af64cbea61e333744`. It indexes 39 REA records and their individual SHA256 digests. These remote evidence JSON files are **not embedded** in the portable pack.

## Identity and scope
- Uploaded TradingView APK SHA256: `dfbc561d32fdd4405956d8bd0b3f30d7490f60a790ebfc143c48206c8f7671b1` (version 1.20.84.0.1002505).
- VM secondary TradingView APK SHA256: `c762b6dfd910b552050e775eba739a0ed5a2838e6f3f433c238a5a8c6c4cf584`. Seven DEX files and the assets/resources are identical to the uploaded original, but the binary manifest differs. Do not equate overall APK hashes or signing lineage.
- MT5 official APK SHA256: `6f220fc7ccc750ed0d670b32a0758a1800fe232c4c9b7637673d4f9c7ea7bdd6` (version 500.6260).
- TradingView's 70,877 raw DEX class definitions are not the same metric as its 40,046 distinct JADX-reported names across seven REA shards. They must not be presented interchangeably.
- `tradingview_strings_dex.jsonl` was intentionally omitted from both packs to avoid distributing unrelated raw APK strings. No source APK or third-party decompiled source bodies are embedded.
- Neither Android app was launched on a device or benchmarked in this study.

## Opus review instruction
Correlate each adoption candidate with owner requirements and the locked VAN designs. Verify `REA_CONFIRMED` versus `APK_RAW_CONFIRMED` versus `ENGINEERING_INFERENCE`; never promote presence of a class to a proven runtime behaviour. Preserve VATI's deterministic risk and execution authority. Proposed chart interactions and LLM/JEV context are observational and cannot mint trade permission. Before changing VAN source, reconcile unmerged candidate branches and the 78-surface preservation register, then generate a DIAL project-scoped Development Pack, validate F0-F15, qualify the exact production callers and read-back postconditions on the Samsung S24, and require owner acceptance for the visual design.
