#!/usr/bin/env python3
"""Read-only, deterministic APK/DEX/AXML metadata indexer.
Does not execute APK, repackage apps, or reproduce decompiled source.
This is NOT REA/JADX; use it as a local attachment forensic supplement.
"""
import os,struct,zipfile,hashlib,json,re,collections,pathlib,datetime,traceback,time
from xml.sax.saxutils import escape,quoteattr
APK=pathlib.Path('/mnt/data/TradingViewcom.tradingview.tradingviewappv1.20.84.0.1002505.apk')
OUT=pathlib.Path('/mnt/data/VAN_REA_Opus_Handoff_20261015/evidence');OUT.mkdir(parents=True,exist_ok=True)

def u2(b,o):return struct.unpack_from('<H',b,o)[0]
def u4(b,o):return struct.unpack_from('<I',b,o)[0]
def u8(b,o):return struct.unpack_from('<Q',b,o)[0]
def uleb(b,o):
 v=0
 for i in range(5):
  t=b[o+i];v|=(t&0x7f)<<(7*i)
  if not(t&0x80):return v,o+i+1
 return v,o+5

def dex_parse(data,filename):
 if not data.startswith(b'dex\n'):raise ValueError('not DEX')
 # Read index tables using standard DEX header offsets.
 cnt=lambda o:(u4(data,o),u4(data,o+4))
 ns,so=cnt(0x38);nt,to=cnt(0x40);np,po=cnt(0x48);nf,fo=cnt(0x50);nm,mo=cnt(0x58);nc,co=cnt(0x60)
 strings=[]
 for i in range(ns):
  o=u4(data,so+4*i);_,o=uleb(data,o);e=data.index(b'\x00',o)
  strings.append(data[o:e].decode('utf-8','replace'))
 types=[strings[u4(data,to+4*i)] for i in range(nt)]
 def typ(idx):return types[idx] if idx<len(types) else f'<badtype:{idx}>'
 protos=[]
 for i in range(np):
  so_,ri,params_off=struct.unpack_from('<III',data,po+i*12)
  par=[]
  if params_off:
   n=u4(data,params_off);par=[typ(u2(data,params_off+4+j*2)) for j in range(n)]
  protos.append({'return':typ(ri),'params':par})
 fields=[]
 for i in range(nf):
  ci,ti,ni=struct.unpack_from('<HHI',data,fo+i*8)
  fields.append({'owner':typ(ci),'type':typ(ti),'name':strings[ni]})
 methods=[]
 for i in range(nm):
  ci,pi,ni=struct.unpack_from('<HHI',data,mo+i*8)
  methods.append({'owner':typ(ci),'name':strings[ni],'return':protos[pi]['return'],'params':protos[pi]['params']})
 classes=[];method_impl=[];class_fields=[];errors=[]
 for i in range(nc):
  at=co+i*32
  clsidx,flags,supidx,interfaces_off,srcidx,anno_off,cd_off,sv_off=struct.unpack_from('<IIIIIIII',data,at)
  name=typ(clsidx);sup=typ(supidx) if supidx!=0xffffffff else None
  inter=[]
  if interfaces_off:
   n=u4(data,interfaces_off);inter=[typ(u2(data,interfaces_off+4+2*j)) for j in range(n)]
  source=strings[srcidx] if srcidx<len(strings) else None
  classes.append({'dex':filename,'name':name,'super':sup,'interfaces':inter,'source':source,'access_flags':flags,'methods_defined':0,'fields_defined':0})
  if not cd_off:continue
  try:
   counts=[None]*4;cur=cd_off
   for k in range(4):counts[k],cur=uleb(data,cur)
   field_index=0
   for n in range(counts[0]+counts[1]):
    delta,cur=uleb(data,cur);field_index+=delta;acc,cur=uleb(data,cur)
    if field_index<len(fields):
     x=dict(fields[field_index]);x['dex']=filename;x['flags']=acc;class_fields.append(x)
     classes[-1]['fields_defined']+=1
   method_index=0
   for n in range(counts[2]+counts[3]):
    delta,cur=uleb(data,cur);method_index+=delta;acc,cur=uleb(data,cur);codeoff,cur=uleb(data,cur)
    if method_index<len(methods):
     x=dict(methods[method_index]);x.update(dex=filename,access_flags=acc,code_off=codeoff,code_insns_size=0,code_registers=None)
     if codeoff and codeoff+16<len(data):
      regs,ins,outs,tries,debug,insns=struct.unpack_from('<HHHHII',data,codeoff)
      x['code_insns_size']=insns;x['code_registers']=regs
     method_impl.append(x);classes[-1]['methods_defined']+=1
  except Exception as e:errors.append({'class':name,'error':str(e)})
 return {'dex':filename,'header':{'version':data[4:7].decode('ascii','replace'),'strings':ns,'types':nt,'protos':np,'fields_ids':nf,'method_ids':nm,'class_defs':nc},'classes':classes,'methods':method_impl,'fields':class_fields,'strings':strings,'errors':errors}

# Android binary XML parsing, including resource namespace mapping.
NO=0xffffffff
XML_NS='http://schemas.android.com/apk/res/android'
def axml(data):
 if u2(data,0)!=3:raise ValueError('Not Android binary XML')
 o=8;strings=[];resource_map=[];stk=[];xml_lines=[];start_tags=[];namespaces={}
 def name(idx):return strings[idx] if idx< len(strings) else ('' if idx==NO else f'UNKNOWN_{idx}')
 def length8(buf,idx):
  a=buf[idx];idx+=1
  if a&0x80:a=((a&0x7f)<<8)|buf[idx];idx+=1
  return a,idx
 def length16(buf,idx):
  a=u2(buf,idx);idx+=2
  if a&0x8000:a=((a&0x7fff)<<16)|u2(buf,idx);idx+=2
  return a,idx
 while o<len(data):
  if o+8>len(data):break
  typ,hs,sz=struct.unpack_from('<HHI',data,o)
  if sz<8 or o+sz>len(data):raise ValueError('Bad xml chunk at '+str(o))
  if typ==0x0001:
   sc,st,flags,sstart,styles=struct.unpack_from('<IIIII',data,o+8)
   utf8=bool(flags&256);start=o+sstart
   for i in range(sc):
    k=u4(data,o+hs+4*i)+start
    if utf8:
     _,k=length8(data,k);count,k=length8(data,k);raw=data[k:k+count];strings.append(raw.decode('utf8','replace'))
    else:
     count,k=length16(data,k);raw=data[k:k+count*2];strings.append(raw.decode('utf-16le','replace'))
  elif typ==0x0180:
   resource_map=[u4(data,o+hs+4*i) for i in range((sz-hs)//4)]
  elif typ==0x0100:
   px,uri=struct.unpack_from('<II',data,o+16);namespaces[name(px)]=name(uri)
  elif typ==0x0102:
   nsidx,tagidx,attr_start,attr_size,attr_count,ididx,clidx,styleidx=struct.unpack_from('<IIHHHHHH',data,o+16)
   tag=name(tagidx);attrs={};raw_attrs={}
   pos=o+16+attr_start
   for ai in range(attr_count):
    ap=pos+ai*attr_size;an,ai_name,raw,vs,res0,vt,vd=struct.unpack_from('<IIIHBBI',data,ap)
    key=name(ai_name)
    if an!=NO:key='android:'+key if name(an)==XML_NS else name(an)+':'+key
    if raw!=NO:value=name(raw)
    elif vt==3:value=name(vd)
    elif vt==0x12:value=(vd!=0)
    elif vt in (0x10,0x11):value=vd
    elif vt==1:value='@'+hex(vd)
    else:value={'type':vt,'data':vd}
    attrs[key]=value
    raw_attrs[key]={'value':value,'type':vt,'resource_id':(resource_map[ai_name] if ai_name<len(resource_map) else None)}
   start_tags.append({'name':tag,'attributes':attrs,'line':u4(data,o+8)})
  o+=sz
 return {'tags':start_tags,'strings_count':len(strings),'namespaces':namespaces,'resource_count':len(resource_map)}

def signature_block_info(data):
 eocd=data.rfind(b'PK\x05\x06');cd=u4(data,eocd+16)
 magic=data[cd-16:cd]
 output={'found':magic==b'APK Sig Block 42','certificates':[],'schemes':[]}
 if magic!=b'APK Sig Block 42':return output
 last=u8(data,cd-24);start=cd-(last+8);assert u8(data,start)==last
 o=start+8
 while o<cd-24:
  sz=u8(data,o);o+=8;key=u4(data,o);o+=4;entry=data[o:o+sz-4];o+=sz-4
  output['schemes'].append(hex(key))
  if key not in (0x7109871a,0xf05368c0):continue
  # Parse the v2/v3 signedData certificates sequence from the first signer.
  def read_lp(data,p):
   if p+4>len(data):raise ValueError('short')
   n=u4(data,p);p+=4
   if p+n>len(data):raise ValueError('bad lp')
   return data[p:p+n],p+n
  try:
   signers,_=read_lp(entry,0);signer,_=read_lp(signers,0)
   signed,_=read_lp(signer,0)
   digests,p=read_lp(signed,0);certs,p=read_lp(signed,p)
   cert,_=read_lp(certs,0)
   from cryptography import x509
   from cryptography.hazmat.primitives import hashes
   parsed=x509.load_der_x509_certificate(cert)
   output['certificates'].append({'scheme':hex(key),'subject':parsed.subject.rfc4514_string(),'issuer':parsed.issuer.rfc4514_string(),'sha256':parsed.fingerprint(hashes.SHA256()).hex(),'sha1':parsed.fingerprint(hashes.SHA1()).hex(),'valid_from':parsed.not_valid_before_utc.isoformat(),'valid_to':parsed.not_valid_after_utc.isoformat()})
  except Exception as e:output.setdefault('parse_errors',[]).append({'scheme':hex(key),'error':str(e)})
 return output

def main():
 started=time.monotonic();raw=APK.read_bytes();sha=hashlib.sha256(raw).hexdigest();sig=signature_block_info(raw)
 z=zipfile.ZipFile(APK)
 archive=[{'path':i.filename,'compressed_bytes':i.compress_size,'uncompressed_bytes':i.file_size,'sha256':hashlib.sha256(z.read(i)).hexdigest()} for i in z.infolist() if not i.is_dir()]
 man=axml(z.read('AndroidManifest.xml'))
 dexfiles=sorted([n for n in z.namelist() if n.endswith('.dex')])
 dexheaders=[];classes=[];methods=[];fields=[];strings=[];errors=[]
 for f in dexfiles:
  d=dex_parse(z.read(f),f)
  dexheaders.append(d['header']|{'dex':f,'sha256':hashlib.sha256(z.read(f)).hexdigest()})
  classes.extend(d['classes']);methods.extend(d['methods']);fields.extend(d['fields']);strings.extend([{'dex':f,'string':s} for s in d['strings']]);errors.extend(d['errors'])
  print('processed',f,len(d['classes']),'classes',len(d['methods']),'methods',flush=True)
 results={'schema':'tv-attachment-source-forensics/1.0','input_file_name':APK.name,'sha256':sha,'input_bytes':len(raw),'dex_headers':dexheaders,'apk_signature':sig,'parse_errors':errors,'manifest':man,'classes_count':len(classes),'method_implementations_count':len(methods),'field_implementations_count':len(fields),'string_occurrences_count':len(strings),'archive_entries_count':len(archive),'processing_seconds':round(time.monotonic()-started,2),'methodology':'Python static DEX/AXML signature-block parser; NOT executed by REA/JADX and NOT runtime verification'}
 def write(name,data):
  p=OUT/name
  if name.endswith('.jsonl'):
   with open(p,'w',encoding='utf8') as fp:
    for row in data:fp.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
  else:json.dump(data,open(p,'w',encoding='utf8'),ensure_ascii=False,indent=2)
 write('tradingview_apk_metadata.json',results)
 write('tradingview_archive_entries.jsonl',archive)
 write('tradingview_class_inventory.jsonl',classes)
 write('tradingview_method_inventory.jsonl',methods)
 write('tradingview_field_inventory.jsonl',fields)
 # Dedup strings, retain provenance list separately for complete evidence.
 write('tradingview_strings_dex.jsonl',strings)
 print('SUMMARY',json.dumps({k:v for k,v in results.items() if k not in ['manifest','dex_headers']},default=str),flush=True)
if __name__=='__main__':main()
