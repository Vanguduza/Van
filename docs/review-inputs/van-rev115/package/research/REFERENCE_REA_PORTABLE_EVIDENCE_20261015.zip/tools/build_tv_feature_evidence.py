#!/usr/bin/env python3
"""High-fidelity derived feature/spec inventory from attached TradingView APK metadata."""
import json,os,collections,re,zipfile,hashlib,datetime,pathlib,csv
D=pathlib.Path('/mnt/data/VAN_REA_Opus_Handoff_20261015/evidence')
A=pathlib.Path('/mnt/data/TradingViewcom.tradingview.tradingviewappv1.20.84.0.1002505.apk')
OUT=pathlib.Path('/mnt/data/VAN_REA_Opus_Handoff_20261015/analysis');OUT.mkdir(parents=True,exist_ok=True)
classes=[json.loads(x) for x in open(D/'tradingview_class_inventory.jsonl')]
fields=[json.loads(x) for x in open(D/'tradingview_field_inventory.jsonl')]
methodidx=collections.defaultdict(list)
for line in open(D/'tradingview_method_inventory.jsonl'):
 row=json.loads(line);methodidx[row['owner']].append(row)
manifest=json.load(open(D/'tradingview_apk_metadata.json'))['manifest']['tags']
app='Lcom/tradingview/tradingviewapp/'
res=[];synthetic_tokens=('$$ExternalSyntheticLambda','_Factory;','Dagger','_MembersInjector','_Provide')
for r in classes:
 n=r['name']
 if not n.startswith(app):continue
 cleaned=n[len(app):].rstrip(';')
 prefix='/'.join(cleaned.split('/')[:3]);subsystem=cleaned.split('/')[0]
 synthetic=any(t in n for t in synthetic_tokens) or '/R$' in n or n.endswith('/R;') or bool(re.search(r'\$\d+;',n))
 res.append({'dex':r['dex'],'class_name':n[1:-1].replace('/','.'),'namespace':prefix,'subsystem':subsystem,'is_generated_or_synthetic':synthetic,'method_count':r['methods_defined'],'field_count':r['fields_defined']})
agg=collections.defaultdict(lambda:collections.Counter())
for r in res:
 s=agg[r['namespace']];s['all']+=1
 if not r['is_generated_or_synthetic']:s['non_generated']+=1
 s['methods']+=r['method_count']
byarea={k:dict(v) for k,v in sorted(agg.items(),key=lambda kv:-kv[1]['non_generated'])}

# Representative source-evidence classes chosen to test user-facing and infra contracts.
subjects={
'chart_js_bridge':['core/js/api/ChartBridge;','core/js/client/JSClient;','core/js/runtime/messaging/WebMessageChannel;','core/js/runtime/adapter/BridgeSubscriptionsDelegateImpl;'],
'chart_presenter':['feature/chart/api/ChartApi;','feature/chart/impl/module/chart/presenter/ChartPresenter;','feature/chart/impl/module/chart/presenter/delegates/ChartSubscriptionEventsDelegateImpl;'],
'chart_native':['chartnative/charts/Chart;','chartnative/charts/BarLineChartBase;'],
'news_feed':['feature/news/api/interactor/NewsListInteractor;','feature/news/api/model/NewsContext;','feature/market/module/feed/presenter/delegates/MarketNewsOutputDelegate;'],
'alerts':['feature/alerts/api/data/network/AlertsWebApi;','feature/alerts/impl/redesign/shared/service/AlertsServiceImpl;'],
'economic_calendar':['feature/economic/calendar/feed/presenter/EconomicCalendarFeedPresenter;','feature/economic/calendar/feed/state/EconomicCalendarFeedViewState;'],
'screeners':['feature/screener/api/model/ScreenerScanRequest;','feature/screener/api/model/ScreenerScanResponse;'],
'watchlists':['feature/watchlist/settings/api/interactor/WatchlistSettingsInteractor;','feature/chart/impl/module/chart/presenter/delegates/ChartWatchlistInteractorDelegateImpl;'],
'broker_and_trading':['feature/trading/interactor/TradingInteractor;','feature/broker/oauth/api/interactor/BrokerOAuthInteractor;','feature/trading/TradingInteractorImpl;']
}
fields_by_owner=collections.defaultdict(list)
for x in fields:fields_by_owner[x['owner']].append(x)
classes_by_name={x['name']:x for x in classes}
focus={}
for topic,patterns in subjects.items():
 arr=[]
 for p in patterns:
  matching=[k for k in classes_by_name if k.endswith(p)]
  for cl in matching:
   r=classes_by_name[cl]
   methods=[]
   for m in methodidx[cl]:
    if m['name'].startswith('$r8$lambda'):continue
    methods.append({'name':m['name'],'param_types':m['params'],'return_type':m['return'],'code_insns_size':m['code_insns_size'],'has_code':bool(m['code_off'])})
   arr.append({'class_name':cl[1:-1].replace('/','.'),'dex':r['dex'],'superclass':r['super'],'interfaces':r['interfaces'],'methods':methods,'fields':[{'name':x['name'],'type':x['type']} for x in fields_by_owner[cl]]})
 focus[topic]=arr

# AXML manifest summary, actual source values, excluding sensitive per-user data (none observed)
perm=sorted(set(t['attributes'].get('android:name','') for t in manifest if t['name'] in ('uses-permission','uses-permission-sdk-23')))
screens={k:[] for k in ['activity','service','receiver','provider','uses-feature','meta-data']}
for t in manifest:
 if t['name'] in screens:
  screens[t['name']].append({k:v for k,v in t['attributes'].items() if k in ('android:name','android:exported','android:enabled','android:permission','android:process','android:authorities','android:foregroundServiceType')})
m={'package':next((t['attributes'].get('package') for t in manifest if t['name']=='manifest'),None),'manifest_root':next((t['attributes'] for t in manifest if t['name']=='manifest'),{}),'uses_sdk':next((t['attributes'] for t in manifest if t['name']=='uses-sdk'),{}),'permissions':perm,'components':screens}

# JS assets: prove existence/strings and assess bridge surface, never redistribute third-party code.
assets=[];flags={
 'web_message':['postMessage','WebMessage','MessageChannel','MessagePort','receiveMessage'],
 'native_android':['Android','android','nativeBridge','NativeBridge'],
 'subscription':['subscribe','unsubscribe','pushstream','pushStream','onmessage'],
 'market_updates':['quote','symbol','feed','price','timestamp'],
 'chart_interop':['chart','interval','indicator','drawing','replay'],
 'trade_interop':['order','position','broker','buy','sell'],
 'event_and_news':['news','alert','economic','notification']
}
with zipfile.ZipFile(A) as z:
 for info in z.infolist():
  if not info.filename.startswith('assets/') or info.is_dir():continue
  ext=pathlib.PurePosixPath(info.filename).suffix
  if ext not in ('.js','.json','.html','.txt'):continue
  dat=z.read(info.filename)
  if not dat:continue
  s=dat.decode('utf8','replace')
  words={cat:{w:len(re.findall(re.escape(w),s,re.I)) for w in patterns if re.search(re.escape(w),s,re.I)} for cat,patterns in flags.items()}
  keys={cat:sum(z.values()) for cat,z in words.items() if z}
  funcs=sorted(set(re.findall(r'\b(?:function\s+|(?:export\s+)?(?:const|let|var)\s+)([A-Za-z_$][A-Za-z_$0-9]{2,})',s)))[:50]
  assets.append({'path':info.filename,'size_bytes':len(dat),'sha256':hashlib.sha256(dat).hexdigest(),'keyword_counts':keys,'keyword_details':words,'named_functions_or_variables_sample':funcs})

summary={'schema':'tradingview-feature-derived-evidence/1.0','analysis_mode':'STATIC_DEX_AXML_AND_APK_ASSET_METADATA_NOT_REA','apk_sha256':json.load(open(D/'tradingview_apk_metadata.json'))['sha256'],'class_count_all':len(classes),'class_count_app_package':len(res),'class_count_app_non_generated_heuristic':sum(not v['is_generated_or_synthetic'] for v in res),'top_namespaces':dict(list(byarea.items())[:90]),'subjects':{k:{'classes':len(v),'class_names':[x['class_name'] for x in v]} for k,v in focus.items()},'permission_count':len(perm),'manifest_component_counts':{k:len(v) for k,v in screens.items()},'embedded_assets_count':len(assets)}
for name,obj in [('tradingview_derived_overview.json',summary),('tradingview_targeted_symbol_contracts.json',focus),('tradingview_manifest_summary.json',m),('tradingview_embedded_js_asset_index.json',assets),('tradingview_app_class_package_index.json',byarea)]:
 json.dump(obj,open(OUT/name,'w'),indent=2,ensure_ascii=False)
with open(OUT/'tradingview_filtered_app_classes.csv','w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=['class_name','dex','namespace','subsystem','is_generated_or_synthetic','method_count','field_count']);writer.writeheader();writer.writerows(res)
print(json.dumps({'app_class_count':len(res),'non_generated':summary['class_count_app_non_generated_heuristic'],'subject_count':len(focus),'target_classes':sum(len(v) for v in focus.values()),'manifest_components':summary['manifest_component_counts'],'js_assets':len(assets),'top_namespaces':list(byarea.items())[:13]},default=str)[:14000])
