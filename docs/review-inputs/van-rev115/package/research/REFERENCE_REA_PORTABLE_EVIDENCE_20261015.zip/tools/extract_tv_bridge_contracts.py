import os,json,zipfile,csv,collections,re,pathlib
APK='/mnt/data/TradingViewcom.tradingview.tradingviewappv1.20.84.0.1002505.apk'
OUT=pathlib.Path('/mnt/data/VAN_REA_Opus_Handoff_20261015/evidence')
with zipfile.ZipFile(APK) as z:obj=json.loads(z.read('assets/config/config.json'))
catmap={
'bar_replay':['replay','autoplay'],
'orders_broker':['trading','broker','buy','sell','position','order'],
'chart_state':['chart','layout','viewmode','autosave','symbol','interval','resolution','zoom','theme','currency','unit','fullscreen','range'],
'annotation_drawings':['draw','linetool','magnet','object','undo','redo'],
'alerts_news':['alert','news','notification'],
'collaboration_share':['share','publish','social'],
'dialog_panel':['dialog','popup','panel','menu','visibility','show','hide'],
}
def cat(name):
 s=name.lower()
 return next((k for k,w in catmap.items() if any(x in s for x in w)),'other')
res={}
for kind in ('methods','subscriptions'):
 data=[]
 for x in obj[kind]:
  callback=x.get('callback') or {}
  def ftype(y):return '.'.join([y.get('typePackageName',''),*y.get('typeSimpleNames',[])]) if isinstance(y,dict) else str(y)
  input_items=x.get('input') or []
  data.append({'name':x['name'],'bridge_name':x.get('bridgeName'),'unsubscribe_name':x.get('unsubscribeName'),'category':cat(x['name']),'argument_types':[ftype(y.get('type') or y) for y in input_items],'callback_type':ftype(callback),'serializer':ftype(x.get('serializer')),'has_callback':bool(callback)})
 res[kind]=data
 json.dump(data,open(OUT/f'tv_js_bridge_{kind}.json','w'),indent=2)
 with open(OUT/f'tv_js_bridge_{kind}.csv','w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['name','bridge_name','unsubscribe_name','category','argument_types','callback_type','serializer','has_callback']);w.writeheader();w.writerows({**v,'argument_types':' | '.join(v['argument_types'])} for v in data)
summary={kind:{'count':len(data),'category_counts':dict(collections.Counter(x['category'] for x in data)),'examples':{k:[x['name'] for x in data if x['category']==k][:14] for k in sorted(set(x['category'] for x in data))}} for kind,data in res.items()}
summary['artifact_sha256']=__import__('hashlib').sha256(zipfile.ZipFile(APK).read('assets/config/config.json')).hexdigest()
summary['methodology']='typed metadata decoded from local APK assets/config/config.json, not REA, functionality requires runtime verification'
json.dump(summary,open(OUT/'tv_js_bridge_summary.json','w'),indent=2)
print(json.dumps(summary)[:14000])
