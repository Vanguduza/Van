# What the current checks prove

`verify_rev114.py` and `plan/render_plan.py --check` validate prepared document identity, references, selected semantic guards, graph order, preservation and synthetic contract examples. `--selftest` deliberately corrupts in-memory document/fixture copies; it does not modify source or live services. The positive-loop fixture is a tiny independent arithmetic contract example, not a production learning implementation or profit study.

`verify_news_readiness.py`, `verify_forecast_contracts.py` and `verify_hva_contracts.py` retain separately scoped document/schema fixtures. Their successful checks do not validate actual provider, source, model, financial or owner facts.

Historical whole-package checkers are under `lineage/rev1_13/verification/` because they bind a different revision. They are not the current readiness gate. Historical raw source/tests and old receipts retain their original scope and execution dates.

F15 and Backend Complete templates are deliberately NOT_ISSUED. Real promotion verification must resolve trusted issuer signatures, exact scope/source/data/policy hashes, independent test receipts, freshness and revocation; neither this document checker nor an archive hash can issue authority.

No local document test is described as a Netcup/Oracle project-runtime test. Actual project/backend/economic/provider/native testing remains under qualified DIAL controls, with all 1,520 application contracts NOT_RUN in this delivery.
