# Document verification versus application qualification

From this extracted package run:

```sh
python verification/verify_unified.py --selftest
python plan/render_plan.py --check
python verification/verify_graph_export.py --selftest
python verification/verify_hva_contracts.py --selftest
python verification/verify_integration_preservation.py --selftest
python verification/verify_news_readiness.py --selftest
python verification/verify_forecast_contracts.py --selftest
python verification/verify_package.py
```

The schema checker requires jsonschema. These commands check this specification and synthetic examples, not VAN application source or provider behavior. The preserved application tests are separately planned and NOT_RUN. `assert_readiness.py` must continue to refuse the unissued F15/BG certificates.

Existing tests and source receipts in lineage are historical. Current VM receipts bind only the exact files sent to the isolated VM and their stated tests; they are not a full app test run or signed acceptance. Coordinated tampering with files and unsigned scope locks still requires independent authority/signature review.

The graph VM receipt is an actual exported report whose bytes were checked against the VM-emitted SHA-256. The local graph script retains its original 14 mutation cases; the VM pass also tests four added domain constraints. Neither certificate template is enabled.
