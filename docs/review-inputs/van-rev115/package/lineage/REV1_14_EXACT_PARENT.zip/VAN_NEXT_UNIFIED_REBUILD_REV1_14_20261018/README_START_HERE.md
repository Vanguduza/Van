# VAN Next Rev 1.14 — Self-optimizing execution and crypto, one backend-first plan

**Status:** complete revised specification candidate; owner/independent admission pending. No F15, BG, live financial or application qualification is issued.

## Start here

1. `VATI_SELF_OPTIMIZING_EXECUTION_AND_CRYPTO_BLUEPRINT_REV2_20261018.md` — focused technical architecture and complete two-level autonomy lifecycle.
2. `VAN_NEXT_UNIFIED_REBUILD_BLUEPRINT_REV1_14_20261018.md` — the same core objective followed by the full inherited VAN product/backend/locked-style specification and scoped precedence rules.
3. `plan/VAN_NEXT_DETERMINISTIC_PLAN_REV1_14.md` — one generated 131-packet plan: every mandatory backend and verifier before BG-001/098; first native UX/099.
4. `ASTRA_CODEX_REVIEW_AND_OPTIMIZATION_PROMPT.md` — complete copy-paste independent Codex review prompt, including qualified backtest-driven design improvement and complexity control.

## What changed

Self-optimization is now mandatory engineering: genuine mature outcomes → durable versioned evidence → automatic later selection within qualified bounds → reproducible replay, plus research → evaluation → qualification → authorized policy activation → monitoring/revocation/recovery. Crypto is no longer only read-only discovery: **actual centralized-exchange spot trading** is a required software integration under existing VATI owners. Existing markets and chain/event research are preserved. No withdrawal, new venue access, derivatives or wallet-signing authority is inferred.

The extension reuses existing units and deployment owners. It adds no independently deployed service requirement, no second trading engine and no extra global navigation tabs. A failed model's economics do not excuse an incomplete required software integration; a qualified software integration does not prove a profitable model.

## Exact scope

301 active requirement objects (237 preserved + 64 new); 1,520 planned application acceptance contracts (1,328 preserved + 192 new), **all NOT_RUN**; 131 stable units; 82 backend and 12 backend-verification; 234 contexts; 349 historical owner actions; 22 Product Truth atoms. Twelve strict record variants, five lifecycle machines with 69 transitions and 33 typed proof predicates, sixteen independent invariants, and the positive loop/replay conformance fixture specify the new acceptance boundary. Counts are not semantic/runtime evidence.

## Verified in this delivery

- Prepared source/requirement/test/action/truth preservation, references and graph checks: zero findings.
- New adversarial document/schema/fixture cases:47/47 detected.
- All 12 new strict-record fixtures validated. The small synthetic evidence→selection arithmetic fixture changes method A→B and reproduces on cold replay; this is **not actual VATI behavior or economic evidence**.
- Preserved independent subdomain documentary checks: news 12/12; forecasting 38/38 (18 schemas/12 fixtures); high-value research 67/67 (12 schemas/12 fixtures).
- Plan rendering and recorded command outputs reproduce from the package. Archive hashes and fresh-extraction check are recorded separately in the delivery receipt.

## Re-run preparation checks

Python 3 and the installed `jsonschema` package are required; no automatic installation or network access is performed. Tested local document environment is recorded in `verification/TOOL_ENVIRONMENT.json`. Commands are document-processing only:

```sh
python plan/render_plan.py --check
python verification/verify_rev114.py --json
python verification/verify_rev114.py --selftest --json
python verification/verify_rev114.py --check-package --json
python verification/verify_news_readiness.py --selftest
python verification/verify_forecast_contracts.py --selftest
python verification/verify_hva_contracts.py --selftest
```

Do not substitute these for actual DIAL source/runtime/backtest/provider/native tests. New application acceptance remains unexecuted. Prepared hashes are not signatures; reference fixtures are not financial proof.

## Key supporting resources

`research/REVIEW_AND_UPGRADE_DECISIONS_REV1_14.md`, `REV114_SOURCE_REGISTER.json`, `traceability/SELF_OPTIMIZATION_SOURCE_CROSSWALK.json`, `REV114_REQUIREMENTS.json`, `contracts/self_optimization/`, `verification/SELF_OPTIMIZATION_ACCEPTANCE_CONTRACTS.json`, `design/SELF_OPTIMIZATION_CRYPTO_INTERACTION_CONTRACT.md`, and `CONSOLIDATION_APPLY_PROTOCOL.md`. Raw supplied recommendations and exact parent inputs remain in source/lineage directories. Both locked dark/light assets are preserved unchanged; no font binaries are redistributed.

## Still required, not waived

Independent semantic and current-source admission, exact owner scope signature, DIAL runtime readiness and F15; all complete backend source/service/actual target-provider tests and BG; actual eligible crypto provider selection/admission; economic qualifications and separately authorized policy use; native and physical S24 acceptance after backend completion. No live market, broker, model fitting, historical backtest, app implementation, repository merge, deployment, network configuration or financial action was performed by this documentation task.
