"""The decision cycle (Rev 2 §61): one pass per bar/tick for one instrument.

   VERIFY DATA → MARKET STATE → OPPORTUNITY → RISK AUTHORITY → ROUTER →
   PROTECT → (marks) → RECONCILE → TCA → REVIEW → VTIL PROPOSE

The same class drives backtests (PaperAdapter over historical bars) and live
sessions (real adapter over a feed), which is what makes backtest-to-live parity
a property of the code rather than a hope."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from decimal import Decimal
from typing import Callable, Optional, Sequence

from vati.arbiter import OpportunityEngine
from vati.core.canonical import canonical_hash
from vati.core.events import EventKind, make_event
from vati.core.ledger import Ledger
from vati.execution.base import StopMode, VenueAdapter
from vati.execution.policy import ExecutionBucket, ExecutionPolicyEngine
from vati.execution.protection import ProtectionManager
from vati.execution.pretrade import MarketReference, PreTradeControls
from vati.execution.route_registry import RouteRegistry
from vati.execution.style_selector import ExecutionStyleSelector, LiquidityView
from vati.execution.router import ExecutionRouter, RouterError
from vati.execution.review import review_trade
from vati.execution.tca import compute_tca
from vati.execution.reconciliation import LedgerPosition, reconcile
from vati.intelligence.events import EventMatrix, EventWindowState
from vati.intelligence.market_state import MarketState, build_market_state
from vati.intelligence.regimes import RegimeEngine
from vati.learning.episodes import LessonStore, lesson_from_verdict
from vati.learning.hooks import LearningHooks, to_payload
from vati.lifecycle.scale_policy import (
    Adjustment, AdjustmentPolicyRegistry, PositionAdjustmentEngine, ScalePolicyRegistry,
)
from vati.lifecycle.thesis import ThesisEngine, ThesisInputs, thesis_from_capsule
from vati.lifecycle.trade_health import PositionHealthInputs, TradeHealthEngine
from vati.cognition.attribution import DecisionQualityInputs, DecisionQualityLedger
from vati.market_data.bars import Bar
from vati.market_data.calendars import MarketCalendar
from vati.observability import metrics
from vati.risk.lockouts import DRAWDOWN_RESUME_EVENT, LockoutPolicy, LossStreakGovernor, relative_top_state, restore_peak_equity
from vati.risk import Decision, KillSwitch, MarketIntegrityState, OpenPosition, RiskAuthority, RiskSnapshot, SymbolContract, TradingMandate
from vati.risk.contracts import Direction, LossModel, StrategyState
from vati.risk.serde import intent_to_dict, snapshot_to_dict
from vati.strategies.base import StrategyContext
from vati.arbiter.strategy_arbiter import ACTIVE_STATES
from vati.vtil import AdmissionLedger

ZERO = Decimal("0")


@dataclass
class SessionConfig:
    symbol: str
    base: str
    quote: str
    venue: str
    account_alias: str
    contract: SymbolContract
    mandate_dict: dict
    #: Explicit market-state identity. Production services always set this from
    #: ServiceConfig; UNKNOWN is retained only for legacy/research callers.
    timeframe: str = "UNKNOWN"
    warmup_bars: int = 60
    max_quote_age_ms: int = 5000
    targets_from_signal: bool = True
    time_in_force: str = "DAY"
    session_id: str = "session"
    activation_id: str = "vtil-act-unresolved"
    software_stops: bool = False   # ZSE: no venue stop


@dataclass
class CycleResult:
    bar_end_ms: int
    state_hash: str
    decision: str            # NO_TRADE | WAIT | SKIP | REJECTED:<code> | APPROVED | REDUCED | ROUTER_REFUSED
    reason: str
    approved_size: Decimal = ZERO


class DecisionCycle:
    def __init__(self, *, cfg: SessionConfig, adapter: VenueAdapter, ledger: Ledger, engine: OpportunityEngine, cost_fn: Callable[[MarketState], Decimal],
                 calendar: MarketCalendar, events: EventMatrix, regime_engine: Optional[RegimeEngine] = None, kill_switch: Optional[KillSwitch] = None,
                 admission: Optional[AdmissionLedger] = None, ctx_fn: Optional[Callable[[MarketState, Decimal], StrategyContext]] = None,
                 learning: Optional[LearningHooks] = None) -> None:
        self.cfg, self.adapter, self.ledger, self.engine, self.cost_fn, self.calendar, self.events = cfg, adapter, ledger, engine, cost_fn, calendar, events
        self.learning = learning
        self.regime = regime_engine or RegimeEngine()
        self.kill = kill_switch or KillSwitch()
        self.mandate = TradingMandate.from_mapping(cfg.mandate_dict)
        self.authority = RiskAuthority(self.mandate)
        self.protection = ProtectionManager()
        self.routes = RouteRegistry(ledger=ledger)
        self.routes.refresh(
            account_alias=cfg.account_alias,
            adapter_id=cfg.venue,
            contracts={cfg.symbol.upper(): cfg.contract},
            now_ms=0,
            source="decision_cycle_init",
        )
        self.pretrade = PreTradeControls(routes=self.routes, ledger=ledger)
        self.style_selector = ExecutionStyleSelector(ledger=ledger)
        self.execution_policy = ExecutionPolicyEngine()
        self.router = ExecutionRouter(
            ledger=ledger, adapters={cfg.venue: adapter}, kill_switch=self.kill,
            protection=self.protection, route_registry=self.routes,
            pretrade_controls=self.pretrade, style_selector=self.style_selector,
            enforce_rev51_controls=True)
        self.admission = admission or AdmissionLedger()
        self.ctx_fn = ctx_fn or (lambda st, cost: StrategyContext(round_trip_cost_pct=cost))
        self.peak_equity = ZERO
        self.day_start_equity = ZERO
        self.week_start_equity = ZERO
        self.consecutive_losses = 0
        # P1-TRADE-RISK-005: lockouts and the high-water mark are rebuilt from the ledger,
        # so a restart can neither reset a losing-streak lock nor re-baseline the peak.
        self.streaks = LossStreakGovernor.rebuild(LockoutPolicy(self.mandate.max_consecutive_losses), ledger.iter())
        restored_peak = restore_peak_equity(ledger.iter())
        if restored_peak is not None and restored_peak > ZERO:
            self.peak_equity = restored_peak
        self.integrity = MarketIntegrityState.NORMAL
        self.reviews: list = []
        self._closed_seen = 0
        self._entries: dict[str, dict] = {}   # trade_intent_id → {entry, stop, direction, strategy_id, cost_pct}
        # GAP-F-003. Active-trade intelligence on the single-symbol runtime.
        # Same components the account runtime uses, so backtest-to-live parity
        # covers the thesis path too rather than only the order path.
        self.thesis = ThesisEngine(ledger=ledger)
        self.trade_health = TradeHealthEngine(ledger=ledger)
        self.adjustment_policies = AdjustmentPolicyRegistry()
        self.adjustments = PositionAdjustmentEngine(
            ledger=ledger, policies=self.adjustment_policies)
        self.scale_policies = ScalePolicyRegistry()
        self.decision_quality = DecisionQualityLedger(ledger=ledger)
        self.lessons = LessonStore(ledger=ledger)
        self.lessons.restore_from_ledger(ledger)
        self.engine.lessons = self.lessons
        #: Headline ingress (events/news_ingress.py) when the runtime has one.
        #: Reduce-only; the calendar keeps the blackout authority.
        self.news = None
        self.proposals: list = []

    # --------------------------------------------------------------- helpers
    def _log(self, kind: EventKind, payload: dict, *, now_ms: int, corr: str = "") -> None:
        self.ledger.append(make_event(kind, "vati-cycle", payload, event_time_ms=now_ms, received_time_ms=now_ms, correlation_id=corr or self.cfg.session_id))

    def _open_positions(self) -> tuple[OpenPosition, ...]:
        out = []
        c = self.cfg.contract
        # Resting entries reserve their worst-case risk until they fill or expire.
        for row in self._entries.values():
            if row.get("pending") and row.get("stop") is not None:
                out.append(OpenPosition(row["symbol"], row["direction"], row["pending_quantity"], abs(row["entry"] - row["stop"]),
                                        c.value_per_price_unit_per_lot, c.base_currency, c.quote_currency, "", True))
        for p in self.adapter.positions():
            stop = p.stop_price if p.stop_price is not None else self.protection.rules.get(p.position_id, None)
            stop_price = stop.stop if hasattr(stop, "stop") else stop
            if p.loss_model is LossModel.ILLIQUID_EQUITY:
                out.append(OpenPosition(p.symbol, p.direction, p.quantity, abs(p.entry_price - (stop_price or p.entry_price)), Decimal(1), c.base_currency, c.quote_currency, "", False, LossModel.ILLIQUID_EQUITY, ZERO, p.entry_price * c.liquidity_haircut))
            else:
                out.append(OpenPosition(p.symbol, p.direction, p.quantity, abs(p.entry_price - stop_price) if stop_price is not None else ZERO, c.value_per_price_unit_per_lot, c.base_currency, c.quote_currency, "", stop_price is not None))
        return tuple(out)

    def _reconciliation_ok(self, *, account_verified: bool) -> bool:
        """P0-TRADE-002 — this was hardcoded True, so RECONCILIATION_FAILED could not fire.

        Reconciled per bar against what the venue reports now, not once at startup. The
        ledger positions come from the entries this cycle actually opened, which is the
        only set the cycle can speak for; a position the venue holds that this cycle never
        opened is an orphan, and `reconcile` already treats it as blocking.
        """
        ledger_positions = [
            LedgerPosition(
                trade_intent_id=iid,
                symbol=self.cfg.symbol,
                quantity=entry.get("quantity", ZERO),
                stop_price=entry.get("stop"),
                software_stop=bool(self.cfg.software_stops),
            )
            for iid, entry in self._entries.items()
            if entry.get("open", True)
        ]
        try:
            report = reconcile(
                ledger_positions, self.adapter.positions(), account_verified=account_verified
            )
        except Exception:  # noqa: BLE001 — a reconciliation that cannot run has not passed
            return False
        return report.permit_new_orders

    def _risk_store_ok(self) -> bool:
        """P0-TRADE-002 — hardcoded True, so RISK_STORE_UNAVAILABLE could not fire.

        The risk store is the ledger: without it the authority cannot know what is open,
        what has been lost today, or whether this decision has already been made. A ledger
        that will not answer is a risk store that is unavailable.

        Incremental (P1-TRADE-LEDGER-001): a full verify from genesis on every decision
        made decision latency grow with the ledger. `verify_incremental` checks only the
        rows written since the last check, against an anchor that cannot move unnoticed,
        and re-verifies from genesis at least hourly.
        """
        try:
            return bool(self.ledger.verify_incremental()[0])
        except Exception:  # noqa: BLE001 — an unreadable ledger is not a healthy one
            return False

    def _tier1_blackout(self, *, now_ms: int) -> bool:
        """P0-TRADE-002 — hardcoded False, so EVENT_BLACKOUT could not fire.

        The event matrix already computes this and the market state already carries it;
        nothing joined the two to the snapshot the authority reads.
        """
        try:
            window, _event = self.events.state_at(now_ms, self.cfg.base, self.cfg.quote)
        except Exception:  # noqa: BLE001 — an event matrix that cannot answer fails closed
            return True
        return window in (EventWindowState.PRE_BLACKOUT, EventWindowState.POST_BLACKOUT)

    def _drawdown_top_state(self):
        """Highest promotion state among the strategies this mandate allows."""
        states = []
        for sid in self.mandate.allowed_strategies:
            try:
                states.append(self.engine.registry.get(sid).state)
            except Exception:  # noqa: BLE001 — a strategy not in the registry has no state
                continue
        return relative_top_state(states)

    def snapshot(self, *, now_ms: int, quote_age_ms: int, strategy_id: str = "") -> RiskSnapshot:
        acct = self.adapter.sync_account()
        if self.peak_equity == ZERO:
            self.peak_equity = acct.equity
        if self.day_start_equity == ZERO:
            self.day_start_equity = acct.equity
        if self.week_start_equity == ZERO:
            self.week_start_equity = acct.equity
        self.peak_equity = max(self.peak_equity, acct.equity)
        streak = self.streaks.verdict(strategy_id, now_ms) if strategy_id else None
        hb = self.adapter.heartbeat(now_ms=now_ms)
        return RiskSnapshot(now_unix=now_ms // 1000, account_alias=acct.account_alias, account_verified=acct.verified, equity=acct.equity, balance=acct.balance,
                            peak_equity=self.peak_equity, day_start_equity=self.day_start_equity, week_start_equity=self.week_start_equity,
                            consecutive_losses=streak.losses if streak else 0,
                            loss_streak_lock=streak.lock if streak else "",
                            loss_streak_multiplier=streak.risk_multiplier if streak else Decimal("1"),
                            drawdown_top_state=self._drawdown_top_state(),
                            open_positions=self._open_positions(), symbol_contract=self.cfg.contract, quote_age_ms=quote_age_ms, max_quote_age_ms=self.cfg.max_quote_age_ms,
                            broker_connected=hb.connected,
                            reconciliation_ok=self._reconciliation_ok(account_verified=acct.verified),
                            clock_sync_ok=abs(hb.server_offset_ms) < 2000,
                            risk_store_ok=self._risk_store_ok(),
                            market_integrity=self.integrity,
                            tier1_event_blackout_active=self._tier1_blackout(now_ms=now_ms),
                            margin_level_pct=acct.margin_level_pct,
                            free_margin=acct.free_margin,
                            kill_switch_triggers=frozenset(self.kill.active))

    def roll_day(self, equity: Decimal, *, new_week: bool = False) -> None:
        self.day_start_equity = equity
        if new_week:
            self.week_start_equity = equity

    # --------------------------------------------------------------- one step
    def step(self, bars: Sequence[Bar], *, now_ms: int, last_quote_ms: int) -> CycleResult:
        cfg = self.cfg
        if len(bars) < cfg.warmup_bars:
            return CycleResult(bars[-1].end_ms if bars else now_ms, "", "NO_TRADE", "warmup")
        state = build_market_state(symbol=cfg.symbol, base=cfg.base, quote=cfg.quote, bars=bars, regime_engine=self.regime, calendar=self.calendar, events=self.events,
                                   integrity=self.integrity, now_ms=now_ms, last_quote_ms=last_quote_ms, activation_id=cfg.activation_id,
                                   timeframe=cfg.timeframe)
        cost = self.cost_fn(state)
        self._log(EventKind.MARKET_STATE, {"state": state.as_dict(), "cost_pct": str(cost)}, now_ms=now_ms)
        ctx = self.ctx_fn(state, cost)
        regime_label = ctx.zse.currency_regime.value if ctx.zse is not None else state.regime.trend.value
        oa = self.engine.assess(state, ctx, regime_label=state.regime.trend.value, currency_regime_label=(ctx.zse.currency_regime.value if ctx.zse is not None else None),
                                account_alias=cfg.account_alias, venue=cfg.venue,
                                # P0-TRADE-005 — this was f"{cfg.session_id}:{state.as_of_ms}",
                                # and session_id embeds the process start timestamp. A crash
                                # and restart on the same bar produced a different key, so
                                # neither the in-process set nor the ledger-seeded router set
                                # recognised the duplicate and the order could be placed twice.
                                # The seed is now the account, the symbol and the bar, all of
                                # which are the same on both sides of a restart.
                                idempotency_seed=f"{cfg.account_alias}:{cfg.symbol}:{state.as_of_ms}")
        self._log(EventKind.OPPORTUNITY_ASSESSMENT, {"symbol": cfg.symbol, "decision": oa.decision, "reason": oa.abstain_reason, "candidates": list(oa.candidates), "assessment_hash": oa.assessment_hash}, now_ms=now_ms)
        metrics.inc("vati_cycles_total", symbol=cfg.symbol)
        if oa.intent is None:
            return CycleResult(state.as_of_ms, state.state_hash, oa.decision, oa.abstain_reason)
        intent = oa.intent
        snap = self.snapshot(now_ms=now_ms, quote_age_ms=state.quote_age_ms, strategy_id=intent.strategy_id)
        decision = self.authority.evaluate_safe(intent, snap)
        self._log(EventKind.RISK_DECISION, {"inputs": {"intent": intent_to_dict(intent), "snapshot": snapshot_to_dict(snap), "mandate": cfg.mandate_dict}, "decision": decision.to_dict()}, now_ms=now_ms, corr=intent.trade_intent_id)
        metrics.inc("vati_decisions_total", outcome=decision.decision.value)
        if decision.decision is Decision.REJECTED:
            return CycleResult(state.as_of_ms, state.state_hash, f"REJECTED:{decision.reason_code}", decision.reason_detail)
        # P1-TRADE-007 and P4-TRADE-009 — this used to be an empty assignment, a loop
        # with a bare `pass`, and a single target re-derived from expected_gross_move_pct,
        # which discarded whatever exit plan the winning strategy had actually produced.
        # The assessment now carries the signal's own targets.
        targets = tuple(oa.targets)
        if not targets and intent.expected_gross_move_pct is not None:
            # A strategy that declares an expected move and no explicit target still gets
            # one, which is the behaviour the old code always applied. It is a fallback
            # now rather than the rule.
            t = intent.entry * (Decimal(1) + intent.expected_gross_move_pct) if intent.direction is Direction.LONG else intent.entry * (Decimal(1) - intent.expected_gross_move_pct)
            targets = (t,)
        try:
            # Refresh route truth at the decision instant so the registry cannot
            # age out while the session continues to run.
            self.routes.refresh(
                account_alias=cfg.account_alias, adapter_id=cfg.venue,
                contracts={cfg.symbol.upper(): cfg.contract}, now_ms=now_ms,
                source="decision_cycle",
            )
            execution_bucket = ExecutionBucket(
                broker=cfg.venue,
                account_alias=cfg.account_alias,
                symbol=cfg.symbol,
                session=state.session.value,
                volatility_bucket=state.regime.vol.value,
                event_proximity=state.event_window.value,
                direction=intent.direction.value,
            )
            policy_decision = self.execution_policy.select(
                candidate_id=intent.trade_intent_id,
                bucket=execution_bucket,
                event_state=state.event_window.value,
                entry_type=oa.entry_type,
            )
            rec = self.router.execute(
                intent, decision, self.mandate, now_ms=now_ms,
                stop_mode=StopMode.SOFTWARE if cfg.software_stops else StopMode.VENUE,
                targets=targets, time_in_force=cfg.time_in_force, entry_type=oa.entry_type,
                execution_policy_decision=policy_decision,
                market_reference=MarketReference(
                    last_price=state.features.close,
                    mark_age_ms=state.quote_age_ms,
                    max_mark_age_ms=cfg.max_quote_age_ms,
                ),
                liquidity=LiquidityView(),
            )
        except RouterError as exc:
            self._log(EventKind.SESSION, {"router_refused": str(exc)}, now_ms=now_ms, corr=intent.trade_intent_id)
            return CycleResult(state.as_of_ms, state.state_hash, "ROUTER_REFUSED", str(exc), decision.approved_size)
        if rec.status == "ACCEPTED" and rec.reject_reason == "PENDING" and rec.filled_qty == ZERO:
            # P1-TRADE-EXEC-004: a resting entry (an untriggered STOP, a LIMIT away from the
            # market) is not a position. It reserves its worst-case risk until it fills or
            # expires (_open_positions), and is excluded from venue reconciliation.
            self._entries[intent.trade_intent_id] = {
                "pending": True, "open": False, "entry": intent.entry, "stop": intent.stop,
                "direction": intent.direction, "strategy_id": intent.strategy_id, "cost_pct": cost,
                "decision_price": intent.entry, "quantity": ZERO, "pending_quantity": decision.approved_size,
                "broker_order_id": rec.broker_order_id, "broker_position_id": "", "opened_ms": now_ms,
                "targets": tuple(targets), "original_approved_risk_pct": decision.approved_risk_pct,
                "protective_stop_confirmed": False, "event_certified": bool(intent.is_event_certified),
                "execution_policy_applied": True, "regime": state.regime.trend.value,
                "session": state.session.value, "symbol": cfg.symbol,
                "opened_in_blackout": state.event_window.value in ("PRE_BLACKOUT", "POST_BLACKOUT"),
                "best_price": intent.entry, "worst_price": intent.entry,
                "event_window": state.event_window.value,
                # In memory only: the fill seals the thesis from the approval that admitted it.
                "_approval": (intent, decision, state, tuple(targets)),
            }
            self._log(EventKind.SESSION, {"event": "ENTRY_RESTING", "entry_type": oa.entry_type, "order": rec.broker_order_id},
                      now_ms=now_ms, corr=intent.trade_intent_id)
            return CycleResult(state.as_of_ms, state.state_hash, decision.decision.value, "pending", decision.approved_size)
        if rec.status in ("FILLED", "PARTIAL", "ACCEPTED", "OWNER_EXECUTED"):
            entry_price = rec.average_fill or intent.entry
            self._entries[intent.trade_intent_id] = {
                "entry": entry_price, "stop": intent.stop, "direction": intent.direction,
                "strategy_id": intent.strategy_id, "cost_pct": cost,
                "decision_price": intent.entry,
                "quantity": rec.filled_qty,
                "broker_position_id": rec.broker_position_id,
                "opened_ms": now_ms,
                "best_price": entry_price, "worst_price": entry_price,
                "original_approved_risk_pct": decision.approved_risk_pct,
                "protective_stop_confirmed": bool(
                    rec.protective_stop_confirmed or cfg.software_stops),
                "opened_in_blackout": state.event_window.value in (
                    "PRE_BLACKOUT", "POST_BLACKOUT"),
                "event_certified": bool(intent.is_event_certified),
                "execution_policy_applied": True,
                "regime": state.regime.trend.value,
                "session": state.session.value,
                "symbol": cfg.symbol,
            }
            self._seal_thesis(intent, decision, state, targets, entry_price, now_ms)
            self._record_tca(rec, intent.direction, cost, state.session.value, state.event_window.value, now_ms=now_ms)
        return CycleResult(state.as_of_ms, state.state_hash, decision.decision.value, "", decision.approved_size)

    # ------------------------------------------------- owner-signed recovery (A4)
    def reset_loss_streak(self, scope: str, *, owner_signature_ref: str, authority, now_ms: int) -> None:
        """Clear a losing-streak suspension. `scope` is a strategy id or ACCOUNT_SCOPE."""
        authority.verify(owner_signature_ref, act="loss-streak-reset", subject=f"{self.cfg.account_alias}:{scope}", now_unix=now_ms // 1000)
        self._log(EventKind.SESSION, {**self.streaks.reset(scope), "owner_signature_ref": owner_signature_ref}, now_ms=now_ms)

    def resume_after_drawdown(self, *, owner_signature_ref: str, authority, now_ms: int) -> None:
        """Owner decision to resume after the suspending drawdown tier: re-baseline the peak."""
        authority.verify(owner_signature_ref, act="drawdown-resume", subject=self.cfg.account_alias, now_unix=now_ms // 1000)
        equity = self.adapter.sync_account().equity
        old = self.peak_equity
        self.peak_equity = equity
        self._log(EventKind.SESSION, {"event": DRAWDOWN_RESUME_EVENT, "old_peak_equity": str(old), "new_peak_equity": str(equity),
                                      "owner_signature_ref": owner_signature_ref}, now_ms=now_ms)

    # ------------------------------------------------------- marks and exits
    def mark(self, bid: Decimal, ask: Decimal, *, now_ms: int) -> None:
        cfg = self.cfg
        # PROTECT stage. Thesis assessment runs before exits are applied, so an
        # invalidated claim is acted on in the same mark rather than waiting for
        # a stop that may be further away than the reason for holding.
        self._review_open_theses(bid, ask, now_ms=now_ms)
        receipts = list(self.router.apply_exits(cfg.venue, cfg.symbol, bid, ask, now_ms=now_ms))
        if hasattr(self.adapter, "mark"):
            receipts += self.adapter.mark(cfg.symbol, bid, ask, now_ms=now_ms)  # type: ignore[attr-defined]
        for r in receipts:
            row = self._entries.get(r.trade_intent_id)
            if row is not None and row.get("pending"):
                self._settle_pending(r, row, now_ms=now_ms)
                continue
            if r.status == "FILLED" and r.trade_intent_id in self._entries and r.reject_reason not in ("TRAIL", "BREAK_EVEN"):
                self._on_close(r.trade_intent_id, r.average_fill, r.reject_reason, now_ms)
                self.protection.forget(r.broker_position_id)

    def _record_tca(self, rec, direction, cost: Decimal, session: str, event_window: str, *, now_ms: int) -> None:
        cfg = self.cfg
        if rec.average_fill is None or rec.filled_qty <= ZERO:
            return
        tca = compute_tca(rec, direction=direction, qty=rec.filled_qty, value_per_unit=cfg.contract.value_per_price_unit_per_lot if cfg.contract.loss_model is LossModel.STOP_DISTANCE else Decimal(1), modelled_cost_pct=cost)
        tca_payload = tca.as_dict()
        if self.learning is not None:
            tca_payload |= {
                "learning_environment": self.learning.environment.value,
                "broker": self.learning.broker,
                "symbol": cfg.symbol,
                "session": session,
                "event_window": event_window,
                "rejected": False,
            }
        self._log(EventKind.TCA_RECORD, tca_payload, now_ms=now_ms, corr=rec.trade_intent_id)
        self._entries[rec.trade_intent_id]["cost_ratio"] = tca.cost_ratio
        if self.learning is not None:
            self.learning.on_tca(symbol=cfg.symbol, session=session, event_window=event_window, cost_ratio=tca.cost_ratio, slippage=tca.slippage)
            self.engine.m.broker_liquidity[cfg.symbol] = self.learning.broker_liquidity(cfg.symbol)

    def _settle_pending(self, r, row: dict, *, now_ms: int) -> None:
        """A resting entry filled (becomes a position) or expired (reserves nothing)."""
        self._log(EventKind.EXECUTION_RECEIPT, {k: (v.value if hasattr(v, "value") else v) for k, v in asdict(r).items()},
                  now_ms=now_ms, corr=r.trade_intent_id)
        if r.status == "FILLED" and r.reject_reason == "PENDING_FILLED":
            row.update({"pending": False, "open": True, "entry": r.average_fill, "quantity": r.filled_qty,
                        "broker_position_id": r.broker_position_id,
                        "protective_stop_confirmed": bool(r.protective_stop_confirmed or self.cfg.software_stops),
                        "best_price": r.average_fill, "worst_price": r.average_fill})
            if row.get("stop") is not None:
                self.router.protection.register(r.broker_position_id, symbol=self.cfg.symbol, direction=row["direction"], entry=r.average_fill,
                                                stop=row["stop"], target=row["targets"][0] if row.get("targets") else None, opened_ms=now_ms,
                                                software_stop=bool(self.cfg.software_stops))
            self._log(EventKind.SESSION, {"event": "ENTRY_FILLED_FROM_REST", "fill": str(r.average_fill), "position": r.broker_position_id},
                      now_ms=now_ms, corr=r.trade_intent_id)
            approval = row.pop("_approval", None)
            if approval is not None:
                intent, decision, state, targets = approval
                self._seal_thesis(intent, decision, state, targets, r.average_fill, now_ms)
            self._record_tca(r, row["direction"], row["cost_pct"], row["session"], row.get("event_window", ""), now_ms=now_ms)
        elif r.status in ("EXPIRED", "CANCELLED", "REJECTED"):
            self._entries.pop(r.trade_intent_id, None)
            self._log(EventKind.SESSION, {"event": "ENTRY_REST_ENDED", "status": r.status, "reason": r.reject_reason},
                      now_ms=now_ms, corr=r.trade_intent_id)

    # ------------------------------------------ active-trade intelligence
    def _seal_thesis(self, intent, decision, state, targets, entry_price: Decimal,
                     now_ms: int) -> None:
        """Seal the claim this position is making (GAP-F-003).

        Written once, at approval, and never edited afterwards
        (INV-REPLAY-001). It also fixes `original_approved_risk_pct`, the
        ceiling every later ADD is measured against.
        """
        if intent.stop is None:
            return
        capsule_data: dict = {}
        capsule_hash = ""
        try:
            capsule = self.engine.registry.get(intent.strategy_id)
            capsule_data, capsule_hash = dict(capsule.data), capsule.capsule_hash
        except Exception:  # noqa: BLE001 — a missing capsule is not a reason to skip
            pass
        spread_pct = getattr(state.features, "spread_percentile", None)
        try:
            self.thesis.seal(thesis_from_capsule(
                trade_intent_id=intent.trade_intent_id,
                symbol=self.cfg.symbol,
                strategy_id=intent.strategy_id,
                direction=intent.direction,
                capsule_hash=capsule_hash,
                market_state_hash=intent.market_snapshot_hash,
                entry=entry_price,
                original_stop=intent.stop,
                original_approved_risk_pct=decision.approved_risk_pct,
                created_ms=now_ms,
                capsule_data=capsule_data,
                expected_gross_move_pct=intent.expected_gross_move_pct,
                targets=tuple(targets),
                regime_label=state.regime.trend.value,
                entry_volatility=getattr(state.features, "atr", None),
                entry_liquidity=(None if spread_pct is None
                                 else Decimal("1") - Decimal(str(spread_pct))),
                event_sensitivity=(self.cfg.base, self.cfg.quote),
            ), now_ms=now_ms)
        except Exception as exc:  # noqa: BLE001 — a thesis fault never blocks a trade
            self._log(EventKind.SESSION,
                      {"event": "THESIS_NOT_SEALED", "error": str(exc)[:300]},
                      now_ms=now_ms, corr=intent.trade_intent_id)

    def _review_open_theses(self, bid: Decimal, ask: Decimal, *, now_ms: int) -> None:
        """Assess every open position's claim and act on what the policy allows."""
        for intent_id, row in list(self._entries.items()):
            if row.get("pending"):
                continue   # a resting entry is not a position yet
            thesis = self.thesis.thesis_for(intent_id)
            if thesis is None:
                continue
            direction = row["direction"]
            mark = bid if direction is Direction.LONG else ask
            row["best_price"] = (
                max(Decimal(str(row.get("best_price", mark))), mark)
                if direction is Direction.LONG
                else min(Decimal(str(row.get("best_price", mark))), mark))
            row["worst_price"] = (
                min(Decimal(str(row.get("worst_price", mark))), mark)
                if direction is Direction.LONG
                else max(Decimal(str(row.get("worst_price", mark))), mark))
            position_id = str(row.get("broker_position_id") or "")
            rule = self.protection.rules.get(position_id)
            current_stop = rule.stop if rule is not None else row.get("stop")
            try:
                health = self.trade_health.assess(PositionHealthInputs(
                    trade_intent_id=intent_id, symbol=self.cfg.symbol,
                    direction=direction,
                    entry_price=Decimal(str(row["entry"])),
                    current_price=mark,
                    original_stop=thesis.original_stop,
                    current_stop=(None if current_stop is None else Decimal(str(current_stop))),
                    has_confirmed_stop=bool(
                        row.get("protective_stop_confirmed")
                        or (rule is not None and rule.software_stop)),
                    opened_ms=int(row.get("opened_ms") or now_ms),
                    now_ms=now_ms,
                    expected_horizon_ms=int(row.get("expected_horizon_ms") or 0),
                    worst_price=Decimal(str(row["worst_price"])),
                    best_price=Decimal(str(row["best_price"])),
                    spread=max(ZERO, ask - bid),
                ))
            except Exception:  # noqa: BLE001 — health is advisory here; exits still run
                continue

            materiality, refs = ZERO, ()
            if self.news is not None:
                try:
                    impacts = self.news.assess_subject(
                        subject_kind="POSITION", subject_id=intent_id,
                        symbol=self.cfg.symbol, direction=direction.value, now_ms=now_ms)
                    materiality, refs = type(self.news).peak(impacts)
                except Exception:  # noqa: BLE001
                    materiality, refs = ZERO, ()

            confirmations: list[str] = []
            first_target = thesis.confirmation.get("first_target")
            if first_target is not None:
                level = Decimal(str(first_target))
                if (mark >= level if direction is Direction.LONG else mark <= level):
                    confirmations.append("first_target")

            assessment = self.thesis.assess(ThesisInputs(
                thesis=thesis, health=health, current_price=mark, now_ms=now_ms,
                current_stop=(None if current_stop is None else Decimal(str(current_stop))),
                adverse_present=tuple(
                    s for s in thesis.adverse_signals
                    if s.upper() in {r.upper() for r in health.reasons}),
                confirmations_met=tuple(confirmations),
                event_materiality=materiality, event_refs=refs,
            ))

            protection_be = (
                current_stop is not None
                and (Decimal(str(current_stop)) >= thesis.entry
                     if direction is Direction.LONG
                     else Decimal(str(current_stop)) <= thesis.entry))
            original_risk = row.get("original_approved_risk_pct")
            original_risk = None if original_risk is None else Decimal(str(original_risk))
            proposal = self.adjustments.propose(
                assessment, health=health,
                original_approved_risk_pct=original_risk,
                current_risk_pct=(ZERO if protection_be else (original_risk or ZERO)),
                protection_at_break_even=protection_be,
                scale_policy=self.scale_policies.policy_for(str(row.get("strategy_id") or "")),
                scale_ins_used=int(row.get("scale_ins_used", 0)),
                proposed_stop=(thesis.entry if not protection_be else None),
                now_ms=now_ms,
            )
            self.proposals.append(proposal)
            row["last_proposal"] = proposal.action.value
            # Only the two adjustments that cannot add exposure execute on this
            # runtime: the single-symbol cycle has no account-level snapshot to
            # put a delta intent through, and an add without RiskAuthority is
            # not an add this system is willing to make (INV-AUTH-001).
            if position_id and proposal.action is Adjustment.MOVE_PROTECTION \
                    and proposal.new_stop is not None:
                try:
                    self.router.apply_preservation(
                        self.cfg.venue, position_id=position_id,
                        trade_intent_id=intent_id, action="TIGHTEN_STOP",
                        now_ms=now_ms, new_stop=proposal.new_stop,
                        reason="THESIS_" + proposal.thesis_state)
                    row["stop"] = proposal.new_stop
                except Exception:  # noqa: BLE001 — a refused tighten leaves the stop as is
                    pass
            elif position_id and proposal.action is Adjustment.EXIT:
                try:
                    receipt = self.router.apply_preservation(
                        self.cfg.venue, position_id=position_id,
                        trade_intent_id=intent_id, action="FULL_CLOSE", now_ms=now_ms,
                        reason="THESIS_" + proposal.thesis_state)
                except Exception:  # noqa: BLE001
                    receipt = None
                if receipt is not None and receipt.status in (
                    "FILLED", "OWNER_EXECUTED", "BROKER_CONFIRMED"
                ):
                    self._on_close(intent_id, receipt.average_fill, "EXIT", now_ms)
                    self.protection.forget(position_id)

    def _classify_decision(self, intent_id: str, entry: dict, rv, now_ms: int):
        """Decision quality x outcome, and the lesson it teaches (GAP-F-003)."""
        thesis = self.thesis.thesis_for(intent_id)
        inputs = DecisionQualityInputs(
            trade_intent_id=intent_id,
            strategy_id=str(entry.get("strategy_id") or ""),
            thesis_sealed=thesis is not None,
            thesis_falsifiable=bool(thesis is not None and thesis.invalidation),
            approved_risk_pct=Decimal(str(entry.get("original_approved_risk_pct", ZERO) or ZERO)),
            mandate_max_risk_pct=self.mandate.max_risk_per_trade,
            protective_stop_confirmed=bool(entry.get("protective_stop_confirmed", True)),
            execution_policy_applied=bool(entry.get("execution_policy_applied", True)),
            cost_ratio=(None if entry.get("cost_ratio") is None
                        else Decimal(str(entry["cost_ratio"]))),
            opened_in_blackout=bool(entry.get("opened_in_blackout")),
            event_certified=bool(entry.get("event_certified")),
        )
        verdict = self.decision_quality.record(
            inputs, symbol=self.cfg.symbol, r_multiple=rv.r_multiple, now_ms=now_ms,
            evidence_refs=(rv.artifact_hash,) + ((thesis.seal,) if thesis else ()))
        if self.learning is not None:
            self.lessons.record(lesson_from_verdict(
                verdict, symbol=self.cfg.symbol,
                regime=str(entry.get("regime", "")), session=str(entry.get("session", "")),
                environment=self.learning.environment, now_ms=now_ms,
                evidence_refs=(rv.artifact_hash,)), now_ms=now_ms)
        self.thesis.forget(intent_id)
        return verdict

    def _on_close(self, intent_id: str, exit_price: Optional[Decimal], reason: str, now_ms: int) -> None:
        e = self._entries.pop(intent_id, None)
        if e is None or exit_price is None:
            return
        closed = getattr(self.adapter, "closed", None)
        pnl = ZERO
        if closed:
            for c in reversed(closed):
                if c["intent"] == intent_id:
                    pnl = c["pnl"]; break
        for lock_event in self.streaks.on_close(e["strategy_id"], pnl, now_ms):
            self._log(EventKind.SESSION, lock_event, now_ms=now_ms, corr=intent_id)
        self.consecutive_losses = self.streaks.verdict(e["strategy_id"], now_ms).losses
        rv = review_trade(trade_intent_id=intent_id, strategy_id=e["strategy_id"], entry=e["entry"], exit_price=exit_price, stop=e["stop"] or e["entry"], direction_long=e["direction"] is Direction.LONG,
                          pnl=pnl, thesis_correct=pnl > ZERO, process_ok=True, exit_reason=reason)
        self.reviews.append(rv)
        self._log(EventKind.TRADE_REVIEW, {k: (v.value if hasattr(v, "value") else (str(v) if isinstance(v, Decimal) else (list(v) if isinstance(v, tuple) else v))) for k, v in asdict(rv).items()}, now_ms=now_ms, corr=intent_id)
        self.admission.propose(rv.artifact_hash, knowledge_class="TRADE_EXPERIENCE", proposed_by=rv.proposed_by, trust_tier="T0_VAN_TRADING_POLICY")
        metrics.inc("vati_trades_closed_total", outcome=rv.outcome.value)
        verdict = None
        try:
            verdict = self._classify_decision(intent_id, e, rv, now_ms)
        except Exception as exc:  # noqa: BLE001 — classification never blocks a close
            self._log(EventKind.SESSION,
                      {"event": "DECISION_QUALITY_FAULT", "error": str(exc)[:300]},
                      now_ms=now_ms, corr=intent_id)
        if self.learning is not None:
            self._learn(intent_id, rv, e.get("cost_ratio", Decimal(1)), now_ms,
                        process_ok=(verdict is None or not verdict.faults))

    # ------------------------------------------------------------ learning
    def _learn(self, intent_id: str, rv, cost_ratio: Decimal, now_ms: int,
               *, process_ok: Optional[bool] = None) -> None:
        """Observe the closed trade; apply only LearningBoundary-checked, reduce-only effects.

        GAP-F-003. `process_ok` now carries the decision-quality verdict rather
        than the review's constant, and the quadrant multiplier is combined
        with `min` below — so a lucky bad decision reduces capsule health and
        an unlucky good one does not, while nothing here can raise it
        (INV-RISK-001).
        """
        assert self.learning is not None
        ep, adj = self.learning.on_review(self.ledger, trade_intent_id=intent_id, strategy_id=rv.strategy_id, r_multiple=rv.r_multiple,
                                          process_ok=(rv.process_ok if process_ok is None else process_ok), cost_ratio=cost_ratio)
        if ep is not None:
            self._log(EventKind.TRADE_EXPERIENCE_ARTIFACT, to_payload(ep), now_ms=now_ms, corr=intent_id)
            self.admission.propose(ep.artifact_hash, knowledge_class="TRADE_EXPERIENCE", proposed_by="vati-learning", trust_tier="T0_VAN_TRADING_POLICY")
        if adj is None:
            return
        self.engine.m.capsule_health[rv.strategy_id] = min(
            adj.multiplier, self.decision_quality.health_multiplier(rv.strategy_id))
        if adj.demote_to:
            cap = self.engine.registry.get(rv.strategy_id)
            # Live capsules step down to SHADOW (observe, no orders); pre-live capsules become DEGRADED (inactive).
            target = StrategyState.SHADOW if cap.state in (StrategyState.LIMITED_LIVE, StrategyState.CERTIFIED_LIVE) else StrategyState.DEGRADED
            if cap.state in ACTIVE_STATES and cap.state is not target:
                new = self.engine.registry.demote(rv.strategy_id, target, reason=f"learning health {adj.multiplier}: {'; '.join(self.learning.health.verdict(rv.strategy_id).reasons)}")
                self.learning.demotions.append((rv.strategy_id, target.value))
                self._log(EventKind.CAPSULE_STATE, {"strategy_id": rv.strategy_id, "from": cap.state.value, "to": target.value, "capsule_hash": new.capsule_hash, "supersedes": cap.capsule_hash,
                                                    "capsule": new.data, "by": "vati-learning", "authority": "AUTOMATIC_DEMOTION_ONLY"}, now_ms=now_ms, corr=intent_id)
                metrics.inc("vati_capsule_demotions_total", strategy=rv.strategy_id, to=target.value)
